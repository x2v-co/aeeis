#!/usr/bin/env node
import { createServer } from 'node:http';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';

const host = process.env.AEEIS_FIXTURE_MODEL_HOST ?? '127.0.0.1';
const port = Number(process.env.AEEIS_FIXTURE_MODEL_PORT ?? 4399);

function nextProposalVersion(baseVersion) {
  const [target, suffix] = baseVersion.split('/', 2);
  if (suffix && /^\d+$/.test(suffix)) {
    const numeric = Number(suffix);
    if (Number.isSafeInteger(numeric)) return `${target}/${numeric + 1}`;
  }
  return `${baseVersion}-next`;
}

function responseFor(system, input) {
  if (system.includes('governed AEEIS RSI proposal synthesizer')) {
    const versions = input?.targetVersions ?? {};
    const evidence = Array.isArray(input?.evidence) ? input.evidence.filter((item) => typeof item?.id === 'string') : [];
    const baseVersion = typeof versions.prompt === 'string' ? versions.prompt : 'prompt/1';
    if (evidence.length === 0) return { proposal: null };
    return {
      proposal: {
        target: 'prompt',
        baseVersion,
        proposedVersion: nextProposalVersion(baseVersion),
        change: 'Require every synthesized result to cite the supplied evidence before completion.',
        reason: 'The fixture received a bounded failure signal with evidence that supports a reversible prompt improvement.',
        risk: 'low',
        sourceReceiptRefs: [evidence[0].id],
      },
    };
  }
  if (system.includes('independent AEEIS competition evaluator')) {
    const candidates = Array.isArray(input.candidates) ? input.candidates : [];
    return {
      scores: candidates.map((candidate, index) => ({
        agentId: candidate.agentId,
        score: Math.max(0, 1 - index * 0.1),
        accepted: true,
        reasons: ['Deterministic Compose evaluator fixture accepted the bounded candidate envelope.'],
        evidenceRefs: [],
      })),
    };
  }
  // Bots that act on their own: a short reply, one proposal when asked to get something done (AEEIS splits a list), and a handoff
  // when another member is named after "交给". Handoff turns ask one question, then accept.
  if (system.includes('在团队群聊（或私聊）里回复一条消息')) {
    const text = String(input?.message?.text ?? '');
    const name = String(input?.you?.name ?? 'Bot');
    const roster = Array.isArray(input?.roster) ? input.roster.map(item => String(item.name)) : [];
    const target = roster.find(member => member !== name && member !== 'AEEIS' && text.includes(`交给${member}`));
    const wants = /写|整理|做|查|出一份|准备/.test(text);
    const title = text.replace(/@\S+\s*/g, '').replace(/交给\S+/g, '').replace(/[，。,.!！?？]+$/u, '').trim().slice(0, 40) || '跟进这件事';
    // AEEIS splits a list ("查竞品、整理风险、写说明") into tasks, dealt out to the other members in turn.
    const parts = title.replace(/^[^：:]*[：:]/u, '').split(/[、；;]/u).map(part => part.trim()).filter(part => part.length >= 2);
    const members = roster.filter(member => member !== 'AEEIS');
    if (input?.you?.frontDoor && wants && parts.length > 1 && members.length) {
      const tasks = parts.slice(0, 5).map((part, index) => ({ title: part.slice(0, 40), reason: '群里刚提到', for: members[index % members.length] }));
      return { reply: `${name}：拆成 ${tasks.length} 件：${tasks.map(task => `${task.for}做「${task.title}」`).join('，')}。`, tasks };
    }
    return {
      reply: wants ? `${name}：收到，我先记成一件事。` : `${name}：收到。`,
      ...(wants ? { proposeTask: { title, reason: '群里刚提到' } } : {}),
      ...(wants && target ? { handoff: { to: target, note: `${target}更合适` } } : {}),
    };
  }
  if (system.includes('在你们的侧线程里谈一件任务的交接')) {
    const said = Array.isArray(input?.transcript_untrusted) ? input.transcript_untrusted.length : 0;
    if (input?.you?.side === 'receiver') return said === 0 ? { decision: 'discuss', message: '什么时候要？' } : { decision: 'accept', message: '好，我接下。' };
    return { decision: 'discuss', message: '今天之内。' };
  }
  // Match the fillable-pdf contract guidance, not the generic fidelity sentence that
  // mentions fillable-pdf/1 on every executor and reviewer prompt.
  if (system.includes('Plan a real deliverable') && system.includes('This Run uses the fillable-pdf/1 contract')) {
    return { summary: 'Inspect and fill the supplied AcroForm using source evidence.', nodes: [{ id: 'fill_form', title: 'Fill form', instruction: 'Inspect the form, fill only sourced values, and report every unknown.', dependsOn: [] }] };
  }
  if (system.includes('Plan a real deliverable')) {
    return {
      summary: 'Local fixture plan: inspect the request, then deliver an evidence-linked result.',
      nodes: [
        { id: 'inspect', title: 'Inspect supplied material', instruction: 'Read the supplied material and extract the facts needed for the result.', dependsOn: [] },
        { id: 'deliver', title: 'Deliver evidence-linked result', instruction: 'Produce the requested result using the inspected facts and cite their evidence IDs.', dependsOn: ['inspect'] },
      ],
    };
  }
  if (system.includes('bounded participant in an AEEIS debate')) {
    return {
      type: 'position',
      content: `Compose debate position from ${input?.speakerAgentId ?? 'the participant'} for the bounded smoke task.`,
      claimRefs: [],
    };
  }
  if (system.includes('independent Moderator of an AEEIS debate')) {
    return { status: 'accepted', violations: [], missingClaimRefs: [] };
  }
  if (system.includes('independent Adjudicator of an AEEIS debate')) {
    return {
      status: 'held',
      decision: 'No evidence-bound decision is available in the fixture debate.',
      rationale: 'The fixture messages contain no claims and therefore cannot support a decision.',
      evidenceRefs: [],
    };
  }
  if (system.includes('Independently review')) {
    if (String(input?.goal ?? '').includes('RSI synthesis smoke')) {
      return { verdict: 'needs_revision', summary: 'The fixture intentionally emits a bounded low-confidence review to exercise RSI proposal synthesis.', issues: ['The controlled smoke run requires a reversible improvement proposal.'], confidence: 0.2 };
    }
    return { verdict: 'accepted', summary: 'Fixture review accepted the evidence-linked artifact.', issues: [] };
  }
  if (system.includes('task working-memory summarizer')) {
    const sliceId = input.slices?.[0]?.id;
    if (typeof sliceId !== 'string' || !sliceId) throw new Error('Fixture compaction response requires a supplied slice id');
    return { items: [{ text: 'MODEL GENERATED: ALPHA-FACT-ONLY remains unverified derived context and is not evidence.', references: [sliceId] }] };
  }

  if (system.includes('This Run uses the fillable-pdf/1 contract')) {
    const pdfSource = input.presentedSources?.find(source => source.format === 'pdf');
    const observations = input.observations ?? [];
    if (!observations.length) return { type: 'tool', tool: 'pdf.formFields', argument: pdfSource.id };
    const listing = observations.find(item => item.tool === 'pdf.formFields')?.result;
    const supplied = [];
    for (const source of input.presentedSources ?? []) {
      if (source.format !== 'json') continue;
      try { supplied.push({ id: source.id, values: JSON.parse(source.content.split('\n').slice(1, -1).join('\n')) }); } catch { /* Fixture only fills intact JSON records. */ }
    }
    const filled = observations.find(item => item.tool === 'pdf.fill')?.result;
    if (!filled) {
      if (listing.page?.nextRead) throw new Error('Fixture requires a small form');
      const fields = {};
      for (const field of listing.fields ?? []) {
        if (field.readOnly) continue;
        const evidence = supplied.find(source => Object.hasOwn(source.values, field.name));
        if (evidence) fields[field.name] = evidence.values[field.name];
      }
      return { type: 'tool', tool: 'pdf.fill', argument: pdfSource.id, fields, filename: 'registration-filled.pdf' };
    }
    const filledFields = filled.filledFields.map(field => ({ ...field, evidenceRefs: [supplied.find(source => Object.hasOwn(source.values, field.name)).id] }));
    return { type: 'finish', title: 'Filled PDF', content: 'Filled only source-supported form fields. Missing values remain empty; read-only fields remain untouched.', evidenceRefs: [pdfSource.id, ...supplied.map(source => source.id), filled.output.ref], artifactType: 'fillable-pdf/1', structured: {
      schemaVersion: 'fillable-pdf/1', form: filled.form, filledFields,
      unknowns: filled.unfilledFields.map(field => ({ field: field.name, text: field.readOnly ? 'Read-only; explicitly untouched.' : 'No source value; left empty.', evidenceRefs: [pdfSource.id, ...supplied.map(source => source.id)] })), output: filled.output, blockers: [],
    } };
  }

  const source = input.sourceCatalog?.[0];
  const dependency = input.dependencies?.[0];
  const answers = Array.isArray(input.answers) ? input.answers.filter((answer) => typeof answer?.answer === 'string' && answer.answer.trim()) : [];
  const catalogTools = Array.isArray(input.capabilityCatalog?.tools) ? input.capabilityCatalog.tools : [];
  const websiteRun = system.includes('website-builder/1');
  // A task named with "先问我" stops once to ask, so a demo can walk blocked → answered → delivered. Only the task's own
  // line counts: a Bot's Run goal also quotes the whole message and its sibling tasks.
  const goal = String(input.goal ?? '');
  if ((goal.match(/^任务：(.*)$/m)?.[1] ?? goal).includes('先问我') && input.task?.id === 'inspect' && !(input.observations?.length)) {
    if (!answers.length) return { type: 'question', question: '开始之前想先确认一下：这件事以哪个范围为准？' };
    return { type: 'finish', title: '按你的回答做完了', content: `按你的回答做完了：${answers.at(-1).answer.trim()}`, evidenceRefs: source?.id ? [source.id] : [] };
  }
  if (websiteRun && input.task?.id === 'inspect' && !(input.observations?.length)) {
    const globTool = catalogTools.find((tool) => tool?.id === 'glob');
    if (globTool) return { type: 'capability', toolId: globTool.id, toolVersion: String(globTool.version), input: { pattern: '**/*', limit: 100 }, purpose: 'Inspect the website workspace before changing files.' };
  }
  if (websiteRun && input.task?.id === 'inspect' && input.observations?.length) {
    const observation = input.observations.at(-1)?.result ?? {};
    const evidenceRefs = Array.isArray(observation.outputRefs) ? observation.outputRefs.filter(Boolean) : [];
    return { type: 'finish', title: 'Website workspace inspected', content: 'Inspected the website workspace with the approved glob tool.', evidenceRefs };
  }
  if (websiteRun && input.task?.id !== 'inspect') {
    const observations = input.observations ?? [];
    const evidenceRefs = observations.flatMap((item) => Array.isArray(item?.result?.outputRefs) ? item.result.outputRefs : []).filter(Boolean);
    if (observations.length === 0) {
      const writeTool = catalogTools.find((tool) => tool?.id === 'write');
      if (writeTool) return { type: 'capability', toolId: writeTool.id, toolVersion: String(writeTool.version), input: { path: 'src/App.tsx', content: '<main><h1>AEEIS website smoke</h1></main>\n' }, purpose: 'Apply the requested website change in the Run workspace.' };
    }
    if (observations.length === 1) {
      const shellTool = catalogTools.find((tool) => tool?.id === 'shell');
      if (shellTool) return { type: 'capability', toolId: shellTool.id, toolVersion: String(shellTool.version), input: { command: 'test -f src/App.tsx && mkdir -p artifacts && cp src/App.tsx artifacts/site.html && test -s artifacts/site.html' }, purpose: 'Build and validate the website artifact.' };
    }
    if (observations.length === 2) {
      const processTool = catalogTools.find((tool) => tool?.id === 'process');
      if (processTool) return { type: 'capability', toolId: processTool.id, toolVersion: String(processTool.version), input: { action: 'start', command: 'python3 -m http.server 3000 --bind 0.0.0.0' }, purpose: 'Start the website preview process.' };
    }
    if (observations.length === 3) {
      const processTool = catalogTools.find((tool) => tool?.id === 'process');
      if (processTool) return { type: 'capability', toolId: processTool.id, toolVersion: String(processTool.version), input: { action: 'ports' }, purpose: 'Verify the website preview port is published.' };
    }
    const dependencyRef = input.dependencies?.[0]?.id;
    const refs = [...new Set([...evidenceRefs, dependencyRef].filter(Boolean))];
    const portOutput = observations.at(-1)?.result?.output;
    const binding = typeof portOutput?.bindings === 'string' ? portOutput.bindings : '';
    const hostPort = binding.match(/127\.0\.0\.1:(\d+)/)?.[1] ?? binding.match(/0\.0\.0\.0:(\d+)/)?.[1];
    const previewUrl = hostPort ? `http://127.0.0.1:${hostPort}` : undefined;
    return { type: 'finish', title: 'Website build and preview', content: 'Applied a website change, produced an artifact, validated it and started the preview process.', evidenceRefs: refs, artifactType: 'website-builder/1', structured: {
      schemaVersion: 'website-builder/1', changedFiles: ['src/App.tsx'], preview: { ...(previewUrl ? { url: previewUrl } : {}), status: previewUrl ? 'ready' : 'unknown', evidenceRefs: refs.slice(-1) },
      validation: [{ name: 'artifact-build', status: 'passed', evidenceRefs: refs.slice(-1) }], artifacts: [{ path: 'artifacts/site.html', kind: 'html', evidenceRefs: refs.slice(-1) }], blockers: [], unknowns: [],
    } };
  }
  const webTool = input.task?.id === 'inspect' && !(input.observations?.length)
    ? catalogTools.find((tool) => tool?.id === (String(input.goal ?? '').match(/https?:\/\//) ? 'web-fetch' : 'web-search'))
    : undefined;
  if (webTool) {
    const argument = webTool.id === 'web-fetch'
      ? String(input.goal).match(/https?:\/\/[^\s]+/)?.[0] ?? 'https://example.com'
      : String(input.goal ?? 'web search');
    return { type: 'capability', toolId: webTool.id, toolVersion: String(webTool.version), input: { input: argument }, purpose: `Use the authorized ${webTool.id} tool for the requested evidence.` };
  }
  if (input.task && input.observations?.length && catalogTools.some((tool) => tool?.id === 'web-search' || tool?.id === 'web-fetch')) {
    const observation = input.observations.at(-1)?.result ?? {};
    const evidenceRefs = Array.isArray(observation.outputRefs) ? observation.outputRefs.filter(Boolean) : [];
    const output = observation.output && typeof observation.output === 'object' ? observation.output : undefined;
    const summary = typeof output?.summary === 'string' ? output.summary : typeof output?.text === 'string' ? output.text : JSON.stringify(output ?? {}, null, 2);
    return { type: 'finish', title: 'Web tool result', content: `已通过授权的 web-fetch 获取资料。\n\n${summary}`.slice(0, 30000), evidenceRefs };
  }
  if (input.task?.id !== 'inspect' && dependency?.content && !system.includes('Project Pulse')) {
    return { type: 'finish', title: '基于网页资料的交付', content: `已使用 inspect 任务取得的网页资料生成交付。\n\n${dependency.content}`.slice(0, 30000), evidenceRefs: [dependency.id] };
  }
  const fixtureAgent = input.capabilityCatalog?.agents?.find((agent) => agent.agentId === 'agent.fixture');
  // Delegate only the inspection task. Subsequent tasks should consume the
  // completed delegation as a dependency instead of spending another call.
  if (fixtureAgent && input.task?.id === 'inspect' && !(input.observations?.length)) {
    return { type: 'delegate', agentId: 'agent.fixture', goal: 'Return a bounded evidence-linked research result', expectedOutput: 'research/1' };
  }
  if (fixtureAgent && input.task && input.observations?.length) {
    const observation = input.observations.at(-1)?.result ?? {};
    const evidenceRefs = [observation.receiptRef, ...(observation.result?.claims ?? []).flatMap((claim) => claim.evidenceRefs ?? [])].filter(Boolean);
    return { type: 'finish', title: 'External Agent result', content: 'Completed the result using the admitted external Agent.', evidenceRefs };
  }
  const workspaceGlob = String(input.goal ?? '').includes('工作区') && input.task?.id === 'inspect'
    ? catalogTools.find((tool) => tool?.id === 'glob')
    : undefined;
  if (workspaceGlob && !(input.observations?.length)) {
    return { type: 'capability', toolId: workspaceGlob.id, toolVersion: String(workspaceGlob.version), input: { pattern: '**/*', limit: 20 }, purpose: 'Look through this Run workspace.' };
  }
  if (workspaceGlob && input.observations?.length) {
    const observation = input.observations.at(-1)?.result ?? {};
    const evidenceRefs = Array.isArray(observation.outputRefs) ? observation.outputRefs.filter(Boolean) : [];
    return { type: 'finish', title: '工作区已看过', content: '已在这件工作的机器里看过工作区。', evidenceRefs };
  }
  if (String(input.goal ?? '').includes('WORKING-MEMORY-COMPACTION') && input.task?.id === 'inspect') {
    const catalog = Array.isArray(input.sourceCatalog) ? input.sourceCatalog : [];
    const alpha = catalog.find((item) => String(item?.title ?? '').includes('任务甲原文')) ?? catalog[0];
    const observations = input.observations ?? [];
    if (observations.length < 2 && alpha?.id) {
      return { type: 'tool', tool: 'sources.read', argument: alpha.id, ...(observations.length === 1 ? { characterOffset: 1 } : {}) };
    }
  }
  if (input.task?.id === 'inspect' && !(input.observations?.length)) {
    if (source?.id) return { type: 'tool', tool: 'sources.read', argument: source.id };
    if (answers.length) {
      const answer = answers.at(-1).answer.trim();
      return { type: 'finish', title: '已收到补充信息', content: `已使用你补充的信息继续处理：${answer}`, evidenceRefs: [] };
    }
    return { type: 'question', question: '请提供可核验的资料或允许访问天气数据的工具。当前任务没有可用证据来源。' };
  }
  return {
    type: 'finish',
    title: input.task?.id === 'inspect'
      ? 'Inspected source facts'
      : answers.length && !source?.id
        ? '固定模型执行回执'
        : 'Evidence-linked deliverable',
    content: input.task?.id === 'inspect'
      ? `Inspected the supplied source: ${source?.title ?? 'source material'}.`
      : answers.length && !source?.id
        ? `已收到补充信息：${answers.at(-1).answer.trim()}\n\n验证结果：当前使用的本地固定模型不会访问外部 URL 或天气服务，因此本次只验证了 AEEIS 的规划、执行和交付协议，没有生成可核验的真实天气报告。`
        : 'Completed the requested result from the inspected task and supplied source material.',
    evidenceRefs: dependency?.id ? [dependency.id] : source?.id ? [source.id] : [],
    ...(system.includes('Project Pulse') && input.task?.id !== 'inspect' ? {
      artifactType: 'project-pulse/1',
      structured: (() => {
        const evidenceRef = dependency?.id ?? source?.id;
        const item = evidenceRef ? [{ text: 'The fixture observed a release snapshot and produced an evidence-linked next step.', evidenceRefs: [evidenceRef] }] : [];
        return {
          schemaVersion: 'project-pulse/1',
          progress: item,
          completedChanges: [],
          blockers: [],
          risks: [],
          decisions: [],
          owners: [],
          deadlines: [],
          nextActions: evidenceRef ? [{ text: 'Review the release verification report before production rollout.', evidenceRefs: [evidenceRef] }] : [],
          unknowns: [],
        };
      })(),
    } : {}),
  };
}

export function createFixtureModelServer() {
  return createServer(async (request, response) => {
    if (request.method === 'GET' && request.url === '/health') {
      response.writeHead(200, { 'content-type': 'application/json' });
      response.end(JSON.stringify({ ok: true, mode: 'development-fixture' }));
      return;
    }
    if (request.method !== 'POST' || request.url !== '/v1/chat/completions') {
      response.writeHead(404); response.end(); return;
    }

    let body = '';
    for await (const chunk of request) body += chunk;
    try {
      const parsed = JSON.parse(body);
      const messages = Array.isArray(parsed.messages) ? parsed.messages : [];
      const system = String(messages.find((item) => item?.role === 'system')?.content ?? '');
      const rawInput = messages.find((item) => item?.role === 'user')?.content ?? '{}';
      if (system.includes('你在给一位新的 Bot 写背景')) {
        const role = String(rawInput).trim().slice(0, 120);
        const value = { background: role ? `负责${role}。自己不代替人做决定。` : '先写下角色定位。' };
        response.writeHead(200, { 'content-type': 'application/json' });
        response.end(JSON.stringify({
          id: `fixture-${Date.now()}`,
          object: 'chat.completion',
          choices: [{ index: 0, message: { role: 'assistant', content: JSON.stringify(value) }, finish_reason: 'stop' }],
          usage: { prompt_tokens: 1, completion_tokens: 1 },
        }));
        return;
      }
      const input = JSON.parse(String(rawInput));
      const value = responseFor(system, input);
      const compactionDelay = Number(process.env.AEEIS_FIXTURE_COMPACTION_DELAY_MS ?? 0);
      if (system.includes('task working-memory summarizer') && Number.isFinite(compactionDelay) && compactionDelay > 0) {
        await new Promise(resolve => setTimeout(resolve, Math.min(compactionDelay, 15_000)));
      }
      response.writeHead(200, { 'content-type': 'application/json' });
      response.end(JSON.stringify({
        id: `fixture-${Date.now()}`,
        object: 'chat.completion',
        choices: [{ index: 0, message: { role: 'assistant', content: JSON.stringify(value) }, finish_reason: 'stop' }],
        usage: { prompt_tokens: 1, completion_tokens: 1 },
      }));
    } catch (error) {
      console.error('fixture model request failed', error instanceof Error ? error.stack : String(error));
      response.writeHead(400, { 'content-type': 'application/json' });
      response.end(JSON.stringify({ error: { message: 'fixture model received invalid JSON' } }));
    }
  });
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  const server = createFixtureModelServer();
  server.listen(port, host, () => {
    console.log(`AEEIS development fixture model listening at http://${host}:${server.address().port}/v1`);
  });

  function shutdown(signal) {
    server.close(() => { console.log(`Fixture model stopped (${signal})`); process.exit(0); });
  }
  process.once('SIGINT', () => shutdown('SIGINT'));
  process.once('SIGTERM', () => shutdown('SIGTERM'));
}
