const baseUrl = (process.env.AEEIS_BASE_URL ?? 'http://127.0.0.1:4323').replace(/\/$/, '');
const timeoutMs = Number(process.env.AEEIS_SMOKE_TIMEOUT_MS ?? 120_000);
const startedAt = Date.now();

async function request(path, init = {}) {
  const response = await fetch(`${baseUrl}${path}`, {
    ...init,
    headers: { 'content-type': 'application/json', ...(init.headers ?? {}) },
  });
  const text = await response.text();
  let body;
  try { body = JSON.parse(text); } catch { body = text; }
  if (!response.ok) throw new Error(`${response.status} ${path}: ${text}`);
  return body;
}

function assertWithinTimeout() {
  if (Date.now() - startedAt > timeoutMs) throw new Error(`full local smoke test timed out after ${timeoutMs}ms`);
}

async function waitForReady() {
  while (true) {
    assertWithinTimeout();
    let readiness;
    try {
      readiness = await request('/readyz');
    } catch {
      // full local services may still be starting. The bounded loop is the timeout.
      await new Promise(resolve => setTimeout(resolve, 500));
      continue;
    }
    if (readiness.protocol && readiness.protocol !== 'aeeis-readiness/1') {
      throw new Error(`AEEIS_BASE_URL returned ${readiness.protocol}; expected aeeis-readiness/1`);
    }
    if (readiness.protocol === 'aeeis-readiness/1' && readiness.status === 'ready') return readiness;
    await new Promise(resolve => setTimeout(resolve, 500));
  }
}

const readiness = await waitForReady();
const health = await request('/health');
if (health.service !== 'aeeis-agent' || health.protocol !== 'aeeis-health/1') {
  throw new Error(`full local smoke target is not an AEEIS API (check AEEIS_BASE_URL; got ${JSON.stringify(health)})`);
}
const status = await request('/api/status');
if (status.runner !== 'LocalDispatcher' || status.dispatcherHealth?.ready !== true) {
  throw new Error(`Full local smoke requires LocalDispatcher readiness, got ${JSON.stringify({ runner: status.runner, dispatcherHealth: status.dispatcherHealth })}`);
}
if (status.modelRouting !== 'catalog' || !String(status.modelHealth?.detail ?? '').includes('catalog selected compose-fixture/aeeis-fixture/1')) {
  throw new Error(`full local smoke requires Planprice catalog routing, got ${JSON.stringify({ modelRouting: status.modelRouting, modelHealth: status.modelHealth })}`);
}
if (status.executionProfile !== 'fixture') throw new Error('full local must identify itself as a fixture demonstration');
if (status.skillGovernanceConfigured !== true || status.skillGovernanceHealth?.ready !== true || status.rsiProposalSynthesisConfigured !== true) {
  throw new Error(`full local smoke requires OwnHow health and RSI proposal synthesis wiring, got ${JSON.stringify({ skillGovernanceConfigured: status.skillGovernanceConfigured, skillGovernanceHealth: status.skillGovernanceHealth, rsiProposalSynthesisConfigured: status.rsiProposalSynthesisConfigured })}`);
}

// Exercise the actual RSI discovery loop. The fixture reviewer intentionally
// emits one bounded low-confidence result for this goal; the background pump
// must synthesize an evidence-bound candidate before any human approval gate.
const synthesisRunRef = await request('/api/runs', {
  method: 'POST',
  body: JSON.stringify({
    goal: 'RSI synthesis smoke: turn a bounded review signal into a proposal',
    materials: [{ title: 'RSI smoke evidence', source: 'full-local-rsi', content: 'The controlled review signal is evidence for this development smoke.' }],
  }),
});
const synthesisRun = await approveRun(synthesisRunRef.id);
if (synthesisRun.status !== 'failed') throw new Error(`Expected controlled RSI synthesis run to fail review, got ${JSON.stringify(synthesisRun)}`);
let synthesizedSignal;
while (true) {
  assertWithinTimeout();
  const signals = await request('/api/evolution/signals?limit=100');
  synthesizedSignal = signals.find((signal) => signal.runId === synthesisRun.id && signal.synthesis?.state === 'completed' && signal.candidateId);
  if (synthesizedSignal) break;
  await new Promise(resolve => setTimeout(resolve, 500));
}
const synthesizedCandidate = await request(`/api/evolution/candidates/${synthesizedSignal.candidateId}`);
if (synthesizedCandidate.status !== 'proposed' || synthesizedCandidate.target !== 'prompt') {
  throw new Error(`Expected an evidence-bound synthesized RSI candidate, got ${JSON.stringify(synthesizedCandidate)}`);
}

// Local mode uses the in-process reminder pump; reminder timer durability is
// covered by the dedicated Compose smoke.
// Verify a durable external trigger can create and run a blind Competition
// through the configured cross-container model pool. The fixture model only
// proves the protocol, attempt lifecycle, and idempotency boundary.
const triggerPolicy = await request('/api/collaborations/triggers/policies', {
  method: 'POST',
  body: JSON.stringify({
    id: `policy.full-local.${Date.now()}`,
    name: 'full local trigger competition',
    enabled: true,
    eventTypes: ['review.completed'],
    sources: ['system'],
    riskAtLeast: 'high',
    reviewConfidenceAtMost: 0.5,
    requiredDiversityAtLeast: 2,
    action: {
      type: 'competition',
      participantAgentIds: ['agent.one', 'agent.two'],
      evaluatorAgentId: 'agent.evaluator',
      expectedResultType: 'plan/1',
      maxRounds: 1,
      blindEvaluation: true,
      dispatch: 'run',
    },
  }),
});
const triggerEvent = {
  eventId: `review:full-local:${Date.now()}`,
  eventType: 'review.completed',
  source: 'system',
  taskId: 'task.full-local.trigger',
  contextVersion: 'ctx.full-local.trigger',
  goal: 'Choose the bounded full local smoke result',
  risk: 'high',
  reviewConfidence: 0.2,
  requiredDiversity: 2,
  allowedAgentIds: ['agent.one', 'agent.two'],
  occurredAt: new Date().toISOString(),
};
const triggered = await request('/api/collaborations/triggers/evaluate', { method: 'POST', body: JSON.stringify(triggerEvent) });
const triggerResult = triggered.find((item) => item.policyId === triggerPolicy.id);
if (!triggerResult?.created || triggerResult.decision.dispatchState !== 'completed' || !triggerResult.decision.resourceId) {
  throw new Error(`Expected trigger dispatch to complete, got ${JSON.stringify(triggered)}`);
}
const triggerDuplicate = await request('/api/collaborations/triggers/evaluate', { method: 'POST', body: JSON.stringify(triggerEvent) });
const triggerDuplicateForPolicy = triggerDuplicate.find((item) => item.policyId === triggerPolicy.id);
if (!triggerDuplicateForPolicy || triggerDuplicateForPolicy.created !== false || triggerDuplicateForPolicy.decision.resourceId !== triggerResult.decision.resourceId) {
  throw new Error(`Expected trigger event idempotency, got ${JSON.stringify(triggerDuplicate)}`);
}
const triggeredCompetition = await request(`/api/collaborations/competitions/${triggerResult.decision.resourceId}`);
if (triggeredCompetition.status !== 'completed' || triggeredCompetition.candidates?.length !== 2 || triggeredCompetition.scores?.length !== 2 || !triggeredCompetition.selectedAgentId) {
  throw new Error(`Expected completed triggered Competition, got ${JSON.stringify(triggeredCompetition)}`);
}

const debatePolicy = await request('/api/collaborations/triggers/policies', {
  method: 'POST',
  body: JSON.stringify({
    id: `policy.full-local.debate.${Date.now()}`,
    name: 'full local trigger debate',
    enabled: true,
    eventTypes: ['task.failed'],
    sources: ['system'],
    riskAtLeast: 'high',
    action: {
      type: 'debate',
      participantAgentIds: ['agent.one', 'agent.two'],
      maxRounds: 1,
      maxMessagesPerAgent: 1,
      maxTotalMessages: 2,
      dispatch: 'run',
    },
  }),
});
const debateEvent = {
  eventId: `task:full-local-debate:${Date.now()}`,
  eventType: 'task.failed',
  source: 'system',
  taskId: 'task.full-local.debate',
  contextVersion: 'ctx.full-local.debate',
  goal: 'Debate the bounded recovery response',
  risk: 'high',
  occurredAt: new Date().toISOString(),
};
const debated = await request('/api/collaborations/triggers/evaluate', { method: 'POST', body: JSON.stringify(debateEvent) });
const debateResult = debated.find((item) => item.policyId === debatePolicy.id);
if (!debateResult?.created || debateResult.decision.dispatchState !== 'completed' || !debateResult.decision.resourceId) {
  throw new Error(`Expected trigger Debate dispatch to complete, got ${JSON.stringify(debated)}`);
}
const debateDuplicate = await request('/api/collaborations/triggers/evaluate', { method: 'POST', body: JSON.stringify(debateEvent) });
const debateDuplicateForPolicy = debateDuplicate.find((item) => item.policyId === debatePolicy.id);
if (!debateDuplicateForPolicy || debateDuplicateForPolicy.created !== false || debateDuplicateForPolicy.decision.resourceId !== debateResult.decision.resourceId) {
  throw new Error(`Expected Debate trigger event idempotency, got ${JSON.stringify(debateDuplicate)}`);
}
const triggeredDebate = await request(`/api/collaborations/debates/${debateResult.decision.resourceId}`);
if (triggeredDebate.status !== 'closed' || triggeredDebate.room?.messages?.length !== 2 || triggeredDebate.room?.adjudication?.status !== 'held' || triggeredDebate.attempts?.some((attempt) => attempt.state !== 'completed')) {
  throw new Error(`Expected closed triggered Debate with settled role attempts, got ${JSON.stringify(triggeredDebate)}`);
}
const goal = await request('/api/goals', {
  method: 'POST',
  body: JSON.stringify({ title: `full local smoke ${new Date().toISOString()}` }),
});
const plan = await request(`/api/goals/${goal.id}/plans`, {
  method: 'POST',
  body: JSON.stringify({ nodes: [
    { id: 'inspect', title: 'Inspect smoke evidence', instruction: 'Inspect the full local smoke evidence.' },
    { id: 'deliver', title: 'Deliver smoke result', instruction: 'Deliver the verified full local smoke result.', dependsOn: ['inspect'] },
  ] }),
});

const scheduled = await request(`/api/plans/${plan.id}/schedule`, { method: 'POST', body: JSON.stringify({
  materials: [{ title: 'Smoke source', source: 'full-local-fixture', content: 'AEEIS full local smoke evidence.' }],
}) });
const firstDispatch = scheduled.dispatches?.find(item => item.taskId === 'inspect');
if (!firstDispatch?.runId || firstDispatch.state !== 'dispatched') {
  throw new Error(`Expected first DAG dispatch, got ${JSON.stringify(scheduled)}`);
}

async function waitForRun(runId, statuses, { allowQueuedReservation = false } = {}) {
  let current;
  while (true) {
    assertWithinTimeout();
    try {
      current = await request(`/api/runs/${runId}`);
    } catch (error) {
      if (!allowQueuedReservation || !(error instanceof Error) || !error.message.startsWith(`404 /api/runs/${runId}:`)) throw error;
      await new Promise(resolve => setTimeout(resolve, 100));
      continue;
    }
    if (statuses.includes(current.status)) return current;
    await new Promise(resolve => setTimeout(resolve, 500));
  }
}

const maxActionApprovals = Number(process.env.AEEIS_SMOKE_MAX_ACTION_APPROVALS ?? 20);

function describeWait(run) {
  if (!run) return 'no Run read yet';
  const action = run.actionApproval;
  return JSON.stringify({
    status: run.status,
    planVersion: run.plans?.at(-1)?.version,
    planApproved: run.approval?.approved === true && run.approval?.planHash === run.plans?.at(-1)?.hash,
    ...(action ? { actionApproval: { status: action.status, kind: action.kind, ref: action.ref, taskId: action.taskId } } : {}),
    ...(run.error ? { error: run.error } : {}),
    ...(run.question ? { question: run.question.text } : {}),
    recentEvents: (run.events ?? []).slice(-5).map(item => ({ type: item.type, ...(item.data?.failure ? { failure: item.data.failure } : {}), ...(item.data?.reason ? { reason: item.data.reason } : {}) })),
  });
}

/** Approve the plan, then every action the Run stops on (write@3 and other tools ask step by step since #124),
 * until it finishes. The decision is "once" so the smoke never widens the owner's standing policy. */
async function approveRun(runId, options = {}) {
  const terminal = ['succeeded', 'failed', 'cancelled'];
  const first = await waitForRun(runId, ['needs_approval', ...terminal], options);
  if (first.status !== 'needs_approval') throw new Error(`Expected ${runId} to need approval, got ${first.status}: ${first.error ?? 'no error'}`);
  const approvedPlans = new Set();
  const approvedActions = [];
  let run = first;
  while (true) {
    if (terminal.includes(run.status)) return run;
    // These states wait for a person or a reconcile, not for an approval; polling would only run out the clock.
    if (['unknown', 'needs_input', 'paused'].includes(run.status)) {
      throw new Error(`Run ${runId} stopped in ${run.status} after ${approvedPlans.size} plan approval(s) and ${approvedActions.length} action approval(s); the smoke cannot resolve it: ${describeWait(run)}`);
    }
    if (Date.now() - startedAt > timeoutMs) {
      throw new Error(`full local smoke timed out after ${timeoutMs}ms approving ${runId}; approved ${approvedPlans.size} plan(s) and ${approvedActions.length} action(s) [${approvedActions.join(', ')}]; last state ${describeWait(run)}`);
    }
    const plan = run.plans?.at(-1);
    const action = run.actionApproval;
    if (run.status === 'needs_approval' && action?.status === 'pending' && !approvedActions.includes(action.idempotencyKey)) {
      if (approvedActions.length >= maxActionApprovals) {
        throw new Error(`Run ${runId} asked for more than ${maxActionApprovals} action approvals; last pending ${action.kind} ${action.ref} (task ${action.taskId}). Raise AEEIS_SMOKE_MAX_ACTION_APPROVALS if this is expected.`);
      }
      try {
        await request(`/api/runs/${runId}/approve-action`, { method: 'POST', body: JSON.stringify({ idempotencyKey: action.idempotencyKey, decision: 'once' }) });
      } catch (error) {
        throw new Error(`Approving action ${action.kind} ${action.ref} (task ${action.taskId}) on ${runId} failed: ${error instanceof Error ? error.message : String(error)}`);
      }
      approvedActions.push(action.idempotencyKey);
      console.log(`[smoke] ${runId}: approved action ${action.kind} ${action.ref} (task ${action.taskId}) once`);
    } else if (run.status === 'needs_approval' && action?.status !== 'pending' && action?.status !== 'judging' && plan?.hash && !approvedPlans.has(plan.hash)) {
      try {
        await request(`/api/runs/${runId}/approve`, { method: 'POST', body: JSON.stringify({ planHash: plan.hash, planVersion: plan.version }) });
      } catch (error) {
        throw new Error(`Approving plan v${plan.version} on ${runId} failed: ${error instanceof Error ? error.message : String(error)}`);
      }
      approvedPlans.add(plan.hash);
    } else if (run.status === 'needs_approval' && !plan?.hash && action?.status !== 'pending' && action?.status !== 'judging') {
      throw new Error(`Run ${runId} needs approval but has neither an approvable plan hash nor a pending action: ${describeWait(run)}`);
    }
    await new Promise(resolve => setTimeout(resolve, 250));
    try {
      run = await request(`/api/runs/${runId}`);
    } catch (error) {
      throw new Error(`Reading ${runId} while approving failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
}

// Exercise the complete website-builder resource path through the catalog
// routed model, OwnHow Skill governance, persistent sandbox tools and the
// structured AEEIS artifact contract. This is the cross-module acceptance
// gate for the resource versioning design.
const websiteRunRef = await request('/api/runs', {
  method: 'POST',
  body: JSON.stringify({
    goal: 'website-builder smoke: update the landing page and verify the preview',
    builtinSkill: 'website-builder/1',
    skillRuntime: 'codex',
    resources: {
      plugin: { id: 'aeeis.website-builder', version: '1.0.0', interface: 'aeeis.website-builder/1', digest: 'a'.repeat(64), channel: 'stable' },
      workflow: { id: 'website-build', version: '1.2.0', interface: 'website-build/1', digest: 'b'.repeat(64), channel: 'canary' },
    },
    materials: [{ title: 'Website smoke request', source: 'full-local-website-builder', content: 'The landing page should contain the AEEIS smoke heading.' }],
    allowedTools: ['glob@3', 'write@3', 'shell@3', 'process@3'],
    externalBudget: { calls: 5 },
  }),
});
const websiteRun = await approveRun(websiteRunRef.id);
const websiteArtifact = websiteRun.artifacts?.find((item) => item.artifactType === 'website-builder/1');
const websiteSnapshot = websiteRun.resourceSnapshot;
if (websiteRun.status !== 'succeeded' || websiteRun.review?.verdict !== 'accepted' || !websiteArtifact?.structured
  || websiteArtifact.structured.schemaVersion !== 'website-builder/1' || websiteArtifact.structured.changedFiles?.length !== 1
  || websiteArtifact.structured.preview?.status !== 'ready' || !websiteArtifact.structured.preview?.url || !websiteArtifact.structured.validation?.some((item) => item.status === 'passed')
  || !websiteArtifact.structured.artifacts?.some((item) => item.path === 'artifacts/site.html')
  || !websiteRun.toolReceipts?.some((receipt) => receipt.operation === 'glob')
  || !websiteRun.toolReceipts?.some((receipt) => receipt.operation === 'write')
  || !websiteRun.toolReceipts?.some((receipt) => receipt.operation === 'shell')
  || !websiteRun.toolReceipts?.some((receipt) => receipt.operation === 'process')
  || websiteSnapshot?.plugin?.interface !== 'aeeis.website-builder/1' || websiteSnapshot?.workflow?.interface !== 'website-build/1'
  || websiteSnapshot?.skill?.interface !== 'website-builder/1' || websiteSnapshot?.registryRevision !== 'full-local-1'
  || !websiteSnapshot?.lockfileDigest || !websiteSnapshot?.policyDigest) {
  throw new Error(`Expected a completed cross-module website-builder Run, got ${JSON.stringify({ status: websiteRun.status, error: websiteRun.error, artifact: websiteArtifact, resources: websiteSnapshot, receipts: websiteRun.toolReceipts })}`);
}
const previewResponse = await fetch(websiteArtifact.structured.preview.url, { signal: AbortSignal.timeout(10_000) });
if (!previewResponse.ok) throw new Error(`Expected website preview HTTP probe to succeed, got ${previewResponse.status}`);

// Verify the configured File project-source connector is part of the real
// full local path. The first run reads the configured source snapshot (or resumes
// an existing durable snapshot when smoke is rerun against a persistent DB),
// creates an evidence-bound Project Pulse artifact, and projects its next
// action into a successor Plan.
const pulseGoal = await request('/api/goals', {
  method: 'POST',
  body: JSON.stringify({ title: `full local Project Pulse ${new Date().toISOString()}` }),
});
const pulseCreated = await request(`/api/goals/${pulseGoal.id}/runs`, {
  method: 'POST',
  body: JSON.stringify({ builtinSkill: 'project-pulse/1', projectSourceQuery: 'release', projectSourceMaxItems: 10 }),
});
const pulseRun = await approveRun(pulseCreated.id);
const firstProjectSync = pulseRun.context?.projectSourceSync;
if (pulseRun.status !== 'succeeded' || !['snapshot', 'unchanged'].includes(firstProjectSync?.update?.mode)
  || !Number.isInteger(firstProjectSync?.checkpointRevision) || firstProjectSync.checkpointRevision < 1 || (pulseRun.context?.sources?.length ?? 0) < 3
  || !pulseRun.artifacts?.some(item => item.artifactType === 'project-pulse/1' && item.structured?.nextActions?.length)) {
  throw new Error(`Expected evidence-bound Project Pulse snapshot, got ${JSON.stringify({ status: pulseRun.status, sync: pulseRun.context?.projectSourceSync, sources: pulseRun.context?.sources?.length, artifacts: pulseRun.artifacts })}`);
}
const pulseGoalAfter = await request(`/api/goals/${pulseGoal.id}`);
const pulsePlans = await request(`/api/goals/${pulseGoal.id}/plans`);
if (!pulseRun.followUpPlanId || pulsePlans.length < 2 || pulseGoalAfter.status !== 'active') {
  throw new Error(`Expected Project Pulse successor plan, got ${JSON.stringify({ followUpPlanId: pulseRun.followUpPlanId, planCount: pulsePlans.length, goalStatus: pulseGoalAfter.status })}`);
}

// A second run with the same query resumes the durable checkpoint and should
// reuse the stored snapshot instead of dropping source context. The combined
// provider may express this as a complete snapshot with changed=false because
// it reassembles child provider views.
const pulseSecond = await request(`/api/goals/${pulseGoal.id}/runs`, {
  method: 'POST',
  body: JSON.stringify({ builtinSkill: 'project-pulse/1', projectSourceQuery: 'release', projectSourceMaxItems: 10 }),
});
const pulseSecondRun = await approveRun(pulseSecond.id);
if (pulseSecondRun.status !== 'succeeded' || !['snapshot', 'unchanged'].includes(pulseSecondRun.context?.projectSourceSync?.update?.mode)
  || pulseSecondRun.context?.projectSourceSync?.changed !== false
  || pulseSecondRun.context?.projectSourceSync?.checkpointRevision !== firstProjectSync.checkpointRevision + 1 || (pulseSecondRun.context?.sources?.length ?? 0) < 3) {
  throw new Error(`Expected Project Pulse checkpoint resume, got ${JSON.stringify({ status: pulseSecondRun.status, sync: pulseSecondRun.context?.projectSourceSync, sources: pulseSecondRun.context?.sources?.length })}`);
}

const firstRun = await approveRun(firstDispatch.runId, { allowQueuedReservation: true });
if (firstRun.status !== 'succeeded') throw new Error(`Expected first DAG task to succeed, got ${firstRun.status}: ${firstRun.error ?? 'no error'}`);

let scheduler;
let secondDispatch;
while (true) {
  assertWithinTimeout();
  scheduler = await request(`/api/plans/${plan.id}/scheduler`);
  secondDispatch = scheduler.find(item => item.taskId === 'deliver');
  if (secondDispatch?.runId) break;
  await new Promise(resolve => setTimeout(resolve, 500));
}

const secondRun = await approveRun(secondDispatch.runId, { allowQueuedReservation: true });
if (secondRun.status !== 'succeeded') throw new Error(`Expected second DAG task to succeed, got ${secondRun.status}: ${secondRun.error ?? 'no error'}`);

let finalScheduler;
let snapshot;
let finalGoal;
while (true) {
  assertWithinTimeout();
  finalScheduler = await request(`/api/plans/${plan.id}/scheduler`);
  snapshot = await request(`/api/plans/${plan.id}/snapshot`);
  finalGoal = await request(`/api/goals/${goal.id}`);
  if (finalScheduler.length === 2 && finalScheduler.every(item => item.state === 'succeeded')
    && snapshot.plan.nodes.every(node => node.status === 'succeeded') && finalGoal.status === 'completed') break;
  await new Promise(resolve => setTimeout(resolve, 500));
}
if (finalScheduler.length !== 2 || finalScheduler.some(item => item.state !== 'succeeded')) {
  throw new Error(`Expected both DAG dispatches to succeed, got ${JSON.stringify(finalScheduler)}`);
}
if (snapshot.plan.nodes.some(node => node.status !== 'succeeded') || finalGoal.status !== 'completed') {
  throw new Error(`Expected completed DAG and Goal, got ${JSON.stringify({ plan: snapshot.plan, goal: finalGoal })}`);
}

// Verify the external Agent boundary through the real full local network. The
// fixture Agent receives a task-scoped Context Pack and Grant over HTTP; its
// Result Envelope must then become evidence for the AEEIS Run.
// This policy intentionally uses dispatch=create and is evaluated only by the
// internal Run Event Pump. The assertion below proves a normal Run's durable
// review.completed event can create a Debate without a manual /evaluate call.
const runEventPolicy = await request('/api/collaborations/triggers/policies', {
  method: 'POST',
  body: JSON.stringify({
    id: `policy.full-local.run-event.${Date.now()}`,
    name: 'full local Run review collaboration',
    enabled: true,
    eventTypes: ['review.completed'],
    sources: ['system'],
    action: {
      type: 'debate',
      participantAgentIds: ['agent.fixture'],
      maxRounds: 1,
      maxMessagesPerAgent: 1,
      maxTotalMessages: 1,
      dispatch: 'create',
    },
  }),
});
const externalRun = await request('/api/runs', {
  method: 'POST',
  body: JSON.stringify({
    goal: 'Use the admitted fixture Agent to return a bounded research result',
    materials: [{ title: 'External smoke source', source: 'full-local-fixture-agent', content: 'The fixture Agent must preserve this evidence boundary.' }],
    allowedAgents: ['agent.fixture'],
    externalBudget: { calls: 1 },
  }),
});
const externalCompleted = await approveRun(externalRun.id);
if (externalCompleted.status !== 'succeeded' || !externalCompleted.delegationOutcomes?.some((outcome) => (outcome.agentId ?? outcome.receipt?.agentId ?? outcome.result?.agentId) === 'agent.fixture' && outcome.status === 'completed')) {
  throw new Error(`Expected external Agent Run to succeed with a completed delegation, got ${JSON.stringify({ status: externalCompleted.status, error: externalCompleted.error, delegations: externalCompleted.delegationOutcomes })}`);
}
let runEventDecision;
while (true) {
  assertWithinTimeout();
  const decisions = await request(`/api/collaborations/triggers/decisions?policyId=${encodeURIComponent(runEventPolicy.id)}`);
  runEventDecision = decisions.find((decision) => decision.eventId.startsWith(`run:${externalRun.id}:`));
  if (runEventDecision?.state === 'triggered' && runEventDecision.resourceId) {
    break;
  }
  await new Promise(resolve => setTimeout(resolve, 500));
}
const runEventDebate = await request(`/api/collaborations/debates/${runEventDecision.resourceId}`);
if (runEventDebate.status !== 'active') throw new Error(`Expected Run Event Pump to create an active Debate, got ${JSON.stringify(runEventDebate)}`);

// Verify the RSI boundary through the real full local evaluator. The evaluator
// is intentionally deterministic: this checks the network protocol and the
// candidate lifecycle, while production quality remains a separate concern.
const activationBeforeRsi = await request('/api/evolution/activation');
let activePrompt = activationBeforeRsi.active?.find((release) => release.target === 'prompt');
if (!activePrompt) {
  // A fresh data directory has only the immutable prompt/1 baseline and no
  // active release pointer. Establish a real, evaluated release before
  // exercising the production traffic boundary.
  const baselineVersion = `prompt/full-local-baseline-${Date.now()}`;
  const baseline = await request('/api/evolution/candidates', {
    method: 'POST',
    body: JSON.stringify({
      target: 'prompt', baseVersion: 'prompt/1', proposedVersion: baselineVersion,
      change: 'Preserve evidence citations in the local smoke baseline.',
      sourceReceiptRefs: ['receipt.full-local.baseline'], reason: 'Establish a canary base release', risk: 'low',
    }),
  });
  const evaluatedBaseline = await request(`/api/evolution/candidates/${baseline.id}/evaluate-suite`, {
    method: 'POST', body: JSON.stringify({ suite: {
      replay: [{ id: 'replay.full-local-baseline', input: { goal: 'baseline' } }],
      holdout: [{ id: 'holdout.full-local-baseline', input: { goal: 'baseline' } }],
      safety: [{ id: 'safety.full-local-baseline', input: { goal: 'safe' } }],
    } }),
  });
  if (evaluatedBaseline.evaluations?.some((evaluation) => !evaluation.passed)) throw new Error(`Baseline RSI evaluation failed: ${JSON.stringify(evaluatedBaseline)}`);
  await request(`/api/evolution/candidates/${baseline.id}/approve`, { method: 'POST', body: JSON.stringify({ approvalRef: 'full-local-baseline-approval' }) });
  await request(`/api/evolution/candidates/${baseline.id}/promote`, { method: 'POST', body: JSON.stringify({}) });
  await request(`/api/evolution/candidates/${baseline.id}/activate`, { method: 'POST', body: JSON.stringify({ activationRef: 'full-local-baseline-activation' }) });
  const afterBaseline = await request('/api/evolution/activation');
  activePrompt = afterBaseline.active?.find((release) => release.target === 'prompt');
  if (!activePrompt) throw new Error(`Expected an active RSI baseline release, got ${JSON.stringify(afterBaseline)}`);
}
const rsiBaseVersion = activePrompt?.version ?? 'prompt/1';
const rsiProposedVersion = `prompt/full-local-smoke-${Date.now()}`;
const candidate = await request('/api/evolution/candidates', {
  method: 'POST',
  body: JSON.stringify({
    target: 'prompt',
    baseVersion: rsiBaseVersion,
    proposedVersion: rsiProposedVersion,
    change: 'Always cite the evidence graph.',
    sourceReceiptRefs: ['receipt.full-local.rsi'],
    reason: 'full local RSI evaluator smoke',
    risk: 'low',
  }),
});
const evaluatedCandidate = await request(`/api/evolution/candidates/${candidate.id}/evaluate-suite`, {
  method: 'POST',
  body: JSON.stringify({
    suite: {
      replay: [{ id: 'replay.full-local', input: { goal: 'full-local-rsi' } }],
      holdout: [{ id: 'holdout.full-local', input: { goal: 'full-local-rsi' } }],
      safety: [{ id: 'safety.full-local', input: { goal: 'safe' } }],
    },
  }),
});
if (evaluatedCandidate.status !== 'evaluating' || evaluatedCandidate.evaluations?.length !== 3 || evaluatedCandidate.evaluations.some((evaluation) => !evaluation.passed)) {
  throw new Error(`Expected all RSI evaluation gates to pass, got ${JSON.stringify(evaluatedCandidate)}`);
}
const approvedCandidate = await request(`/api/evolution/candidates/${candidate.id}/approve`, {
  method: 'POST',
  body: JSON.stringify({ approvalRef: 'full-local-rsi-approval' }),
});
if (approvedCandidate.status !== 'approved') throw new Error(`Expected RSI candidate to be approved, got ${JSON.stringify(approvedCandidate)}`);
const promotedCandidate = await request(`/api/evolution/candidates/${candidate.id}/promote`, { method: 'POST', body: JSON.stringify({}) });
if (promotedCandidate.status !== 'promoted') throw new Error(`Expected RSI candidate to be promoted, got ${JSON.stringify(promotedCandidate)}`);

// Verify the production traffic canary boundary before full activation. A
// route must be durable, observations must be evidence-bound, and every new
// Run must freeze its deterministic route/bucket decision.
const trafficRoute = await request(`/api/evolution/candidates/${candidate.id}/start-traffic`, {
  method: 'POST',
  body: JSON.stringify({ percentage: 2500, rolloutRef: 'full-local-rsi-traffic-start' }),
});
if (trafficRoute.status !== 'active' || trafficRoute.candidateId !== candidate.id || trafficRoute.percentage !== 2500) {
  throw new Error(`Expected active production traffic route, got ${JSON.stringify(trafficRoute)}`);
}
const trafficRunRef = await request('/api/runs', {
  method: 'POST',
  body: JSON.stringify({ goal: 'Freeze the full local production traffic decision' }),
});
const trafficRun = await request(`/api/runs/${trafficRunRef.id}`);
if (!trafficRun.evolutionTraffic?.some((selection) => selection.routeId === trafficRoute.id && selection.candidateId === candidate.id && Number.isInteger(selection.bucket))) {
  throw new Error(`Expected Run to freeze the production traffic route and bucket, got ${JSON.stringify(trafficRun.evolutionTraffic)}`);
}
const observedTraffic = await request(`/api/evolution/candidates/${candidate.id}/record-traffic`, {
  method: 'POST',
  body: JSON.stringify({ id: 'traffic.full-local.observation', passed: true, score: 0.98, evidenceRefs: ['metric.full-local.acceptance', 'metric.full-local.latency'] }),
});
if (observedTraffic.observations?.length !== 1 || observedTraffic.observations[0]?.id !== 'traffic.full-local.observation') {
  throw new Error(`Expected durable production traffic observation, got ${JSON.stringify(observedTraffic)}`);
}
const stoppedTraffic = await request(`/api/evolution/candidates/${candidate.id}/stop-traffic`, {
  method: 'POST',
  body: JSON.stringify({ reason: 'full local smoke completed the traffic observation window' }),
});
if (stoppedTraffic.status !== 'stopped' || stoppedTraffic.observations?.length !== 1) {
  throw new Error(`Expected stopped traffic route with observation, got ${JSON.stringify(stoppedTraffic)}`);
}
const activatedCandidate = await request(`/api/evolution/candidates/${candidate.id}/activate`, {
  method: 'POST',
  body: JSON.stringify({ activationRef: 'full-local-rsi-activation' }),
});
if (activatedCandidate.candidateId !== candidate.id || activatedCandidate.version !== rsiProposedVersion) {
  throw new Error(`Expected RSI activation release for ${rsiProposedVersion}, got ${JSON.stringify(activatedCandidate)}`);
}
const activatedCandidateState = await request(`/api/evolution/candidates/${candidate.id}`);
if (activatedCandidateState.status !== 'promoted') throw new Error(`Expected activated RSI candidate to remain promoted, got ${JSON.stringify(activatedCandidateState)}`);
const activation = await request('/api/evolution/activation');
if (!activation.active?.some((release) => release.candidateId === candidate.id && release.target === 'prompt' && release.version === rsiProposedVersion)) {
  throw new Error(`Expected ${rsiProposedVersion} to be active after RSI activation, got ${JSON.stringify(activation)}`);
}

console.log(JSON.stringify({
  status: 'passed',
  goalId: goal.id,
  planId: plan.id,
  runIds: [firstDispatch.runId, secondDispatch.runId],
  websiteRunId: websiteRun.id,
  externalRunId: externalRun.id,
  trafficRouteId: trafficRoute.id,
  trafficRunId: trafficRunRef.id,
  trafficObservationId: observedTraffic.observations[0].id,
  rsiCandidateId: candidate.id,
  runStatus: secondRun.status,
  dagTasks: snapshot.plan.nodes.map(node => ({ id: node.id, status: node.status })),
  artifacts: (firstRun.artifacts?.length ?? 0) + (secondRun.artifacts?.length ?? 0),
  reviews: [firstRun.review?.verdict ?? null, secondRun.review?.verdict ?? null],
  goalStatus: finalGoal.status,
  rsiStatus: activatedCandidateState.status,
  activeEvolution: activation.active.map((release) => ({ target: release.target, version: release.version })),
  readiness: readiness.status,
  triggeredCompetitionId: triggeredCompetition.id,
  triggeredCompetitionStatus: triggeredCompetition.status,
  triggeredDebateId: triggeredDebate.id,
  triggeredDebateStatus: triggeredDebate.status,
  runEventDebateId: runEventDebate.id,
  runEventDebateStatus: runEventDebate.status,
}, null, 2));
