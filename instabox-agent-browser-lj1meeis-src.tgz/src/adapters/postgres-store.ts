import { CHANNEL_METADATA_MIGRATION, channelRoom } from '../channel-metadata.js';
import { ChangeAuditService, type ChangeContext } from '../change-audit.js';
import { memoryAuditInput, memorySnapshot, memorySnapshotIds, type MemoryChanges } from '../memory-change-audit.js';
import { PostgresChangeAuditStore } from './postgres-change-audit.js';
import { decodeCollectionCursor, decodeVersionCursor, encodeCollectionCursor, encodeVersionCursor, validateCollectionLimit } from './collection-query.js';
import type { Ownership } from '../security/principal.js';
import pg from 'pg';
import type { ContextManifest, Goal, Id, MemoryEntry, Plan, ProjectionIntent, RunReceipt, Room } from '../contracts.js';
import type { AeeisStore, RoomPage } from './in-memory-store.js';
import { assertMemoryCommit, assertRoomCommit, assertTaskCommit } from './task-commit.js';
import { withPostgresMigrationLock } from './postgres-migration.js';
import { createPostgresPool } from './postgres-pool.js';
import { openAggregate, pick, sealAggregate } from '../content-encryption.js';

/** PostgreSQL domain store. Each aggregate is kept as validated JSONB while
 * indexed ownership columns support the bounded Goal/Plan/Memory queries. */
export class PostgresAeeisStore implements AeeisStore {
  private readonly pool: pg.Pool;
  private readonly auditStore: PostgresChangeAuditStore;
  readonly changeAudit: ChangeAuditService<pg.PoolClient>;
  constructor(connectionString: string) {
    this.pool = createPostgresPool(connectionString);
    this.auditStore = new PostgresChangeAuditStore(this.pool, 'domain-memory');
    this.changeAudit = new ChangeAuditService(this.auditStore, {
      read: async (entry, client) => {
        const records: MemoryChanges = {};
        for (const id of memorySnapshotIds(entry)) records[id] = await openMemory((await client.query<{ state: MemoryEntry }>('SELECT state FROM aeeis_memories WHERE id=$1 FOR UPDATE', [id])).rows[0]?.state) ?? null;
        return { records };
      },
      restore: async (entry, snapshot, client) => {
        for (const [id, memory] of Object.entries(memorySnapshot(entry, snapshot))) {
          if (memory === null) await client.query('DELETE FROM aeeis_memories WHERE id=$1', [id]);
          else await this.writeMemory(client, memory);
        }
      },
    });
  }

  async init(): Promise<void> {
    await this.auditStore.init();
    await withPostgresMigrationLock(this.pool, 'domain', async client => { await client.query(`
      CREATE TABLE IF NOT EXISTS aeeis_goals (id text PRIMARY KEY, state jsonb NOT NULL, created_at timestamptz NOT NULL);
      CREATE INDEX IF NOT EXISTS aeeis_goals_recent_idx ON aeeis_goals ((COALESCE(state->>'owner','owner')), (COALESCE(state->>'tenantId','local')), created_at DESC, id);
      CREATE TABLE IF NOT EXISTS aeeis_rooms (id text PRIMARY KEY, state jsonb NOT NULL, owner text, tenant_id text, created_at timestamptz NOT NULL);
      ALTER TABLE aeeis_rooms ADD COLUMN IF NOT EXISTS updated_at timestamptz;
      UPDATE aeeis_rooms SET updated_at=(state->>'updatedAt')::timestamptz WHERE updated_at IS NULL;
      ALTER TABLE aeeis_rooms ALTER COLUMN updated_at SET NOT NULL;
      CREATE INDEX IF NOT EXISTS aeeis_rooms_recent_idx ON aeeis_rooms ((COALESCE(tenant_id, 'local')), updated_at DESC, id);
      CREATE TABLE IF NOT EXISTS aeeis_plans (id text PRIMARY KEY, goal_id text NOT NULL, version integer NOT NULL, state jsonb NOT NULL, created_at timestamptz NOT NULL);
      CREATE TABLE IF NOT EXISTS aeeis_receipts (id text PRIMARY KEY, plan_id text NOT NULL, state jsonb NOT NULL, occurred_at timestamptz NOT NULL);
      CREATE TABLE IF NOT EXISTS aeeis_memories (id text PRIMARY KEY, goal_id text, state jsonb NOT NULL, created_at timestamptz NOT NULL);
      CREATE TABLE IF NOT EXISTS aeeis_context_manifests (id text PRIMARY KEY, goal_id text, owner text, tenant_id text, state jsonb NOT NULL, created_at timestamptz NOT NULL);
      CREATE TABLE IF NOT EXISTS aeeis_projection_intents (id text PRIMARY KEY, state jsonb NOT NULL, created_at timestamptz NOT NULL, status text NOT NULL);
      CREATE INDEX IF NOT EXISTS aeeis_plans_goal_idx ON aeeis_plans(goal_id);
      ALTER TABLE aeeis_plans ADD COLUMN IF NOT EXISTS version integer;
      UPDATE aeeis_plans SET version=COALESCE(version, (state->>'version')::integer) WHERE version IS NULL;
      ALTER TABLE aeeis_plans ALTER COLUMN version SET NOT NULL;
      CREATE UNIQUE INDEX IF NOT EXISTS aeeis_plans_goal_version_idx ON aeeis_plans(goal_id, version);
      CREATE INDEX IF NOT EXISTS aeeis_receipts_plan_idx ON aeeis_receipts(plan_id);
      CREATE INDEX IF NOT EXISTS aeeis_memories_goal_idx ON aeeis_memories(goal_id);
      ALTER TABLE aeeis_memories ADD COLUMN IF NOT EXISTS owner text;
      ALTER TABLE aeeis_memories ADD COLUMN IF NOT EXISTS tenant_id text;
      UPDATE aeeis_memories SET owner=COALESCE(owner, state->>'owner', 'owner'), tenant_id=COALESCE(tenant_id, state->>'tenantId', 'local') WHERE owner IS NULL OR tenant_id IS NULL;
      CREATE INDEX IF NOT EXISTS aeeis_memories_owner_idx ON aeeis_memories(tenant_id, owner, goal_id);
      ALTER TABLE aeeis_context_manifests ADD COLUMN IF NOT EXISTS goal_id text;
      ALTER TABLE aeeis_context_manifests ADD COLUMN IF NOT EXISTS owner text;
      ALTER TABLE aeeis_context_manifests ADD COLUMN IF NOT EXISTS tenant_id text;
      UPDATE aeeis_context_manifests SET goal_id=COALESCE(goal_id, state->>'goalId'), owner=COALESCE(owner, state->>'owner', 'owner'), tenant_id=COALESCE(tenant_id, state->>'tenantId', 'local') WHERE goal_id IS NULL OR owner IS NULL OR tenant_id IS NULL;
      CREATE INDEX IF NOT EXISTS aeeis_context_manifests_scope_idx ON aeeis_context_manifests(tenant_id, owner, goal_id, created_at);
    `);
      // 009 runs under the domain lock after Rooms exist, before server RLS finalize.
      await client.query(CHANNEL_METADATA_MIGRATION);
    });
  }

  private async writeChannelMetadata(client: pg.PoolClient, room: Room): Promise<void> {
    const state = await sealAggregate('channel-metadata', room.tenantId, room.id, { topicRef: room.topicRef });
    await client.query(`INSERT INTO aeeis_channel_metadata(tenant_id,owner,room_id,category,revision,state,updated_at) VALUES($1,$2,$3,$4,$5,$6,$7)
      ON CONFLICT(tenant_id,owner,room_id) DO UPDATE SET category=EXCLUDED.category,revision=EXCLUDED.revision,state=EXCLUDED.state,updated_at=EXCLUDED.updated_at`,
      [room.tenantId ?? 'local', room.owner ?? 'owner', room.id, room.category ?? 'general', room.revision ?? 0, state, room.updatedAt]);
  }

  async commitRoomCreation(room: Room, intents: ProjectionIntent[] = []): Promise<void> {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      await client.query('INSERT INTO aeeis_rooms(id,state,owner,tenant_id,created_at,updated_at) VALUES($1,$2,$3,$4,$5,$6)', [room.id, roomState(room), room.owner ?? 'owner', room.tenantId ?? 'local', room.createdAt, room.updatedAt]);
      await this.writeChannelMetadata(client, room);
      for (const intent of intents) await client.query('INSERT INTO aeeis_projection_intents(id,state,created_at,status) VALUES($1,$2,$3,$4) ON CONFLICT(id) DO NOTHING', [intent.id, intent, intent.createdAt, intent.status]);
      await client.query('COMMIT');
    } catch (error) { await client.query('ROLLBACK'); throw error; } finally { client.release(); }
  }

  async commitRoomUpdate(expected: Room, next: Room, intents: ProjectionIntent[] = []): Promise<void> {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      // Lock first, then take a fresh snapshot of metadata after any concurrent writer commits.
      await client.query('SELECT id FROM aeeis_rooms WHERE id=$1 FOR UPDATE', [expected.id]);
      const locked = await client.query<RoomRow>(`${ROOM_SELECT} WHERE id=$1`, [expected.id]);
      assertRoomCommit(locked.rows[0] ? await openRoom(locked.rows[0]) : undefined, expected, next);
      await client.query('UPDATE aeeis_rooms SET state=$2, owner=$3, tenant_id=$4, updated_at=$5 WHERE id=$1', [next.id, roomState(next), next.owner ?? 'owner', next.tenantId ?? 'local', next.updatedAt]);
      await this.writeChannelMetadata(client, next);
      for (const intent of intents) await client.query('INSERT INTO aeeis_projection_intents(id,state,created_at,status) VALUES($1,$2,$3,$4) ON CONFLICT(id) DO NOTHING', [intent.id, intent, intent.createdAt, intent.status]);
      await client.query('COMMIT');
    } catch (error) { await client.query('ROLLBACK'); throw error; } finally { client.release(); }
  }

  async getRoom(id: Id): Promise<Room | undefined> { const result = await this.pool.query<RoomRow>(`${ROOM_SELECT} WHERE id=$1`, [id]); return result.rows[0] ? openRoom(result.rows[0]) : undefined; }
  async getRooms(scope?: Ownership, limit?: number, memberRoomIds?: string[]): Promise<Room[]> {
    validateCollectionLimit(limit);
    const values: unknown[] = scope ? [scope.tenantId, scope.owner, memberRoomIds ?? []] : [];
    if (limit !== undefined) values.push(limit);
    const result = await this.pool.query<RoomRow>(`${ROOM_SELECT}${scope ? " WHERE COALESCE(tenant_id, 'local')=$1 AND (COALESCE(owner, 'owner')=$2 OR id=ANY($3::text[]))" : ''} ORDER BY updated_at DESC, id${limit === undefined ? '' : ` LIMIT $${values.length}`}`, values);
    return Promise.all(result.rows.map(openRoom));
  }
  async getRoomsPage(limit: number, cursor?: string): Promise<RoomPage> {
    validateCollectionLimit(limit);
    const parsed = decodeCollectionCursor(cursor);
    const values: unknown[] = [];
    let where = '';
    if (parsed) { values.push(parsed.timestamp, parsed.id); where = ' WHERE updated_at < $1 OR (updated_at = $1 AND id > $2)'; }
    values.push(limit + 1);
    const result = await this.pool.query<RoomRow>(`${ROOM_SELECT}${where} ORDER BY updated_at DESC, id LIMIT $${values.length}`, values);
    const page = await Promise.all(result.rows.map(openRoom)); const hasMore = page.length > limit; const visible = hasMore ? page.slice(0, limit) : page;
    return { rooms: visible, ...(hasMore && visible.length ? { nextCursor: encodeCollectionCursor({ timestamp: visible.at(-1)!.updatedAt, id: visible.at(-1)!.id }) } : {}) };
  }

  async commitGoalCreation(goal: Goal, intents: ProjectionIntent[] = []): Promise<void> {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      await client.query('INSERT INTO aeeis_goals(id,state,created_at) VALUES($1,$2,$3)', [goal.id, goal, goal.createdAt]);
      for (const intent of intents) await client.query('INSERT INTO aeeis_projection_intents(id,state,created_at,status) VALUES($1,$2,$3,$4) ON CONFLICT(id) DO NOTHING', [intent.id, intent, intent.createdAt, intent.status]);
      await client.query('COMMIT');
    } catch (error) { await client.query('ROLLBACK'); throw error; } finally { client.release(); }
  }

  async commitPlanCreation(plan: Plan, intents: ProjectionIntent[] = [], reopenGoal = false): Promise<void> {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const goal = await client.query('SELECT id FROM aeeis_goals WHERE id=$1 FOR UPDATE', [plan.goalId]);
      if (!goal.rowCount) throw new Error('Plan creation references missing goal');
      await client.query('INSERT INTO aeeis_plans(id,goal_id,version,state,created_at) VALUES($1,$2,$3,$4,$5)', [plan.id, plan.goalId, plan.version, plan, plan.createdAt]);
      for (const intent of intents) await client.query('INSERT INTO aeeis_projection_intents(id,state,created_at,status) VALUES($1,$2,$3,$4) ON CONFLICT(id) DO NOTHING', [intent.id, intent, intent.createdAt, intent.status]);
      if (reopenGoal) await client.query(`UPDATE aeeis_goals SET state=jsonb_set(state, '{status}', '"active"'::jsonb) WHERE id=$1`, [plan.goalId]);
      await client.query('COMMIT');
    } catch (error) { await client.query('ROLLBACK'); throw error; } finally { client.release(); }
  }

  async saveGoal(goal: Goal): Promise<void> {
    await this.pool.query('INSERT INTO aeeis_goals(id,state,created_at) VALUES($1,$2,$3) ON CONFLICT(id) DO UPDATE SET state=EXCLUDED.state, created_at=EXCLUDED.created_at', [goal.id, goal, goal.createdAt]);
  }
  async getGoal(id: Id): Promise<Goal | undefined> { return one<Goal>(this.pool, 'SELECT state FROM aeeis_goals WHERE id=$1', [id]); }
  async getGoals(scope?: Ownership, limit?: number): Promise<Goal[]> { validateCollectionLimit(limit);
    const values: unknown[] = scope ? [scope.owner, scope.tenantId] : [];
    if (limit !== undefined) values.push(limit);
    return many<Goal>(this.pool, `SELECT state FROM aeeis_goals${scope ? " WHERE COALESCE(state->>'owner','owner')=$1 AND COALESCE(state->>'tenantId','local')=$2" : ''} ORDER BY created_at DESC, id${limit === undefined ? '' : ` LIMIT $${values.length}`}`, values); }
  async getReadableGoals(scope: Ownership, memberRoomIds: readonly string[]): Promise<Goal[]> {
    return many<Goal>(this.pool, `SELECT state FROM aeeis_goals
      WHERE COALESCE(state->>'tenantId','local')=$1
        AND (COALESCE(state->>'owner','owner')=$2 OR COALESCE(state->>'roomId','') = ANY($3::text[]))`, [scope.tenantId, scope.owner, [...new Set(memberRoomIds)]]);
  }
  async getGoalsPage(scope: Ownership, limit: number, cursor?: string) {
    validateCollectionLimit(limit);
    const pageCursor = decodeCollectionCursor(cursor);
    const values: unknown[] = [scope.owner, scope.tenantId];
    const cursorClause = pageCursor ? ` AND (created_at < $3::timestamptz OR (created_at = $3::timestamptz AND id > $4))` : '';
    if (pageCursor) values.push(pageCursor.timestamp, pageCursor.id);
    values.push(limit + 1);
    const result = await this.pool.query<{ state: Goal }>(`SELECT state FROM aeeis_goals WHERE COALESCE(state->>'owner','owner')=$1 AND COALESCE(state->>'tenantId','local')=$2${cursorClause} ORDER BY created_at DESC, id ASC LIMIT $${values.length}`, values);
    const hasMore = result.rows.length > limit; const visible = hasMore ? result.rows.slice(0, limit) : result.rows;
    return { goals: visible.map(row => row.state), ...(hasMore && visible.length ? { nextCursor: encodeCollectionCursor({ timestamp: visible.at(-1)!.state.createdAt, id: visible.at(-1)!.state.id }) } : {}) };
  }
  async savePlan(plan: Plan): Promise<void> {
    await this.pool.query('INSERT INTO aeeis_plans(id,goal_id,version,state,created_at) VALUES($1,$2,$3,$4,$5) ON CONFLICT(id) DO UPDATE SET goal_id=EXCLUDED.goal_id, version=EXCLUDED.version, state=EXCLUDED.state, created_at=EXCLUDED.created_at', [plan.id, plan.goalId, plan.version, plan, plan.createdAt]);
  }
  async commitTaskTransition(expected: Plan, next: Plan, receipt: RunReceipt, intents: ProjectionIntent[] = []): Promise<void> {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const locked = await client.query<{ state: Plan }>('SELECT state FROM aeeis_plans WHERE id=$1 FOR UPDATE', [expected.id]);
      assertTaskCommit(locked.rows[0]?.state, expected, next, receipt);
      const goal = await client.query('SELECT id FROM aeeis_goals WHERE id=$1 FOR UPDATE', [next.goalId]);
      if (!goal.rowCount) throw new Error('Task commit references missing goal');
      await client.query('UPDATE aeeis_plans SET state=$2 WHERE id=$1', [next.id, next]);
      await client.query('INSERT INTO aeeis_receipts(id,plan_id,state,occurred_at) VALUES($1,$2,$3,$4)', [receipt.id, receipt.planId, receipt, receipt.occurredAt]);
      for (const intent of intents) await client.query('INSERT INTO aeeis_projection_intents(id,state,created_at,status) VALUES($1,$2,$3,$4) ON CONFLICT(id) DO NOTHING', [intent.id, intent, intent.createdAt, intent.status]);
      if (next.nodes.every(node => node.status === 'succeeded')) {
        await client.query(`UPDATE aeeis_goals SET state=jsonb_set(state, '{status}', '"completed"'::jsonb) WHERE id=$1`, [next.goalId]);
      }
      await client.query('COMMIT');
    } catch (error) { await client.query('ROLLBACK'); throw error; }
    finally { client.release(); }
  }
  async getPlan(id: Id): Promise<Plan | undefined> { return one<Plan>(this.pool, 'SELECT state FROM aeeis_plans WHERE id=$1', [id]); }
  async getPlans(goalId?: Id): Promise<Plan[]> { return goalId === undefined ? many<Plan>(this.pool, 'SELECT state FROM aeeis_plans ORDER BY created_at') : many<Plan>(this.pool, 'SELECT state FROM aeeis_plans WHERE goal_id=$1 ORDER BY created_at', [goalId]); }
  async getPlansPage(goalId: Id, limit: number, cursor?: string) {
    validateCollectionLimit(limit);
    const pageCursor = decodeVersionCursor(cursor);
    const values: unknown[] = [goalId];
    const cursorClause = pageCursor ? ` AND (version < $2 OR (version = $2 AND id > $3))` : '';
    if (pageCursor) values.push(pageCursor.version, pageCursor.id);
    values.push(limit + 1);
    const result = await this.pool.query<{ state: Plan }>(`SELECT state FROM aeeis_plans WHERE goal_id=$1${cursorClause} ORDER BY version DESC, id ASC LIMIT $${values.length}`, values);
    const hasMore = result.rows.length > limit; const visible = hasMore ? result.rows.slice(0, limit) : result.rows;
    return { plans: visible.map(row => row.state), ...(hasMore && visible.length ? { nextCursor: encodeVersionCursor({ version: visible.at(-1)!.state.version, id: visible.at(-1)!.state.id }) } : {}) };
  }
  async appendReceipt(receipt: RunReceipt): Promise<void> { await this.pool.query('INSERT INTO aeeis_receipts(id,plan_id,state,occurred_at) VALUES($1,$2,$3,$4) ON CONFLICT(id) DO NOTHING', [receipt.id, receipt.planId, receipt, receipt.occurredAt]); }
  async getReceipts(planId: Id): Promise<RunReceipt[]> { return many<RunReceipt>(this.pool, 'SELECT state FROM aeeis_receipts WHERE plan_id=$1 ORDER BY occurred_at,id', [planId]); }
  private async writeMemory(client: pg.PoolClient, memory: MemoryEntry): Promise<void> {
    await client.query('INSERT INTO aeeis_memories(id,goal_id,owner,tenant_id,state,created_at) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(id) DO UPDATE SET goal_id=EXCLUDED.goal_id,owner=EXCLUDED.owner,tenant_id=EXCLUDED.tenant_id,state=EXCLUDED.state,created_at=EXCLUDED.created_at', [memory.id, memory.goalId ?? null, memory.owner ?? 'owner', memory.tenantId ?? 'local', await sealMemory(memory), memory.createdAt]);
  }
  async saveMemory(memory: MemoryEntry, context?: ChangeContext): Promise<void> {
    await this.auditStore.transaction(async (log, client) => {
      const previous = await openMemory((await client.query<{ state: MemoryEntry }>('SELECT state FROM aeeis_memories WHERE id=$1 FOR UPDATE', [memory.id])).rows[0]?.state);
      log.append(memoryAuditInput(memory, previous ? { [memory.id]: previous } : null, { [memory.id]: memory }, 'memory.save', context));
      await this.writeMemory(client, memory);
    });
  }
  async commitMemoryUpdate(expected: MemoryEntry, next: MemoryEntry, context?: ChangeContext): Promise<void> {
    await this.auditStore.transaction(async (log, client) => {
      const result = await client.query<{ state: MemoryEntry }>('SELECT state FROM aeeis_memories WHERE id=$1 FOR UPDATE', [expected.id]);
      assertMemoryCommit(await openMemory(result.rows[0]?.state), expected, next);
      log.append(memoryAuditInput(next, { [expected.id]: expected }, { [next.id]: next }, 'memory.update', context));
      await this.writeMemory(client, next);
    });
  }
  async commitMemoryRevision(previous: MemoryEntry, next: MemoryEntry, context?: ChangeContext): Promise<void> {
    await this.auditStore.transaction(async (log, client) => {
      const result = await client.query<{ state: MemoryEntry }>('SELECT state FROM aeeis_memories WHERE id=$1 FOR UPDATE', [previous.id]);
      assertMemoryCommit(await openMemory(result.rows[0]?.state), previous, previous);
      if ((await client.query('SELECT id FROM aeeis_memories WHERE id=$1', [next.id])).rows.length) throw new Error('Memory revision already exists');
      const superseded = { ...previous, state: 'superseded' as const, updatedAt: next.updatedAt };
      log.append(memoryAuditInput(previous, { [previous.id]: previous, [next.id]: null }, { [previous.id]: superseded, [next.id]: next }, 'memory.correct', context));
      await this.writeMemory(client, superseded);
      await this.writeMemory(client, next);
    });
  }
  async getMemories(goalId?: Id, limit?: number): Promise<MemoryEntry[]> {
    validateCollectionLimit(limit);
    const values: unknown[] = goalId === undefined ? [] : [goalId];
    if (limit !== undefined) values.push(limit);
    const where = goalId === undefined ? '' : ' WHERE goal_id=$1';
    const order = limit === undefined ? ' ORDER BY created_at, id' : ' ORDER BY (state->>\'updatedAt\')::timestamptz DESC NULLS LAST, id';
    const rows = await many<MemoryEntry>(this.pool, `SELECT state FROM aeeis_memories${where}${order}${limit === undefined ? '' : ` LIMIT $${values.length}`}`, values);
    return Promise.all(rows.map(row => openMemory(row) as Promise<MemoryEntry>));
  }
  async saveContextManifest(manifest: ContextManifest): Promise<void> { await this.pool.query('INSERT INTO aeeis_context_manifests(id,goal_id,owner,tenant_id,state,created_at) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(id) DO UPDATE SET goal_id=EXCLUDED.goal_id,owner=EXCLUDED.owner,tenant_id=EXCLUDED.tenant_id,state=EXCLUDED.state,created_at=EXCLUDED.created_at', [manifest.id, manifest.goalId ?? null, manifest.owner ?? 'owner', manifest.tenantId ?? 'local', manifest, manifest.createdAt]); }
  async getContextManifest(id: Id): Promise<ContextManifest | undefined> { return one<ContextManifest>(this.pool, 'SELECT state FROM aeeis_context_manifests WHERE id=$1', [id]); }
  async listProjectionIntents(): Promise<ProjectionIntent[]> { return many<ProjectionIntent>(this.pool, "SELECT state FROM aeeis_projection_intents WHERE status='pending' ORDER BY created_at,id"); }
  async markProjectionIntentDispatched(id: Id, dispatchedAt = new Date().toISOString()): Promise<void> { await this.pool.query("UPDATE aeeis_projection_intents SET status='dispatched', state=state || jsonb_build_object('status','dispatched','dispatchedAt',$2::text) WHERE id=$1", [id, dispatchedAt]); }
  async close(): Promise<void> { await this.pool.end(); }
}

/** SQL orders memories by update time; the remembered text is sealed. */
const memoryPlain = (memory: MemoryEntry) => pick(memory, ['id', 'goalId', 'owner', 'createdAt', 'updatedAt', 'state']);
export const sealMemory = (memory: MemoryEntry) => sealAggregate('memory', memory.tenantId, memory.id, memory, memoryPlain);
const openMemory = async (stored: unknown): Promise<MemoryEntry | undefined> => stored === undefined || stored === null ? undefined : openAggregate<MemoryEntry>('memory', String((stored as { id?: unknown }).id), stored);

async function one<T>(pool: pg.Pool, query: string, values: unknown[] = []): Promise<T | undefined> {
  const result = await pool.query<{ state: T }>(query, values);
  return result.rows[0]?.state;
}
async function many<T>(pool: pg.Pool, query: string, values: unknown[] = []): Promise<T[]> {
  const result = await pool.query<{ state: T }>(query, values);
  return result.rows.map(row => row.state);
}

// Metadata is read in the same statement/snapshot as the Room. No second title/status authority.
const ROOM_SELECT = `SELECT state, (SELECT jsonb_build_object('category',m.category,'revision',m.revision,'state',m.state)
  FROM aeeis_channel_metadata m WHERE m.room_id=aeeis_rooms.id AND m.tenant_id=COALESCE(aeeis_rooms.tenant_id,'local') AND m.owner=COALESCE(aeeis_rooms.owner,'owner')) AS metadata FROM aeeis_rooms`;
type RoomRow = { state: Room; metadata?: { category: Room['category']; revision: number; state: unknown } };
async function openRoom(row: RoomRow): Promise<Room> {
  const metadata = row.metadata;
  const details = metadata ? await openAggregate<{ topicRef?: string }>('channel-metadata', row.state.id, metadata.state) : {};
  return channelRoom({ ...row.state, ...details, category: metadata?.category ?? 'general', revision: Number(metadata?.revision ?? 0) });
}
function roomState(room: Room): Omit<Room, 'category' | 'revision' | 'topicRef'> {
  const { category, revision, topicRef, ...state } = channelRoom(room);
  return state;
}
