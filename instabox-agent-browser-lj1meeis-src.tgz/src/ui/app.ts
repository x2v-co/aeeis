import { renderChannelManager } from './channel-management.js';
import { STARTER_BOTS, starterBot } from '../starter-bots.js';
import type { PlanComparison } from '../runtime/graphs.js';
import { planningDecision, planningRefusal } from '../runtime/planning-shape.js';
import { conversationTaskOrder, type ConversationMessageSource } from '../conversations.js';
import { planReview } from './plan-review.js';
import { artifactDownloadLink, releaseArtifactDownloads, renderArtifactMarkdown } from './artifact-markdown.js';
import { isFillablePdfArtifact, renderFillablePdf } from './fillable-pdf.js';

window.addEventListener('pagehide', releaseArtifactDownloads);

interface RunSummary { id: string; goal: string; goalId?: string; domainPlanId?: string; followUpPlanId?: string; taskExecution?: { domainPlanId: string; taskId: string }; status: string; updatedAt?: string; threadId?: string; parentRunId?: string; threadSequence?: number; derivationBlocked?: { kind: 'collaboration_trigger' | 'project_pulse'; limit: number; reason: string; at: string; acknowledgedAt?: string } }
interface ThreadRun extends RunSummary { threadSequence: number; privacy?: string; outputExcerpt?: string }
interface ThreadPage { id: string; title?: string; runs: ThreadRun[]; nextAfterSequence?: number }
interface ThreadShareView { kind: 'thread'; thread: { id: string; title?: string }; throughSequence: number; runs: Array<RunView & { explanation: RunExplanation }> }
interface RoomSummary { chat?: 'direct' | 'group' | 'unclassified'; category?: string; topicRef?: string; revision?: number; memberRole?: string; canEdit?: boolean; canArchive?: boolean; canWrite?: boolean; id: string; title: string; description?: string; status: string; createdAt: string; updatedAt: string }
interface RoomMemberSummary { id: string; roomId: string; principalId: string; role: 'editor' | 'viewer' | 'agent' | 'owner'; status: 'active' | 'revoked'; invitedBy: string; createdAt: string; updatedAt: string; displayName?: string }
interface SessionEventSummary {
  schemaVersion: 'session-event/1'; id: string; roomId: string; goalId?: string; owner: string; tenantId: string;
  sequence: number; type: 'message' | 'canonical_response' | 'decision' | 'task_update' | 'system' | 'digest';
  actorId: string; actorType: 'principal' | 'agent' | 'system'; recordedBy?: { id: string; type: 'principal' | 'agent' | 'system' }; operation?: 'publish' | 'revise' | 'retract'; targetEventId?: string; revision?: number; retractionReason?: string; classification?: 'public' | 'internal' | 'confidential' | 'private'; contextManifestId: string; contextManifestHash: string;
  audienceSnapshot: { digest: string; members: Array<{ principalId: string; role: string; status: string }> };
  content: string; contentHash: string; evidenceRefs: string[]; idempotencyKey: string; createdAt: string;
  botDelivery?: { mode: 'immediate' | 'digest'; at: string };
  digest?: { eventIds: string[]; minutes: number };
  taskAction?: { kind: string; conversationId: string; taskId: string; agentId?: string; reason?: string };
}
interface ChannelNoiseSettings { mode: 'quiet' | 'lively'; digestMinutes: number; quietHours: { start: string; end: string; timeZone: string } | null; canEdit: boolean }
interface SessionEventPage { items: SessionEventSummary[]; nextCursor?: string; previousCursor?: string }
interface GoalSummary { id: string; title: string; status: string; createdAt: string; roomId?: string }
interface MemoryView { id: string; goalId?: string; kind: string; scope: string; classification?: string; content: string; source: string; confidence: number; version?: number; state?: string; evidenceRefs?: string[]; evidenceRunId?: string; supersedesId?: string; retractionReason?: string; updatedAt: string }
interface DomainPlanSummary { id: string; version: number; nodes: Array<{ id: string; title: string; instruction?: string; status: string; dependsOn: string[]; evidenceRefs?: string[]; evidenceRunId?: string }> }
interface TaskDispatchSummary { id: string; planId: string; taskId: string; runId: string; workflowId: string; runner: string; state: string; dispatchAttempts: number; updatedAt: string; lastRunStatus?: string; lastError?: string }
interface EvolutionSummary { id: string; target: string; proposedVersion: string; risk: string; status: string; proposalSignalId?: string; evaluations: Array<{ kind: string; passed: boolean }>; shadowObservations?: Array<{ id: string; passed: boolean; score: number }>; canaryObservations?: Array<{ id: string; passed: boolean; score: number }>; rolloutAttempts?: Array<{ id: string; phase: string; caseId: string; state: string; error?: string }> }
interface ImprovementSignalSummary { id: string; kind: string; runId: string; eventId: string; owner: string; tenantId: string; sourceRefs: string[]; reason: string; occurredAt: string; proposal?: unknown; candidateId?: string; synthesis?: { id: string; state: string; inputHash: string; idempotencyKey: string; usage?: { tokens?: number }; error?: string; settled?: boolean; hasProposal?: boolean } }
interface EvolutionView extends EvolutionSummary { baseVersion: string; change: string; reason: string; sourceReceiptRefs: string[]; approvalRef?: string; shadowStartedAt?: string; canaryStartedAt?: string; promotedAt?: string; rolledBackAt?: string }
interface EvolutionTrafficView { id: string; candidateId: string; target: string; baseCandidateId?: string; baseVersion: string; version: string; contentHash?: string; percentage: number; status: 'active' | 'paused' | 'stopped'; rolloutRef: string; lastReason?: string; observations?: Array<{ id: string; passed: boolean; score: number; evidenceRefs: string[]; recordedAt: string }>; startedAt: string; updatedAt: string }
interface CollaborationUsageView { calls: number; tokens: number; moneyUsd?: number; unreportedTokenCalls: number; unreportedMoneyCalls: number }
interface CollaborationBudgetView { calls?: number; tokens?: number; moneyUsd?: number }
interface CompetitionSummary { usage?: CollaborationUsageView; id: string; status: string; brief: { goal: string; participantAgentIds: string[]; blindEvaluation: boolean; modelBudget?: CollaborationBudgetView }; candidates: Array<{ agentId: string }>; scores: Array<{ agentId: string; score: number; accepted: boolean }>; attempts?: Array<{ id: string; participantAgentId: string; state: string; error?: string; result?: unknown; usage?: unknown; startedAt: string; endedAt?: string; reconciliationReason?: string }>; evaluatorAttempt?: { id: string; state: string; error?: string; scores?: unknown[]; usage?: unknown; startedAt: string; endedAt?: string; reconciliationReason?: string }; evaluatorAgentId?: string; selectedAgentId?: string; updatedAt: string; failureReason?: string }
interface DebateSummary { usage?: CollaborationUsageView; modelBudget?: CollaborationBudgetView; id: string; status: string; roles?: { moderatorAgentId?: string; adjudicatorAgentId?: string }; attempts?: Array<{ id: string; slot: string; agentId: string; state: string; output?: unknown; error?: string; usage?: unknown; startedAt: string; endedAt?: string; reconciliationReason?: string }>; room: { goal?: string; taskId: string; contextVersion: string; participantAgentIds: string[]; messages: Array<{ messageId: string; round: number; speakerAgentId: string; type: string; content: string; claimRefs: string[] }>; moderation?: Array<{ messageId: string; status: string; violations?: string[] }>; moderatorReviews?: Array<{ messageId: string; status: string }>; adjudication?: { status: string; decision?: string; rationale?: string; evidenceRefs?: string[] } }; updatedAt: string; closeReason?: string }
interface ProjectionSummary { id: string; channel: string; destination: string; aggregateType: string; aggregateId: string; status: string; attempts: number; updatedAt: string; lastError?: string }
interface TriggerPolicySummary { id: string; name: string; enabled: boolean; eventTypes: string[]; action: { type: string; participantAgentIds: string[]; dispatch: string }; cooldownMs: number; updatedAt: string }
interface TriggerDecisionSummary { id: string; policyId: string; eventId: string; state: string; actionType: string; resourceId?: string; dispatchState: string; dispatchError?: string; error?: string; startedAt: string; completedAt?: string }
interface AgentSummary { agentId: string; status: 'discovered' | 'admitted' | 'revoked'; card: { name: string; owner: string; capabilities: string[]; cardVersion: string; endpoint?: string }; discoveredAt: string; admittedAt?: string; revokedAt?: string; reputation: { samples: number; dimensions: Record<string, number> } }
interface AgentAuditEvent { id: string; agentId: string; action: string; actor: string; cardVersion: string; status: string; at: string }
interface GraphNodeView { id: string; type: string; label: string; status?: string; metadata?: Record<string, unknown> }
interface GraphEdgeView { from: string; to: string; type: string }
interface RunGraphsView {
  execution: { nodes: GraphNodeView[]; edges: GraphEdgeView[] };
  evidence: { nodes: GraphNodeView[]; edges: GraphEdgeView[] };
  planHistory?: Array<{ version: number; hash: string; nodes: GraphNodeView[]; edges: GraphEdgeView[] }>;
  planComparisons?: PlanComparison[];
}
interface RunView extends RunSummary {
  workingMemoryEnabled?: boolean;
  canEdit?: boolean;
  takeover?: { by: string; at: string; actions?: TakeoverActionView[] };
  actionApproval?: { status: 'pending' | 'approved' | 'denied'; kind: 'tool' | 'agent'; ref: string; taskId: string; idempotencyKey: string; reason: string; decision?: string };
  evolution?: Array<{ target: string; version: string }>;
  corrections?: Array<{ id: string; text: string; candidateId: string; sourceRefs: string[]; createdAt: string }>;
  revision: number; goalId?: string; domainPlanId?: string; followUpPlanId?: string; taskExecution?: { domainPlanId: string; taskId: string; requestHash?: string };
  privacy?: string; skillRuntime?: string; skillSelection?: { methodId?: string; version?: string; plan: unknown; receiptRef?: string }; skillOutcome?: { outcome: 'success' | 'failure'; receiptRef?: string; error?: string }; approvedTools?: Array<{ id: string; version: string; capabilities: string[]; description?: string }>; toolManifestDigest?: string; resourceSnapshot?: { plugin?: { id: string; version: string; interface: string; digest: string; channel?: string }; skill?: { id: string; version: string; interface: string; digest: string; channel?: string }; workflow?: { id: string; version: string; interface: string; digest: string; channel?: string }; tools?: Array<{ id: string; version: string; interface: string; digest: string; channel?: string }>; lockfileDigest: string; policyDigest: string; resolvedAt: string; resolverVersion: string }; modelDecision?: { selected?: { model?: string; provider?: string }; catalogHash?: string; catalogRetrievedAt?: string; reason?: string }; context?: { id?: string; manifestHash?: string; memoryManifestId?: string; memoryManifestHash?: string; memoryRefs?: string[]; sources: Array<{ id: string; title: string; content: string; source: string; hash: string; contentHash?: string; kind?: string; untrusted?: boolean; classification?: string; origin?: { runId: string; ref: string } }> };
  plans: Array<{ hash: string; version: number; summary: string; author?: { type: 'user' | 'model' | 'policy' }; nodes: Array<{ id: string; title: string; instruction?: string; evidenceRequirements?: string; dependsOn: string[]; evidenceRefs?: string[]; evidenceRunId?: string }> }>;
  steps: Array<{ taskId: string; status: string; error?: string; failureReason?: string }>;
  artifacts: Array<{ id: string; title: string; content: string; evidenceRefs: string[]; artifactType?: string; structured?: unknown }>;
  model?: { model?: string; provider?: string; endpoint?: string; promptVersion?: string; routingMode?: string };
  events: Array<{ seq: number; type: string; at: string; data?: { phase?: string; reason?: string; validation?: { issues?: Array<{ path?: string; message?: string }> } } }>;
  calls: Array<{ phase: string; state: string; usage?: { inputTokens: number; outputTokens: number } }>;
  modelBudget?: { tokens?: number; moneyUsd?: number }; modelUsage?: { tokens: number; moneyUsd?: number; unreportedCalls: number };
  evolutionTraffic?: Array<{ routeId: string; target: string; candidateId: string; percentage: number; bucket: number; selected: boolean }>;
  externalBudget?: { calls?: number; tokens?: number; moneyUsd?: number };
  externalUsage?: { calls: number; tokens: number; moneyUsd?: number; unreportedTokenCalls: number; unreportedMoneyCalls: number };
  question?: { text: string }; error?: string;
  toolReceipts?: Array<{ receiptId: string; operation: string; provider: string; status: string; errorCode?: string; cost?: { credits?: number }; costStatus?: 'reported' | 'unreported' | 'interrupted'; authorization?: { decision: 'authorized' | 'isolated'; reason: string } }>;
  pendingTool?: { taskId: string; toolId: string; receiptId?: string };
  pendingDelegation?: { agentId: string; taskBrief: { taskId: string }; receiptRef?: string };
  agentProgress?: Array<{ idempotencyKey: string; progress: { agentId: string; taskId: string; sequence: number; status: string; message: string; percent?: number; evidenceRefs: string[]; artifactRefs: string[]; at: string } }>;
  delegationOutcomes?: Array<{ agentId?: string; status: string; receiptRef: string }>;
  review?: { verdict: string; summary: string; issues: string[]; confidence?: number };
  graphs?: RunGraphsView;
}
type ProjectPulseItem = Record<string, unknown> & { evidenceRefs?: unknown };
type ProjectPulseArtifact = {
  schemaVersion: 'project-pulse/1';
  progress: ProjectPulseItem[];
  completedChanges: ProjectPulseItem[];
  blockers: ProjectPulseItem[];
  risks: ProjectPulseItem[];
  decisions: ProjectPulseItem[];
  owners: ProjectPulseItem[];
  deadlines: ProjectPulseItem[];
  nextActions: ProjectPulseItem[];
  unknowns: ProjectPulseItem[];
};
interface ConversationTaskView { column?: string; autoColumn?: string; id: string; threadId: string; title: string; createdAt?: string; latestRunId?: string; runId?: string; pendingMessageId?: string; priority?: number; status: string; memory?: { originals: number; activeSummaries: number }; pendingApproval?: { planVersion: number; planHash: string; summary: string }; pendingQuestion?: { text: string }; takenOver?: { at: string }; pendingAction?: { kind: 'tool' | 'agent'; ref: string; reason: string; idempotencyKey: string; step?: string }; machine?: { state: 'absent' | 'present' | 'released' | 'unknown'; ready: boolean }; execution?: { steps: Array<{ title: string; state: 'done' | 'current' | 'waiting' }>; evidence?: string[] } }
interface ConversationReply { text: string; artifactId: string; truncated?: true }
interface ConversationMessageView {
  id: string; role: 'user' | 'notification'; speaker?: { role: 'user' | 'agent'; id: string }; text: string; createdAt: string; replyTo?: string; notificationRunId?: string;
  correctsMessageId?: string; effectiveTaskIds?: string[];
  route: { status: 'routed' | 'clarify' | 'general'; reason: string; taskIds: string[]; candidateTaskIds: string[]; focusEffect: 'keep' | 'switch' };
  execution?: { runId: string; taskId: string; state: string };
  /** The answer of the Run this message started, once it succeeded. */
  reply?: ConversationReply;
  source?: ConversationMessageSource;
}
interface RoutineView {
  id: string; agentId: string; name: string; prompt: string; executionReview: 'required' | 'auto' | 'yolo'; status: 'active' | 'paused'; revision: number;
  trigger: { kind: 'schedule'; calendar: { frequency: 'daily' | 'weekly' | 'monthly'; timeZone: string; time: string; daysOfWeek?: number[]; dayOfMonth?: number } } | { kind: 'webhook' } | { kind: 'manual' };
  nextDueAt?: string; pendingDueAt?: string; lastRunId?: string; webhookConfigured?: boolean; webhookEnabled: boolean;
}
interface LifePresence { state: 'idle' | 'working' | 'thinking' | 'waiting' | 'paused' | 'blocked' | 'unknown'; label: string; taskId?: string; taskTitle?: string }
interface ConversationSummary { id: string; title: string; revision: number; focusTaskId?: string; taskCount?: number; agentId?: string; standingInstruction?: string; hasStandingInstruction?: boolean; presence?: LifePresence }
interface LastDelivery { taskId: string; taskTitle: string; runId: string; planSummary?: string; artifactTitles?: string[] }
interface AcceptedPractice { claimId: string; text: string; runId: string; evidenceRefs: string[] }
interface SkillProfileView { claimId: string; taskKind: string; methodId: string; version: string; runId: string; evidenceRefs: string[] }
interface TaskModelView { claimId: string; taskKind: string; model: string; provider?: string }
interface TaskKindComparison {
  taskKind: string; runId: string; taskTitle: string;
  methodId?: string; version?: string; model?: string; provider?: string;
  profileMethodId?: string; profileVersion?: string; profileRunId?: string; profileModel?: string; profileProvider?: string;
  differs: boolean; kept: boolean;
  proposal?: { candidateId: string; status: string };
}
interface TaskSettingsView { skills: SkillProfileView[]; models: TaskModelView[]; comparisons?: TaskKindComparison[] }
interface ConversationView extends ConversationSummary { tasks: ConversationTaskView[]; messages: ConversationMessageView[]; hasEarlierMessages?: boolean; lastDelivery?: LastDelivery; acceptedPractice?: AcceptedPractice; taskSettings?: TaskSettingsView }
interface ConversationAttempt { conversationId: string; scope: string; key: string; body: string }
interface ConversationPost { conversation: ConversationView; message: ConversationMessageView; response: string; runId?: string }
interface RuntimeStatus {
  conversationRouting?: boolean;
  executionProfile?: 'fixture' | 'unverified'; modelConfigured: boolean; model?: { model: string; endpoint: string } | null; modelRouting: string; runner: string;
  modelHealth?: { ready: boolean; detail?: string; catalog?: { ready: boolean; detail?: string }; provider?: { ready: boolean; detail?: string } }; skillGovernanceHealth?: { ready: boolean; detail?: string };
  rsiEvaluatorHealth?: { ready: boolean; detail?: string } | null;
  dispatcherHealth?: { ready: boolean; detail?: string } | null; knowledgeConfigured: boolean; brainSemanticSearchConfigured: boolean; brainSemanticIndexHealth?: { ready: boolean; detail?: string } | null;
  toolsConfigured: boolean; toolsHealth?: { ready: boolean; detail?: string } | null;
  projectSourcesConfigured: boolean; evolutionConfigured: boolean; rsiEvaluatorConfigured: boolean; rsiProposalSynthesisConfigured: boolean; skillGovernanceConfigured: boolean;
  rsiAutomation?: { enabled: boolean; autoApproveLowRisk?: boolean; autoRollout?: boolean; autoActivate?: boolean; suiteVersion?: string; inFlight?: boolean; lastRunAt?: string; lastResult?: { inspected: number; evaluated: number; approved: number; shadowed: number; canaried: number; promoted: number; activated: number; skipped: number; failed: number } };
  collaborationConfigured: boolean; projectionConfigured: boolean; projectionSinkConfigured: boolean; domainConfigured: boolean;
  projectionSinkHealth?: { ready: boolean; detail?: string } | null;
  routinesConfigured?: boolean; feishuLifeConfigured?: boolean;
  botTeamConfigured?: boolean;
  botDialogueRouting?: boolean;
  taskSchedulerConfigured: boolean; agentGatewayConfigured: boolean; agentRegistryConfigured: boolean; mode: string; principal?: string; tenantId?: string; roles?: string[];
}
interface RunPage { items: RunSummary[]; nextCursor?: string }
interface GoalPage { goals: GoalSummary[]; nextCursor?: string }
interface ReminderSummary { recurrence?: { intervalMs?: number; calendar?: { frequency: string; timeZone: string; time: string; daysOfWeek?: number[]; dayOfMonth?: number }; maxOccurrences?: number }; id: string; title: string; message: string; dueAt: string; delivery: { channel: string; destination: string }; privacy: string; status: string; occurrence: number; updatedAt: string; lastError?: string }
interface ReminderPage { items: ReminderSummary[]; nextCursor?: string }
interface RunExplanation {
  schemaVersion: 'run-explanation/1'; run: { id: string; status: string; privacy: string; updatedAt: string };
  attention: { kind: string; nextAction: string; blockers: Array<{ kind: string; detail: string; refs: string[] }> };
  plan: { version?: number; hash?: string; summary?: string; tasks: { total: number; pending: number; running: number; succeeded: number }; readyTaskIds: string[]; pendingTaskIds: string[] };
  execution: { eventCount: number; modelCalls: { total: number; started: number; completed: number; failed: number; unknown: number; discarded: number }; tools: { total: number; completed: number; failed: number; unknown: number }; delegations: { total: number; completed: number; failed: number; unknown: number } };
  evidence: { sourceCount: number; artifactCount: number; receiptCount: number; evidenceNodeCount: number; contextManifestId?: string; contextManifestHash?: string; memoryRefs: string[] };
  governance: { model?: { model: string; provider?: string; catalogHash?: string }; skill?: { methodId?: string; version?: string; outcome?: string }; tools: Array<{ id: string; version: string; capabilities: string[] }>; agents: string[] };
  budget: { model?: { limitTokens?: number; usedTokens: number; limitMoneyUsd?: number; usedMoneyUsd?: number; unreportedCalls: number }; external?: { limitCalls?: number; usedCalls: number; limitTokens?: number; usedTokens: number; limitMoneyUsd?: number; usedMoneyUsd?: number; unreportedCalls: number; unreportedTokenCalls: number; unreportedMoneyCalls: number } };
  review?: { verdict: string; confidence?: number; issueCount: number; summary: string };
}
const $ = <T extends HTMLElement = HTMLElement>(id: string): T => document.getElementById(id) as T;
const shareToken = window.location.pathname.match(/^\/share\/([A-Za-z0-9_-]{43})\/?$/)?.[1];
const linkedRunId = window.location.pathname.match(/^\/runs\/(run_[a-f0-9-]{36})\/?$/)?.[1];
const linkedThreadId = window.location.pathname.match(/^\/threads\/(thread_[a-f0-9-]{36})\/?$/)?.[1];
const readOnlyShare = Boolean(shareToken);
// Declared before anything at load can call api() or message(), which read them.
const TOKEN_KEY = 'aeeis.token';
/** Set while the saved token was dropped as unusable: the 401 that follows must not replace that explanation. */
let badTokenNotice = false;
document.body.classList.toggle('shared-run', readOnlyShare);
let currentId = linkedRunId ?? (readOnlyShare || linkedThreadId ? '' : localStorage.getItem('aeeis.run') ?? '');
let entryEpoch = 0;
document.body.classList.toggle('thread-page', Boolean(linkedThreadId));
let threadPagesAfter = [0];
let threadNextAfter: number | undefined;
let threadRuns: ThreadRun[] = [];
let pendingFollowup: { key: string; body: unknown; signature: string } | undefined;
let followupSubmitting = false;
let conversationEnabled = false;
let botDialogueRouting = false;
let canCreateChannels = false;
const dialogueRoomIds = new Map<string, string>();
function archivedDialogue(): boolean {
  const id = conversation ? dialogueRoomIds.get(conversation.id) : undefined;
  return Boolean(id && roomSummaries.find(room => room.id === id)?.status === 'archived');
}
let conversationScope = '';
let conversationEpoch = 0;
let conversation: ConversationView | undefined;
let conversationList: ConversationSummary[] = [];
let conversationBusy = false;
let conversationRefreshing = false;
let conversationNeedsRefresh = false;
let conversationReplyId: string | undefined;
let conversationCorrectionId: string | undefined;
let conversationAttempt: ConversationAttempt | undefined;
let conversationRenderSignature = '';
let standingBoundId = '';
let practiceBoundRunId = '';
const CONVERSATION_SELECTION = 'aeeis.conversation';
const CONVERSATION_SCOPE = 'aeeis.conversation-scope';
const CONVERSATION_PENDING = 'aeeis.conversation-pending';
const LIFE_HOME = 'aeeis.life.aeeis';
let aeeisConversationId = linkedRunId || linkedThreadId || readOnlyShare ? '' : (localStorage.getItem(LIFE_HOME) ?? '');
const lifeOpening = new Set<string>();
let selectedCandidateId = localStorage.getItem('aeeis.candidate') ?? '';
let current: RunView | undefined;
type InputPanelMode = 'answer' | 'reconcile' | 'reconcile-cancelled';
let inputPanelMode: InputPanelMode = 'answer';
let cancelArmedRunId = '';
const minimalMode = !readOnlyShare && !linkedThreadId && localStorage.getItem('aeeis.minimal-mode') !== '0';
document.body.classList.toggle('minimal-mode', minimalMode);
let quickRunReady = false;
let intentPresetsOpen = false;
let recentRunsOpen = false;
let attentionInboxOpen = false;
let currentRunOpen = !minimalMode || Boolean(currentId);
let polling = false;
let goalViewSignature = '';
let modelConfigured = false;
let routinesConfigured = false;
/** The routines of the person whose life thread is open. Loaded when that person changes. */
let routineState: { agentId: string; items: RoutineView[] } | undefined;
let routineLoading = '';
/** A webhook secret is shown once, right after it is made. */
let routineSecret: { routineId: string; secret: string } | undefined;
let runtimeModel = '';
let taskModelBound = '';
let evolutionConfigured = false;
let taskSchedulerConfigured = false;
let sessionPrincipal = '';
let eventStreamRunId = '';
let eventStreamAbort: AbortController | undefined;
let eventStreamCursor: string | undefined;
let eventStreamRefreshQueued = false;
let reminderNextCursor: string | undefined;
let reminderItems: ReminderSummary[] = [];
let reminderStatusFilter = '';
let runFilter = localStorage.getItem('aeeis.run-filter') ?? 'all';
let runSummaries: RunSummary[] = [];
interface BotGroups { groups: Array<{ id: string; name: string }>; placement: Record<string, string> }
type BotMark = 'letter' | 'round' | 'square' | 'diamond' | 'drop';
interface RosterBot { id: string; name: string; note: string; demo: boolean; mark?: BotMark; color?: string; background?: string; role?: string; held?: string; autonomy?: BotAutonomy }
interface StoredBot { id: string; name: string; mark: BotMark; color: string; background: string; role?: string; held?: string }
const CUSTOM_BOTS_KEY = 'aeeis.custom-bots';
const LOCAL_BOT_ACCOUNT = 'aeeis.custom-bots-account';
const CUSTOM_BOT_CAP = 30;
const BOT_MARKS: BotMark[] = ['letter', 'round', 'square', 'diamond', 'drop'];
const BOT_MARK_LABEL: Record<BotMark, string> = { letter: '名字', round: '圆', square: '方', diamond: '菱', drop: '角' };
const BOT_COLORS = ['#171717', '#6b4a32', '#b42318', '#c2410c', '#a16207', '#176b45', '#0f766e', '#1d4e89', '#6d28d9', '#be185d', '#57534e'];
const DEMO_BOTS: RosterBot[] = STARTER_BOTS.map(bot => ({ id: bot.id, name: bot.name, note: bot.role, demo: true }));
let agentSummaries: AgentSummary[] = [];
let agentsLoaded = false;
let ownedBotRecords: RosterBot[] = [];
/** The server lets Bots reply, propose and hand off on their own. */
let botsActive = false;
let sideThreadRooms: RoomSummary[] = [];
const SIDE_THREAD = '侧线程';
const BOT_AUTONOMY_LABEL: Record<BotAutonomy, string> = { quiet: '只记录，不回复', reply: '回复，提议等我', auto: '自动开工（auto 审批）', yolo: '放手（yolo 审批）' };
type BotAutonomy = 'quiet' | 'reply' | 'auto' | 'yolo';
let localBotsAdopted = false;
let localBotNote = '';
interface OwnedBotView { id: string; name: string; mark: BotMark; color: string; background: string; role?: string; autonomy?: BotAutonomy; createdAt?: string; updatedAt?: string }
let roomSummaries: RoomSummary[] = [];
let botGroups: BotGroups | undefined;
let selectedBotId = linkedRunId || linkedThreadId || readOnlyShare ? 'aeeis' : (localStorage.getItem('aeeis.bot') || 'aeeis');
let openGroupId = '';
let groupDraftOpen = false;
let groupMembers: RoomMemberSummary[] = [];
let groupEvents: SessionEventSummary[] = [];
let laterChannelEvents: SessionEventSummary[] = [];
let liveChannelEvents: SessionEventSummary[] = [];
let groupEventCursor: string | undefined;
let channelLoadedRoomId = '';
let channelEventsCaughtUp = false;
let channelReadEpoch = 0;
const CHANNEL_TRANSCRIPT_PAGE = 50;
let channelHistoryPages = 1;
let channelTranscriptKey = '';
let channelReadQueue: Promise<void> = Promise.resolve();
let channelReadFlight: Promise<void> | undefined;
const handoffViews = new Map<string, ConversationView>();
let channelBoardOpen = false;
let channelBoardEpoch = 0;
/** The server's board for the open channel. Decisions come only from here. */
let channelBoardState: ChannelBoardView | undefined;
let channelBoardRoomId = '';
let channelBoardLoad: Promise<void> | undefined;
/** What the transcript held when the board was last read; a change means new events. */
let channelBoardSeen = '';
/** Sequence to read older messages from; empty once the first message is loaded. */
let channelOlderCursor: string | undefined;
type StudioView = 'floor' | 'graph' | 'timeline';
type DigestWindow = 'day' | 'week';
let studioView: StudioView = 'floor';
let studioPrivacy = false;
let studioIndex = -1;
let studioPlaying = false;
let studioSpeed: 1 | 2 = 1;
let studioTimer: number | undefined;
let studioKey = '';
let digestWindow: DigestWindow = 'week';
let handoffEpoch = 0;
const CITATION_ID = /^[a-z][a-z0-9_.-]{1,127}$/;
const draftAgents = new Set<string>();
let draftPeople: string[] = [];
const directMembers = new Map<string, string>();
const directOpening = new Set<string>();
let directIndexKey = '';
let directIndexPromise: Promise<void> = Promise.resolve();
const AEEIS_EMPTY_COPY = '这是一个 Bot，可以同时推进多项任务。点开左侧任务只是查看这次执行，其他任务不会因此停掉。';
let timelineFilter = localStorage.getItem('aeeis.timeline-filter') ?? 'all';
const MAX_MATERIAL_FILES = 8;
const MAX_MATERIAL_FILE_BYTES = 1_000_000;
const MAX_MATERIAL_CONTENT_LENGTH = 30_000;
let materialFilesLoading = false;
let selectedMaterialFiles: Array<{ name: string; content: string; size: number }> = [];
let materialFileReadSequence = 0;
const ATTENTION_STATUSES = new Set(['needs_approval', 'needs_input', 'waiting_external', 'unknown', 'failed']);
const ACTIVE_STATUSES = new Set(['queued', 'planning', 'running', 'reviewing', 'paused']);
const DONE_STATUSES = new Set(['succeeded', 'cancelled']);
function runStatusLabel(status: string): string {
  const labels: Record<string, string> = {
    queued: '排队中', planning: '规划中', needs_approval: '待批准', running: '执行中', reviewing: '复核中',
    needs_input: '待补充', waiting_external: '待回执', unknown: '待核查', unreadable: '读不到', paused: '已暂停', succeeded: '已完成', failed: '失败', cancelled: '已取消',
    pending: '待处理', ready: '可执行', active: '进行中', in_progress: '进行中', completed: '已完成', done: '已完成', started: '执行中', accepted: '已接收',
    collecting: '收集中', held: '已暂停', approved: '已批准', evaluating: '评估中', shadowing: '影子验证中', canarying: '灰度验证中', promoted: '已晋升', rolled_back: '已回滚',
    scheduled: '已排程', firing: '触发中', projected: '已投影', discovered: '已发现', admitted: '已批准', revoked: '已撤销', archived: '已归档', stopped: '已停止',
    superseded: '已被替代', retracted: '已撤回', revoked_pending: '待撤销',
  };
  return labels[status] ?? status;
}
function privacyLabel(value: string | undefined): string {
  return ({ public: '公开', internal: '内部', confidential: '机密', private: '私人' } as Record<string, string>)[value ?? 'internal'] ?? value ?? '内部';
}
function roleLabel(value: string): string {
  return ({ owner: '所有者', editor: '编辑者', viewer: '查看者', agent: 'Agent' } as Record<string, string>)[value] ?? value;
}
function frequencyLabel(value: string): string {
  return ({ daily: '每天', weekly: '每周', monthly: '每月', once: '一次性', interval: '固定间隔' } as Record<string, string>)[value] ?? value;
}
function runtimeLabel(value: string): string {
  return ({ unconfigured: '未配置', local: '本地执行', temporal: 'Temporal 调度', fixture: 'Fixture 演示' } as Record<string, string>)[value] ?? value;
}
function eventLabel(type: string): string {
  const labels: Record<string, string> = {
    'run.created': '已接收', 'run.updated': '状态更新', 'run.planned': '计划生成', 'run.approved': '计划已批准',
    'run.started': '开始执行', 'task.started': '任务开始', 'task.completed': '任务完成', 'run.reviewed': '审核完成',
    'run.completed': '运行完成', 'run.failed': '运行异常', 'run.cancelled': '运行已取消',
    'plan.budgets_updated': '预算已更新', 'plan.proposed': '计划已生成', 'plan.approved': '计划已批准', 'plan.revised': '计划已更新',
    'plan.auto_approved': '计划已按审核档自动放行', 'plan.approval_requested': '模型请求批准',
    'model.selected': '模型已选择', 'model.started': '模型开始调用', 'model.completed': '模型调用完成', 'model.usage.recorded': '模型用量已记录',
    'skill.selected': '工作方式已选择', 'skill.completed': '工作方式已完成',
    'tool.requested': '等待工具回执', 'tool.completed': '工具已返回', 'tool.failed': '工具调用失败', 'tool.unknown': '工具结果待核查', 'tool.reconciled': '工具结果已核查',
    'agent.requested': '已请求外部 Agent', 'agent.progress': '外部 Agent 有进展', 'agent.completed': '外部 Agent 已完成', 'agent.failed': '外部 Agent 调用失败', 'agent.unknown': '外部 Agent 结果待核查',
    'external.usage.recorded': '外部用量已记录', 'external.usage_recorded': '外部用量已记录', 'external.budget_stopped': '外部预算已停止',
    'model.usage_recorded': '模型用量已记录',
    'input.requested': '等待补充信息', 'input.received': '已收到补充信息', 'review.requested': '开始独立审核', 'review.completed': '审核完成',
    'plan.repair_requested': '计划格式修复中', 'plan.revision_requested': '已请求修改计划', 'run.paused': '运行已暂停', 'run.resumed': '运行已继续', 'run.taken_over': '人已接管', 'takeover.tool': '人在 Bot 的工作区里做了一步', 'run.handed_back': '人已交还，Bot 接着做',
    'run.retry_requested': '已请求重试', 'run.reconciled': '状态已对齐', 'run.interrupted': '运行中断', 'run.cancel.workflow_failed': '取消后台任务失败',
    'run.cancelled_reconcile_requested': '已请求核查取消前的调用', 'run.cancelled_reconcile_failed': '取消前的调用核查失败', 'artifact.created': '产物已生成',
    'model.unknown': '模型结果待核查', 'model.reconciled': '模型结果已核查', 'model.validation_failed': '模型输出校验失败', 'model.budget_stopped': '模型预算已停止',
    'task.execution.started': '任务开始执行', 'task.execution.completed': '任务执行完成', 'task.execution.failed': '任务执行失败',
    'context.summary_active': '压缩摘要已写入', 'context.summary_rejected': '压缩摘要未采用',
    'context.summary_discarded': '压缩摘要已丢弃', 'context.summary_failed': '压缩摘要未生成',
  };
  const normalized = type.trim().replace(/\s+/g, '.');
  return labels[type] ?? labels[normalized] ?? normalized.replace(/^run\./, '').replace(/[._-]+/g, ' ');
}
function describeEvent(type: string, data?: { phase?: string; reason?: string; source?: string; actor?: string }, verbose = false): string {
  if (type === 'plan.proposed' && data?.source === 'direct') return '直接计划已写入';
  if (type === 'plan.auto_approved' && data?.actor === 'policy:direct') return '直接计划已按边界放行';
  const compaction = data?.phase === 'compaction' || (typeof data?.reason === 'string' && data.reason.startsWith('compaction'));
  if (compaction) {
    const short: Record<string, string> = {
      'model.started': '整理任务记忆', 'model.completed': '记忆整理完成', 'model.failed': '记忆整理失败',
      'model.unknown': '记忆整理待核查', 'model.result_discarded': '记忆整理已丢弃',
    };
    const full: Record<string, string> = {
      'model.started': '开始整理任务记忆（摘要不是证据）', 'model.completed': '任务记忆整理完成（摘要不是证据）',
      'model.failed': '任务记忆整理失败（未写入摘要）', 'model.unknown': '任务记忆整理结果待核查（未写入摘要）',
      'model.result_discarded': '过期的任务记忆整理已丢弃（不是证据）',
    };
    if (short[type]) return verbose ? full[type]! : short[type]!;
  }
  if (verbose && type.startsWith('context.summary_')) {
    const full: Record<string, string> = {
      'context.summary_active': '已写入压缩摘要（不是证据，不改变讨论焦点）',
      'context.summary_rejected': '压缩摘要未采用（不是证据）',
      'context.summary_discarded': '压缩摘要已丢弃（不是证据）',
      'context.summary_failed': '压缩摘要未生成（不是证据）',
    };
    if (full[type]) return full[type];
  }
  return eventLabel(type);
}
function compactionProgress(event: { type: string; data?: { phase?: string; reason?: string } } | undefined): [string, string] | undefined {
  if (!event) return;
  const compaction = event.data?.phase === 'compaction' || (typeof event.data?.reason === 'string' && event.data.reason.startsWith('compaction')) || event.type.startsWith('context.summary_');
  if (!compaction) return;
  const detail = '压缩摘要只留给该任务后续引用。它不是证据，也不改变讨论焦点。';
  if (event.type === 'context.summary_active' || event.type === 'model.completed') return ['已整理任务记忆', detail];
  if (event.type === 'model.started') return ['正在整理任务记忆', detail];
  return ['任务记忆未写入', detail];
}

// Keep the control rail useful at a glance. Advanced modules remain in the DOM
// (and keep their existing IDs/handlers) but can be opened on demand.
function setupAdvancedPanels(): void {
  const storageKey = 'aeeis.advanced-panels';
  let stored: Record<string, boolean> = {};
  try { stored = JSON.parse(localStorage.getItem(storageKey) ?? '{}') as Record<string, boolean>; }
  catch { stored = {}; }
  document.querySelectorAll<HTMLElement>('.advanced-panel').forEach((panel, index) => {
    const heading = panel.querySelector('h2');
    if (!heading || panel.querySelector('.panel-toggle')) return;
    const key = panel.id || `panel-${index}-${(heading.textContent ?? '').trim()}`;
    panel.dataset.panelKey = key;
    if (!panel.id) panel.id = `advanced-panel-${index}`;
    const toggle = document.createElement('button');
    toggle.type = 'button';
    toggle.className = 'panel-toggle';
    const expanded = stored[key] === true;
    toggle.textContent = expanded ? '收起' : '展开';
    toggle.setAttribute('aria-expanded', String(expanded));
    toggle.setAttribute('aria-controls', panel.id);
    heading.insertAdjacentElement('afterend', toggle);
    panel.classList.toggle('collapsed', !expanded);
    toggle.addEventListener('click', () => {
      const isExpanded = !panel.classList.toggle('collapsed');
      toggle.textContent = isExpanded ? '收起' : '展开';
      toggle.setAttribute('aria-expanded', String(isExpanded));
      stored[key] = isExpanded;
      localStorage.setItem(storageKey, JSON.stringify(stored));
    });
  });
}

setupAdvancedPanels();
function setupMinimalSections(): void {
  const selectors = ['#execution-graph', '#evidence-graph', '#graph', '#sources', '#governance', '#external-effects', '#agent-progress', '#events', '#timeline'];
  for (const selector of selectors) document.querySelector(selector)?.closest('section')?.classList.add('minimal-detail-section');
  const secondarySelectors = ['#explanation-section', '#plan-summary', '#execution-graph', '#evidence-graph', '#sources', '#governance', '#external-effects', '#agent-progress', '#artifacts', '#timeline', '#events'];
  for (const selector of secondarySelectors) document.querySelector(selector)?.closest('section')?.classList.add('run-secondary');
}
setupMinimalSections();
type ComputerTab = 'run' | 'setup' | 'status' | 'about';
let computerOpen = false;
let computerTab: ComputerTab = 'setup';
const COMPUTER_TITLES: Record<ComputerTab, string> = {
  run: '这次运行', setup: '设置', status: '运行状态', about: '关于它',
};
function presenceOf(status?: string): { state: string; label: string } {
  if (!status) return { state: 'idle', label: '空闲' };
  if (status === 'planning' || status === 'reviewing') return { state: 'thinking', label: '思考中' };
  if (status === 'running' || status === 'queued') return { state: 'working', label: status === 'queued' ? '排队' : '执行中' };
  if (status === 'needs_approval' || status === 'needs_input' || status === 'waiting_external' || status === 'paused') return { state: 'waiting', label: '等你' };
  if (status === 'succeeded') return { state: 'done', label: '完成' };
  if (status === 'failed' || status === 'unknown' || status === 'cancelled') return { state: 'blocked', label: runStatusLabel(status) };
  return { state: 'idle', label: runStatusLabel(status) };
}
function botPresence(runs: RunSummary[]): { state: string; label: string } {
  const statuses = runs.map(run => run.status);
  if (statuses.some(status => status === 'running' || status === 'queued')) return presenceOf('running');
  if (statuses.some(status => status === 'planning' || status === 'reviewing')) return presenceOf('planning');
  if (statuses.some(status => status === 'needs_approval' || status === 'needs_input' || status === 'waiting_external' || status === 'paused')) return presenceOf('needs_approval');
  if (statuses.some(status => status === 'failed' || status === 'unknown')) return presenceOf('failed');
  if (statuses.some(status => status === 'succeeded')) return presenceOf('succeeded');
  return presenceOf(undefined);
}
function entryShowsBot(): boolean {
  return !currentRunOpen && !openGroupId && !document.body.classList.contains('group-draft') && !readOnlyShare && !linkedThreadId;
}
function syncBotRow(): void {
  if (conversationEnabled) return;
  const state = botPresence(runSummaries);
  const label = $('gb-bot-presence');
  if (label) label.textContent = runSummaries.length ? `${state.label} · ${runSummaries.length} 项任务` : state.label;
  const avatar = document.querySelector<HTMLElement>('#gb-bot .roster-avatar');
  if (avatar) avatar.dataset.state = state.state;
  const pressed = entryShowsBot();
  const visible = activeBotId();
  document.querySelectorAll<HTMLButtonElement>('#bots [data-bot-id]').forEach(row => {
    row.setAttribute('aria-pressed', String(pressed && row.dataset.botId === visible));
  });
  syncComposerForBot();
}
function syncEmptyCopy(): void {
  const empty = $('empty');
  const heading = empty?.querySelector('h2');
  const copy = empty?.querySelector('p');
  const bot = botById(activeBotId());
  if (heading) heading.textContent = entryShowsBot() && bot ? bot.name : 'AEEIS';
  if (copy) {
    copy.textContent = !entryShowsBot() || !bot || bot.id === 'aeeis'
      ? AEEIS_EMPTY_COPY
      : bot.demo
        ? '这是内置的一位 Bot。把要做的事直接发给它就能开工，计划和审批都在这里处理。'
        : '这位已经准入。单独对话还没有接上，可以在群聊里点名。';
  }
}
/** The entry, built-in starter Bots and live account Bots use the local execution path; admitted external agents only discuss. */
function localBotCanExecute(id = activeBotId()): boolean {
  return id === 'aeeis' || Boolean(starterBot(id)) || ownedBotRecords.some(bot => bot.id === id);
}
function syncComposerForBot(): void {
  const other = entryShowsBot() && !localBotCanExecute();
  const form = $('quick-run');
  const input = $<HTMLInputElement>('quick-goal');
  const submit = document.querySelector<HTMLButtonElement>('#quick-run button[type="submit"]');
  const busy = form?.dataset.busy === 'true';
  if (input) {
    if (!busy) input.disabled = other;
    input.placeholder = other ? '这位成员仅支持讨论' : '写下要这个 Bot 推进的结果，然后发送';
  }
  if (!submit || busy) return;
  if (other) {
    submit.disabled = true;
    submit.title = '这位成员不支持本地执行';
    if (submit.childNodes[0]) submit.childNodes[0].textContent = '仅讨论 ';
    return;
  }
  submit.disabled = !quickRunReady;
  submit.title = quickRunReady ? '发送' : '请先连接模型';
  if (submit.childNodes[0]) submit.childNodes[0].textContent = quickRunReady ? '发送 ' : '等待连接 ';
}
function syncComposerHeading(): void {
  const heading = document.querySelector('.command-context h2');
  if (!heading) return;
  if (openGroupId) heading.textContent = '发到群里';
  else if (entryShowsBot()) heading.textContent = `给 ${botById(activeBotId())?.name ?? 'AEEIS'} 发消息`;
  else heading.textContent = '给 AEEIS 发消息';
}
/** A Run's goal as people read it. Runs started on a life thread carry a header for the model
 * (私聊、说话人、任务、当前请求) with internal ids; people see the task line. */
function runTitle(run: { goal: string }): string {
  if (!/^(私聊|说话人)：/.test(run.goal)) return run.goal;
  return /^任务：(.+)$/m.exec(run.goal)?.[1]?.trim() || run.goal;
}
function mirrorShell(titleText: string, presenceText: string, state?: string): void {
  const title = $('gb-title');
  const presence = $('gb-presence');
  const entryTitle = $('entry-title');
  const entryPresence = $('entry-presence');
  if (title) title.textContent = titleText;
  if (entryTitle) entryTitle.textContent = titleText;
  if (presence) {
    if (state) presence.dataset.state = state;
    presence.textContent = presenceText;
  }
  if (entryPresence) entryPresence.textContent = presenceText;
}
function syncPresence(run?: RunView): void {
  const title = $('gb-title');
  const presence = $('gb-presence');
  syncBotRow();
  syncComposerHeading();
  if (conversationEnabled) { syncEntrySurface(); return; }
  if (!title || !presence) return;
  if (document.body.classList.contains('group-draft') || groupDraftOpen) {
    mirrorShell('新建群聊', `2 到 ${groupCap()} 人 · AEEIS 始终在场`, 'idle');
    return;
  }
  if (openGroupId) {
    const room = roomSummaries.find(item => item.id === openGroupId);
    const names = ['AEEIS', ...groupMembers.map(member => participantLabel(member.principalId))];
    mirrorShell(room?.title ?? '群聊', `${names.length} 人 · ${names.join('、')}`, 'idle');
    return;
  }
  const bot = botById(activeBotId());
  if (entryShowsBot() && bot && bot.id !== 'aeeis') {
    mirrorShell(bot.name, bot.demo ? '内置 · 可以直接派活' : '已准入 · 单独对话还没接上', 'idle');
    syncEmptyCopy();
    renderBotPlacement();
    syncShellClasses();
    return;
  }
  const active = Boolean(run && currentRunOpen);
  const state = presenceOf(active ? run?.status : undefined);
  const presenceState = active ? state.state : botPresence(runSummaries).state;
  mirrorShell('AEEIS', active && run ? `${state.label} · ${runTitle(run)}` : (runSummaries.length ? '入口 · 任务都还在跑' : '空闲 · 可以同时交给它几件事'), presenceState);
  syncEmptyCopy();
  renderBotPlacement();
}
function syncTranscriptEmpty(): void {
  const empty = $('empty');
  if (!empty) return;
  empty.hidden = readOnlyShare || Boolean(linkedThreadId) || currentRunOpen || Boolean(current) || Boolean(openGroupId) || document.body.classList.contains('group-draft');
  syncEmptyCopy();
  renderBotPlacement();
}
function setComputerOpen(open: boolean, tab?: ComputerTab): void {
  if (tab) computerTab = tab;
  computerOpen = open;
  const panel = $('gb-computer');
  if (panel) {
    panel.hidden = !open;
    panel.dataset.tab = computerTab;
  }
  document.body.classList.toggle('computer-open', open);
  const toggle = $('gb-computer-toggle') as HTMLButtonElement | null;
  if (toggle) {
    toggle.setAttribute('aria-pressed', String(open));
    toggle.textContent = open ? '收起工作台' : '打开它的工作台';
  }
  const entryComputer = $('entry-computer') as HTMLButtonElement | null;
  if (entryComputer) {
    entryComputer.setAttribute('aria-pressed', String(open));
    entryComputer.textContent = open ? '关上工作台' : '打开它的工作台';
  }
  const title = $('gb-computer-title');
  if (title) title.textContent = COMPUTER_TITLES[computerTab];
  document.querySelectorAll<HTMLButtonElement>('[data-computer-tab]').forEach(button => {
    const selected = open && button.dataset.computerTab === computerTab;
    button.setAttribute('aria-pressed', String(selected));
    button.classList.toggle('is-selected', selected);
  });
}
function closeComputer(): void {
  const tab = computerTab;
  setComputerOpen(false);
  if (tab === 'run' && runDetailsMode) setRunDetailsMode(false);
  if (tab === 'setup' && detailsMode) setDetailsMode(false);
}
let runDetailsMode = localStorage.getItem('aeeis.run-details-mode') === '1';
function syncRunDetailsToggleLabel(): void {
  const control = $('run-details-toggle') as HTMLButtonElement | null;
  if (!control) return;
  control.textContent = runDetailsMode ? '收起工作台' : '打开它的工作台';
  control.setAttribute('aria-expanded', String(runDetailsMode));
  control.title = runDetailsMode ? '收起图、证据和事件' : '打开它的工作台，查看图、证据和事件';
}
function setRunDetailsMode(enabled: boolean): void {
  runDetailsMode = enabled;
  document.body.classList.toggle('run-details-mode', enabled);
  syncRunDetailsToggleLabel();
  localStorage.setItem('aeeis.run-details-mode', enabled ? '1' : '0');
  if (enabled) setComputerOpen(true, 'run');
}
setRunDetailsMode(runDetailsMode);
($('run-details-toggle') as HTMLButtonElement | null)?.addEventListener('click', () => {
  const next = !runDetailsMode;
  setRunDetailsMode(next);
  if (!next && computerTab === 'run') setComputerOpen(false);
});
function syncCurrentRunToggle(run?: RunView): void {
  const control = $('current-run-toggle') as HTMLButtonElement | null;
  if (!control) return;
  const hasRun = Boolean(run ?? current ?? currentId);
  control.hidden = !hasRun;
  control.setAttribute('aria-expanded', String(currentRunOpen));
  control.textContent = currentRunOpen
    ? '收起当前运行'
    : `当前运行${run ? ` · ${runStatusLabel(run.status)}` : ''}`;
  control.title = currentRunOpen ? '收起当前运行工作区' : '查看当前运行、交付和下一步';
  control.dataset.state = currentRunOpen ? 'expanded' : 'ready';
}
function setCurrentRunOpen(enabled: boolean): void {
  const opening = enabled && !currentRunOpen;
  currentRunOpen = enabled;
  if (!enabled && runDetailsMode) setRunDetailsMode(false);
  if (!enabled && computerTab === 'run') setComputerOpen(false);
  const detail = $('detail');
  if (detail) detail.hidden = !enabled || !current;
  document.body.classList.toggle('run-open', enabled && Boolean(current || currentId));
  if (opening) document.body.classList.remove('roster-focus');
  syncTranscriptEmpty();
  syncCurrentRunToggle(current);
  syncPresence(current);
}
setCurrentRunOpen(currentRunOpen);
($('current-run-toggle') as HTMLButtonElement | null)?.addEventListener('click', () => {
  const next = !currentRunOpen;
  setCurrentRunOpen(next);
  if (next) window.requestAnimationFrame(() => $('run-workspace')?.scrollIntoView({ behavior: 'smooth', block: 'start' }));
});
function setupRunPhaseNavigation(): void {
  const targets: Record<string, string> = {
    goal: '#command-center',
    plan: '#graph',
    execute: '#execution-graph',
    proof: '#evidence-graph',
  };
  document.querySelectorAll<HTMLElement>('#run-phases [data-phase]').forEach(phase => {
    const key = phase.dataset.phase ?? '';
    const selector = targets[key];
    if (!selector) return;
    phase.setAttribute('role', 'button');
    phase.tabIndex = 0;
    phase.setAttribute('aria-controls', selector.slice(1));
    const jump = (): void => {
      if (key !== 'goal') setRunDetailsMode(true);
      const target = document.querySelector<HTMLElement>(selector);
      target?.closest('section')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    };
    phase.addEventListener('click', jump);
    phase.addEventListener('keydown', event => {
      if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); jump(); }
    });
  });
}
setupRunPhaseNavigation();
let focusMode = localStorage.getItem('aeeis.focus-mode') === '1';
function setFocusMode(enabled: boolean): void {
  focusMode = enabled;
  document.body.classList.toggle('focus-mode', enabled);
  const control = $('focus-toggle');
  if (control) control.textContent = enabled ? '退出专注模式' : '专注当前运行';
  localStorage.setItem('aeeis.focus-mode', enabled ? '1' : '0');
}
setFocusMode(focusMode);
($('focus-toggle') as HTMLButtonElement | null)?.addEventListener('click', () => setFocusMode(!focusMode));
let detailsMode = !minimalMode && localStorage.getItem('aeeis.details-mode') === '1';
function syncConfigurationNotice(): void {
  const notice = $('configuration');
  if (!notice.dataset.fullText) return;
  notice.textContent = minimalMode && !detailsMode ? (notice.dataset.minimalText ?? notice.dataset.fullText) : notice.dataset.fullText;
  notice.dataset.state = quickRunReady ? 'ready' : 'attention';
}
function syncDetailsToggleLabel(): void {
  const control = $('details-toggle') as HTMLButtonElement | null;
  if (!control) return;
  control.textContent = detailsMode ? '收起设置' : quickRunReady ? '更多设置' : authRequired ? '输入令牌' : '连接模型';
  control.title = detailsMode ? '收起运行配置' : quickRunReady ? '展开运行边界和治理设置' : '打开令牌和模型配置';
  control.dataset.state = detailsMode ? 'expanded' : quickRunReady ? 'ready' : 'attention';
  control.setAttribute('aria-expanded', String(detailsMode));
}
function setDetailsMode(enabled: boolean, options?: { reveal?: boolean }): void {
  detailsMode = enabled;
  document.body.classList.toggle('details-mode', enabled);
  if (enabled && options?.reveal) setComputerOpen(true, 'setup');
  if (!enabled && options?.reveal && computerTab === 'setup' && !runDetailsMode) setComputerOpen(false);
  syncDetailsToggleLabel();
  localStorage.setItem('aeeis.details-mode', enabled ? '1' : '0');
  syncConfigurationNotice();
}
setDetailsMode(detailsMode);
($('details-toggle') as HTMLButtonElement | null)?.addEventListener('click', () => {
  if (!detailsMode && !quickRunReady) {
    openConfiguration();
    return;
  }
  setDetailsMode(!detailsMode, { reveal: true });
  if (detailsMode) {
    setFocusMode(false);
    $('new-run-panel')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
});
function openConfiguration(): void {
  setDetailsMode(true, { reveal: true });
  setFocusMode(false);
  $('access-panel')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  window.requestAnimationFrame(() => $<HTMLInputElement>('token')?.focus());
}
($('config-action') as HTMLButtonElement | null)?.addEventListener('click', () => {
  openConfiguration();
});
function setIntentPresetsOpen(enabled: boolean): void {
  intentPresetsOpen = enabled;
  const presets = $('intent-presets');
  const control = $('intent-toggle') as HTMLButtonElement | null;
  if (presets) presets.hidden = !enabled;
  if (control) {
    control.textContent = enabled ? '隐藏示例' : '示例';
    control.setAttribute('aria-expanded', String(enabled));
  }
}
setIntentPresetsOpen(!currentId && !readOnlyShare && !linkedThreadId);
($('intent-toggle') as HTMLButtonElement | null)?.addEventListener('click', () => {
  const presets = $('intent-presets');
  setIntentPresetsOpen(Boolean(presets?.hidden));
});
function setRecentRunsOpen(enabled: boolean): void {
  recentRunsOpen = enabled;
  const list = $('minimal-recent-runs');
  const control = $('recent-runs-toggle') as HTMLButtonElement | null;
  if (list) list.hidden = !enabled;
  if (control) {
    control.textContent = enabled ? '隐藏最近运行' : '最近运行';
    control.setAttribute('aria-expanded', String(enabled));
  }
}
setRecentRunsOpen(false);
($('recent-runs-toggle') as HTMLButtonElement | null)?.addEventListener('click', () => {
  const list = $('minimal-recent-runs');
  setRecentRunsOpen(Boolean(list?.hidden));
});
function setAttentionInboxOpen(enabled: boolean): void {
  attentionInboxOpen = enabled;
  const panel = $('attention-inbox');
  const control = $('attention-toggle') as HTMLButtonElement | null;
  if (panel) panel.hidden = !enabled;
  if (control) {
    const count = control.dataset.count ?? '';
    control.textContent = enabled ? '收起待处理' : count ? `待处理 · ${count}` : '待处理';
    control.setAttribute('aria-expanded', String(enabled));
  }
}
setAttentionInboxOpen(false);
($('attention-toggle') as HTMLButtonElement | null)?.addEventListener('click', () => {
  const panel = $('attention-inbox');
  setAttentionInboxOpen(Boolean(panel?.hidden));
  if (attentionInboxOpen) {
    window.requestAnimationFrame(() => $('attention-inbox')?.scrollIntoView({ behavior: 'smooth', block: 'start' }));
  }
});
function showEntry(): void {
  selectedBotId = 'aeeis';
  localStorage.setItem('aeeis.bot', 'aeeis');
  entryEpoch += 1;
  leaveGroup();
  stopRunEventStream();
  currentId = '';
  current = undefined;
  localStorage.removeItem('aeeis.run');
  document.body.classList.remove('roster-focus');
  document.body.classList.add('draft-open');
  setCurrentRunOpen(false);
  if (!readOnlyShare && !linkedThreadId && window.location.pathname !== '/') window.history.replaceState(null, '', '/');
  setIntentPresetsOpen(true);
  renderBotRoster();
  renderRunQueue(runSummaries);
}
document.querySelectorAll<HTMLButtonElement>('[data-computer-tab]').forEach(button => {
  button.addEventListener('click', () => {
    const tab = button.dataset.computerTab as ComputerTab | undefined;
    if (!tab) return;
    if (computerOpen && computerTab === tab) {
      closeComputer();
      return;
    }
    if (tab === 'run') {
      if (!current && !currentId) return;
      setRunDetailsMode(true);
      return;
    }
    if (tab === 'setup') setDetailsMode(true, { reveal: true });
    else setComputerOpen(true, tab);
  });
});
($('gb-computer-toggle') as HTMLButtonElement | null)?.addEventListener('click', () => {
  if (computerOpen) closeComputer();
  else if (current || currentId) setRunDetailsMode(true);
  else setComputerOpen(true, 'setup');
});
($('gb-computer-close') as HTMLButtonElement | null)?.addEventListener('click', () => closeComputer());
($('group-person') as HTMLInputElement | null)?.addEventListener('keydown', event => {
  if (event.key !== 'Enter') return;
  event.preventDefault();
  addDraftPerson();
});
($('gb-back') as HTMLButtonElement | null)?.addEventListener('click', () => showRoster());
document.querySelectorAll<HTMLAnchorElement>('nav.workbench-nav a').forEach(link => {
  link.addEventListener('click', event => {
    const href = link.getAttribute('href') ?? '';
    const tabs: Record<string, ComputerTab | 'conversation'> = {
      '#new-run-panel': 'setup',
      '#run-workspace': 'conversation',
      '#goals-panel': 'setup',
      '#reminders-panel': 'setup',
      '#rsi-panel': 'setup',
      '#collaboration-panel': 'setup',
      '#system-status': 'status',
    };
    const target = tabs[href];
    if (!target) return;
    event.preventDefault();
    if (target === 'conversation') {
      if (current || currentId) setCurrentRunOpen(true);
      $('run-workspace')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      return;
    }
    if (target === 'setup') setDetailsMode(true, { reveal: true });
    else setComputerOpen(true, target);
    window.requestAnimationFrame(() => document.querySelector<HTMLElement>(href)?.scrollIntoView({ behavior: 'smooth', block: 'start' }));
  });
});
interface OwnerActionPolicyView { allow: string[]; block: string[]; revision: number }
let ownerActionPolicy: OwnerActionPolicyView | undefined;
function actionPolicyView(value: unknown): OwnerActionPolicyView {
  const raw = (value && typeof value === 'object' ? value : {}) as Partial<OwnerActionPolicyView>;
  return { allow: Array.isArray(raw.allow) ? raw.allow : [], block: Array.isArray(raw.block) ? raw.block : [], revision: typeof raw.revision === 'number' ? raw.revision : 0 };
}
/** The owner's standing action lists on the Settings page. A new Run copies them when it is created. */
async function loadActionPolicy(): Promise<void> {
  const list = $('action-policy-lists');
  if (!list) return;
  try { ownerActionPolicy = actionPolicyView(await api<unknown>('/action-policy')); }
  catch (error) { list.replaceChildren(element('p', `读不到动作清单：${errorMessage(error)}`, 'muted')); return; }
  renderActionPolicy();
}
function renderActionPolicy(): void {
  const list = $('action-policy-lists');
  if (!list || !ownerActionPolicy) return;
  list.replaceChildren();
  for (const [key, title, empty] of [['allow', '允许', '还没有。批准卡片上点「以后都允许」会加到这里。'], ['block', '阻止', '还没有。']] as const) {
    const section = element('div', '', 'action-policy-list');
    section.dataset.actionPolicyList = key;
    section.append(element('h3', `${title} ${ownerActionPolicy[key].length}`));
    if (!ownerActionPolicy[key].length) section.append(element('small', empty));
    for (const ref of ownerActionPolicy[key]) {
      const row = element('div', '', 'action-policy-item');
      row.append(element('code', ref));
      const remove = dashboardButton('移除', () => changeActionPolicy({ remove: { list: key, ref } }, `已从「${title}」移除 ${ref}。已经开始的 Run 不受影响。`));
      remove.dataset.actionPolicyRemove = ref;
      row.append(remove);
      section.append(row);
    }
    list.append(section);
  }
}
async function changeActionPolicy(change: Record<string, unknown>, done: string): Promise<void> {
  const note = $('action-policy-note');
  try {
    ownerActionPolicy = actionPolicyView(await api<unknown>('/action-policy', { ...change, ...(ownerActionPolicy ? { expectedRevision: ownerActionPolicy.revision } : {}) }, 'PATCH'));
    renderActionPolicy();
    if (note) note.textContent = done;
  } catch (error) {
    if (note) note.textContent = errorMessage(error);
    await loadActionPolicy();
  }
}
$('action-policy-add')?.addEventListener('submit', event => {
  event.preventDefault();
  const input = $<HTMLInputElement>('action-policy-ref');
  const ref = input?.value.trim() ?? '';
  const list = ($<HTMLSelectElement>('action-policy-list')?.value === 'block' ? 'block' : 'allow');
  if (!ref) { input?.focus(); return; }
  void changeActionPolicy({ add: { list, ref } }, `已把 ${ref} 加到「${list === 'allow' ? '允许' : '阻止'}」。下一件 Run 开始生效。`).then(() => { if (input) input.value = ''; });
});
document.querySelector<HTMLAnchorElement>('nav.settings-index a[href="#settings-actions"]')?.addEventListener('click', () => { void loadActionPolicy(); });
interface WorkGrantView {
  grantId: string; title: string; tools: string[]; agents: string[]; expiresAt: string; runCount: number;
  state: 'active' | 'revoked' | 'expired' | 'exhausted'; remaining: { tokens?: number; moneyUsd?: number };
}
const WORK_GRANT_STATE: Record<WorkGrantView['state'], string> = { active: '有效', revoked: '已撤销', expired: '已过期', exhausted: '预算用完' };
let workGrants: WorkGrantView[] = [];
/** The owner's Work Grants on the Settings page, and as choices in the composer's permission menu. */
async function loadWorkGrants(): Promise<void> {
  const list = $('work-grant-list');
  try { workGrants = (await api<{ grants: WorkGrantView[] }>('/work-grants')).grants ?? []; }
  catch (error) { list?.replaceChildren(element('p', `读不到授权：${errorMessage(error)}`, 'muted')); return; }
  renderWorkGrants();
  syncWorkGrantChoices();
}
function workGrantSummary(grant: WorkGrantView): string {
  const left = [grant.remaining.tokens === undefined ? '' : `剩 ${grant.remaining.tokens.toLocaleString()} tokens`, grant.remaining.moneyUsd === undefined ? '' : `剩 $${grant.remaining.moneyUsd}`].filter(Boolean).join('、');
  const scope = [grant.tools.length ? `工具 ${grant.tools.join('、')}` : '', grant.agents.length ? `代理 ${grant.agents.join('、')}` : ''].filter(Boolean).join(' · ');
  return `${WORK_GRANT_STATE[grant.state]} · ${scope} · ${left} · ${grant.runCount} 件 Run · 到 ${new Date(grant.expiresAt).toLocaleString()}`;
}
function renderWorkGrants(): void {
  const list = $('work-grant-list');
  if (!list) return;
  list.replaceChildren();
  if (!workGrants.length) { list.append(element('small', '还没有授权。')); return; }
  for (const grant of workGrants) {
    const row = element('div', '', 'action-policy-item');
    row.dataset.workGrant = grant.grantId;
    row.append(element('strong', grant.title), element('small', workGrantSummary(grant)));
    if (grant.state !== 'revoked') {
      const revoke = dashboardButton('撤销', () => revokeWorkGrant(grant));
      revoke.dataset.workGrantRevoke = grant.grantId;
      row.append(revoke);
    }
    list.append(row);
  }
}
async function revokeWorkGrant(grant: WorkGrantView): Promise<void> {
  const note = $('work-grant-note');
  try {
    const result = await api<{ pausedRunIds?: string[] }>(`/work-grants/${encodeURIComponent(grant.grantId)}/revoke`, {});
    if (note) note.textContent = `已撤销「${grant.title}」${result.pausedRunIds?.length ? `，暂停了 ${result.pausedRunIds.length} 件进行中的 Run` : ''}。`;
  } catch (error) { if (note) note.textContent = errorMessage(error); }
  await loadWorkGrants();
}
/** Active grants appear in the permission menu after the three review modes. */
function syncWorkGrantChoices(): void {
  const select = $<HTMLSelectElement>('execution-review');
  if (!select) return;
  const chosen = select.value;
  select.querySelector('optgroup[data-work-grants]')?.remove();
  const active = workGrants.filter(grant => grant.state === 'active');
  if (active.length) {
    const group = document.createElement('optgroup');
    group.label = '授权'; group.dataset.workGrants = '';
    for (const grant of active) { const option = document.createElement('option'); option.value = `grant:${grant.grantId}`; option.textContent = `授权：${grant.title}`; group.append(option); }
    select.append(group);
  }
  const saved = (() => { try { return localStorage.getItem('aeeis.execution-review'); } catch { return null; } })();
  const wanted = chosen.startsWith('grant:') ? chosen : saved?.startsWith('grant:') ? saved : chosen;
  select.value = [...select.options].some(option => option.value === wanted) ? wanted : chosen.startsWith('grant:') ? 'auto' : chosen;
  updateConversationControls();
}
/** The grant chosen in the permission menu, if any. */
function selectedWorkGrant(): WorkGrantView | undefined {
  const value = $<HTMLSelectElement>('execution-review')?.value ?? '';
  return value.startsWith('grant:') ? workGrants.find(grant => grant.grantId === value.slice('grant:'.length) && grant.state === 'active') : undefined;
}
$('work-grant-add')?.addEventListener('submit', event => {
  event.preventDefault();
  const note = $('work-grant-note');
  const ids = (fieldId: string) => ($<HTMLInputElement>(fieldId)?.value ?? '').split(/[,，\s]+/).map(item => item.trim()).filter(Boolean);
  const num = (fieldId: string) => { const value = $<HTMLInputElement>(fieldId)?.value.trim(); return value ? Number(value) : undefined; };
  const perRun = { ...(num('work-grant-run-tokens') === undefined ? {} : { tokens: num('work-grant-run-tokens') }), ...(num('work-grant-run-usd') === undefined ? {} : { moneyUsd: num('work-grant-run-usd') }) };
  const total = { ...(num('work-grant-total-tokens') === undefined ? {} : { tokens: num('work-grant-total-tokens') }), ...(num('work-grant-total-usd') === undefined ? {} : { moneyUsd: num('work-grant-total-usd') }) };
  const body = { title: $<HTMLInputElement>('work-grant-title')?.value.trim() ?? '', tools: ids('work-grant-tools'), agents: ids('work-grant-agents'), budget: { perRun, total }, durationHours: Number($<HTMLSelectElement>('work-grant-hours')?.value ?? 24) };
  void api<WorkGrantView>('/work-grants', body).then(async grant => {
    if (note) note.textContent = `已创建「${grant.title}」。在发送框的「权限」里选它即可。`;
    ($('work-grant-add') as HTMLFormElement).reset();
    await loadWorkGrants();
  }).catch(error => { if (note) note.textContent = errorMessage(error); });
});
document.querySelector<HTMLAnchorElement>('nav.settings-index a[href="#settings-grants"]')?.addEventListener('click', () => { void loadWorkGrants(); });
void loadWorkGrants();
void loadActionPolicy();
// The Settings page's own index: jump within the open pane without changing the URL.
document.querySelectorAll<HTMLAnchorElement>('nav.settings-index a').forEach(link => {
  link.addEventListener('click', event => {
    event.preventDefault();
    document.querySelector<HTMLElement>(link.getAttribute('href') ?? '')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
});
let commandPaletteOpen = false;
let commandPaletteReturnFocus: HTMLElement | null = null;
function setCommandPalette(open: boolean, restoreFocus = true): void {
  if (open) commandPaletteReturnFocus = document.activeElement instanceof HTMLElement && document.activeElement !== document.body ? document.activeElement : null;
  commandPaletteOpen = open;
  const palette = $('command-palette');
  if (!palette) return;
  palette.hidden = !open;
  if (open) {
    const search = $<HTMLInputElement>('command-search');
    search.value = '';
    filterCommandPalette('');
    window.requestAnimationFrame(() => search.focus());
  } else if (restoreFocus && commandPaletteReturnFocus) {
    const target = commandPaletteReturnFocus;
    commandPaletteReturnFocus = null;
    window.requestAnimationFrame(() => {
      if (document.contains(target) && !target.hasAttribute('disabled') && target.offsetParent !== null) target.focus();
      else ($<HTMLInputElement>('quick-goal')?.offsetParent !== null ? $<HTMLInputElement>('quick-goal') : $<HTMLButtonElement>('details-toggle'))?.focus();
    });
  } else if (!restoreFocus) {
    commandPaletteReturnFocus = null;
  }
}
function executePaletteCommand(command: string): void {
  // A command owns the next focus target. Do not let the palette's close
  // animation restore the element that opened it after the command runs.
  setCommandPalette(false, false);
  if (command === 'new-group') {
    showGroupDraft();
  } else if (command === 'new-run') {
    showEntry();
    $('command-center')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    if (conversationEnabled) $<HTMLTextAreaElement>('conversation-text').focus();
    else $<HTMLInputElement>('quick-goal').focus();
  } else if (command === 'attention') {
    if (!runSummaries.some(run => ATTENTION_STATUSES.has(run.status))) {
      runFilter = 'attention';
      localStorage.setItem('aeeis.run-filter', runFilter);
      renderRunQueue(runSummaries);
      $('run-queue')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      document.querySelector<HTMLElement>('#runs button')?.focus({ preventScroll: true });
    } else {
      setAttentionInboxOpen(true);
      $('attention-inbox')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      $<HTMLElement>('#attention-items .is-selected, #attention-items [role="button"]')?.focus({ preventScroll: true });
    }
  } else if (command === 'current') {
    leaveGroup();
    setCurrentRunOpen(true);
    $('run-workspace')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    $<HTMLElement>('#run-title')?.focus({ preventScroll: true });
  } else if (command === 'focus') {
    setFocusMode(!focusMode);
  } else if (command === 'details') {
    if (!quickRunReady) openConfiguration();
    else {
      setDetailsMode(true, { reveal: true });
      setFocusMode(false);
      $('new-run-panel')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }
}
function filterCommandPalette(query: string): void {
  const normalized = query.trim().toLocaleLowerCase();
  let visible = 0;
  document.querySelectorAll<HTMLButtonElement>('#command-list [data-command]').forEach(control => {
    const matches = !normalized || (control.textContent ?? '').toLocaleLowerCase().includes(normalized);
    control.hidden = !matches;
    if (matches) visible += 1;
  });
  const empty = $('command-empty');
  if (empty) empty.hidden = visible > 0;
}
function focusCommandItem(direction: 1 | -1): void {
  const items = [...document.querySelectorAll<HTMLButtonElement>('#command-list [data-command]:not([hidden])')];
  if (!items.length) return;
  const currentIndex = items.indexOf(document.activeElement as HTMLButtonElement);
  const nextIndex = currentIndex < 0 ? (direction > 0 ? 0 : items.length - 1) : (currentIndex + direction + items.length) % items.length;
  items[nextIndex]?.focus();
}
document.querySelectorAll<HTMLButtonElement>('#command-list [data-command]').forEach(control => {
  control.addEventListener('click', () => executePaletteCommand(control.dataset.command ?? ''));
});
document.querySelector('[data-command-close]')?.addEventListener('click', () => setCommandPalette(false));
($('command-search') as HTMLInputElement | null)?.addEventListener('input', event => filterCommandPalette((event.target as HTMLInputElement).value));
document.querySelectorAll<HTMLButtonElement>('#run-filters [data-run-filter]').forEach(control => {
  control.addEventListener('click', () => {
    runFilter = control.dataset.runFilter ?? 'all';
    localStorage.setItem('aeeis.run-filter', runFilter);
    renderRunQueue(runSummaries);
  });
});
document.querySelectorAll<HTMLButtonElement>('#timeline-filters [data-timeline-filter]').forEach(control => {
  control.addEventListener('click', () => {
    timelineFilter = control.dataset.timelineFilter ?? 'all';
    localStorage.setItem('aeeis.timeline-filter', timelineFilter);
    renderTimelineFilterState();
    if (current) render(current);
  });
});
renderTimelineFilterState();
document.querySelectorAll<HTMLButtonElement>('.intent-presets [data-intent]').forEach(preset => {
  preset.addEventListener('click', () => {
    const intent = preset.dataset.intent?.trim();
    if (!intent) return;
    const quickGoal = $('quick-goal') as HTMLInputElement | null;
    const goal = $('goal') as HTMLTextAreaElement | null;
    if (quickGoal) quickGoal.value = intent;
    if (goal) goal.value = intent;
    const skill = preset.dataset.skill;
    const skillSelect = $('builtin-skill') as HTMLSelectElement | null;
    if (skill && skillSelect) skillSelect.value = skill;
    setIntentPresetsOpen(false);
    quickGoal?.focus();
  });
});
($('quick-goal') as HTMLInputElement | null)?.addEventListener('input', event => {
  $<HTMLTextAreaElement>('goal').value = (event.target as HTMLInputElement).value;
});
let quickRunStatusTimer: number | undefined;
function setQuickRunBusy(busy: boolean, text = ''): void {
  const form = $('quick-run');
  if (!form) return;
  if (quickRunStatusTimer !== undefined) {
    window.clearInterval(quickRunStatusTimer);
    quickRunStatusTimer = undefined;
  }
  form.dataset.busy = busy ? 'true' : 'false';
  form.setAttribute('aria-busy', String(busy));
  form.querySelectorAll<HTMLInputElement | HTMLButtonElement>('input, button').forEach(control => {
    control.disabled = busy || (control instanceof HTMLButtonElement && control.type === 'submit' && !quickRunReady);
  });
  const status = $('quick-run-status');
  if (status) {
    status.textContent = text;
    status.dataset.busy = busy ? 'true' : 'false';
    if (busy) {
      const phases = ['正在接收目标…', '正在生成执行入口…', '正在准备 Agent 计划…'];
      let index = Math.max(0, phases.indexOf(text));
      quickRunStatusTimer = window.setInterval(() => {
        index = (index + 1) % phases.length;
        status.textContent = phases[index] ?? phases[0]!;
      }, 1400);
    }
  }
}
($('quick-run') as HTMLFormElement | null)?.addEventListener('submit', event => {
  event.preventDefault();
  if (conversationEnabled && entryShowsBot()) {
    if (!conversation || conversationBusy || conversationAttempt || conversationNeedsRefresh) return;
    if (!localBotCanExecute()) { message('这位成员不支持本地执行。'); return; }
    $<HTMLTextAreaElement>('conversation-text').value = $<HTMLInputElement>('quick-goal').value;
    void sendConversation(conversationSendIntent()).catch(error => message(errorMessage(error)));
    return;
  }
  if (entryShowsBot() && activeBotId() !== 'aeeis') { message('请先连接对话服务，再给这位 Bot 派活。'); return; }
  const value = $<HTMLInputElement>('quick-goal').value.trim();
  if (!value) { $<HTMLInputElement>('quick-goal').focus(); return; }
  const submit = $('submit') as HTMLButtonElement;
  if (submit.disabled) { message('当前还没有可用的模型配置，请先连接运行服务。'); return; }
  setQuickRunBusy(true, '正在接收目标…');
  $<HTMLTextAreaElement>('goal').value = value;
  setCurrentRunOpen(true);
  submit.click();
  setFocusMode(true);
});
window.addEventListener('keydown', event => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
    event.preventDefault(); setCommandPalette(!commandPaletteOpen); return;
  }
  if (event.key === 'Escape' && commandPaletteOpen) {
    event.preventDefault(); setCommandPalette(false); return;
  }
  if (commandPaletteOpen && event.key === 'ArrowDown') {
    event.preventDefault(); focusCommandItem(1); return;
  }
  if (commandPaletteOpen && event.key === 'ArrowUp') {
    event.preventDefault(); focusCommandItem(-1); return;
  }
  if (commandPaletteOpen && event.key === 'Tab') {
    const palette = $('command-palette');
    const focusable = [...palette.querySelectorAll<HTMLElement>('input:not([disabled]), button:not([disabled]):not([hidden])')];
    if (focusable.length) {
      const currentIndex = focusable.indexOf(document.activeElement as HTMLElement);
      const nextIndex = event.shiftKey
        ? (currentIndex <= 0 ? focusable.length - 1 : currentIndex - 1)
        : (currentIndex < 0 || currentIndex === focusable.length - 1 ? 0 : currentIndex + 1);
      event.preventDefault();
      focusable[nextIndex]?.focus();
    }
    return;
  }
  if (commandPaletteOpen && event.key === 'Enter' && document.activeElement === $('command-search')) {
    const first = document.querySelector<HTMLButtonElement>('#command-list [data-command]:not([hidden])');
    if (first) { event.preventDefault(); first.click(); }
    return;
  }
  if (!commandPaletteOpen && !event.metaKey && !event.ctrlKey && !event.altKey && !event.repeat) {
    const target = event.target as HTMLElement | null;
    const typing = Boolean(target?.closest('input, textarea, select, [contenteditable="true"]'));
    if (!typing) {
      const key = event.key.toLowerCase();
      if (key === 'n') { event.preventDefault(); executePaletteCommand('new-run'); }
      else if (key === 'g') { event.preventDefault(); executePaletteCommand('new-group'); }
      else if (key === 'r') { event.preventDefault(); executePaletteCommand('current'); }
      else if (key === 'f') { event.preventDefault(); executePaletteCommand('focus'); }
      else if (key === 'd') { event.preventDefault(); executePaletteCommand('details'); }
    }
  }
});
/** A token goes in the authorization header, which only carries Latin-1: drop what copying tends to add, and refuse the rest. */
function cleanToken(raw: string): string | undefined {
  const token = raw.replace(/[\u200B-\u200D\u2060\uFEFF]/g, '').trim().replace(/^bearer\s+/i, '').replace(/^(["'“‘「])(.*)(["'”’」])$/, '$2').trim();
  return /^[\x21-\x7E]*$/.test(token) ? token : undefined;
}
const BAD_TOKEN = '令牌里有不能放进请求头的字符（比如中文、全角符号或空格）。请重新复制令牌，只保留令牌本身。';
/** The access token lives under one key. It is remembered in localStorage so a new tab or the installed
 * home-screen app connects without re-entering it; sessionStorage is still read once so a token saved by an
 * older build carries over. "忘记令牌" (and connecting with an empty field) clears both. */
function getToken(): string | null {
  try { return localStorage.getItem(TOKEN_KEY) ?? sessionStorage.getItem(TOKEN_KEY); } catch { return null; }
}
function setToken(token: string): void {
  if (!token) { clearToken(); return; }
  try { localStorage.setItem(TOKEN_KEY, token); sessionStorage.removeItem(TOKEN_KEY); }
  catch { try { sessionStorage.setItem(TOKEN_KEY, token); } catch { /* storage may be unavailable */ } }
}
function clearToken(): void {
  try { localStorage.removeItem(TOKEN_KEY); } catch { /* storage may be unavailable */ }
  try { sessionStorage.removeItem(TOKEN_KEY); } catch { /* storage may be unavailable */ }
}
class ApiError extends Error { constructor(message: string, readonly status: number, readonly retrySameRequest = false) { super(message); } }
async function api<T>(path: string, body?: unknown, method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE', idempotencyKey?: string): Promise<T> {
  if (readOnlyShare && (path !== `/share/${shareToken}` || body !== undefined || (method && method !== 'GET'))) throw new Error('Shared runs are read-only');
  const token = readOnlyShare ? null : getToken();
  const response = await fetch(`/api${path}`, {
    method: method ?? (body === undefined ? 'GET' : 'POST'),
    headers: { ...(body === undefined ? {} : { 'content-type': 'application/json' }), ...(token ? { authorization: `Bearer ${token}` } : {}), ...(idempotencyKey ? { 'Idempotency-Key': idempotencyKey } : {}) },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  const raw = await response.text();
  if (!readOnlyShare && token !== getToken()) throw new Error('身份已更改，请重新连接');
  let value: (T & { error?: string; retrySameRequest?: unknown }) | undefined;
  if (raw.trim()) {
    try { value = JSON.parse(raw) as T & { error?: string; retrySameRequest?: unknown }; }
    catch {
      if (!response.ok) {
        const fallback = raw.replace(/\s+/g, ' ').trim();
        throw new ApiError(fallback && !fallback.startsWith('<') ? fallback.slice(0, 240) : `运行服务暂时不可用（HTTP ${response.status}）`, response.status);
      }
    }
  }
  if (!response.ok) throw new ApiError(value?.error ?? `运行服务请求失败（HTTP ${response.status}）`, response.status, value?.retrySameRequest === true);
  return (value ?? {}) as T;
}
let authRequired = false;
const SERVER_ERROR_LABELS: Record<string, string> = {
  'Local access token required': '需要访问令牌：点击“输入令牌”，填写本地访问令牌后连接。',
  'Invalid local access token': '访问令牌无效，请重新输入。',
  'Shared runs are read-only': '只读分享页不能执行操作。',
};
function errorMessage(error: unknown): string {
  const text = error instanceof Error && error.message ? error.message : String(error || '运行服务暂时不可用');
  if (/access token/i.test(text)) { authRequired = true; syncDetailsToggleLabel(); }
  return SERVER_ERROR_LABELS[text] ?? text;
}
function formatTime(value: string | number | Date): string {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleString('zh-CN', { hour12: false });
}
const REVIEW_VERDICT_LABELS: Record<string, string> = { accepted: '通过', revise: '需修改', rejected: '未通过', needs_revision: '需修改' };
// Keep the raw verdict next to non-passing labels so operators can grep logs and debug bundles for it.
function reviewVerdictLabel(verdict: string): string { const label = REVIEW_VERDICT_LABELS[verdict]; return !label ? verdict : verdict === 'accepted' ? label : `${label}（${verdict}）`; }
let errorToastTimer: number | undefined;
function message(text: string): void {
  if (badTokenNotice && text === SERVER_ERROR_LABELS['Local access token required']) text = BAD_TOKEN;
  $('error').textContent = text;
  const toast = $('error-toast');
  const toastMessage = $('error-toast-message');
  if (!toast || !toastMessage) return;
  if (errorToastTimer !== undefined) window.clearTimeout(errorToastTimer);
  toastMessage.textContent = text;
  toast.hidden = !text;
  if (text) errorToastTimer = window.setTimeout(() => { toast.hidden = true; }, 8000);
}
($('error-toast-close') as HTMLButtonElement | null)?.addEventListener('click', () => {
  const toast = $('error-toast');
  if (toast) toast.hidden = true;
  if (errorToastTimer !== undefined) window.clearTimeout(errorToastTimer);
});
function element<K extends keyof HTMLElementTagNameMap>(tag: K, text = '', className = ''): HTMLElementTagNameMap[K] {
  const el = document.createElement(tag); el.textContent = text; el.className = className; return el;
}
function dashboardButton(label: string, action: () => Promise<void>): HTMLButtonElement {
  const control = element('button', label); control.type = 'button';
  control.addEventListener('click', () => { if (!control.disabled) void action(); });
  return control;
}
function button(label: string, action: () => Promise<void>): HTMLButtonElement {
  const b = element('button', label);
  b.onclick = () => {
    b.disabled = true;
    b.classList.add('is-busy');
    b.setAttribute('aria-busy', 'true');
    void action().catch(error => message(errorMessage(error))).finally(() => {
      b.disabled = false;
      b.classList.remove('is-busy');
      b.removeAttribute('aria-busy');
    });
  };
  return b;
}
function resetConversation(clearStorage = true): void {
  conversationEpoch++; conversation = undefined; conversationList = []; conversationAttempt = undefined;
  conversationReplyId = undefined; conversationCorrectionId = undefined; conversationBusy = false; conversationRefreshing = false; conversationNeedsRefresh = false; conversationRenderSignature = '';
  $('conversation-messages').replaceChildren(); $('conversation-tasks').replaceChildren();
  $<HTMLFormElement>('conversation-composer').reset();
  $('conversation-status').textContent = ''; $('conversation-error').textContent = ''; $('conversation-reply-label').textContent = ''; $('conversation-correction-label').textContent = '';
  $('working-memory-content').replaceChildren(); delete $('working-memory-content').dataset.signature; $('working-memory-panel').hidden = true;
  if (clearStorage) {
    localStorage.removeItem(CONVERSATION_SELECTION); localStorage.removeItem(CONVERSATION_SCOPE); localStorage.removeItem(LIFE_HOME); sessionStorage.removeItem(CONVERSATION_PENDING);
    aeeisConversationId = '';
  }
  renderConversation();
}
function saveConversationAttempt(): void {
  if (conversationAttempt) sessionStorage.setItem(CONVERSATION_PENDING, JSON.stringify(conversationAttempt));
  else sessionStorage.removeItem(CONVERSATION_PENDING);
}
function conversationTaskName(id: string): string { return conversation?.tasks.find(task => task.id === id)?.title ?? id; }
function conversationTargetTask(): ConversationTaskView | undefined {
  const target = $<HTMLSelectElement>('conversation-target').value;
  const reply = conversation?.messages.find(item => item.id === conversationReplyId);
  const replyTasks = reply?.effectiveTaskIds ?? reply?.route.taskIds;
  const id = target || (replyTasks?.length === 1 ? replyTasks[0] : reply ? undefined : conversation?.focusTaskId);
  return conversation?.tasks.find(task => task.id === id);
}
/** What the main send button does now: start work when a Run can start, otherwise only record the message. */
function conversationSendIntent(): 'discuss' | 'execute' {
  const surface = rosterView();
  if (!conversation || conversationCorrectionId || !quickRunReady || selectedLifeSpeaker() || !localBotCanExecute(lifeAgent(conversation)) || (surface !== 'entry' && surface !== 'bot')) return 'discuss';
  const task = conversationTargetTask();
  const preparing = Boolean(task && task.status === 'preparing' && !task.runId && !task.latestRunId);
  const active = task && !preparing && (task.pendingMessageId || !['discussion', 'succeeded', 'failed', 'cancelled'].includes(task.status));
  return preparing || active ? 'discuss' : 'execute';
}
/** A new task named after the message, for a send that names no task. Titles need at least two characters. */
function autoTaskTitle(text: string): string {
  const line = text.split('\n').map(part => part.trim()).find(Boolean) ?? '';
  return line.length > 60 ? `${line.slice(0, 59)}…` : line;
}
function openConversationRoute(): void {
  const route = document.querySelector<HTMLDetailsElement>('#conversation-route');
  if (route) route.open = true;
}
function updateConversationControls(): void {
  const locked = conversationBusy || Boolean(conversationAttempt);
  const target = $<HTMLSelectElement>('conversation-target').value;
  const task = conversationTargetTask();
  const preparing = Boolean(task && task.status === 'preparing' && !task.runId && !task.latestRunId);
  const active = task && !preparing && (task.pendingMessageId || !['discussion', 'succeeded', 'failed', 'cancelled'].includes(task.status));
  $('conversation-panel').setAttribute('aria-busy', String(conversationBusy));
  $('conversation-new-task-fields').hidden = target !== '__new';
  $<HTMLInputElement>('conversation-task-title').required = target === '__new';
  $('conversation-reply').hidden = !conversationReplyId;
  $('conversation-retry-panel').hidden = !conversationAttempt;
  $<HTMLButtonElement>('conversation-retry').disabled = conversationBusy;
  $('conversation-composer').querySelectorAll<HTMLInputElement | HTMLButtonElement | HTMLSelectElement | HTMLTextAreaElement>('input, button, select, textarea').forEach(control => { control.disabled = locked || !conversation; });
  const correcting = Boolean(conversationCorrectionId);
  $('conversation-correction').hidden = !correcting;
  $<HTMLTextAreaElement>('conversation-text').readOnly = correcting;
  $<HTMLSelectElement>('conversation-focus-effect').disabled ||= correcting;
  for (const option of $<HTMLSelectElement>('conversation-target').options) option.disabled = correcting && (!option.value || option.value === '__new');
  $<HTMLButtonElement>('conversation-send').textContent = correcting ? '保存归属纠正' : conversationSendIntent() === 'execute' ? '发送' : '记下来';
  $<HTMLButtonElement>('conversation-send').disabled = locked || !conversation || conversationNeedsRefresh || (correcting && !conversation?.tasks.some(task => task.id === target));
  $<HTMLButtonElement>('conversation-note').disabled = locked || !conversation || conversationNeedsRefresh || correcting;
  restoreExecutionReview();
  syncEntryDefaults();
  const executionNote = $('conversation-execution-note');
  executionNote.textContent = correcting ? '请明确选择任务。纠正以新记录追加，仅影响后续消息和新执行上下文；已有执行记录不变，不启动执行，也不切换焦点。' : preparing ? '执行尚未创建。请等待回执；确认失败后再重新发送。' : active ? '此任务已有未结束的 Run。这条消息只记下来；批准、回答或取消在计划卡片和运行里。' : !quickRunReady ? '模型尚未就绪；发送只记下来，不会执行。' : selectedLifeSpeaker() ? '以别人的口吻说的话只记下来，不会启动执行。' : !localBotCanExecute(lifePersonId()) ? '这位成员不支持本地执行，发送只记下来。' : executionReviewNote();
  // The usual review explanation lives on the review menu; only a note that changes what Send does stays in view.
  executionNote.dataset.routine = String(executionNote.textContent === executionReviewNote());
  $('execution-review').title = executionReviewNote();
  for (const id of ['conversation-new', 'conversation-select', 'conversation-clear-focus']) ($<HTMLButtonElement | HTMLSelectElement>(id)).disabled = locked;
  for (const id of ['conversation-refresh', 'conversation-sync']) $<HTMLButtonElement>(id).disabled = conversationBusy || conversationRefreshing || !conversation;
  $<HTMLButtonElement>('conversation-clear-focus').disabled ||= !conversation?.focusTaskId;
  document.querySelectorAll<HTMLButtonElement | HTMLTextAreaElement>('#conversation-tasks button[data-change-focus], #conversation-tasks button[data-priority], #conversation-tasks button[data-approve], #conversation-tasks button[data-approve-once], #conversation-tasks button[data-reject-submit], #conversation-tasks button[data-answer-submit], #conversation-tasks button[data-retry], #conversation-tasks button[data-run-pause], #conversation-tasks button[data-run-resume], #conversation-tasks button[data-reconcile-submit], #conversation-tasks textarea[data-answer], #conversation-tasks textarea[data-reconcile], #conversation-tasks textarea[data-reject], #group-transcript button[data-approve], #group-transcript button[data-approve-once], #group-transcript button[data-reject-submit], #group-transcript button[data-answer-submit], #group-transcript textarea[data-reject], #group-transcript textarea[data-answer], #conversation-messages button[data-plan-start], #conversation-messages button[data-plan-revise], #conversation-messages button[data-plan-cancel], #conversation-messages button[data-plan-revise-submit], #conversation-messages textarea[data-plan-feedback], #conversation-messages button[data-card-decision], #conversation-messages button[data-question-submit], #conversation-messages textarea[data-question-answer]').forEach(control => {
    control.disabled = control.dataset.boundary === 'true' || locked || (Boolean(control.dataset.priority) && conversationNeedsRefresh);
  });
  const surface = rosterView();
  if (surface === 'group' || surface === 'draft' || surface === 'direct') {
    $<HTMLButtonElement>('conversation-send').disabled = true;
    $<HTMLButtonElement>('conversation-note').disabled = true;
    if (surface === 'direct' && !conversationCorrectionId) {
      $<HTMLButtonElement>('conversation-send').textContent = '先回到这个人';
      $('conversation-execution-note').textContent = '这间私聊只保留会话记录。执行回到这个人的对话里，明确创建 Run。它不会自己回复。';
    }
  }
  if (archivedDialogue()) {
    $('conversation-composer').querySelectorAll<HTMLInputElement | HTMLButtonElement | HTMLSelectElement | HTMLTextAreaElement>('input, button, select, textarea').forEach(control => { control.disabled = true; });
    $('conversation-execution-note').textContent = '此私聊已归档，只读。已有 Run 继续运行，可从频道管理恢复。';
  }
  syncEntrySurface();
  syncStandingInstruction();
}
function syncStandingInstruction(): void {
  const section = $('standing-instruction');
  if (!section) return;
  const life = rosterView() === 'entry' || rosterView() === 'bot';
  section.hidden = !life;
  const field = $<HTMLTextAreaElement>('standing-text');
  const locked = conversationBusy || Boolean(conversationAttempt) || !conversation || !life || archivedDialogue();
  const nextId = conversation?.id ?? '';
  if (field) {
    const focused = document.activeElement === field;
    if (!conversation || nextId !== standingBoundId || !focused) {
      field.value = conversation?.standingInstruction ?? '';
      standingBoundId = nextId;
    }
    field.disabled = locked;
  }
  $<HTMLButtonElement>('standing-save').disabled = locked;
  $<HTMLButtonElement>('standing-clear').disabled = locked || !conversation?.standingInstruction;
  syncLastDelivery();
  syncRoutines(life ? routinePerson() : '');
}
/** The person whose life thread is open; the entry is AEEIS. */
function routinePerson(): string { return lifeAgent(conversation) || (rosterView() === 'entry' ? 'aeeis' : ''); }
const ROUTINE_WEEKDAYS = ['', '周一', '周二', '周三', '周四', '周五', '周六', '周日'];
const ROUTINE_REVIEW: Record<RoutineView['executionReview'], string> = { required: '每一步都问我', auto: '自动判断', yolo: '放手' };
function routineWhen(routine: RoutineView): string {
  if (routine.trigger.kind === 'webhook') return '收到 Webhook 时';
  if (routine.trigger.kind === 'manual') return '你叫它时';
  const calendar = routine.trigger.calendar;
  const days = calendar.frequency === 'weekly' ? (calendar.daysOfWeek ?? []).map(day => ROUTINE_WEEKDAYS[day]).join('、') : calendar.frequency === 'monthly' ? `每月 ${calendar.dayOfMonth} 日` : '每天';
  return `${days} ${calendar.time}（${calendar.timeZone}）`;
}
async function runRoutineNow(id: string, name: string): Promise<void> {
  const result = await api<{ status: string; runId?: string }>(`/routines/${encodeURIComponent(id)}/run`, {});
  message(result.status === 'started' ? `已让它按「${name}」做一次。` : result.status === 'pending' ? `「${name}」排上了，稍后开始。` : `「${name}」没能开始，稍后会再试。`);
  await refresh();
}
function routineWebhookUrl(id: string): string { return `${location.origin}/webhooks/routines/${encodeURIComponent(id)}`; }
function syncRoutines(agentId: string): void {
  const section = $<HTMLDetailsElement>('routines');
  if (!section) return;
  section.hidden = !agentId || !routinesConfigured;
  if (section.hidden) return;
  if (routineState?.agentId !== agentId && routineLoading !== agentId) void loadRoutines(agentId);
  renderRoutines();
}
async function loadRoutines(agentId: string): Promise<void> {
  routineLoading = agentId;
  try {
    const { routines } = await api<{ routines: RoutineView[] }>(`/routines?agentId=${encodeURIComponent(agentId)}`);
    if (routineLoading !== agentId) return;
    routineState = { agentId, items: routines };
  } catch (error) {
    $('routine-error').textContent = errorMessage(error);
  } finally {
    if (routineLoading === agentId) routineLoading = '';
  }
  renderRoutines();
}
function renderRoutines(): void {
  const list = $('routine-list');
  if (!list) return;
  const agentId = routinePerson();
  const items = routineState?.agentId === agentId ? routineState.items : [];
  $('routine-count').textContent = items.length ? `· ${items.length}` : '';
  list.replaceChildren(...items.map(routine => {
    const row = element('li'); row.dataset.status = routine.status; row.dataset.routineId = routine.id;
    const timing = routine.status === 'paused' ? '已暂停'
      : routine.pendingDueAt ? `上一件还没做完，${formatTime(routine.pendingDueAt)} 那次等它做完再补`
      : routine.nextDueAt ? `下次 ${formatTime(routine.nextDueAt)}` : routine.trigger.kind === 'manual' ? '等你叫它' : routine.webhookEnabled ? '等 Webhook' : 'Webhook 已关闭';
    row.append(element('strong', routine.name), element('small', `${routineWhen(routine)} · ${ROUTINE_REVIEW[routine.executionReview]} · ${timing}`), element('span', routine.prompt));
    if (routine.trigger.kind === 'webhook') row.append(element('small', `地址：${routineWebhookUrl(routine.id)}`));
    const actions = element('div', '', 'standing-actions');
    const toggle = button(routine.status === 'active' ? '暂停' : '恢复', () => changeRoutine(routine, { status: routine.status === 'active' ? 'paused' : 'active' })); toggle.type = 'button';
    actions.append(toggle);
    if (routine.trigger.kind === 'manual' && routine.status === 'active') {
      const now = button('现在做一次', async () => { await runRoutineNow(routine.id, routine.name); }); now.type = 'button'; now.dataset.routineRun = routine.id;
      actions.append(now);
    }
    if (routine.trigger.kind === 'webhook') {
      const webhookToggle = button(routine.webhookEnabled ? '关闭 Webhook' : '开启 Webhook', () => changeRoutine(routine, { webhookEnabled: !routine.webhookEnabled })); webhookToggle.type = 'button';
      actions.append(webhookToggle);
      const rotate = button('换密钥', async () => {
        const result = await api<{ routine: RoutineView; webhookSecret: string }>(`/routines/${encodeURIComponent(routine.id)}/rotate-secret`, {});
        routineSecret = { routineId: routine.id, secret: result.webhookSecret };
        replaceRoutine(result.routine);
      }); rotate.type = 'button'; rotate.className = 'quiet-button';
      actions.append(rotate);
    }
    const remove = button('删除', async () => {
      if (!confirm(`删除例程「${routine.name}」？已经开始的工作不受影响。`)) return;
      await api<unknown>(`/routines/${encodeURIComponent(routine.id)}`, undefined, 'DELETE');
      if (routineState) routineState = { ...routineState, items: routineState.items.filter(item => item.id !== routine.id) };
      if (routineSecret?.routineId === routine.id) routineSecret = undefined;
      renderRoutines();
    }); remove.type = 'button'; remove.className = 'quiet-button';
    actions.append(remove);
    row.append(actions);
    return row;
  }));
  const secret = $('routine-secret');
  const shown = routineSecret && items.find(item => item.id === routineSecret!.routineId);
  secret.hidden = !shown;
  secret.textContent = shown ? `「${shown.name}」的密钥只显示这一次：${routineSecret!.secret}\n用它对「时间戳.投递 id.请求体」做 HMAC-SHA256，放在 x-aeeis-signature: sha256=…，同时带上 x-aeeis-timestamp（秒）和 x-aeeis-delivery。同一投递 id 只开始一次。` : '';
  const kind = $<HTMLSelectElement>('routine-kind').value;
  $('routine-weekday').hidden = kind !== 'weekly';
  $('routine-time').hidden = kind === 'webhook';
}
function replaceRoutine(next: RoutineView): void {
  if (routineState?.agentId === next.agentId) routineState = { ...routineState, items: routineState.items.some(item => item.id === next.id) ? routineState.items.map(item => item.id === next.id ? next : item) : [...routineState.items, next] };
  renderRoutines();
}
async function changeRoutine(routine: RoutineView, change: Record<string, unknown>): Promise<void> {
  const result = await api<{ routine: RoutineView }>(`/routines/${encodeURIComponent(routine.id)}`, { expectedRevision: routine.revision, ...change }, 'PATCH');
  replaceRoutine(result.routine);
}
async function addRoutine(): Promise<void> {
  const agentId = routinePerson();
  if (!agentId) throw new Error('先打开这个人');
  const kind = $<HTMLSelectElement>('routine-kind').value;
  const time = $<HTMLInputElement>('routine-time').value || '09:00';
  const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
  const trigger = kind === 'webhook' ? { kind: 'webhook' }
    : { kind: 'schedule', calendar: { frequency: kind, timeZone, time, ...(kind === 'weekly' ? { daysOfWeek: [Number($<HTMLSelectElement>('routine-weekday').value)] } : {}) } };
  const result = await api<{ routine: RoutineView; webhookSecret?: string }>('/routines', {
    agentId, name: $<HTMLInputElement>('routine-name').value, prompt: $<HTMLTextAreaElement>('routine-prompt').value,
    trigger, executionReview: $<HTMLSelectElement>('routine-review').value,
  });
  if (result.webhookSecret) routineSecret = { routineId: result.routine.id, secret: result.webhookSecret };
  $<HTMLFormElement>('routine-form').reset();
  replaceRoutine(result.routine);
}
function deliveryDraft(delivery: LastDelivery): string {
  const parts = [delivery.taskTitle.trim()];
  if (delivery.planSummary?.trim()) parts.push(delivery.planSummary.trim());
  if (delivery.artifactTitles?.length) parts.push(delivery.artifactTitles.join('、'));
  const text = parts.join('。');
  return text.length > 500 ? `${text.slice(0, 499)}…` : text;
}
function syncLastDelivery(): void {
  const section = $('last-delivery');
  if (!section) return;
  const life = rosterView() === 'entry' || rosterView() === 'bot';
  const delivery = life ? conversation?.lastDelivery : undefined;
  section.hidden = !delivery;
  const copy = $('last-delivery-copy');
  if (copy) copy.textContent = delivery ? deliveryDraft(delivery) : '';
  const pin = $<HTMLButtonElement>('last-delivery-pin');
  if (pin) pin.disabled = !delivery || conversationBusy || Boolean(conversationAttempt);
  syncPracticeDraft(delivery);
  syncAcceptedPractice();
}
function syncPracticeDraft(delivery: LastDelivery | undefined): void {
  const field = $<HTMLTextAreaElement>('practice-text');
  const accept = $<HTMLButtonElement>('practice-accept');
  const locked = !delivery || conversationBusy || Boolean(conversationAttempt);
  if (field) {
    const nextRun = delivery?.runId ?? '';
    const focused = document.activeElement === field;
    if (!delivery || nextRun !== practiceBoundRunId || !focused) {
      field.value = delivery ? deliveryDraft(delivery) : '';
      practiceBoundRunId = nextRun;
    }
    field.disabled = locked;
  }
  if (accept) accept.disabled = locked;
}
function syncAcceptedPractice(): void {
  const section = $('accepted-practice');
  if (!section) return;
  const life = rosterView() === 'entry' || rosterView() === 'bot';
  const practice = life ? conversation?.acceptedPractice : undefined;
  section.hidden = !practice;
  const copy = $('accepted-practice-copy');
  if (copy) copy.textContent = practice?.text ?? '';
  const retract = $<HTMLButtonElement>('accepted-practice-retract');
  if (retract) retract.disabled = !practice || conversationBusy || Boolean(conversationAttempt);
  syncTaskSettings();
}
function currentTaskKind(): string {
  return $<HTMLInputElement>('task-kind')?.value.trim() ?? '';
}
function syncTaskSettings(): void {
  const section = $('task-settings');
  if (!section) return;
  const life = rosterView() === 'entry' || rosterView() === 'bot';
  section.hidden = !life;
  const kind = currentTaskKind();
  const settings = life ? conversation?.taskSettings : undefined;
  const skill = kind ? settings?.skills.find(item => item.taskKind === kind) : undefined;
  const model = kind ? settings?.models.find(item => item.taskKind === kind) : undefined;
  const copy = $('skill-profile-copy');
  if (copy) {
    if (skill) copy.textContent = `${skill.methodId} · ${skill.version}，引用 ${skill.runId}`;
    else if (!kind && settings?.skills.length) copy.textContent = settings.skills.map(item => `${item.taskKind}：${item.methodId} · ${item.version}`).join('；');
    else copy.textContent = kind ? '这个种类还没有技能档案。' : '这个人还没有按任务种类留下技能档案。';
  }
  const modelCopy = $('task-model-copy');
  if (modelCopy) {
    if (model) modelCopy.textContent = model.provider ? `${model.model} · ${model.provider}` : model.model;
    else if (!kind && settings?.models.length) modelCopy.textContent = settings.models.map(item => `${item.taskKind}：${item.model}`).join('；');
    else modelCopy.textContent = kind ? '这个种类沿用当前运行时。' : '还没有哪个种类单独选了模型。';
  }
  const runtime = $('task-runtime-model');
  if (runtime) runtime.textContent = runtimeModel ? `当前运行时：${runtimeModel}。留空就用它。` : '当前按目录选择模型。留空就继续按目录。';
  const modelField = $<HTMLInputElement>('task-model');
  const providerField = $<HTMLInputElement>('task-model-provider');
  const bound = `${conversation?.id ?? ''}:${kind}`;
  if (modelField && document.activeElement !== modelField && bound !== taskModelBound) {
    modelField.value = model?.model ?? '';
    if (providerField && document.activeElement !== providerField) providerField.value = model?.provider ?? '';
    taskModelBound = bound;
  }
  const locked = !life || !conversation || conversationBusy || Boolean(conversationAttempt);
  const kindLocked = locked || !kind;
  $<HTMLInputElement>('task-kind').disabled = locked;
  if (modelField) modelField.disabled = locked;
  if (providerField) providerField.disabled = locked;
  const compare = kind ? settings?.comparisons?.find(item => item.taskKind === kind) : undefined;
  const compareCopy = $('task-kind-compare');
  if (compareCopy) {
    compareCopy.hidden = !compare;
    compareCopy.textContent = compare ? taskKindCompareText(compare) : '';
  }
  $<HTMLButtonElement>('skill-promote').disabled = kindLocked || !promotionRunId();
  $<HTMLButtonElement>('task-kind-keep').disabled = kindLocked || !compare?.differs || compare.kept;
  $<HTMLButtonElement>('task-kind-propose').disabled = kindLocked || !skillLineup(compare) || Boolean(compare?.proposal);
  $<HTMLButtonElement>('skill-rollback').disabled = kindLocked || !skill;
  $<HTMLButtonElement>('skill-retract').disabled = kindLocked || !skill;
  $<HTMLInputElement>('skill-rollback-reason').disabled = kindLocked || !skill;
  $<HTMLButtonElement>('task-model-save').disabled = kindLocked;
  $<HTMLButtonElement>('task-model-clear').disabled = kindLocked || !model;
}
function skillLineup(compare: TaskKindComparison | undefined): boolean {
  return Boolean(compare?.methodId && compare.profileMethodId && compare.version && compare.profileVersion && (compare.methodId !== compare.profileMethodId || compare.version !== compare.profileVersion));
}
function taskKindCompareText(compare: TaskKindComparison): string {
  const usedSkill = compare.methodId ? `${compare.methodId} · ${compare.version}` : '没有技能版本';
  const usedModel = compare.model ?? '当前运行时';
  const used = `这次做成：${usedSkill}，模型 ${usedModel}，引用 ${compare.runId}`;
  const sent = compare.proposal?.status === 'proposed'
    ? '已送去评测。候选停在 proposed。'
    : compare.proposal
      ? `已送去评测。候选状态：${compare.proposal.status}。`
      : '';
  if (!compare.profileMethodId && !compare.profileModel) return `${sent}${used}。这个种类还没有档案。`;
  const profileSkill = compare.profileMethodId ? `${compare.profileMethodId} · ${compare.profileVersion}` : '没有技能档案';
  const profileModel = compare.profileModel ?? '未指定模型';
  if (compare.kept) return `${sent}已留下这份档案。${used}。档案：${profileSkill}，模型 ${profileModel}。`;
  if (!compare.differs) return `${sent}这次做成和档案一致：${profileSkill}，模型 ${profileModel}。`;
  const offer = skillLineup(compare) ? '技能版本不同，可以送去评测。' : '';
  return `${sent}${used}。档案：${profileSkill}，模型 ${profileModel}。可以晋升这次技能，也可以留下档案。${offer}不点就不动。`;
}
function promotionRunId(): string {
  const kind = currentTaskKind();
  const compare = kind ? conversation?.taskSettings?.comparisons?.find(item => item.taskKind === kind) : undefined;
  if (compare) return compare.methodId ? compare.runId : '';
  return conversation?.lastDelivery?.runId ?? '';
}
function pinLastDelivery(): void {
  const surface = rosterView();
  const delivery = conversation?.lastDelivery;
  if ((surface !== 'entry' && surface !== 'bot') || !conversation || !delivery || conversationBusy || conversationAttempt) return;
  const field = $<HTMLTextAreaElement>('standing-text');
  const draft = deliveryDraft(delivery);
  const current = field.value.trim();
  if (current && current !== draft && !current.includes(draft)) {
    const combined = `${current}\n${draft}`;
    if (combined.length > 500) {
      $('conversation-error').textContent = '这句话已经写满。先删短，再放上次的做法。';
      field.focus();
      return;
    }
    field.value = combined;
  } else field.value = draft;
  standingBoundId = conversation.id;
  field.focus();
  $('conversation-status').textContent = '已放进嘱咐草稿。还没记住。要点「记住这句」才会留下。';
  $('conversation-error').textContent = '';
  updateConversationControls();
}
function usingDemoBots(): boolean {
  return agentsLoaded && localStorage.getItem('aeeis.demo-roster') !== '0' && ownedBotRecords.length === 0 && loadCustomBots().length === 0 && !agentSummaries.some(agent => agent.status === 'admitted');
}
function reservedBotName(name: string): boolean {
  const normalized = name.normalize('NFKC').trim();
  return ['所有人', '团队', 'AEEIS'].some(reserved => reserved.localeCompare(normalized, 'zh', { sensitivity: 'accent' }) === 0);
}
/** A saved Bot joins a room once this account has the profile. A copy still waiting in this browser stays off the roster until this person writes it onto the account. */
function roomReadyBot(bot: RosterBot): boolean {
  if (bot.id === 'aeeis' || reservedBotName(bot.name)) return false;
  if (bot.id.startsWith('bot_')) return ownedBotRecords.some(item => item.id === bot.id);
  return true;
}
function ownedRosterBot(bot: OwnedBotView): RosterBot {
  return { id: bot.id, name: bot.name, note: '', demo: false, mark: bot.mark, color: bot.color, background: bot.background, ...(bot.role ? { role: bot.role } : {}), ...(bot.autonomy ? { autonomy: bot.autonomy } : {}) };
}
function rememberOwnedBot(bot: OwnedBotView): void {
  const next = ownedRosterBot(bot);
  ownedBotRecords = [...ownedBotRecords.filter(item => item.id !== next.id), next];
}
function loadCustomBots(): RosterBot[] {
  const raw = localStorage.getItem(CUSTOM_BOTS_KEY);
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];
    const bots: RosterBot[] = [];
    for (const item of parsed) {
      if (!item || typeof item !== 'object') continue;
      const bot = item as Partial<StoredBot>;
      if (typeof bot.id !== 'string' || !/^bot_[a-z0-9-]{8,80}$/.test(bot.id)) continue;
      if (typeof bot.name !== 'string' || !bot.name.trim() || bot.name.trim().length > 40 || reservedBotName(bot.name)) continue;
      if (typeof bot.mark !== 'string' || !BOT_MARKS.includes(bot.mark as BotMark)) continue;
      if (typeof bot.color !== 'string' || !BOT_COLORS.includes(bot.color)) continue;
      if (typeof bot.background !== 'string' || !bot.background.trim() || bot.background.trim().length > 800) continue;
      const mark = bot.mark as BotMark;
      const role = typeof bot.role === 'string' ? bot.role.trim().slice(0, 120) : '';
      const held = typeof bot.held === 'string' ? bot.held : '';
      bots.push({
        id: bot.id, name: bot.name.trim(), note: '', demo: false, mark, color: bot.color, background: bot.background.trim(), ...(role ? { role } : {}), ...(held ? { held } : {}),
      });
      if (bots.length >= CUSTOM_BOT_CAP) break;
    }
    return bots;
  } catch {
    return [];
  }
}
function saveCustomBots(bots: RosterBot[]): void {
  const stored: StoredBot[] = bots.slice(0, CUSTOM_BOT_CAP).map(bot => ({
    id: bot.id, name: bot.name, mark: bot.mark ?? 'letter', color: bot.color ?? BOT_COLORS[0]!, background: bot.background ?? '', ...(bot.role ? { role: bot.role } : {}), ...(bot.held ? { held: bot.held } : {}),
  }));
  localStorage.setItem(CUSTOM_BOTS_KEY, JSON.stringify(stored));
}
function botDutyLine(bot: RosterBot | undefined): string {
  if (bot?.background) return bot.role ? `角色：${bot.role}。背景：${bot.background}` : `背景：${bot.background}`;
  if (bot?.note) return `职责：${bot.note}`;
  return '职责还没有单独写下。';
}
function rosterBots(): RosterBot[] {
  const admitted = agentSummaries.filter(agent => agent.status === 'admitted').map(agent => ({
    id: agent.agentId, name: agent.card.name, note: '已准入', demo: false,
  }));
  return [{ id: 'aeeis', name: 'AEEIS', note: '', demo: false }, ...ownedBotRecords, ...(admitted.length ? admitted : (usingDemoBots() ? DEMO_BOTS : []))];
}
function claimableLocalBots(): RosterBot[] {
  const account = localStorage.getItem(LOCAL_BOT_ACCOUNT);
  if (account && sessionPrincipal && account !== sessionPrincipal) return [];
  const serverIds = new Set(ownedBotRecords.map(bot => bot.id));
  return loadCustomBots().filter(bot => !bot.held && !serverIds.has(bot.id));
}
function renderLocalBotNote(): void {
  const note = $('bot-local-note');
  const claim = $('bot-local-claim');
  if (!note || !claim) return;
  const account = localStorage.getItem(LOCAL_BOT_ACCOUNT);
  const stored = loadCustomBots();
  const claimable = claimableLocalBots();
  if (localBotNote) {
    note.hidden = false;
    note.textContent = localBotNote;
    claim.hidden = claimable.length === 0;
    return;
  }
  if (account && sessionPrincipal && account !== sessionPrincipal && stored.some(bot => !bot.held)) {
    note.hidden = false;
    note.textContent = '这台浏览器还有上一个账号留下的 Bot，没有写入当前账号。';
    claim.hidden = true;
    return;
  }
  if (claimable.length) {
    note.hidden = false;
    note.textContent = `这台浏览器还有${claimable.map(bot => bot.name).join('、')}，还没写入这个账号。`;
    claim.hidden = false;
    return;
  }
  note.hidden = true;
  note.textContent = '';
  claim.hidden = true;
}
async function writeLocalBots(): Promise<void> {
  if (!sessionPrincipal) return;
  localStorage.setItem(LOCAL_BOT_ACCOUNT, sessionPrincipal);
  const local = loadCustomBots();
  const kept: RosterBot[] = [];
  const reasons: string[] = [];
  for (const bot of local) {
    if (bot.held) { kept.push(bot); continue; }
    try {
      const saved = await api<OwnedBotView>('/bots', {
        id: bot.id, name: bot.name, mark: bot.mark ?? 'letter', color: bot.color ?? BOT_COLORS[0]!, background: bot.background ?? '', ...(bot.role ? { role: bot.role } : {}),
      });
      rememberOwnedBot(saved);
    } catch (error) {
      if (error instanceof ApiError && error.status === 409) {
        const reason = errorMessage(error);
        kept.push({ ...bot, held: reason });
        reasons.push(`${bot.name}：${reason}`);
      } else kept.push(bot);
    }
  }
  if (kept.length) saveCustomBots(kept);
  else localStorage.removeItem(CUSTOM_BOTS_KEY);
  const held = kept.filter(bot => bot.held);
  if (reasons.length) localBotNote = `没有写入这个账号。${reasons.join(' ')}`;
  else if (held.length) localBotNote ||= `没有写入这个账号。${held.map(bot => `${bot.name}：${bot.held}`).join(' ')}`;
  else localBotNote = '';
}
async function adoptLocalBots(): Promise<void> {
  if (localBotsAdopted || !sessionPrincipal) return;
  const account = localStorage.getItem(LOCAL_BOT_ACCOUNT);
  if (account !== sessionPrincipal) return;
  localBotsAdopted = true;
  await writeLocalBots();
}
async function claimLocalBots(): Promise<void> {
  if (!sessionPrincipal) return;
  localBotsAdopted = true;
  await writeLocalBots();
  renderBotRoster();
  renderGroups(roomSummaries);
}
function loadBotGroups(): BotGroups {
  const raw = localStorage.getItem('aeeis.bot-groups');
  if (!raw) return usingDemoBots() ? {
    groups: [{ id: 'work', name: '工作' }, { id: 'research', name: '研究' }],
    placement: { aeeis: 'work', 'demo.release': 'work', 'demo.research': 'research', 'demo.brief': 'research' },
  } : { groups: [], placement: {} };
  try {
    const parsed = JSON.parse(raw) as BotGroups;
    if (!parsed || !Array.isArray(parsed.groups) || !parsed.placement || typeof parsed.placement !== 'object') throw new Error('bad');
    return {
      groups: parsed.groups.filter(group => group && typeof group.id === 'string' && typeof group.name === 'string' && group.name.trim()).slice(0, 8),
      placement: Object.fromEntries(Object.entries(parsed.placement).filter((entry): entry is [string, string] => typeof entry[0] === 'string' && typeof entry[1] === 'string')),
    };
  } catch {
    return { groups: [], placement: {} };
  }
}
function ensureBotGroups(): BotGroups {
  if (!agentsLoaded) return botGroups ?? { groups: [], placement: {} };
  botGroups ??= loadBotGroups();
  return botGroups;
}
function saveBotGroups(): void {
  if (!botGroups) return;
  localStorage.setItem('aeeis.bot-groups', JSON.stringify(botGroups));
}
function botById(id: string): RosterBot | undefined {
  return rosterBots().find(bot => bot.id === id);
}
function activeBotId(): string {
  return rosterBots().some(bot => bot.id === selectedBotId) ? selectedBotId : 'aeeis';
}
function chatRoom(): RoomSummary | undefined {
  return roomSummaries.find(room => room.id === openGroupId);
}
function roomChat(room: RoomSummary | undefined): string | undefined { return room?.chat ?? (room?.description === '私聊' ? 'direct' : room?.description === '群聊' ? 'group' : undefined); }
function isManagedChat(room: RoomSummary): boolean {
  return room.chat === 'direct' || room.chat === 'group' || room.chat === 'unclassified' || (!room.chat && (room.description === '私聊' || room.description === '群聊'));
}
function rosterView(): 'entry' | 'bot' | 'group' | 'draft' | 'direct' {
  if (groupDraftOpen) return 'draft';
  const room = chatRoom();
  if (roomChat(room) === 'direct') return 'direct';
  if (roomChat(room) === 'group' || openGroupId) return openGroupId ? 'group' : 'entry';
  return activeBotId() === 'aeeis' ? 'entry' : 'bot';
}
function directRoomId(principalId: string): string {
  for (const [roomId, memberId] of directMembers) {
    if (memberId !== principalId) continue;
    const room = roomSummaries.find(item => item.id === roomId);
    if (room && isManagedChat(room) && roomChat(room) === 'direct') return roomId;
  }
  return '';
}
function lifeAgent(view: { id: string; agentId?: string } | undefined): string {
  if (!view) return '';
  if (view.agentId) return view.agentId;
  return view.id === aeeisConversationId ? 'aeeis' : '';
}
function lifeSummary(agentId: string): ConversationSummary | undefined {
  const stamped = conversationList.find(item => item.agentId === agentId);
  if (stamped) return stamped;
  if (agentId === 'aeeis' && aeeisConversationId) return conversationList.find(item => item.id === aeeisConversationId) ?? (conversation?.id === aeeisConversationId ? conversation : undefined);
  return undefined;
}
function taskCountOf(item: ConversationSummary | undefined): number | undefined {
  if (!item) return undefined;
  if (typeof item.taskCount === 'number') return item.taskCount;
  const tasks = (item as ConversationView).tasks;
  return Array.isArray(tasks) ? tasks.length : undefined;
}
function presenceFromTasks(tasks: Array<{ id: string; title: string; status: string }>): LifePresence {
  const rank = (status: string) => status === 'needs_approval' || status === 'needs_input' || status === 'waiting_external' ? 0
    : status === 'unknown' ? 1
    : status === 'failed' || status === 'channel_blocked' ? 2
    : status === 'paused' ? 3
    : status === 'planning' || status === 'reviewing' ? 4
    : status === 'running' || status === 'queued' || status === 'preparing' ? 5
    : 9;
  const lead = tasks.filter(task => rank(task.status) < 9).sort((left, right) => rank(left.status) - rank(right.status))[0];
  if (!lead) return { state: 'idle', label: '空闲' };
  const ranked = rank(lead.status);
  const state = ranked === 0 ? 'waiting' as const : ranked === 1 ? 'unknown' as const : ranked === 2 ? 'blocked' as const : ranked === 3 ? 'paused' as const : ranked === 4 ? 'thinking' as const : 'working' as const;
  const label = state === 'waiting' ? '等你' : state === 'unknown' ? '待核查' : state === 'blocked' ? '卡住' : state === 'paused' ? '已暂停' : state === 'thinking' ? '思考中' : '执行中';
  return { state, label, taskId: lead.id, taskTitle: lead.title };
}
/** Tasks a group handed from one person's thread to another holder, or blocked in
 * the channel. The roster counts each with its holder, so a transfer moves the work
 * and its Run state; a channel block shows as stuck and waits in the inbox. */
interface BoardHoldingView { roomId: string; roomTitle?: string; conversationId: string; taskId: string; holderId: string; fromId: string; title?: string; status: string; blocked?: string; blockedAt?: string }
let boardHoldings: BoardHoldingView[] = [];
let boardHoldingsReadAt = 0;
async function loadBoardHoldings(): Promise<void> {
  if (Date.now() - boardHoldingsReadAt < 10_000) return;
  boardHoldingsReadAt = Date.now();
  boardHoldings = await api<{ items?: BoardHoldingView[] }>('/board-holdings').then(page => Array.isArray(page.items) ? page.items : []).catch(() => boardHoldings);
}
function lifePresence(agentId: string): LifePresence {
  const open = conversation && lifeAgent(conversation) === agentId ? conversation.tasks : undefined;
  const listed = lifeSummary(agentId);
  const away = new Set(boardHoldings.filter(item => item.fromId === agentId).map(item => item.taskId));
  const held = boardHoldings.filter(item => item.holderId === agentId).map(item => ({ id: item.taskId, title: item.title ?? '交过来的事', status: item.blocked ? 'channel_blocked' : item.status }));
  const own = open ?? (listed && 'tasks' in listed ? (listed as ConversationView).tasks : undefined);
  const tasks = own ? [...own.filter(task => !away.has(task.id)), ...held] : undefined;
  if (tasks?.length) {
    const derived = presenceFromTasks(tasks);
    if (derived.state !== 'idle') return derived;
    return { state: 'idle', label: `空闲 · ${tasks.length} 件事` };
  }
  const fromHeld = presenceFromTasks(held);
  if (fromHeld.state !== 'idle') return fromHeld;
  if (listed?.presence && listed.presence.state !== 'idle' && !(listed.presence.taskId && away.has(listed.presence.taskId))) return listed.presence;
  const count = Math.max(0, (taskCountOf(listed) ?? 0) - away.size) + held.length;
  if (count) return { state: 'idle', label: `空闲 · ${count} 件事` };
  return { state: 'idle', label: '空闲' };
}
function lifePresenceLabel(agentId: string): string {
  const presence = lifePresence(agentId);
  return presence.state === 'idle' || !presence.taskTitle ? presence.label : `${presence.label} · ${presence.taskTitle}`;
}
function lifeAvatarState(agentId: string): string {
  const state = lifePresence(agentId).state;
  if (state === 'paused') return 'waiting';
  if (state === 'unknown' || state === 'blocked') return 'blocked';
  return state;
}
function rememberAeeisHome(list: ConversationSummary[], loaded?: ConversationSummary): void {
  const stamped = list.find(item => item.agentId === 'aeeis');
  if (stamped) {
    aeeisConversationId = stamped.id;
    localStorage.setItem(LIFE_HOME, stamped.id);
    return;
  }
  if (aeeisConversationId && list.some(item => item.id === aeeisConversationId && !item.agentId)) return;
  const unscoped = loaded && !loaded.agentId ? loaded : list.find(item => !item.agentId);
  if (!unscoped) return;
  aeeisConversationId = unscoped.id;
  localStorage.setItem(LIFE_HOME, unscoped.id);
}
function aeeisThread(): { id: string; revision: number } | undefined {
  const stamped = conversationList.find(item => item.agentId === 'aeeis');
  if (stamped) return stamped;
  if (aeeisConversationId) {
    const remembered = conversationList.find(item => item.id === aeeisConversationId);
    if (remembered) return remembered;
    if (conversation?.id === aeeisConversationId) return conversation;
  }
  if (conversationList.length <= 1) return conversation ?? conversationList[0];
  return conversation;
}
function participantLabel(principalId: string): string {
  return botById(principalId)?.name ?? groupMembers.find(member => member.principalId === principalId)?.displayName ?? agentSummaries.find(agent => agent.agentId === principalId)?.card.name ?? principalId;
}
function eventWriter(event: SessionEventSummary): { id: string; type: 'principal' | 'agent' | 'system' } {
  return event.recordedBy ?? { id: event.actorId, type: event.actorType };
}
function roomOwnerWrote(event: SessionEventSummary): boolean {
  const writer = eventWriter(event);
  if (writer.type !== 'principal') return false;
  if (event.owner) return writer.id === event.owner;
  return Boolean(sessionPrincipal) && writer.id === sessionPrincipal;
}
/** Board marks and receipts the server wrote for the Bots (proposals, handoffs, reassignment). */
function automaticRecord(event: SessionEventSummary): boolean {
  return event.actorType === 'principal' && /^(bot-|handoff-)/.test(event.idempotencyKey ?? '');
}
function eventAuthor(event: SessionEventSummary): string {
  if (event.type === 'digest') return 'AEEIS · 摘要';
  if (automaticRecord(event)) return '自动记录';
  if (event.type === 'system') {
    const writer = eventWriter(event);
    if (writer.type === 'system' || roomOwnerWrote(event)) return '记录';
    return participantLabel(writer.id);
  }
  if (event.actorType === 'agent') return participantLabel(event.actorId);
  if (groupMembers.some(member => member.principalId === event.actorId)) return participantLabel(event.actorId);
  return '你';
}
function lifePersonId(): string {
  const view = rosterView();
  if (view === 'entry') return lifeAgent(conversation) || 'aeeis';
  if (view === 'bot') return lifeAgent(conversation) || activeBotId();
  return '';
}
function messageSource(item: ConversationMessageView): string {
  if (item.source?.kind === 'channel') return item.source.channel === 'feishu' ? ' · 来自飞书' : ` · 来自 ${item.source.channel}`;
  if (item.source?.kind === 'room') return ` · 旧私聊历史${item.source.operation === 'retract' ? '（已撤回）' : ''}`;
  if (item.source?.kind === 'artifact') return ` · 产物草稿：${item.source.title}`;
  if (item.source?.kind === 'routine') return item.source.trigger === 'webhook' ? ' · 例程（Webhook）' : ' · 例程（定时）';
  return '';
}
function messageAuthor(item: ConversationMessageView): string {
  if (item.role === 'notification') return '任务通知';
  const person = lifePersonId();
  const personLabel = person ? participantLabel(person) : '';
  if (item.speaker?.role === 'agent') {
    const who = participantLabel(item.speaker.id);
    if (person && item.speaker.id !== person) return `${who} · 对${personLabel}`;
    return who;
  }
  if (item.speaker && person && item.speaker.id !== person) return `你 · 对${personLabel}`;
  return '你';
}
function selectedLifeSpeaker(): { role: 'agent'; id: string } | undefined {
  const view = rosterView();
  if (view !== 'entry' && view !== 'bot') return;
  const id = $<HTMLSelectElement>('life-speaker')?.value.trim() ?? '';
  const person = lifePersonId();
  if (!id || id !== person || !/^[A-Za-z0-9._-]+$/.test(id)) return;
  return { role: 'agent', id };
}
function syncLifeSpeaker(): void {
  const select = $<HTMLSelectElement>('life-speaker');
  if (!select) return;
  const view = rosterView();
  const person = lifePersonId();
  const valid = /^[A-Za-z0-9._-]+$/.test(person);
  const previous = select.value;
  select.replaceChildren();
  const you = document.createElement('option');
  you.value = '';
  you.textContent = '你';
  select.append(you);
  if (valid) {
    const option = document.createElement('option');
    option.value = person;
    option.textContent = participantLabel(person);
    select.append(option);
  }
  select.value = valid && previous === person ? previous : '';
  select.hidden = view !== 'entry' && view !== 'bot';
}
function speakerChoices(): Array<{ id: string; label: string; type: 'agent' | 'principal' }> {
  const view = rosterView();
  if (view === 'group') {
    return groupMembers.filter(member => member.role === 'agent' && member.status === 'active').map(member => ({ id: member.principalId, label: participantLabel(member.principalId), type: 'agent' as const }));
  }
  if (view === 'direct') {
    return groupMembers.filter(member => member.status === 'active').map(member => ({
      id: member.principalId,
      label: participantLabel(member.principalId),
      type: member.role === 'agent' ? 'agent' as const : 'principal' as const,
    }));
  }
  return [];
}
function selectedRoomSpeaker(): { type: 'agent' | 'principal'; id: string } | undefined {
  const view = rosterView();
  if (view !== 'group' && view !== 'direct') return;
  const id = $<HTMLSelectElement>('group-speaker')?.value.trim() ?? '';
  if (!id) return;
  const choice = speakerChoices().find(item => item.id === id);
  if (!choice) return;
  return { type: choice.type, id: choice.id };
}
function syncGroupSpeaker(): void {
  const select = $<HTMLSelectElement>('group-speaker');
  if (!select) return;
  const previous = select.value;
  const choices = speakerChoices();
  select.replaceChildren();
  const you = document.createElement('option');
  you.value = '';
  you.textContent = '你';
  select.append(you);
  for (const choice of choices) {
    const option = document.createElement('option');
    option.value = choice.id;
    option.textContent = choice.label;
    select.append(option);
  }
  select.value = choices.some(choice => choice.id === previous) ? previous : '';
  const view = rosterView();
  select.hidden = view !== 'group' && view !== 'direct';
  syncGroupHandoff();
}
function handoffChoices(): RosterBot[] {
  const members = new Set(groupMembers.filter(member => member.role === 'agent' && member.status === 'active').map(member => member.principalId));
  return rosterBots().filter(bot => bot.id === 'aeeis' || members.has(bot.id));
}
function syncGroupHandoff(): void {
  const select = $<HTMLSelectElement>('group-handoff');
  if (!select) return;
  const previous = select.value;
  const choices = handoffChoices();
  select.replaceChildren();
  const stay = document.createElement('option');
  stay.value = '';
  stay.textContent = '只留在会话里';
  select.append(stay);
  for (const bot of choices) {
    const option = document.createElement('option');
    option.value = bot.id;
    option.textContent = `交给${bot.name}`;
    select.append(option);
  }
  select.value = choices.some(bot => bot.id === previous) ? previous : '';
  select.hidden = rosterView() !== 'group';
}
function handoffCitation(event: SessionEventSummary): { conversationId: string; taskId: string; agentId?: string } | undefined {
  if (!roomOwnerWrote(event)) return;
  const refs = event.evidenceRefs ?? [];
  const conversationId = refs.find(id => id.startsWith('conv_') && CITATION_ID.test(id));
  const taskId = refs.find(id => id.startsWith('task_') && CITATION_ID.test(id));
  if (!conversationId || !taskId) return;
  const agentId = refs.find(id => id !== conversationId && id !== taskId && CITATION_ID.test(id) && botById(id));
  return agentId ? { conversationId, taskId, agentId } : { conversationId, taskId };
}
type BoardColumn = 'capture' | 'ready' | 'doing' | 'blocked' | 'review' | 'done';
const BOARD_COLUMNS: Array<{ id: BoardColumn; title: string }> = [
  { id: 'capture', title: '待整理' },
  { id: 'ready', title: '待领取' },
  { id: 'doing', title: '进行中' },
  { id: 'blocked', title: '阻塞' },
  { id: 'review', title: '待验收' },
  { id: 'done', title: '完成' },
];
interface BoardDecision { assigneeId?: string; conflicts: string[]; accepted: boolean; revision?: string; blockedNote?: string; cancelReason?: string; cancelled: boolean; released: boolean; handedUp: boolean; lines: string[]; proposedBy?: string; proposalReason?: string; adopted?: boolean; offer?: { to: string; note?: string } }
interface ChannelBoardCardView { version?: number; runRevision?: number; canMove?: boolean; override?: boolean; autoColumn?: string; conversationId: string; taskId: string; agentId?: string; ownerId: string; movedFrom?: string; title?: string; status: string; runId?: string; column: string; decision: BoardDecision; chain: string[] }
interface ChannelBoardView {
  cursor: number;
  cards: ChannelBoardCardView[];
  citations: Array<{ eventId: string; sequence?: number; conversationId: string; taskId: string; agentId?: string; actorId: string; actorType: string; at?: string; content: string; automatic?: boolean }>;
  actions: Array<{ eventId: string; sequence?: number; kind: string; conversationId: string; taskId: string; agentId?: string; at?: string }>;
  wip: Array<{ agentId: string; count: number }>;
}
function channelLog(): SessionEventSummary[] {
  if (!laterChannelEvents.length && !liveChannelEvents.length) return groupEvents;
  return [...groupEvents, ...laterChannelEvents, ...liveChannelEvents];
}
function channelReadableEvents(): SessionEventSummary[] {
  return channelLog().filter(event => event.operation !== 'retract' && event.botDelivery?.mode !== 'digest');
}
function earlierChannelCount(): number {
  return Math.max(0, channelReadableEvents().length - channelHistoryPages * CHANNEL_TRANSCRIPT_PAGE);
}
function visibleChannelEvents(): SessionEventSummary[] {
  const readable = channelReadableEvents();
  const keep = channelHistoryPages * CHANNEL_TRANSCRIPT_PAGE;
  return readable.length > keep ? readable.slice(-keep) : readable;
}
function citedTaskSignature(event: SessionEventSummary): string {
  const cite = handoffCitation(event);
  if (!cite) return '';
  const view = handoffViews.get(cite.conversationId);
  const task = view?.tasks.find(item => item.id === cite.taskId);
  if (!view || !task) return 'pending';
  const delivery = view.lastDelivery?.taskId === task.id ? view.lastDelivery : undefined;
  return JSON.stringify({
    person: cite.agentId ?? view.agentId ?? '',
    title: task.title,
    status: task.status,
    runId: task.runId ?? '',
    latestRunId: task.latestRunId ?? '',
    approval: task.pendingApproval?.summary ?? '',
    question: task.pendingQuestion?.text ?? '',
    takenOver: task.takenOver?.at ?? '',
    steps: (task.execution?.steps ?? []).map(step => `${step.state}:${step.title}`),
    evidence: task.execution?.evidence ?? [],
    plan: delivery?.planSummary ?? '',
    artifacts: delivery?.artifactTitles ?? [],
    deliveryRun: delivery?.runId ?? '',
    decision: boardCardFor(cite.conversationId, cite.taskId)?.decision ?? null,
  });
}
function channelTranscriptSignature(): string {
  const members = groupMembers.map(member => `${member.principalId}:${member.status}:${participantLabel(member.principalId)}`).join('\n');
  const events = visibleChannelEvents().map(event => [
    event.id,
    event.operation ?? '',
    event.type,
    eventAuthor(event),
    event.content,
    (event.evidenceRefs ?? []).join(' '),
    citedTaskSignature(event),
  ].join('\u001f')).join('\u001e');
  return `${channelHistoryPages}\u0000${earlierChannelCount()}\u0000${members}\u0000${events}`;
}
function eventCursor(event: SessionEventSummary | undefined): string | undefined {
  const sequence = event?.sequence;
  return typeof sequence === 'number' && Number.isInteger(sequence) && sequence > 0 ? String(sequence) : undefined;
}
function noteEventPage(page: SessionEventPage, requestedCursor: string | undefined): void {
  const next = page.nextCursor;
  if (next && next !== requestedCursor) {
    groupEventCursor = next;
    channelEventsCaughtUp = false;
    return;
  }
  const sequence = eventCursor(page.items?.at(-1));
  groupEventCursor = sequence ?? requestedCursor;
  channelEventsCaughtUp = true;
}
function resetChannelLog(): void {
  groupEvents = [];
  laterChannelEvents = [];
  liveChannelEvents = [];
  groupEventCursor = undefined;
  channelLoadedRoomId = '';
  channelEventsCaughtUp = false;
  channelHistoryPages = 1;
  channelTranscriptKey = '';
  channelReadEpoch += 1;
  channelOlderCursor = undefined;
  channelBoardState = undefined;
  channelBoardRoomId = '';
  channelBoardSeen = '';
}
/** Reads the page before the oldest loaded message. Only the transcript needs
 * it; the board already covers the whole channel. */
async function readOlderChannelPage(): Promise<void> {
  const roomId = openGroupId;
  const before = channelOlderCursor;
  if (!roomId || !before) return;
  const epoch = channelReadEpoch;
  const page = await api<SessionEventPage>(`/rooms/${encodeURIComponent(roomId)}/session-events?limit=50&before=${encodeURIComponent(before)}`);
  if (openGroupId !== roomId || epoch !== channelReadEpoch || channelOlderCursor !== before) return;
  const seen = new Set(channelLog().map(event => event.id));
  groupEvents = [...(page.items ?? []).filter(event => !seen.has(event.id)), ...groupEvents];
  channelOlderCursor = page.previousCursor;
  channelHistoryPages += 1;
  renderGroupTranscript();
  void refreshHandoffViews();
}
function appendUnseen(items: SessionEventSummary[] | undefined, into: SessionEventSummary[]): void {
  const seen = new Set(channelLog().map(event => event.id));
  for (const item of items ?? []) if (!seen.has(item.id)) { into.push(item); seen.add(item.id); }
}
function emptyBoardDecision(): BoardDecision {
  return { conflicts: [], accepted: false, cancelled: false, released: false, handedUp: false, lines: [] };
}
function boardState(): ChannelBoardView | undefined {
  return channelBoardRoomId && channelBoardRoomId === openGroupId ? channelBoardState : undefined;
}
function boardCardFor(conversationId: string, taskId: string): ChannelBoardCardView | undefined {
  return boardState()?.cards.find(card => card.conversationId === conversationId && card.taskId === taskId);
}
/** "From X" when a handoff moved the task off X's thread; "claimed" when someone took it. */
function holderNote(conversationId: string, taskId: string, decision: BoardDecision): string | undefined {
  const movedFrom = boardCardFor(conversationId, taskId)?.movedFrom;
  if (movedFrom) return `来自${participantLabel(movedFrom)}`;
  return decision.assigneeId ? `${botById(decision.assigneeId)?.name ?? decision.assigneeId}已领取` : undefined;
}
function boardDecision(conversationId: string, taskId: string): BoardDecision {
  return boardCardFor(conversationId, taskId)?.decision ?? emptyBoardDecision();
}
/** Reads the server's board for this channel. Every decision on a card comes
 * from it; the browser does not work out task state from message text. */
async function loadChannelBoardState(roomId: string): Promise<void> {
  if (channelBoardLoad) return channelBoardLoad;
  const seen = channelLogMark();
  const run = (async () => {
    const board = await api<ChannelBoardView>(`/rooms/${encodeURIComponent(roomId)}/board`);
    if (openGroupId !== roomId) return;
    channelBoardState = board;
    channelBoardRoomId = roomId;
    channelBoardSeen = seen;
  })();
  channelBoardLoad = run.finally(() => { channelBoardLoad = undefined; });
  return channelBoardLoad;
}
function channelLogMark(): string {
  const log = channelLog();
  return `${log.length}\u0000${log.at(-1)?.id ?? ''}`;
}
function boardBehind(): boolean {
  return channelBoardOpen || !boardState() || channelLogMark() !== channelBoardSeen;
}
function taskRunId(task: ConversationTaskView): string | undefined {
  return task.runId ?? task.latestRunId;
}
function blockPausesRun(task: ConversationTaskView): boolean {
  return Boolean(taskRunId(task) && ['queued', 'planning', 'running', 'reviewing'].includes(task.status));
}
function blockNoteCurrent(status: string, decision: BoardDecision): string | undefined {
  if (!decision.blockedNote) return;
  if (['planning', 'running', 'reviewing', 'preparing', 'queued', 'succeeded', 'failed', 'cancelled', 'unreadable'].includes(status)) return;
  return decision.blockedNote;
}
function channelCancelHolds(task: ConversationTaskView, decision: BoardDecision): boolean {
  if (!decision.cancelled || taskRunId(task)) return false;
  return task.status === 'discussion' || task.status === 'preparing' || task.status === 'queued';
}
function boardColumn(status: string, decision?: BoardDecision, runId?: string): BoardColumn | 'failed' {
  if (decision?.cancelled && !runId && (status === 'discussion' || status === 'preparing' || status === 'queued')) return 'failed';
  if (status === 'failed' || status === 'cancelled' || status === 'unreadable') return 'failed';
  if (decision && blockNoteCurrent(status, decision)) return 'blocked';
  if (decision?.released && !decision.assigneeId && !runId && (status === 'discussion' || status === 'preparing' || status === 'queued')) return 'ready';
  if (status === 'discussion') return 'capture';
  if (status === 'preparing' || status === 'queued') return 'ready';
  if (status === 'planning' || status === 'running' || status === 'reviewing') return 'doing';
  if (status === 'needs_approval' || status === 'needs_input' || status === 'waiting_external' || status === 'paused' || status === 'unknown') return 'blocked';
  if (status === 'succeeded') return decision?.accepted ? 'done' : 'review';
  return 'capture';
}
function taskAgeLabel(createdAt: string | undefined): string | undefined {
  if (!createdAt) return;
  const hours = (Date.now() - Date.parse(createdAt)) / 3_600_000;
  if (!Number.isFinite(hours) || hours < 24) return;
  return `从记下起已停留 ${Math.floor(hours / 24)} 天`;
}
function blockedCaption(status: string): string {
  if (status === 'waiting_external') return '等外部';
  if (status === 'unknown') return '待核查';
  if (status === 'needs_approval' || status === 'needs_input' || status === 'paused') return '需要你';
  return '';
}
function taskStateLabel(task: ConversationTaskView): string {
  if (task.status === 'discussion') return '仅讨论，未执行';
  if (task.status === 'preparing') return '正在准备执行';
  return runStatusLabel(task.status);
}
function hideChannelBoard(): void {
  channelBoardOpen = false;
  channelBoardEpoch += 1;
  const board = $('channel-board');
  const task = $('channel-task');
  const transcript = $('group-transcript');
  if (board) board.hidden = true;
  if (task) task.hidden = true;
  $('channel-task-body')?.replaceChildren();
  if (transcript) transcript.hidden = false;
}
function channelCitations(): Array<{ conversationId: string; taskId: string; agentId?: string }> {
  const seen = new Set<string>();
  const citations: Array<{ conversationId: string; taskId: string; agentId?: string }> = [];
  for (const cite of boardState()?.citations ?? []) {
    const key = `${cite.conversationId}\0${cite.taskId}`;
    if (seen.has(key)) continue;
    seen.add(key);
    citations.push(cite.agentId && botById(cite.agentId) ? { conversationId: cite.conversationId, taskId: cite.taskId, agentId: cite.agentId } : { conversationId: cite.conversationId, taskId: cite.taskId });
  }
  return citations;
}
function channelBoardIds(): string[] {
  return [...new Set((boardState()?.cards ?? []).map(card => card.conversationId))];
}
async function absorbLaterEventsNow(roomId: string, epoch: number): Promise<void> {
  for (let page = 0; page < 20 && groupEventCursor && !channelEventsCaughtUp && openGroupId === roomId && channelLoadedRoomId === roomId && epoch === channelReadEpoch; page += 1) {
    const cursor = groupEventCursor;
    const next = await api<SessionEventPage>(`/rooms/${encodeURIComponent(roomId)}/session-events?limit=50&cursor=${encodeURIComponent(cursor)}`).catch(() => undefined);
    if (!next || openGroupId !== roomId || channelLoadedRoomId !== roomId || epoch !== channelReadEpoch) return;
    appendUnseen(next.items, laterChannelEvents);
    noteEventPage(next, cursor);
  }
}
function absorbLaterEvents(roomId: string, epoch: number): Promise<void> {
  const run = channelReadQueue.then(() => absorbLaterEventsNow(roomId, epoch));
  channelReadQueue = run.then(() => undefined, () => undefined);
  return run;
}
async function showChannelBoard(): Promise<void> {
  const roomId = openGroupId;
  if (!roomId) return;
  channelBoardOpen = true;
  const epoch = ++channelBoardEpoch;
  await loadChannelBoardState(roomId);
  if (epoch !== channelBoardEpoch || openGroupId !== roomId || !channelBoardOpen) return;
  renderChannelBoard();
  const loaded = await Promise.all(channelBoardIds().map(async id => {
    try { return await api<ConversationView>(`/conversations/${encodeURIComponent(id)}`); }
    catch { return handoffViews.get(id); }
  }));
  if (epoch !== channelBoardEpoch || openGroupId !== roomId || !channelBoardOpen) return;
  for (const view of loaded) if (view) handoffViews.set(view.id, view);
  renderChannelBoard();
}
function renderChannelBoard(): void {
  const board = $('channel-board');
  const columns = $('channel-board-columns');
  const failures = $('channel-board-failures');
  const note = $('channel-board-note');
  const transcript = $('group-transcript');
  const empty = $('group-thread-empty');
  if (board) board.hidden = !channelBoardOpen;
  if (transcript) transcript.hidden = channelBoardOpen;
  if (empty) empty.hidden = channelBoardOpen || visibleChannelEvents().some(event => event.operation !== 'retract');
  if (!channelBoardOpen || !columns || !failures) return;
  const cards = (boardState()?.cards ?? []).flatMap(card => {
    const view = handoffViews.get(card.conversationId);
    const task = view?.tasks.find(item => item.id === card.taskId);
    if (!view || !task) return [];
    const decision = card.decision;
    const ownerId = decision.released ? '' : (card.ownerId || view.agentId || '');
    const owner = decision.released ? '待领取' : (botById(ownerId)?.name ?? (ownerId || '这个人'));
    return [{ view, task, owner, ownerId, decision }];
  });
  const placed = cards.map(card => ({ ...card, column: boardCardFor(card.view.id, card.task.id)?.column ?? boardColumn(card.task.status, card.decision, taskRunId(card.task)) }));
  const failed = placed.filter(card => card.column === 'failed');
  failures.replaceChildren();
  failures.append(document.createTextNode(failed.length ? `有 ${failed.length} 件失败或读不到` : '没有失败或读不到的事'));
  for (const card of failed) failures.append(boardCard(card.view, card.task, card.owner, 'channel-failure-card', card.decision));
  const doing = placed.filter(card => card.column === 'doing');
  const loads = new Map<string, { name: string; count: number }>();
  for (const card of doing) {
    const current = loads.get(card.ownerId) ?? { name: card.owner, count: 0 };
    current.count += 1;
    loads.set(card.ownerId, current);
  }
  const wip = (boardState()?.wip.map(item => ({ name: participantLabel(item.agentId),count: item.count })) ?? [...loads.values()]).filter(item => item.count > 3).map(item => `${item.name}进行中已有 ${item.count} 件。先完成或转交。`);
  if (note) note.textContent = ['这六列只列出这个频道交接过的事。看一眼不会执行，也不会改讨论焦点。', ...wip].filter(Boolean).join(' ');
  const moreButton = $('channel-board-more');
  if (moreButton) moreButton.hidden = true;
  columns.replaceChildren();
  const pending = pendingBoardMove();
  if (pending) columns.append(dashboardButton('用原请求确认上次移动', () => submitBoardMove(pending)));
  for (const column of BOARD_COLUMNS) {
    const section = element('section', '', 'channel-board-column');
    section.dataset.column = column.id;
    section.addEventListener('dragover', event => event.preventDefault());
    section.addEventListener('drop', event => { event.preventDefault(); const card = draggedBoardCard; draggedBoardCard = undefined; if (card) void moveChannelCard(card, column.id).catch(error => message(errorMessage(error))); });
    const items = placed.filter(card => card.column === column.id);
    section.append(element('h3', `${column.title} ${items.length}`));
    if (!items.length) section.append(element('small', '这一列还空着'));
    for (const card of items) section.append(boardCard(card.view, card.task, card.owner, 'channel-board-card', card.decision));
    columns.append(section);
  }
  if (!cards.length) columns.append(element('p', '这个频道还没有记下的事。'));
}
let draggedBoardCard: ChannelBoardCardView | undefined;
const BOARD_MOVE_PENDING = 'aeeis.board.pending';
interface BoardMoveAttempt { roomId: string; scope: string; body: string }
function pendingBoardMove(): BoardMoveAttempt | undefined {
  try { const saved = JSON.parse(sessionStorage.getItem(BOARD_MOVE_PENDING) ?? 'null') as BoardMoveAttempt | null; return saved?.scope === conversationScope && saved.roomId === openGroupId && typeof saved.body === 'string' ? saved : undefined; }
  catch { sessionStorage.removeItem(BOARD_MOVE_PENDING); return undefined; }
}
async function submitBoardMove(attempt: BoardMoveAttempt): Promise<void> {
  try { await api(`/rooms/${encodeURIComponent(attempt.roomId)}/board-controls`, JSON.parse(attempt.body)); sessionStorage.removeItem(BOARD_MOVE_PENDING); }
  catch (error) { if (error instanceof ApiError && error.status < 500) sessionStorage.removeItem(BOARD_MOVE_PENDING); throw error; }
  finally { await loadChannelBoardState(attempt.roomId); renderChannelBoard(); }
}
async function moveChannelCard(card: ChannelBoardCardView, toColumn: string | null): Promise<void> {
  const existing = pendingBoardMove();
  if (existing) { await submitBoardMove(existing); return; }
  const roomId = openGroupId;
  const reason = window.prompt('移动原因（移动不会执行、暂停或批准 Run）', '主人整理任务板');
  if (!reason?.trim()) return;
  const attempt = { roomId,scope: conversationScope,body: JSON.stringify({ kind: toColumn === null ? 'clear_override' : 'move',conversationId: card.conversationId,taskId: card.taskId,toColumn,expectedVersion: card.version,expectedRunId: card.runId ?? null,expectedRunRevision: card.runRevision ?? null,reason,source: 'home',idempotencyKey: crypto.randomUUID() }) };
  sessionStorage.setItem(BOARD_MOVE_PENDING,JSON.stringify(attempt));
  const oldColumn = card.column; card.column = toColumn ?? card.autoColumn ?? oldColumn; renderChannelBoard();
  try { await submitBoardMove(attempt); }
  catch (error) { card.column = oldColumn; renderChannelBoard(); message('移动未确认，已重新读取任务板；可用原请求确认结果。'); throw error; }
}
function boardCard(view: ConversationView, task: ConversationTaskView, owner: string, className: string, decision: BoardDecision): HTMLElement {
  const button = element('button', '', className) as HTMLButtonElement;
  button.type = 'button';
  button.dataset.boardTask = task.id;
  button.dataset.boardOwner = view.agentId ?? '';
  button.append(element('strong', task.title), element('small', owner), element('small', taskStateLabel(task)));
  const blocked = blockedCaption(task.status);
  if (blocked) button.append(element('small', blocked));
  const blockNote = blockNoteCurrent(task.status, decision);
  if (blockNote) button.append(element('small', `阻塞：${blockNote}`));
  if (decision.proposedBy && !decision.adopted && !decision.cancelled && task.status === 'discussion') button.append(element('small', `提议 · ${participantLabel(decision.proposedBy)}${decision.proposalReason ? `：${decision.proposalReason}` : ''}`));
  if (decision.offer) button.append(element('small', `交接中 → ${participantLabel(decision.offer.to)}`));
  const held = holderNote(view.id, task.id, decision);
  if (held) button.append(element('small', held));
  if (decision.conflicts.length) button.append(element('small', '已被领取'));
  if (decision.accepted) button.append(element('small', '已验收'));
  if (decision.revision) button.append(element('small', `要求修改：${decision.revision}`));
  if (channelCancelHolds(task, decision)) button.append(element('small', '已在频道里取消'));
  const age = taskAgeLabel(task.createdAt);
  if (age) button.append(element('small', age));
  button.addEventListener('click', () => openChannelTask(view, task, owner));
  const card = boardCardFor(view.id, task.id);
  if (!card?.canMove) return button;
  button.draggable = true;
  button.addEventListener('dragstart', event => { draggedBoardCard = card; event.dataTransfer?.setData('text/plain', task.id); });
  button.addEventListener('dragend', () => { draggedBoardCard = undefined; });
  const wrap = element('div', '', 'channel-board-control');
  const menu = element('select', '') as HTMLSelectElement; menu.setAttribute('aria-label', `移动到 · ${task.title}`);
  menu.append(new Option('移动到…', ''));
  for (const column of BOARD_COLUMNS) if (column.id !== card.column) menu.append(new Option(column.title, column.id));
  menu.addEventListener('change', () => { if (menu.value) void moveChannelCard(card, menu.value).catch(error => message(errorMessage(error))); });
  const handle = element('button', '⠿', 'board-touch-handle') as HTMLButtonElement; handle.type = 'button'; handle.setAttribute('aria-label', `拖动 ${task.title}`);
  let start: { x: number; y: number } | undefined;
  handle.addEventListener('pointerdown', event => { if (event.pointerType !== 'mouse') { start = { x: event.clientX, y: event.clientY }; handle.setPointerCapture?.(event.pointerId); } });
  handle.addEventListener('pointercancel', () => { start = undefined; });
  handle.addEventListener('pointerup', event => {
    if (!start) return;
    const distance = Math.hypot(event.clientX-start.x, event.clientY-start.y); start = undefined;
    if (distance < 8) return;
    const target = document.elementFromPoint(event.clientX,event.clientY)?.closest<HTMLElement>('[data-column]');
    if (target?.dataset.column) void moveChannelCard(card,target.dataset.column).catch(error => message(errorMessage(error)));
  });
  wrap.append(button, handle, menu);
  if (card.override) wrap.append(dashboardButton('恢复自动列', () => moveChannelCard(card, null)));
  return wrap;
}
function channelOwnerName(view: ConversationView, task: ConversationTaskView): string {
  const cite = channelCitations().find(item => item.conversationId === view.id && item.taskId === task.id);
  const ownerId = boardCardFor(view.id, task.id)?.ownerId || cite?.agentId || view.agentId || '';
  return botById(ownerId)?.name ?? (ownerId || '这个人');
}
function doingCount(agentId: string): number {
  return channelCitations().filter(cite => {
    const view = handoffViews.get(cite.conversationId);
    const task = view?.tasks.find(item => item.id === cite.taskId);
    if (!view || !task) return false;
    const ownerId = boardCardFor(cite.conversationId, task.id)?.ownerId || cite.agentId || view.agentId || '';
    return ownerId === agentId && boardColumn(task.status, boardDecision(cite.conversationId, task.id), taskRunId(task)) === 'doing';
  }).length;
}
function handoffChain(conversationId: string, taskId: string): string[] {
  // The server's chain is in event order; the fallback is for a card the board has not projected yet.
  const card = boardCardFor(conversationId, taskId);
  if (card) return card.chain;
  const lines = (boardState()?.citations ?? [])
    .filter(cite => cite.conversationId === conversationId && cite.taskId === taskId)
    .map(cite => `交给${cite.agentId ? (botById(cite.agentId)?.name ?? cite.agentId) : '这个人'}`);
  return [...lines, ...boardDecision(conversationId, taskId).lines];
}
function spendLine(run: RunView): string {
  const tokens = run.modelUsage?.tokens ?? run.calls.reduce((sum, call) => sum + (call.usage?.inputTokens ?? 0) + (call.usage?.outputTokens ?? 0), 0);
  const credits = (run.toolReceipts ?? []).reduce((sum, receipt) => sum + (receipt.cost?.credits ?? 0), 0);
  const money = run.modelUsage?.moneyUsd;
  if (!tokens && !credits && money === undefined) return '还没有记下花费。';
  return `花费：${tokens} 已报告 tokens${money === undefined ? '' : ` · 估算 $${money.toFixed(4)}`}${credits ? ` · ${credits} credits` : ''}。看一眼不会改预算。`;
}
function stopLine(task: ConversationTaskView, decision: BoardDecision): string {
  if (task.pendingQuestion) return `停在这里：${task.pendingQuestion.text}`;
  if (task.pendingApproval) return `停在批准：${task.pendingApproval.summary}`;
  const blocked = blockNoteCurrent(task.status, decision);
  if (blocked) return `阻塞：${blocked}`;
  if (channelCancelHolds(task, decision)) return '已在频道里取消';
  if (task.status === 'cancelled' && decision.cancelReason) return `取消原因：${decision.cancelReason}`;
  return blockedCaption(task.status);
}
async function roomWriteContext(roomId: string): Promise<{ goalId: string; manifestId: string }> {
  const room = roomSummaries.find(item => item.id === roomId);
  const listed = await api<GoalSummary[] | { goals?: GoalSummary[] }>(`/rooms/${encodeURIComponent(roomId)}/goals`);
  const goals = Array.isArray(listed) ? listed : (listed.goals ?? []);
  let goal = goals.find(item => item.status === 'active') ?? goals[0];
  if (!goal) goal = await api<GoalSummary>('/goals', { title: room?.title || '群聊', roomId });
  const manifest = await api<{ id: string }>(`/goals/${encodeURIComponent(goal.id)}/context-manifests`, { purpose: roomChat(room) === 'direct' ? '私聊消息' : '群聊消息', audienceMode: 'room' });
  return { goalId: goal.id, manifestId: manifest.id };
}
type TaskActionKind = 'claim' | 'assign' | 'transfer' | 'refuse' | 'release' | 'accept' | 'request_changes' | 'block' | 'unblock' | 'cancel' | 'restore' | 'adopt' | 'offer';
/** Sends what the person did. The server checks the rules (first claim
 * holds, work-in-progress limit, only a success can be accepted) and answers
 * with the new board, or 409 with the reason. */
async function postTaskAction(kind: TaskActionKind, view: ConversationView, task: ConversationTaskView, extra: { agentId?: string; reason?: string } = {}): Promise<boolean> {
  const roomId = openGroupId;
  if (!roomId) return false;
  const ctx = await roomWriteContext(roomId);
  try {
    const result = await api<{ board: ChannelBoardView }>(`/rooms/${encodeURIComponent(roomId)}/task-actions`, {
      kind, conversationId: view.id, taskId: task.id, goalId: ctx.goalId, contextManifestId: ctx.manifestId, idempotencyKey: groupIdempotencyKey(),
      ...(extra.agentId ? { agentId: extra.agentId } : {}), ...(extra.reason ? { reason: extra.reason } : {}),
    });
    if (openGroupId === roomId && result?.board) { channelBoardState = result.board; channelBoardRoomId = roomId; }
    // The roster and inbox read the board again on the next refresh.
    boardHoldingsReadAt = 0;
    return true;
  } catch (error) {
    message(errorMessage(error));
    if (openGroupId === roomId) await loadChannelBoardState(roomId).catch(() => undefined);
    return false;
  }
}
async function channelPostSession(type: 'message' | 'system', content: string, evidenceRefs?: string[]): Promise<unknown> {
  const roomId = openGroupId;
  if (!roomId) return;
  const ctx = await roomWriteContext(roomId);
  const refs = [...new Set((evidenceRefs ?? []).filter(id => CITATION_ID.test(id)))];
  return api(`/rooms/${encodeURIComponent(roomId)}/session-events`, {
    goalId: ctx.goalId, type, content, contextManifestId: ctx.manifestId, idempotencyKey: groupIdempotencyKey(), ...(refs.length ? { evidenceRefs: refs } : {}),
  });
}
async function afterChannelWrite(view: ConversationView, taskId: string): Promise<void> {
  const roomId = openGroupId;
  if (!roomId) return;
  const boardWasOpen = channelBoardOpen;
  await loadGroup(roomId);
  if (openGroupId !== roomId) return;
  if (boardWasOpen) await showChannelBoard();
  const fresh = handoffViews.get(view.id);
  const task = fresh?.tasks.find(item => item.id === taskId);
  if (fresh && task && !($('channel-task')?.hidden)) openChannelTask(fresh, task, channelOwnerName(fresh, task));
}
async function claimChannelTask(view: ConversationView, task: ConversationTaskView, agentId: string): Promise<void> {
  const decision = boardDecision(view.id, task.id);
  const name = botById(agentId)?.name ?? agentId;
  if (decision.assigneeId && decision.assigneeId !== agentId) {
    message(`${botById(decision.assigneeId)?.name ?? '这位'}已领取。`);
    return;
  }
  if (decision.assigneeId === agentId) { message(`${name}已经领取这件事。`); return; }
  if (!await postTaskAction('claim', view, task, { agentId })) { await afterChannelWrite(view, task.id); return; }
  message(`已记下${name}领取「${task.title}」。还没有执行。`);
  await afterChannelWrite(view, task.id);
}
async function handChannelTask(view: ConversationView, task: ConversationTaskView, agentId: string, kind: '分派' | '转交'): Promise<void> {
  const bot = botById(agentId);
  if (!bot) { message('先从名单里选一位。'); return; }
  const load = doingCount(agentId);
  if (load >= 3) { message(`${bot.name}进行中已有 ${load} 件。先完成或转交。`); return; }
  const room = roomSummaries.find(item => item.id === openGroupId);
  const verb = kind === '分派' ? '分派' : '转交';
  const note = await recordRosterHandoff(bot, `${verb}「${task.title}」`, room, undefined, channelPostSession, title => kind === '分派'
    ? `已分派给${bot.name}，记成讨论「${title}」。未执行。`
    : `已转交给${bot.name}，记成讨论「${title}」。原来的事还在，未执行。`, 'handoff');
  if (note) { message(note); return; }
  if (!await postTaskAction(kind === '分派' ? 'assign' : 'transfer', view, task, { agentId: bot.id })) return;
  message(kind === '分派' ? `已分派给${bot.name}。记成一条新的讨论，未执行。` : `已转交给${bot.name}。原来的事还在，未执行。`);
  await afterChannelWrite(view, task.id);
}
/** How much this Bot does on its own. Only Bots saved on this account carry the setting. */
function renderBotAutonomy(bot: RosterBot | undefined): void {
  const row = $('bot-autonomy-row');
  const select = $<HTMLSelectElement>('bot-autonomy');
  const owned = bot && ownedBotRecords.find(item => item.id === bot.id);
  if (!row || !select) return;
  row.hidden = !botsActive || !owned;
  if (row.hidden || !owned) return;
  if (!select.options.length) for (const [value, label] of Object.entries(BOT_AUTONOMY_LABEL)) { const option = document.createElement('option'); option.value = value; option.textContent = label; select.append(option); }
  select.value = owned.autonomy ?? 'reply';
  select.dataset.botId = owned.id;
}
async function saveBotAutonomy(): Promise<void> {
  const select = $<HTMLSelectElement>('bot-autonomy');
  const bot = ownedBotRecords.find(item => item.id === select?.dataset.botId);
  if (!select || !bot || !bot.mark || !bot.color || !bot.background) return;
  const autonomy = select.value as BotAutonomy;
  const saved = await api<OwnedBotView>(`/bots/${encodeURIComponent(bot.id)}`, { name: bot.name, mark: bot.mark, color: bot.color, background: bot.background, ...(bot.role ? { role: bot.role } : {}), autonomy }, 'PATCH');
  rememberOwnedBot(saved);
  message(`${bot.name}：${BOT_AUTONOMY_LABEL[autonomy]}。`);
}
/** The Bot's side threads, read on demand. They never show in the chat lists. */
function renderBotSideThreads(bot: RosterBot | undefined): void {
  const details = $<HTMLDetailsElement>('bot-side-threads');
  if (!details) return;
  details.hidden = !botsActive || !bot || !sideThreadRooms.length;
  details.dataset.botId = bot?.id ?? '';
  if (details.open) void loadBotSideThreads();
}
async function loadBotSideThreads(): Promise<void> {
  const details = $<HTMLDetailsElement>('bot-side-threads');
  const list = $('bot-side-thread-list');
  const botId = details?.dataset.botId ?? '';
  if (!list || !botId) return;
  list.replaceChildren(element('li', '正在读取…'));
  const rows: HTMLElement[] = [];
  for (const room of sideThreadRooms) {
    const members = await api<RoomMemberSummary[]>(`/rooms/${encodeURIComponent(room.id)}/members`).catch(() => [] as RoomMemberSummary[]);
    if (!members.some(member => member.principalId === botId && member.status === 'active')) continue;
    const page = await api<SessionEventPage>(`/rooms/${encodeURIComponent(room.id)}/session-events?latest=1&limit=20`).catch(() => ({ items: [] as SessionEventSummary[] }));
    const row = element('li', '', 'side-thread');
    row.append(element('strong', room.title));
    const lines = element('ol');
    for (const event of page.items.filter(item => item.type === 'message')) lines.append(element('li', `${participantLabel(event.actorId)}：${event.content}`));
    row.append(lines);
    rows.push(row);
  }
  list.replaceChildren(...(rows.length ? rows : [element('li', '这位还没有和其他 Bot 谈过交接。')]));
}
/** The other Bot must accept before the card moves; the two talk it over in their side thread. */
async function offerChannelTask(view: ConversationView, task: ConversationTaskView, agentId: string): Promise<void> {
  const bot = botById(agentId);
  if (!bot) { message('先从名单里选一位。'); return; }
  if (!await postTaskAction('offer', view, task, { agentId: bot.id })) return;
  message(`已交给${bot.name}，等对方接受。卡片先留在原处。`);
  await afterChannelWrite(view, task.id);
}
async function refuseChannelTask(view: ConversationView, task: ConversationTaskView, reason: string): Promise<void> {
  const text = reason.trim();
  if (!text) { message('请先写下拒绝原因。'); return; }
  if (!await postTaskAction('refuse', view, task, { reason: text })) return;
  message(`已记下拒绝领取「${task.title}」。还没有执行。`);
  await afterChannelWrite(view, task.id);
}
async function blockChannelTask(view: ConversationView, task: ConversationTaskView, reason: string): Promise<void> {
  const text = reason.trim();
  if (!text) { message('请先写下阻塞原因。'); return; }
  const pauses = blockPausesRun(task);
  const runId = taskRunId(task);
  if (pauses && runId) {
    await api(`/runs/${encodeURIComponent(runId)}/pause`, {});
    task.status = 'paused';
  }
  if (!await postTaskAction('block', view, task, { reason: text })) return;
  message(pauses
    ? `已暂停「${task.title}」这件 Run，并记下阻塞。讨论焦点没有改变。`
    : `已记下「${task.title}」的阻塞。这次只记在频道里。讨论焦点没有改变。`);
  await afterChannelWrite(view, task.id);
}
async function unblockChannelTask(view: ConversationView, task: ConversationTaskView, reason: string): Promise<void> {
  const text = reason.trim();
  if (!text) { message('请先写下解除原因。'); return; }
  const runId = taskRunId(task);
  const still = task.status === 'paused' && runId
    ? `这件 Run 仍是已暂停。`
    : runId && ['planning', 'running', 'reviewing'].includes(task.status)
      ? `这件 Run 仍在执行。`
      : `这次只改频道记录。`;
  if (!await postTaskAction('unblock', view, task, { reason: text })) return;
  message(`已解除「${task.title}」的阻塞说明。${still}讨论焦点没有改变。`);
  await afterChannelWrite(view, task.id);
}
async function cancelChannelTask(view: ConversationView, task: ConversationTaskView, reason: string): Promise<void> {
  const text = reason.trim();
  if (!text) { message('请先写下取消原因。'); return; }
  const runId = task.runId ?? task.latestRunId;
  if (runId && !['succeeded', 'failed', 'cancelled'].includes(task.status)) {
    await api(`/runs/${encodeURIComponent(runId)}/cancel`, { reason: text });
    task.status = 'cancelled';
  }
  if (!await postTaskAction('cancel', view, task, { reason: text })) return;
  message(runId ? `已取消「${task.title}」这件 Run。讨论焦点没有改变。` : `已在频道里取消「${task.title}」。这件还没有 Run。`);
  await afterChannelWrite(view, task.id);
}
async function restoreChannelTask(view: ConversationView, task: ConversationTaskView, reason: string): Promise<void> {
  const text = reason.trim();
  if (!text) { message('请先写下撤回原因。'); return; }
  if (!await postTaskAction('restore', view, task, { reason: text })) return;
  message(task.status === 'cancelled'
    ? `已撤回「${task.title}」在频道里的取消说明。这件 Run 仍是已取消。讨论焦点没有改变。`
    : `已撤回「${task.title}」在频道里的取消。这次只改频道记录。讨论焦点没有改变。`);
  await afterChannelWrite(view, task.id);
}
async function acceptChannelTask(view: ConversationView, task: ConversationTaskView): Promise<void> {
  if (task.status !== 'succeeded' || boardDecision(view.id, task.id).accepted) return;
  if (!await postTaskAction('accept', view, task)) return;
  message(`已验收「${task.title}」。原来的产物还在，未另开 Run。`);
  await afterChannelWrite(view, task.id);
}
async function reviseChannelTask(view: ConversationView, task: ConversationTaskView, raw: string): Promise<void> {
  const text = raw.trim();
  if (!text) { message('请先写下要改的地方。'); return; }
  const bot = view.agentId ? botById(view.agentId) : undefined;
  if (!bot) { message('这件还没有可以承接修改的人。'); return; }
  const load = doingCount(bot.id);
  if (load >= 3) { message(`${bot.name}进行中已有 ${load} 件。先完成或转交。`); return; }
  const room = roomSummaries.find(item => item.id === openGroupId);
  const note = await recordRosterHandoff(bot, `要求修改「${task.title}」：${text}`, room, undefined, channelPostSession, title => `已另开修改讨论「${title}」。原来的产物还在，未执行。`, 'handoff');
  if (note) { message(note); return; }
  if (!await postTaskAction('request_changes', view, task, { agentId: bot.id, reason: text })) return;
  message(`已为「${task.title}」另开一条修改讨论。原来的产物还在。`);
  await afterChannelWrite(view, task.id);
}
interface TaskTimelineView { at: string; who: string; text: string; source: 'room' | 'run'; human: boolean }
/** §8.8: replay one task from the request to delivery, one moment at a time. Loads only when asked. */
function taskReplay(roomId: string, conversationId: string, taskId: string): HTMLElement {
  const box = element('section', '', 'task-replay');
  box.dataset.taskReplay = taskId;
  const load = dashboardButton('回放这件事', async () => {
    const { items } = await api<{ items: TaskTimelineView[] }>(`/rooms/${encodeURIComponent(roomId)}/tasks/${encodeURIComponent(conversationId)}/${encodeURIComponent(taskId)}/timeline`);
    if (!box.isConnected) return;
    if (!items.length) { box.replaceChildren(element('small', '这件事还没有可以回放的记录。')); return; }
    let index = 0;
    const caption = element('p', '');
    caption.dataset.replayStep = '';
    const list = element('ol', '', 'task-replay-list');
    for (const item of items) list.append(element('li', `${formatTime(item.at)} · ${item.who}：${item.text}`));
    const back = button('上一步', async () => show(index - 1)); back.type = 'button';
    const next = button('下一步', async () => show(index + 1)); next.type = 'button';
    const show = (to: number) => {
      index = Math.max(0, Math.min(items.length - 1, to));
      const item = items[index]!;
      caption.textContent = `${index + 1} / ${items.length} · ${formatTime(item.at)} · ${item.who}${item.human ? '（人做的决定）' : ''}：${item.text}`;
      back.disabled = index === 0; next.disabled = index === items.length - 1;
      [...list.children].forEach((row, position) => { if (position === index) (row as HTMLElement).dataset.current = 'true'; else delete (row as HTMLElement).dataset.current; });
    };
    const nav = element('div', '', 'task-replay-nav');
    nav.append(back, next);
    box.replaceChildren(element('strong', '从开口到交付'), caption, nav, list);
    show(0);
  });
  load.dataset.taskReplayLoad = taskId;
  box.append(load);
  return box;
}
function openChannelTask(view: ConversationView, task: ConversationTaskView, owner: string): void {
  const panel = $('channel-task');
  const title = $('channel-task-title');
  const body = $('channel-task-body');
  if (!panel || !body) return;
  if (title) title.textContent = task.title;
  body.dataset.task = task.id;
  body.replaceChildren();
  const decision = boardDecision(view.id, task.id);
  const column = boardColumn(task.status, decision, taskRunId(task));
  body.append(element('p', `${owner} · ${taskStateLabel(task)}`));
  const stopped = stopLine(task, decision);
  if (stopped) body.append(element('small', stopped));
  if (!blockNoteCurrent(task.status, decision) && decision.blockedNote) body.append(element('small', `频道里还留着阻塞说明：${decision.blockedNote}`));
  const held = holderNote(view.id, task.id, decision);
  if (held) body.append(element('small', held));
  if (decision.conflicts.length) body.append(element('small', '已被领取'));
  const steps = task.execution?.steps ?? [];
  body.append(element('small', steps.length ? steps.map(step => `${step.title}（${step.state === 'done' ? '已完成' : step.state === 'current' ? '正在做' : '还没开始'}）`).join('、') : '还没有执行步骤。'));
  const evidence = task.execution?.evidence ?? (view.lastDelivery?.taskId === task.id ? view.lastDelivery.artifactTitles : undefined) ?? [];
  body.append(element('small', evidence.length ? `证据：${evidence.join('、')}` : '未验证'));
  const chain = handoffChain(view.id, task.id);
  body.append(element('small', chain.length ? `交接：${chain.join(' → ')}` : '还没有交接记录。'));
  const spend = element('small', '还没有记下花费。');
  spend.dataset.spend = task.id;
  body.append(spend);
  body.append(element('small', '看一眼不会执行，也不会改讨论焦点。'));
  if (openGroupId) body.append(taskReplay(openGroupId, view.id, task.id));
  const runId = task.runId ?? task.latestRunId ?? (view.lastDelivery?.taskId === task.id ? view.lastDelivery.runId : undefined);
  if (runId) {
    const read = dashboardButton('阅读全文', () => openChannelArtifact(runId));
    read.dataset.readArtifact = runId;
    body.append(read);
    void api<RunView>(`/runs/${encodeURIComponent(runId)}`).then(run => {
      if (body.dataset.task === task.id) spend.textContent = spendLine(run);
    }).catch(() => { if (body.dataset.task === task.id) spend.textContent = '花费暂时读不到。'; });
  }
  const people = handoffChoices();
  const picker = document.createElement('select');
  picker.dataset.channelOwner = task.id;
  picker.setAttribute('aria-label', '交给谁');
  for (const bot of people) {
    const option = document.createElement('option');
    option.value = bot.id;
    option.textContent = bot.name;
    picker.append(option);
  }
  if (view.agentId && people.some(bot => bot.id === view.agentId)) picker.value = view.agentId;
  if (column === 'ready') {
    const claim = dashboardButton('领取', () => claimChannelTask(view, task, picker.value));
    claim.dataset.claimTask = task.id;
    body.append(picker, claim);
  }
  if (column === 'capture' || column === 'ready' || column === 'doing' || column === 'blocked') {
    const assign = dashboardButton('分派', () => handChannelTask(view, task, picker.value, '分派'));
    assign.dataset.assignTask = task.id;
    const transfer = dashboardButton('转交', () => handChannelTask(view, task, picker.value, '转交'));
    transfer.dataset.transferTask = task.id;
    if (column !== 'ready') body.append(picker);
    body.append(assign, transfer);
    if (botsActive && !decision.offer) {
      const offer = dashboardButton('交给，等对方接受', () => offerChannelTask(view, task, picker.value));
      offer.dataset.offerTask = task.id;
      body.append(offer);
    }
  }
  if (decision.offer) body.append(element('p', `交接中：${participantLabel(decision.offer.to)}还没接。两位在侧线程里谈，谈不拢会来问你。`));
  if (decision.proposedBy && !decision.adopted && !decision.cancelled && task.status === 'discussion') {
    const adopt = dashboardButton('采纳提议', async () => { if (await postTaskAction('adopt', view, task)) { message(`已采纳「${task.title}」。还没有执行。`); await afterChannelWrite(view, task.id); } });
    adopt.dataset.adoptTask = task.id;
    body.append(element('p', `${participantLabel(decision.proposedBy)}提议${decision.proposalReason ? `：${decision.proposalReason}` : ''}`), adopt);
  }
  if (decision.assigneeId) {
    const reason = document.createElement('textarea');
    reason.dataset.refuseTask = task.id;
    reason.setAttribute('aria-label', '拒绝领取的原因');
    reason.maxLength = 500;
    reason.rows = 2;
    reason.placeholder = '写下拒绝领取的原因';
    const refuse = dashboardButton('拒绝领取', () => refuseChannelTask(view, task, reason.value));
    refuse.dataset.refuseSubmit = task.id;
    body.append(reason, refuse);
  }
  const pauses = blockPausesRun(task);
  const blockReason = document.createElement('textarea');
  blockReason.dataset.blockTask = task.id;
  blockReason.setAttribute('aria-label', pauses ? '阻塞原因，提交后会暂停这件 Run' : '阻塞原因，这次只记在频道里');
  blockReason.maxLength = 500;
  blockReason.rows = 2;
  blockReason.placeholder = pauses ? '写下阻塞原因。这会暂停这件 Run。' : '写下阻塞原因。这次只记在频道里。';
  const block = dashboardButton(pauses ? '暂停并标成阻塞' : '标成阻塞', () => blockChannelTask(view, task, blockReason.value));
  block.dataset.blockSubmit = task.id;
  const cancelReason = document.createElement('textarea');
  cancelReason.dataset.cancelTask = task.id;
  cancelReason.setAttribute('aria-label', '取消原因');
  cancelReason.maxLength = 500;
  cancelReason.rows = 2;
  cancelReason.placeholder = runId ? '写下取消原因。这会停下这件已经存在的 Run。' : '写下取消原因。这件还没有 Run，只记在频道里。';
  const cancel = dashboardButton(runId ? '取消这件 Run' : '在频道里取消', () => cancelChannelTask(view, task, cancelReason.value));
  cancel.dataset.cancelSubmit = task.id;
  if (column !== 'failed' && column !== 'done') body.append(blockReason, block, cancelReason, cancel);
  if (decision.blockedNote) {
    const unblockReason = document.createElement('textarea');
    unblockReason.dataset.unblockTask = task.id;
    unblockReason.setAttribute('aria-label', '解除阻塞的原因');
    unblockReason.maxLength = 500;
    unblockReason.rows = 2;
    unblockReason.placeholder = task.status === 'paused' && taskRunId(task)
      ? '写下解除原因。这只清掉频道里的阻塞说明。这件 Run 仍是已暂停。'
      : '写下解除原因。这只清掉频道里的阻塞说明。';
    const unblock = dashboardButton('解除阻塞', () => unblockChannelTask(view, task, unblockReason.value));
    unblock.dataset.unblockSubmit = task.id;
    body.append(unblockReason, unblock);
  }
  if (decision.cancelled) {
    const restoreReason = document.createElement('textarea');
    restoreReason.dataset.restoreTask = task.id;
    restoreReason.setAttribute('aria-label', '撤回取消的原因');
    restoreReason.maxLength = 500;
    restoreReason.rows = 2;
    restoreReason.placeholder = task.status === 'cancelled'
      ? '写下撤回原因。这次只清掉频道里的说明。这件 Run 仍是已取消。'
      : '写下撤回原因。这次只改频道记录。';
    const restore = dashboardButton('撤回频道里的取消', () => restoreChannelTask(view, task, restoreReason.value));
    restore.dataset.restoreSubmit = task.id;
    body.append(restoreReason, restore);
  }
  if (task.status === 'succeeded' && !decision.accepted) {
    const accept = dashboardButton('验收', () => acceptChannelTask(view, task));
    accept.dataset.acceptTask = task.id;
    const reviseText = document.createElement('textarea');
    reviseText.dataset.reviseTask = task.id;
    reviseText.maxLength = 500;
    reviseText.rows = 2;
    reviseText.placeholder = '写下要改的地方。会另开一条讨论，原来的产物还在。';
    const revise = dashboardButton('要求修改', () => reviseChannelTask(view, task, reviseText.value));
    revise.dataset.reviseSubmit = task.id;
    body.append(accept, reviseText, revise);
  }
  if (decision.accepted) body.append(element('small', '已验收。原来的产物还在。'));
  panel.hidden = false;
}
function hideChannelArtifact(): void {
  const panel = $('channel-artifact');
  const body = $('channel-artifact-body');
  if (panel) panel.hidden = true;
  if (body) body.replaceChildren();
}
async function openChannelArtifact(runId: string): Promise<void> {
  const panel = $('channel-artifact');
  const body = $('channel-artifact-body');
  const roomId = openGroupId;
  if (!panel || !body || !roomId) return;
  body.replaceChildren(element('p', '正在读取产物。看一眼不会执行。'));
  panel.hidden = false;
  trackUi('ui.artifact.view', roomId);
  try {
    const run = await api<RunView>(`/runs/${encodeURIComponent(runId)}`);
    if (openGroupId !== roomId) return;
    body.replaceChildren();
    const artifacts = (run.artifacts ?? []).slice(0, 8);
    if (!artifacts.length) {
      body.append(element('p', '这件 Run 还没有写下产物。'));
      return;
    }
    for (const artifact of artifacts) {
      const block = element('article', '', 'channel-artifact-item');
      block.append(element('strong', artifact.title.trim() || '未命名产物'));
      const text = artifact.content.trim();
      block.append(element('p', text ? (text.length > 4000 ? `${text.slice(0, 4000)}…` : text) : '这篇产物还没有正文。'));
      if (artifact.evidenceRefs?.length) {
        block.append(element('small', `证据：${artifact.evidenceRefs.slice(0, 8).join('、')}`));
        block.append(evidenceToggle(run, artifact.evidenceRefs.slice(0, 8), roomId));
      }
      body.append(block);
    }
  } catch (error) {
    body.replaceChildren(element('p', errorMessage(error)));
  }
}
/** Opens the sources an artifact cites, in place. Refs that are not a source of this Run stay as their id. */
function evidenceToggle(run: RunView, refs: string[], roomId: string): HTMLElement {
  const box = element('div', '', 'channel-evidence');
  const list = element('div', '', 'channel-evidence-list');
  list.hidden = true;
  const toggle = button('看证据', async () => {
    list.hidden = !list.hidden;
    toggle.textContent = list.hidden ? '看证据' : '收起证据';
    toggle.setAttribute('aria-expanded', String(!list.hidden));
    if (list.hidden || list.childElementCount) return;
    trackUi('ui.evidence.open', roomId);
    const sources = new Map((run.context?.sources ?? []).map(source => [source.id, source]));
    for (const ref of refs) {
      const source = sources.get(ref);
      const item = element('article', '', 'channel-evidence-item');
      item.append(element('strong', source?.title?.trim() || ref));
      const text = source?.content?.trim() ?? '';
      item.append(element('p', text ? (text.length > 1200 ? `${text.slice(0, 1200)}…` : text) : '这条证据不是本次 Run 读取的资料，打开工作台看来源。'));
      list.append(item);
    }
  });
  toggle.type = 'button';
  toggle.dataset.evidenceToggle = '';
  toggle.setAttribute('aria-expanded', 'false');
  box.append(toggle, list);
  return box;
}
/** Interaction-design §18.2 events only the browser sees. Fire and forget: a lost count never blocks the person. */
function trackUi(name: 'ui.channel.open' | 'ui.artifact.view' | 'ui.evidence.open' | 'ui.digest.view' | 'ui.studio.open', roomId: string): void {
  if (readOnlyShare || !roomId) return;
  void api('/ui-events', { name, roomId }).catch(() => undefined);
}
/** `live` puts the task's current state, artifact and decisions under this event. Only the
 * latest event that cites a task is live, so one plan shows one approval card in the channel. */
function appendHandoffCard(item: HTMLElement, event: SessionEventSummary, drafts: { answer: Map<string, string>; reject: Map<string, string> } = { answer: new Map(), reject: new Map() }, live = true): void {
  const cite = handoffCitation(event);
  if (!cite) return;
  const view = handoffViews.get(cite.conversationId);
  const task = view?.tasks.find(candidate => candidate.id === cite.taskId);
  const card = element('div', '', 'group-run-card');
  card.dataset.card = 'handoff';
  card.dataset.handoff = cite.taskId;
  const named = cite.agentId ? botById(cite.agentId) : undefined;
  const viewed = !named && view?.agentId ? botById(view.agentId) : undefined;
  const person = named?.name ?? cite.agentId ?? viewed?.name ?? view?.agentId ?? '这个人';
  card.append(element('strong', `交给${person}`));
  if (!view) card.append(element('small', '正在读取这件事。看一眼不会执行。'));
  else if (!task) card.append(element('small', '这条讨论不在这个人的对话里。'));
  else card.append(element('small', task.title));
  const bot = named ?? viewed;
  if (bot) {
    const open = element('button', `打开${bot.name}`) as HTMLButtonElement;
    open.type = 'button';
    open.dataset.openLife = bot.id;
    open.addEventListener('click', () => { void openLifeThread(bot.id).catch(error => message(errorMessage(error))); });
    card.append(open);
  }
  item.append(card);
  if (!task || !live) return;
  const taskCard = element('div', '', 'group-run-card');
  taskCard.dataset.card = 'task';
  taskCard.dataset.handoff = cite.taskId;
  const state = task.status === 'discussion' ? '仅讨论，未执行' : task.status === 'preparing' ? '正在准备执行' : runStatusLabel(task.status);
  taskCard.append(element('strong', '任务'), element('small', task.title), element('small', state));
  if (task.execution?.steps.length) taskCard.append(element('small', executionLine(task.execution), 'conversation-steps'));
  taskCard.append(element('small', '这张卡只描述这件事。看一眼不会执行。'));
  item.append(taskCard);
  const delivery = view?.lastDelivery?.taskId === task.id ? view.lastDelivery : undefined;
  const artifactTitles = task.execution?.evidence?.length ? task.execution.evidence : (delivery?.artifactTitles ?? []);
  if (artifactTitles.length || delivery?.planSummary) {
    const artifact = element('div', '', 'group-run-card');
    artifact.dataset.card = 'artifact';
    artifact.dataset.handoff = cite.taskId;
    artifact.append(element('strong', '产物'));
    if (delivery?.planSummary) artifact.append(element('small', `结论：${delivery.planSummary}`));
    if (artifactTitles.length) artifact.append(element('small', artifactTitles.join('、')));
    artifact.append(element('small', '在频道里阅读。不会改讨论焦点，也不会另开一件 Run。'));
    const artifactRunId = task.runId ?? task.latestRunId ?? delivery?.runId;
    if (artifactRunId) {
      const read = dashboardButton('阅读全文', () => openChannelArtifact(artifactRunId));
      read.dataset.readArtifact = artifactRunId;
      artifact.append(read);
    }
    if (view && task.status === 'succeeded') {
      const decision = boardDecision(cite.conversationId, task.id);
      if (decision.accepted) artifact.append(element('small', '已验收。原来的产物还在。'));
      else {
        const accept = dashboardButton('验收', () => acceptChannelTask(view, task));
        accept.dataset.acceptTask = task.id;
        const reviseText = document.createElement('textarea');
        reviseText.dataset.reviseTask = task.id;
        reviseText.maxLength = 500;
        reviseText.rows = 2;
        reviseText.placeholder = '写下要改的地方。会另开一条讨论，原来的产物还在。';
        const revise = dashboardButton('要求修改', () => reviseChannelTask(view, task, reviseText.value));
        revise.dataset.reviseSubmit = task.id;
        artifact.append(accept, reviseText, revise);
      }
    }
    item.append(artifact);
  }
  const decision = (kind: string, title: string, copy: string, where = '在这个人的对话里处理。') => {
    const extra = element('div', '', 'group-run-card');
    extra.dataset.card = kind;
    extra.dataset.handoff = cite.taskId;
    extra.append(element('strong', title), element('small', copy), element('small', `${where}这里只读，不会执行。`));
    item.append(extra);
  };
  if (task.pendingApproval && task.runId) {
    const extra = element('div', '', 'group-run-card');
    extra.dataset.card = 'approval';
    extra.dataset.handoff = cite.taskId;
    extra.dataset.run = task.runId;
    extra.append(element('strong', '审批'), element('small', `待批准：${task.pendingApproval.summary}`), element('small', '在这里批准或拒绝。不会改讨论焦点，也不会另开一件 Run。'));
    const approve = dashboardButton('批准并执行', () => approveConversationTask(task, 'task'));
    approve.dataset.approve = task.id;
    const once = dashboardButton('仅这一次', () => approveConversationTask(task, 'once'));
    once.dataset.approveOnce = task.id;
    once.title = '记在这次批准记录上。这次仍按当前计划执行，以后的计划仍要再批。';
    const field = document.createElement('textarea');
    field.className = 'conversation-answer'; field.maxLength = 8000; field.rows = 2;
    field.placeholder = '写下拒绝原因。拒绝后重新规划，新计划仍停在等待批准，不会按这份计划执行。';
    field.dataset.reject = task.id;
    const rejectDraft = drafts.reject.get(task.id);
    if (rejectDraft) field.value = rejectDraft;
    const reject = dashboardButton('拒绝并说明', () => rejectConversationTask(task, field.value));
    reject.dataset.rejectSubmit = task.id;
    extra.append(approve, once, field, reject);
    item.append(extra);
  } else if (task.pendingApproval) decision('approval', '审批', `待批准：${task.pendingApproval.summary}`);
  if (task.pendingQuestion && task.runId) {
    const extra = element('div', '', 'group-run-card');
    extra.dataset.card = 'question';
    extra.dataset.handoff = cite.taskId;
    extra.dataset.run = task.runId;
    extra.append(element('strong', '提问'), element('small', `待回答：${task.pendingQuestion.text}`), element('small', '在这里回答。不会改讨论焦点，也不会另开一件 Run。'));
    const field = document.createElement('textarea');
    field.className = 'conversation-answer'; field.maxLength = 8000; field.rows = 2;
    field.placeholder = '回答后从当前节点继续';
    field.dataset.answer = task.id;
    field.setAttribute('aria-label', `回答「${task.title}」`);
    const answerDraft = drafts.answer.get(task.id);
    if (answerDraft) field.value = answerDraft;
    const submit = dashboardButton('提交回答', () => answerConversationTask(task, field.value));
    submit.dataset.answerSubmit = task.id;
    extra.append(field, submit);
    item.append(extra);
  } else if (task.pendingQuestion) decision('question', '提问', `待回答：${task.pendingQuestion.text}`);
  if (task.takenOver) decision('takeover', '人已接管', 'Bot 停下了，由人来做。做完后写一句说明交还，Bot 接着做。', '在工作台交还。');
  if (task.status === 'unknown' || task.status === 'waiting_external') decision('reconcile', '核查', task.status === 'unknown' ? '结果需要核查。' : '还在等外部回执。');
  if (task.status === 'failed') decision('blocked', '卡住', '这件工作失败了。先看原因，再决定是否重试。');
}
async function refreshHandoffViews(): Promise<void> {
  const epoch = ++handoffEpoch;
  const roomId = openGroupId;
  const ids = [...new Set(visibleChannelEvents().flatMap(event => {
    const cite = handoffCitation(event);
    return cite ? [cite.conversationId] : [];
  }))];
  if (!ids.length || !roomId) return;
  const views = await Promise.all(ids.map(async id => {
    try { return await api<ConversationView>(`/conversations/${encodeURIComponent(id)}`); }
    catch { return undefined; }
  }));
  if (epoch !== handoffEpoch || openGroupId !== roomId) return;
  ids.forEach((id, index) => {
    const view = views[index];
    if (view) handoffViews.set(id, view);
  });
  renderGroupTranscript();
  if (!$('channel-studio')?.hidden) renderStudio();
}
const GROUP_CAP_KEY = 'aeeis.group-cap';
const GROUP_CAP_DEFAULT = 10;
const GROUP_CAP_MIN = 2;
const GROUP_CAP_MAX = 30;
function groupCap(): number {
  const raw = Number(localStorage.getItem(GROUP_CAP_KEY));
  return Number.isInteger(raw) && raw >= GROUP_CAP_MIN && raw <= GROUP_CAP_MAX ? raw : GROUP_CAP_DEFAULT;
}
function groupOccupancy(): number {
  return 1 + draftAgents.size + draftPeople.length;
}
function commitGroupCap(commitInvalid: boolean): void {
  const input = $<HTMLInputElement>('group-cap');
  if (!input) return;
  const value = Math.trunc(Number(input.value));
  const valid = Number.isInteger(value) && value >= GROUP_CAP_MIN && value <= GROUP_CAP_MAX;
  if (!valid) {
    if (!commitInvalid) return;
    input.value = String(groupCap());
    message(`人数上限是 ${GROUP_CAP_MIN} 到 ${GROUP_CAP_MAX}。`);
    return;
  }
  localStorage.setItem(GROUP_CAP_KEY, String(value));
  if (commitInvalid) message('');
  renderGroupCandidates();
}

function hideChannelSurfaces(): void {
  const noise = $('channel-noise'); if (noise) noise.hidden = true;
  hideChannelArtifact();
  hideChannelBoard();
  stopStudioPlay();
  studioIndex = -1;
  studioKey = '';
  const memory = $('channel-memory');
  const profile = $('channel-bot');
  const studio = $('channel-studio');
  const digest = $('channel-digest');
  const teach = $('channel-teach');
  if (memory) memory.hidden = true;
  if (profile) profile.hidden = true;
  if (studio) studio.hidden = true;
  if (digest) digest.hidden = true;
  if (teach) teach.hidden = true;
}
function leaveGroup(): void {
  openGroupId = '';
  clearChannelUpgrades();
  groupMembers = [];
  resetChannelLog();
  handoffViews.clear();
  groupDraftOpen = false;
  hideChannelSurfaces();
  localStorage.removeItem('aeeis.group');
  document.body.classList.remove('group-open', 'group-draft');
  const panel = $('group-panel');
  const draft = $('group-draft');
  const composer = $('group-composer');
  if (panel) panel.hidden = true;
  if (draft) draft.hidden = true;
  if (composer) composer.hidden = true;
  syncComposerHeading();
}
function clearOpenGroup(): void {
  openGroupId = '';
  groupMembers = [];
  resetChannelLog();
  handoffViews.clear();
  hideChannelSurfaces();
  localStorage.removeItem('aeeis.group');
}
function showRoster(focused = true): void {
  document.body.classList.toggle('roster-focus', focused);
  if (focused) document.body.classList.remove('draft-open');
}
let shellView = '';
function syncShellClasses(): void {
  const view = rosterView();
  document.body.classList.toggle('group-draft', view === 'draft');
  document.body.classList.toggle('group-open', view === 'group' || view === 'direct');
  if (view === 'bot' || view === 'draft' || view === 'group' || view === 'direct') {
    // Opening a view leaves the roster; a refresh of the same view keeps the roster the person went back to.
    if (view !== shellView) document.body.classList.remove('roster-focus');
    document.body.classList.add('draft-open');
  }
  shellView = view;
}
function syncEntrySurface(): void {
  const view = rosterView();
  const life = view === 'entry' || view === 'bot';
  const messages = $('conversation-messages');
  const earlier = $('conversation-earlier');
  const empty = $('conversation-empty');
  const composer = $('conversation-composer');
  const note = $('bot-note');
  const placement = $('bot-placement');
  const draft = $('group-draft');
  const panel = $('group-panel');
  if (messages) messages.hidden = !life;
  if (earlier) earlier.hidden = !life || !conversation?.hasEarlierMessages;
  if (empty) {
    empty.hidden = !life || Boolean(conversation?.messages.length);
    empty.textContent = view === 'bot' ? localBotCanExecute() ? '把要做的事直接交给我。' : '这位成员仅支持讨论，不能在这里执行任务。' : '今天要我做什么？';
  }
  if (composer) composer.hidden = view === 'group' || view === 'draft' || view === 'direct';
  if (note) note.hidden = view !== 'bot';
  if (placement) placement.hidden = view !== 'bot' && view !== 'direct';
  if (draft) draft.hidden = view !== 'draft';
  if (panel) panel.hidden = view !== 'group' && view !== 'direct';
  const room = chatRoom();
  const directPrincipal = directMembers.get(room?.id ?? '') ?? '';
  const counterpart = view === 'direct' ? (botById(directPrincipal) ?? botById(activeBotId())) : botById(activeBotId());
  if (view === 'bot') {
    const title = $('bot-note-title');
    const copy = $('bot-note-copy');
    if (title) title.textContent = counterpart?.name ?? '成员';
    if (copy) copy.textContent = '对话会留在这里，做完以后它还在。';
    if (copy) copy.textContent += localBotCanExecute() ? '直接发送任务就能开工；计划、动作审批和补充问题都在这里处理。' : '这位成员不支持本地执行，消息只记下来。';
    const role = $('bot-profile-role');
    if (role) role.textContent = counterpart?.background || counterpart?.note ? botDutyLine(counterpart) : '职责：见背景资料。';
    const actions = $('bot-profile-actions');
    if (actions) actions.hidden = !counterpart || counterpart.id === 'aeeis' || !ownedBotRecords.some(bot => bot.id === counterpart.id);
    const boundary = $('bot-profile-boundary');
    if (boundary) boundary.textContent = localBotCanExecute()
      ? '边界：背景与常驻嘱咐只是参考，不授予权限。你派的任务沿用执行审批；它自主开的 Run 来源是 agent，写操作要你批准，放手档下直接拒绝。'
      : '边界：外部准入成员仅支持讨论，不作为本地 Bot 执行，也不会自己回复。';
    if (copy && botsActive && localBotCanExecute()) copy.textContent += '只记下的讨论是否自主回复，按下面的设置。';
    renderBotAutonomy(counterpart);
    renderBotSideThreads(counterpart);
  }
  const botStatus = $('bot-status');
  if (botStatus) {
    const personId = view === 'bot' ? activeBotId() : '';
    const presence = personId ? lifePresence(personId) : undefined;
    botStatus.hidden = view !== 'bot';
    botStatus.textContent = presence ? (presence.taskTitle && presence.state !== 'idle' ? `${presence.label} · ${presence.taskTitle}。看一眼不会执行。` : `${presence.label}。看一眼不会执行。`) : '';
  }
  const chatNote = $('chat-note');
  const rename = $('group-rename');
  const send = document.querySelector<HTMLButtonElement>('#group-composer button[type="submit"]');
  const groupText = $<HTMLTextAreaElement>('group-text');
  if (chatNote) chatNote.textContent = view === 'direct'
    ? '这间私聊只保留会话记录。选说话人只是标明这句话是谁说的，对方不会自己回复，也不会执行。@AEEIS 会记到 AEEIS 的对话里，不执行。归档后从成员列表里撤下，不会改讨论焦点，也不会停下任务。'
    : '这是群聊。每句话都留在这间房里。没有点名时，这句话送到其他成员的对话。写了常驻要求的成员会被提醒看一下，其余成员留一个 👍 表示收到。回执合成一条，只写这次送到的人。@某一位时，这一位和 AEEIS 同时接收；写了常驻要求的其他成员会再被提醒。没有收到这句话的成员不留表情。说话人不会再收到自己的这句话。@所有人同样按没点名送达。选一位说话人，只是标明这句话是谁说的。选「交给」会请那一位回应，AEEIS 同时收下。这些接收不调用模型，也不另外创建 Run。频道里可以批准或拒绝已经摆出来的计划，也可以阅读已经写下的产物。归档后从群聊列表撤下。';
  if (botsActive && view !== 'direct' && chatNote) chatNote.textContent = '这是群聊。没有点名时 AEEIS 回复；@某一位时这一位自己回复。回复只是讨论，要做的事会作为提议出现在任务板上，交接在两位 Bot 的侧线程里谈，对方接受才转过去。';
  if (botsActive && view === 'direct' && chatNote) chatNote.textContent = '这间私聊里，对方会自己回复。回复只是讨论；要做的事会作为提议出现在任务板上。';
  if (rename) rename.hidden = room?.canEdit === false || view === 'direct';
  const archiveButton = $<HTMLButtonElement>('chat-archive');
  if (archiveButton) archiveButton.hidden = room?.canArchive === false || room?.status === 'archived';
  if (send) send.disabled = room?.canWrite === false || room?.status === 'archived';
  if (groupText) groupText.disabled = room?.canWrite === false || room?.status === 'archived';
  if (room && chatNote && (room.memberRole || room.status === 'archived')) chatNote.textContent = `${room.memberRole ?? ''} · ${room.status === 'archived' ? '已归档，只读。已有 Run 继续运行；可从频道管理恢复。' : room.canWrite === false ? '只有阅读权限。' : '按频道成员权限协作。'}`;
  if (send) send.textContent = view === 'direct' ? '发给这位' : '发到群里';
  if (groupText) groupText.placeholder = view === 'direct' ? '写给这一位。@AEEIS 会记到 AEEIS 的对话里，不执行，也不调用模型。' : '写到这间群里。没有点名时，成员用 👍 表示收到；写了常驻要求的成员会被提醒。@某一位或 @AEEIS 时，这一位和 AEEIS 同时接收。';
  if (groupText && botsActive) groupText.placeholder = view === 'direct' ? '写给这一位，它会自己回复。' : '写到这间群里。没有点名时 AEEIS 回复；@某一位时这一位回复。';
  const sendNote = $('group-send-note');
  if (sendNote) sendNote.textContent = view === 'direct'
    ? '批准、登录和密钥仍留在和 AEEIS 的单独对话。发送先写入这个 Room 的会话记录。选一位说话人，只是标明这句话是谁说的。'
    : '批准、登录和密钥仍留在和 AEEIS 的单独对话。发送先写入这个 Room 的会话记录。没有点名时，其余成员用 👍 表示收到，写了常驻要求的成员会被提醒。@某一位时，这一位和 AEEIS 同时接收。没有收到这句话的成员不留表情。选一位说话人，只是标明这句话是谁说的。';
  if (sendNote && botsActive) sendNote.textContent = view === 'direct'
    ? '批准、登录和密钥仍留在和 AEEIS 的单独对话。对方会自己回复，回复只是讨论。'
    : '批准、登录和密钥仍留在和 AEEIS 的单独对话。没有点名时 AEEIS 回复；@某一位时这一位回复。要做的事会作为提议出现在任务板上。';
  syncGroupSpeaker();
  syncLifeSpeaker();
  const directName = botById(directPrincipal)?.name ?? room?.title ?? directPrincipal;
  const personName = view === 'direct' ? (directName || '成员') : (counterpart?.name ?? '成员');
  const entryTitle = $('entry-title');
  const entryPresence = $('entry-presence');
  const titleText = view === 'group' ? (room?.title || '群聊') : view === 'draft' ? '新建群聊' : (view === 'direct' || view === 'bot') ? personName : 'AEEIS';
  const presenceText = view === 'group' ? '群聊' : view === 'direct' ? '私聊' : view === 'draft' ? '选择成员' : lifePresenceLabel(view === 'bot' ? activeBotId() : 'aeeis');
  if (entryTitle) entryTitle.textContent = titleText;
  if (entryPresence) entryPresence.textContent = presenceText;
  const shellTitle = $('gb-title');
  const shellPresence = $('gb-presence');
  if (shellTitle) shellTitle.textContent = titleText;
  if (shellPresence) shellPresence.textContent = presenceText;
  const stageEmpty = $('empty');
  if (stageEmpty && conversationEnabled) stageEmpty.hidden = true;
  syncShellClasses();
  renderBotPlacement();
}
function renderBotRoster(): void {
  const list = $('bots');
  if (!list) return;
  const bots = rosterBots();
  const groups = ensureBotGroups();
  list.replaceChildren();
  const renderRow = (bot: RosterBot) => {
    const item = document.createElement('button');
    item.type = 'button';
    item.className = 'bot-row';
    item.dataset.botId = bot.id;
    if (bot.id === 'aeeis') item.id = 'gb-bot';
    const avatar = element('span', bot.mark && bot.mark !== 'letter' ? '' : (bot.name.slice(0, 1) || 'B'), 'roster-avatar');
    avatar.dataset.state = lifeAvatarState(bot.id);
    if (bot.mark) avatar.dataset.mark = bot.mark;
    if (bot.color) avatar.style.background = bot.color;
    avatar.setAttribute('aria-hidden', 'true');
    const copy = element('span', '', 'roster-copy');
    const presence = element('small', lifePresenceLabel(bot.id));
    copy.append(element('strong', bot.name), presence);
    item.append(avatar, copy);
    list.append(item);
  };
  const known = new Set(groups.groups.map(group => group.id));
  for (const group of groups.groups) {
    const members = bots.filter(bot => groups.placement[bot.id] === group.id);
    const heading = document.createElement('button');
    heading.type = 'button';
    heading.className = 'bot-group-label';
    heading.dataset.groupId = group.id;
    heading.textContent = `${group.name} · ${members.length}`;
    list.append(heading);
    for (const bot of members) renderRow(bot);
  }
  const loose = bots.filter(bot => !known.has(groups.placement[bot.id] ?? ''));
  if (loose.length && groups.groups.length) list.append(element('p', '未分组', 'bot-group-label'));
  for (const bot of loose) renderRow(bot);
  renderLocalBotNote();
  for (const room of roomSummaries.filter(item => item.status === 'active' && roomChat(item) === 'direct')) {
    const principalId = directMembers.get(room.id);
    if (principalId && rosterBots().some(bot => bot.id === principalId)) continue;
    const item = document.createElement('button');
    item.type = 'button';
    item.className = 'bot-row';
    item.dataset.roomId = room.id;
    const avatar = element('span', room.title.slice(0, 1) || '成', 'roster-avatar');
    const copy = element('span', '', 'roster-copy');
    copy.append(element('strong', room.title), element('small', '私聊'));
    item.append(avatar, copy);
    list.append(item);
  }
  const viewingBot = rosterView() === 'entry' || rosterView() === 'bot' || rosterView() === 'direct';
  const visible = activeBotId();
  list.querySelectorAll<HTMLButtonElement>('[data-bot-id]').forEach(row => {
    row.setAttribute('aria-pressed', String(viewingBot && row.dataset.botId === visible));
  });
}
function renderBotPlacement(): void {
  const host = $('bot-placement');
  if (!host || host.hidden) return;
  host.replaceChildren();
  const groups = ensureBotGroups();
  const botId = activeBotId();
  const current = groups.groups.some(group => group.id === groups.placement[botId]) ? groups.placement[botId] : '';
  host.append(element('span', '分组', 'bot-placement-label'));
  const none = document.createElement('button');
  none.type = 'button';
  none.textContent = '未分组';
  none.setAttribute('aria-pressed', String(!current));
  none.addEventListener('click', () => placeBot(botId, ''));
  host.append(none);
  for (const group of groups.groups) {
    const chip = document.createElement('button');
    chip.type = 'button';
    chip.textContent = group.name;
    chip.setAttribute('aria-pressed', String(current === group.id));
    chip.addEventListener('click', () => placeBot(botId, group.id));
    host.append(chip);
  }
}
function placeBot(botId: string, groupId: string): void {
  const groups = ensureBotGroups();
  if (!agentsLoaded) return;
  if (groupId && !groups.groups.some(group => group.id === groupId)) return;
  if (groupId) groups.placement[botId] = groupId;
  else delete groups.placement[botId];
  saveBotGroups();
  renderBotRoster();
  updateConversationControls();
}
function createBotGroup(event: Event): void {
  event.preventDefault();
  const input = $<HTMLInputElement>('bot-group-name');
  const name = input?.value.trim().slice(0, 40) ?? '';
  if (!name) { input?.focus(); return; }
  const groups = ensureBotGroups();
  if (!agentsLoaded) return;
  if (groups.groups.length >= 8) { message('最多 8 个分组。'); return; }
  if (groups.groups.some(group => group.name === name)) { message('已经有这个分组。'); return; }
  groups.groups.push({ id: `group_${Date.now().toString(36)}`, name });
  saveBotGroups();
  if (input) input.value = '';
  const draft = $('bot-group-draft');
  if (draft) draft.hidden = true;
  renderBotRoster();
  updateConversationControls();
}
function renameBotGroup(id: string): void {
  const groups = ensureBotGroups();
  const group = groups.groups.find(item => item.id === id);
  if (!group) return;
  const next = window.prompt('分组名称。留空则解散这一组。', group.name);
  if (next === null) return;
  const name = next.trim().slice(0, 40);
  if (!name) {
    groups.groups = groups.groups.filter(item => item.id !== id);
    for (const [botId, groupId] of Object.entries(groups.placement)) if (groupId === id) delete groups.placement[botId];
  } else if (groups.groups.some(item => item.id !== id && item.name === name)) {
    message('已经有这个分组。');
    return;
  } else group.name = name;
  saveBotGroups();
  renderBotRoster();
  updateConversationControls();
}
function selectBot(id: string): void {
  if (!rosterBots().some(bot => bot.id === id)) return;
  if (conversationEnabled) {
    void openLifeThread(id).catch(error => message(errorMessage(error)));
    return;
  }
  if (id === 'aeeis') { showEntry(); return; }
  selectedBotId = id;
  localStorage.setItem('aeeis.bot', id);
  entryEpoch += 1;
  leaveGroup();
  stopRunEventStream();
  currentId = '';
  current = undefined;
  localStorage.removeItem('aeeis.run');
  document.body.classList.remove('roster-focus');
  document.body.classList.add('draft-open');
  setCurrentRunOpen(false);
  if (!readOnlyShare && !linkedThreadId && window.location.pathname !== '/') window.history.replaceState(null, '', '/');
  setIntentPresetsOpen(false);
  renderBotRoster();
  renderRunQueue(runSummaries);
  syncPresence();
}
async function openLifeThread(agentId: string): Promise<void> {
  if (!conversationEnabled || conversationBusy || conversationAttempt || lifeOpening.has(agentId)) return;
  const bot = botById(agentId);
  if (!bot) return;
  if (conversation && lifeAgent(conversation) === agentId && !openGroupId && !groupDraftOpen) {
    selectedBotId = agentId;
    localStorage.setItem('aeeis.bot', agentId);
    showRoster(false);
    renderBotRoster();
    renderGroups(roomSummaries);
    updateConversationControls();
    return;
  }
  lifeOpening.add(agentId);
  const epoch = conversationEpoch;
  conversationBusy = true;
  updateConversationControls();
  try {
    let summary = lifeSummary(agentId);
    let view: ConversationView;
    if (botDialogueRouting && (agentId === 'aeeis' || agentId.startsWith('bot_'))) {
      const binding = await api<{ conversationId: string; roomId: string }>(`/bots/${encodeURIComponent(agentId)}/dialogue`, {});
      dialogueRoomIds.set(binding.conversationId, binding.roomId);
      view = await api<ConversationView>(`/conversations/${encodeURIComponent(binding.conversationId)}`);
    }
    else if (!summary) view = await api<ConversationView>('/conversations', { title: bot.name, agentId });
    else if (agentId === 'aeeis' && !summary.agentId) view = await api<ConversationView>('/conversations', { title: 'AEEIS', agentId: 'aeeis', claimId: summary.id });
    else if (conversation && conversation.id === summary.id) view = conversation;
    else view = await api<ConversationView>(`/conversations/${encodeURIComponent(summary.id)}`);
    if (epoch !== conversationEpoch) return;
    groupDraftOpen = false;
    clearOpenGroup();
    showRoster(false);
    if (conversation?.id !== view.id) {
      conversationReplyId = undefined;
      conversationCorrectionId = undefined;
      conversationNeedsRefresh = false;
      $<HTMLFormElement>('conversation-composer').reset();
      $('conversation-status').textContent = '';
      $('conversation-error').textContent = '';
    }
    selectedBotId = agentId;
    localStorage.setItem('aeeis.bot', agentId);
    if (agentId === 'aeeis') {
      aeeisConversationId = view.id;
      localStorage.setItem(LIFE_HOME, view.id);
    }
    acceptConversation(view);
    renderBotRoster();
    renderGroups(roomSummaries);
  } finally {
    lifeOpening.delete(agentId);
    if (epoch === conversationEpoch) { conversationBusy = false; updateConversationControls(); }
  }
}
function indexDirectRooms(rooms: RoomSummary[]): void {
  const directs = rooms.filter(room => room.status === 'active' && roomChat(room) === 'direct');
  const key = directs.map(room => room.id).join('|');
  if (key === directIndexKey) return;
  directIndexKey = key;
  directIndexPromise = Promise.all(directs.map(async room => {
    if (directMembers.has(room.id)) return;
    const members = await api<RoomMemberSummary[]>(`/rooms/${encodeURIComponent(room.id)}/members`).catch(() => [] as RoomMemberSummary[]);
    const other = members.find(member => member.status === 'active');
    if (other) directMembers.set(room.id, other.principalId);
  })).then(() => { if (directIndexKey === key && $('bots')) renderBotRoster(); });
}
async function openDirect(principalId: string): Promise<void> {
  if (!principalId) return;
  if (botById(principalId)) { await openLifeThread(principalId); return; }
  if (directOpening.has(principalId)) return;
  groupDraftOpen = false;
  showRoster(false);
  renderBotRoster();
  updateConversationControls();
  directOpening.add(principalId);
  try {
    await directIndexPromise;
    const existing = directRoomId(principalId);
    if (existing) { await openGroup(existing); return; }
    const room = await api<RoomSummary>('/rooms', { title: principalId, description: '私聊' });
    try {
      await api(`/rooms/${encodeURIComponent(room.id)}/members`, { principalId, role: 'editor' });
    } catch (error) {
      await api(`/rooms/${encodeURIComponent(room.id)}`, { status: 'archived', expectedRevision: room.revision ?? 0 }, 'PATCH').catch(() => undefined);
      throw error;
    }
    directMembers.set(room.id, principalId);
    directIndexKey = '';
    roomSummaries = [room, ...roomSummaries.filter(item => item.id !== room.id)];
    message('');
    await openGroup(room.id);
  } finally { directOpening.delete(principalId); }
}
async function archiveOpenChat(): Promise<void> {
  const id = openGroupId;
  const room = chatRoom();
  if (!id || !room || !isManagedChat(room)) return;
  const what = roomChat(room) === 'direct' ? '这间私聊' : `群聊「${room.title}」`;
  if (!window.confirm(`归档${what}？归档后从列表里撤下，历史和任务板仍能读，但不能再发消息。`)) return;
  const updated = await api<RoomSummary>(`/rooms/${encodeURIComponent(id)}`, { status: 'archived', expectedRevision: room.revision ?? 0 }, 'PATCH');
  roomSummaries = roomSummaries.map(item => item.id === id ? { ...item, ...updated, status: 'archived' } : item);
  directMembers.delete(id);
  directIndexKey = '';
  clearOpenGroup();
  selectedBotId = 'aeeis';
  localStorage.setItem('aeeis.bot', 'aeeis');
  message('');
  renderBotRoster();
  renderGroups(roomSummaries);
  updateConversationControls();
}
function renderGroupCandidates(): void {
  const host = $('group-candidates');
  const people = $('group-people');
  const live = $('group-count-live');
  if (!host || !people || !live) return;
  host.replaceChildren();
  for (const bot of rosterBots().filter(roomReadyBot)) {
    const row = element('label', '', 'group-candidate');
    const box = document.createElement('input');
    box.type = 'checkbox';
    box.checked = draftAgents.has(bot.id);
    box.addEventListener('change', () => {
      if (box.checked) {
        if (groupOccupancy() >= groupCap()) { box.checked = false; message(`一个群聊最多 ${groupCap()} 人。`); return; }
        draftAgents.add(bot.id);
      } else draftAgents.delete(bot.id);
      renderGroupCandidates();
    });
    row.append(box, document.createTextNode(` ${bot.name}`));
    host.append(row);
  }
  people.replaceChildren();
  for (const person of draftPeople) {
    const row = element('div', '', 'group-person');
    row.append(element('span', person));
    const remove = element('button', '移除') as HTMLButtonElement;
    remove.type = 'button';
    remove.className = 'quiet-button';
    remove.addEventListener('click', () => { draftPeople = draftPeople.filter(item => item !== person); renderGroupCandidates(); });
    row.append(remove);
    people.append(row);
  }
  const names = [...draftAgents].map(participantLabel).concat(draftPeople);
  live.textContent = `${groupOccupancy()} / ${groupCap()} · AEEIS${names.length ? `、${names.join('、')}` : ''}`;
  const proposal = $('group-proposal');
  if (proposal) proposal.textContent = groupProposalText();
}
function groupProposalText(): string {
  const reused = [...draftAgents].map(id => participantLabel(id));
  const roster = reused.length ? `复用${reused.join('、')}。` : '优先复用名单里已有的人。';
  const extras = draftPeople.length ? `名单以外：${draftPeople.join('、')}。` : '';
  const reason = $<HTMLInputElement>('group-newcomer-reason')?.value.trim() ?? '';
  const why = reason ? '原因已写下。' : '';
  return `提议：AEEIS 担任 PM。${roster}${extras}一共 ${groupOccupancy()} / ${groupCap()}。创建前确认这一组。${why}`;
}
function reuseRoster(): void {
  for (const bot of rosterBots().filter(roomReadyBot)) {
    if (draftAgents.has(bot.id)) continue;
    if (groupOccupancy() >= groupCap()) break;
    draftAgents.add(bot.id);
  }
  renderGroupCandidates();
}
function showGroupDraft(): void {
  clearOpenGroup();
  showRoster(false);
  draftAgents.clear();
  draftPeople = [];
  groupDraftOpen = true;
  setCurrentRunOpen(false);
  renderBotRoster();
  updateConversationControls();
  const title = $<HTMLInputElement>('group-title');
  if (title) { title.value = ''; title.focus(); }
  const person = $<HTMLInputElement>('group-person');
  if (person) person.value = '';
  const reason = $<HTMLInputElement>('group-newcomer-reason');
  if (reason) reason.value = '';
  const cap = $<HTMLInputElement>('group-cap');
  if (cap) cap.value = String(groupCap());
  renderGroupCandidates();
}
function addDraftPerson(): void {
  const input = $<HTMLInputElement>('group-person');
  const person = input?.value.trim() ?? '';
  if (!person) { input?.focus(); return; }
  if (draftPeople.includes(person) || draftAgents.has(person) || person === 'aeeis') { message('这位已经在群里。'); return; }
  if (groupOccupancy() >= groupCap()) { message(`一个群聊最多 ${groupCap()} 人。`); return; }
  draftPeople = [...draftPeople, person];
  if (input) input.value = '';
  renderGroupCandidates();
}
async function createGroup(event: Event): Promise<void> {
  event.preventDefault();
  const title = $<HTMLInputElement>('group-title')?.value.trim() ?? '';
  if (!title) return;
  for (const id of [...draftAgents]) if (!roomReadyBot(botById(id) ?? { id, name: id, note: '', demo: false })) draftAgents.delete(id);
  if (groupOccupancy() < 2) { message('群聊至少要 AEEIS 和另外一位。'); return; }
  if (groupOccupancy() > groupCap()) { message(`一个群聊最多 ${groupCap()} 人。`); return; }
  const room = await api<RoomSummary>('/rooms', { title, description: '群聊', chat: 'group', category: $<HTMLSelectElement>('group-category')?.value ?? 'general', topicRef: $<HTMLInputElement>('group-topic')?.value.trim() ?? '' });
  try {
    for (const agentId of draftAgents) await api(`/rooms/${encodeURIComponent(room.id)}/members`, { principalId: agentId, role: 'agent' });
    for (const person of draftPeople) await api(`/rooms/${encodeURIComponent(room.id)}/members`, { principalId: person, role: 'editor' });
  } catch (error) {
    await api(`/rooms/${encodeURIComponent(room.id)}`, { status: 'archived', expectedRevision: room.revision ?? 0 }, 'PATCH').catch(() => undefined);
    throw error;
  }
  roomSummaries = [room, ...roomSummaries.filter(item => item.id !== room.id)];
  const reason = $<HTMLInputElement>('group-newcomer-reason')?.value.trim() ?? '';
  const reused = [...draftAgents].map(id => participantLabel(id));
  const newcomers = [...draftPeople];
  groupDraftOpen = false;
  message('');
  await openGroup(room.id);
  if (reason && newcomers.length) {
    const roster = reused.length ? `复用${reused.join('、')}。` : '';
    await channelPostSession('system', `分工：AEEIS 担任 PM。${roster}名单以外的人：${newcomers.join('、')}。原因：${reason}。`);
  }
  await refresh();
}
function renderGroups(all: RoomSummary[]): void {
  // Side threads are Bot-to-Bot rooms: they show in a Bot's profile, not in the chat lists.
  const rooms = all.filter(room => room.description !== SIDE_THREAD);
  roomSummaries = rooms;
  indexDirectRooms(rooms);
  if (!openGroupId && !groupDraftOpen) {
    const saved = localStorage.getItem('aeeis.group') ?? '';
    const savedRoom = rooms.find(room => room.id === saved);
    if (savedRoom && isManagedChat(savedRoom)) openGroupId = saved;
    else if (saved) localStorage.removeItem('aeeis.group');
  }
  const list = $('groups');
  if (!list) return;
  const manager = $('channel-manager');
  if (manager) renderChannelManager(manager, rooms, api, refresh, message, canCreateChannels, openGroup);
  const visible = rooms.filter(room => room.status === 'active' && roomChat(room) === 'group');
  if (openGroupId && !rooms.some(room => room.id === openGroupId && isManagedChat(room))) {
    openGroupId = '';
    groupMembers = [];
    resetChannelLog();
    localStorage.removeItem('aeeis.group');
  }
  list.replaceChildren();
  for (const room of visible) {
    const item = document.createElement('button');
    item.type = 'button';
    item.className = `group-row${room.id === openGroupId ? ' selected' : ''}`;
    item.addEventListener('click', () => { void openGroup(room.id).catch(error => message(errorMessage(error))); });
    const avatar = element('span', room.title.slice(0, 1) || '群', 'roster-avatar');
    const copy = element('span', '', 'roster-copy');
    copy.append(element('strong', room.title), element('small', '群聊'));
    item.append(avatar, copy);
    list.append(item);
  }
  const empty = $('groups-empty');
  if (empty) empty.hidden = visible.length > 0;
  if (openGroupId) void loadGroup(openGroupId);
  renderBotRoster();
  syncEntrySurface();
}
async function openGroup(id: string): Promise<void> {
  let room = roomSummaries.find(item => item.id === id);
  if (!room && botDialogueRouting) {
    room = await api<RoomSummary>(`/rooms/${encodeURIComponent(id)}`);
    roomSummaries.push(room);
  }
  if (botDialogueRouting && room && (room.chat === 'direct' || !room.chat && roomChat(room) === 'direct')) {
    const members = await api<RoomMemberSummary[]>(`/rooms/${encodeURIComponent(id)}/members`);
    const bot = members.find(member => member.status === 'active' && (member.principalId === 'aeeis' || member.principalId.startsWith('bot_')));
    if (bot) {
      const linked = await api<ConversationView>(`/rooms/${encodeURIComponent(id)}/dialogue`);
      if (linked.agentId) { await openLifeThread(linked.agentId); return; }
    }
  }
  if (openGroupId !== id) { groupMembers = []; resetChannelLog(); handoffViews.clear(); hideChannelSurfaces(); clearChannelUpgrades(); trackUi('ui.channel.open', id); }
  openGroupId = id;
  groupDraftOpen = false;
  showRoster(false);
  localStorage.setItem('aeeis.group', id);
  renderGroups(roomSummaries);
  $<HTMLTextAreaElement>('group-text')?.focus();
}
function finishChannelRead(id: string, epoch: number): void {
  if (openGroupId !== id || channelLoadedRoomId !== id || epoch !== channelReadEpoch) return;
  renderGroupTranscript();
  void refreshHandoffViews();
  renderChannelSurfaces();
  if (boardBehind()) {
    void loadChannelBoardState(id).then(() => {
      if (openGroupId !== id || epoch !== channelReadEpoch) return;
      renderGroupTranscript();
      renderChannelSurfaces();
    }).catch(() => undefined);
  }
}
function renderChannelSurfaces(): void {
  if (channelBoardOpen) renderChannelBoard();
  if (!$('channel-studio')?.hidden) renderStudio();
  if (!$('channel-digest')?.hidden) renderDigestBody();
}
async function refreshLoadedChannel(id: string): Promise<void> {
  const epoch = channelReadEpoch;
  const membersPromise = api<RoomMemberSummary[]>(`/rooms/${encodeURIComponent(id)}/members`).catch(() => [] as RoomMemberSummary[]);
  if (!channelEventsCaughtUp && groupEventCursor) {
    const members = await membersPromise;
    if (openGroupId !== id || channelLoadedRoomId !== id || epoch !== channelReadEpoch) return;
    groupMembers = members.filter(member => member.status === 'active' && member.principalId !== 'aeeis');
    finishChannelRead(id, epoch);
    await absorbLaterEvents(id, epoch);
    finishChannelRead(id, epoch);
    return;
  }
  if (channelEventsCaughtUp && groupEventCursor) {
    const cursor = groupEventCursor;
    const [members, page] = await Promise.all([
      membersPromise,
      api<SessionEventPage>(`/rooms/${encodeURIComponent(id)}/session-events?limit=50&cursor=${encodeURIComponent(cursor)}`).catch((): SessionEventPage => ({ items: [] })),
    ]);
    if (openGroupId !== id || channelLoadedRoomId !== id || epoch !== channelReadEpoch) return;
    groupMembers = members.filter(member => member.status === 'active' && member.principalId !== 'aeeis');
    appendUnseen(page.items, liveChannelEvents);
    noteEventPage(page, cursor);
    finishChannelRead(id, epoch);
    if (!channelEventsCaughtUp) {
      await absorbLaterEvents(id, epoch);
      finishChannelRead(id, epoch);
    }
    return;
  }
  const [members, events] = await Promise.all([
    membersPromise,
    api<SessionEventPage>(`/rooms/${encodeURIComponent(id)}/session-events?limit=50&latest=1`).catch((): SessionEventPage => ({ items: [] })),
  ]);
  if (openGroupId !== id || channelLoadedRoomId !== id || epoch !== channelReadEpoch) return;
  groupMembers = members.filter(member => member.status === 'active' && member.principalId !== 'aeeis');
  const held = new Set([...laterChannelEvents, ...liveChannelEvents].map(event => event.id));
  groupEvents = (events.items ?? []).filter(event => !held.has(event.id));
  channelOlderCursor = events.previousCursor;
  noteEventPage(events, undefined);
  finishChannelRead(id, epoch);
  if (!channelEventsCaughtUp) {
    await absorbLaterEvents(id, epoch);
    finishChannelRead(id, epoch);
  }
}
async function loadGroupFromStart(id: string): Promise<void> {
  const epoch = ++channelReadEpoch;
  const [members, events] = await Promise.all([
    api<RoomMemberSummary[]>(`/rooms/${encodeURIComponent(id)}/members`).catch(() => [] as RoomMemberSummary[]),
    api<SessionEventPage>(`/rooms/${encodeURIComponent(id)}/session-events?limit=50&latest=1`).catch((): SessionEventPage => ({ items: [] })),
  ]);
  if (openGroupId !== id || epoch !== channelReadEpoch) return;
  groupMembers = members.filter(member => member.status === 'active' && member.principalId !== 'aeeis');
  groupEvents = events.items ?? [];
  channelOlderCursor = events.previousCursor;
  laterChannelEvents = [];
  liveChannelEvents = [];
  channelLoadedRoomId = id;
  noteEventPage(events, undefined);
  finishChannelRead(id, epoch);
  if (!channelEventsCaughtUp) {
    await absorbLaterEvents(id, epoch);
    finishChannelRead(id, epoch);
  }
}
function trackChannelRead(run: Promise<void>): Promise<void> {
  const tracked = run.finally(() => { if (channelReadFlight === tracked) channelReadFlight = undefined; });
  channelReadFlight = tracked;
  return tracked;
}
async function loadGroup(id: string): Promise<void> {
  if (channelReadFlight) await channelReadFlight.catch(() => undefined);
  if (openGroupId !== id) return;
  if (upgradesRoomId !== id) void renderChannelUpgrades(id).catch(error => message(errorMessage(error)));
  if (channelLoadedRoomId === id) return trackChannelRead(refreshLoadedChannel(id));
  return trackChannelRead(loadGroupFromStart(id));
}
interface ChannelUpgradeView {
  kind: 'full' | 'summary'; id: string; target: string; version: string; status: string; updatedAt: string;
  baseVersion?: string; change?: string; reason?: string; risk?: 'low' | 'medium' | 'high';
  evaluations?: Array<{ kind: string; passed: boolean; score: number }>; evaluated?: boolean;
  shadow?: { passed: number; failed: number; needed: number }; canary?: { passed: number; failed: number; needed: number };
  sources?: number; fromThisChannel?: boolean; affectedChannels?: number; active?: boolean; canActivate?: boolean;
}
const UPGRADE_TARGETS: Record<string, string> = { profile: '档案', skill: '技能', prompt: '提示词', workflow: '工作流程', 'tool-policy': '工具权限', 'model-policy': '模型选择' };
const UPGRADE_STATUSES: Record<string, string> = { proposed: '刚提出', evaluating: '评估中', held: '已暂停', approved: '已批准', shadowing: '影子运行中', canarying: '灰度中', promoted: '已上线', rejected: '已拒绝', rolled_back: '已回滚' };
const UPGRADE_CHECKS: Record<string, string> = { replay: '回放', holdout: '留出集', safety: '安全', cost: '花费', shadow: '影子' };
const UPGRADE_RISKS: Record<string, string> = { low: '低', medium: '中', high: '高' };
let upgradesRoomId = '';
let upgradesKey = '';
/** Interaction-design §8.9: Bot upgrades as cards in the group, never a silent swap. Only the owner gets the full card. */
async function renderChannelUpgrades(roomId: string): Promise<void> {
  const box = $('channel-upgrades');
  if (!box) return;
  const loaded = await api<{ items?: ChannelUpgradeView[] }>(`/rooms/${encodeURIComponent(roomId)}/upgrades`).catch(() => undefined);
  if (openGroupId !== roomId || !loaded) return;
  // A server without upgrade cards answers without a list.
  const items = Array.isArray(loaded.items) ? loaded.items : [];
  const key = `${roomId}\0${JSON.stringify(items)}`;
  if (key === upgradesKey) return;
  upgradesRoomId = roomId;
  upgradesKey = key;
  box.replaceChildren(...items.map(item => item.kind === 'full' ? upgradeCard(item, roomId) : upgradeSummary(item)));
  box.hidden = items.length === 0;
}
function clearChannelUpgrades(): void {
  upgradesRoomId = ''; upgradesKey = '';
  const box = $('channel-upgrades');
  if (box) { box.replaceChildren(); box.hidden = true; }
}
function upgradeSummary(item: ChannelUpgradeView): HTMLElement {
  const card = element('article', '', 'group-run-card upgrade-card');
  card.dataset.upgrade = item.id; card.dataset.upgradeKind = 'summary';
  card.append(element('strong', '团队升级'), element('small', `${UPGRADE_TARGETS[item.target] ?? item.target}升到 ${item.version} · ${UPGRADE_STATUSES[item.status] ?? item.status}`));
  return card;
}
function upgradeCard(item: ChannelUpgradeView, roomId: string): HTMLElement {
  const card = element('article', '', 'group-run-card upgrade-card');
  card.dataset.upgrade = item.id; card.dataset.upgradeKind = 'full'; card.dataset.status = item.status;
  const target = UPGRADE_TARGETS[item.target] ?? item.target;
  card.append(element('strong', `升级：${target}从 ${item.baseVersion} 到 ${item.version}`), element('small', `${UPGRADE_STATUSES[item.status] ?? item.status} · 风险${UPGRADE_RISKS[item.risk ?? ''] ?? item.risk}`));
  card.append(element('p', `改什么：${item.change ?? ''}`), element('p', `为什么：${item.reason ?? ''}`));
  const evidence = [
    item.evaluations?.length ? item.evaluations.map(check => `${UPGRADE_CHECKS[check.kind] ?? check.kind}${check.passed ? '通过' : '没通过'} ${check.score}`).join('、') : '还没有评估',
    ...(item.shadow && (item.shadow.passed || item.shadow.failed || item.status === 'shadowing') ? [`影子运行 ${item.shadow.passed}/${item.shadow.needed} 通过${item.shadow.failed ? `，${item.shadow.failed} 次没通过` : ''}`] : []),
    ...(item.canary && (item.canary.passed || item.canary.failed || item.status === 'canarying') ? [`灰度 ${item.canary.passed}/${item.canary.needed} 通过${item.canary.failed ? `，${item.canary.failed} 次没通过` : ''}`] : []),
    `${item.sources ?? 0} 条来源`,
    ...(item.fromThisChannel ? ['由这个群里的一件事引出'] : []),
  ];
  card.append(element('small', `证据：${evidence.join(' · ')}`));
  const live = item.status === 'promoted' && item.active;
  const impact = item.status === 'rejected' || item.status === 'rolled_back' ? '新开的 Run 不用这个版本。'
    : live ? `已用到新 Run：你的 ${item.affectedChannels ?? 0} 个群聊里，Bot 新开的 Run 用这个版本；正在做的事不受影响。`
    : `影响：上线并启用后，你的 ${item.affectedChannels ?? 0} 个群聊里 Bot 新开的 Run 用这个版本；正在做的事不受影响。`;
  card.append(element('small', impact));
  const act = (label: string, action: string, body: unknown = {}) => {
    const control = dashboardButton(label, async () => {
      await api(`/evolution/candidates/${encodeURIComponent(item.id)}/${action}`, body);
      upgradesKey = '';
      await renderChannelUpgrades(roomId);
    });
    control.dataset.upgradeAction = action;
    return control;
  };
  const actions = element('div', '', 'upgrade-actions');
  const ref = `room:${roomId}`;
  if (['evaluating', 'held'].includes(item.status) && item.evaluated) actions.append(act('批准', 'approve', { approvalRef: ref }));
  else if (['proposed', 'evaluating', 'held'].includes(item.status)) card.append(element('small', '评估还没全部通过，先不能批准。'));
  if (item.status === 'approved') {
    actions.append(act('先影子运行', 'start-shadow'));
    if (item.risk === 'low') actions.append(act('上线', 'promote'));
  }
  if (item.status === 'shadowing' && item.shadow && item.shadow.passed >= item.shadow.needed && !item.shadow.failed) actions.append(act('开始灰度', 'start-canary'));
  if (item.status === 'canarying' && item.canary && item.canary.passed >= item.canary.needed && !item.canary.failed) actions.append(act('上线', 'promote'));
  if (item.status === 'promoted' && !item.active && item.canActivate) actions.append(act('用到新 Run', 'activate', { activationRef: ref }));
  const rejectable = ['proposed', 'evaluating', 'held', 'approved'].includes(item.status);
  const revertible = ['approved', 'shadowing', 'canarying', 'promoted', 'held'].includes(item.status);
  if (rejectable || revertible) {
    const reason = document.createElement('textarea');
    reason.rows = 2; reason.maxLength = 1000; reason.dataset.upgradeReason = item.id;
    reason.placeholder = rejectable ? '拒绝或回滚前写下原因' : '回滚前写下原因';
    reason.setAttribute('aria-label', `${target}升级的原因`);
    const withReason = (label: string, action: string) => {
      const control = dashboardButton(label, async () => {
        const text = reason.value.trim();
        if (!text) { message(`${label}前写下原因。`); reason.focus(); return; }
        if (action === 'rollback' && !window.confirm(`回滚${target}到 ${item.baseVersion}？新开的 Run 改回原来的版本，正在做的事不受影响。`)) return;
        await api(`/evolution/candidates/${encodeURIComponent(item.id)}/${action}`, { reason: text });
        upgradesKey = '';
        await renderChannelUpgrades(roomId);
      });
      control.dataset.upgradeAction = action;
      return control;
    };
    actions.append(reason);
    if (rejectable) actions.append(withReason('拒绝', 'reject'));
    if (revertible) actions.append(withReason('回滚', 'rollback'));
  }
  if (actions.childElementCount) card.append(actions);
  return card;
}
function renderGroupTranscript(): void {
  const list = $('group-transcript');
  const empty = $('group-thread-empty');
  if (!list) return;
  if (empty) empty.hidden = channelBoardOpen || channelReadableEvents().length > 0;
  list.hidden = channelBoardOpen;
  const key = channelTranscriptSignature();
  if (key === channelTranscriptKey) return;
  channelTranscriptKey = key;
  const members = $('group-members');
  if (members) {
    const archive = (id: string) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'quiet-button';
      button.dataset.botProfile = id;
      button.textContent = '档案';
      button.addEventListener('click', () => { void openChannelBot(id).catch(error => message(errorMessage(error))); });
      return button;
    };
    members.replaceChildren(document.createTextNode('AEEIS'), archive('aeeis'));
    for (const member of groupMembers) {
      members.append(document.createTextNode('、'));
      const openMember = document.createElement('button');
      openMember.type = 'button';
      openMember.className = 'quiet-button';
      openMember.textContent = participantLabel(member.principalId);
      openMember.addEventListener('click', () => { void openDirect(member.principalId).catch(error => message(errorMessage(error))); });
      members.append(openMember, archive(member.principalId));
    }
  }
  const answerDrafts = new Map<string, string>();
  const rejectDrafts = new Map<string, string>();
  list.querySelectorAll<HTMLTextAreaElement>('textarea[data-answer]').forEach(field => {
    if (field.dataset.answer) answerDrafts.set(field.dataset.answer, field.value);
  });
  list.querySelectorAll<HTMLTextAreaElement>('textarea[data-reject]').forEach(field => {
    if (field.dataset.reject) rejectDrafts.set(field.dataset.reject, field.value);
  });
  list.replaceChildren();
  const earlier = earlierChannelCount();
  if (earlier > 0 || channelOlderCursor) {
    const row = element('li', '', 'group-earlier');
    const fromServer = Boolean(channelOlderCursor) && earlier < CHANNEL_TRANSCRIPT_PAGE;
    const older = element('button', channelOlderCursor ? '查看更早的消息' : `查看更早的消息 · 还有 ${earlier} 条`, 'quiet-button') as HTMLButtonElement;
    older.type = 'button';
    older.dataset.earlierMessages = String(earlier);
    older.addEventListener('click', () => {
      if (!fromServer) {
        channelHistoryPages += 1;
        renderGroupTranscript();
        void refreshHandoffViews();
        return;
      }
      void readOlderChannelPage().catch(error => message(errorMessage(error)));
    });
    row.append(older);
    list.append(row);
  }
  // A Bot's proposal writes a receipt and a board mark; the receipt already says it, with the doer's name.
  const shown = visibleChannelEvents().filter(event => event.operation !== 'retract' && !event.idempotencyKey?.startsWith('bot-propose-mark:'));
  const latestCite = new Map<string, string>();
  for (const event of shown) {
    const cite = handoffCitation(event);
    if (cite) latestCite.set(`${cite.conversationId}:${cite.taskId}`, event.id);
  }
  for (const event of shown) {
    const item = element('li', '', 'group-message');
    item.dataset.type = event.type;
    item.dataset.kind = event.type === 'system' ? 'system' : event.actorType === 'agent' ? 'bot' : event.type === 'message' ? 'human' : event.type;
    const heading = element('header');
    heading.append(element('strong', eventAuthor(event)), element('small', formatTime(event.createdAt)));
    if (event.actorType === 'agent' && event.idempotencyKey?.startsWith('bot-reply:')) { heading.append(element('small', '自动回复', 'bot-auto')); item.dataset.auto = 'true'; }
    item.append(heading, element('p', event.content));
    if (event.digest) {
      item.dataset.kind = 'digest';
      const originals = new Map<string, Promise<SessionEventSummary>>();
      const readOriginal = (id: string) => {
        if (!originals.has(id)) originals.set(id, api<SessionEventSummary>(`/rooms/${encodeURIComponent(event.roomId)}/session-events/${encodeURIComponent(id)}`));
        return originals.get(id)!;
      };
      const preview = element('ul');
      void Promise.all(event.digest.eventIds.slice(0, 3).map(id => readOriginal(id)
        .then(original => element('li', `${eventAuthor(original)}：${original.content.slice(0, 160)}${original.content.length > 160 ? '…' : ''}`))
        .catch(() => element('li', '这条记录当前不可读')))).then(rows => preview.replaceChildren(...rows));
      const details = element('details') as HTMLDetailsElement;
      const summary = element('summary', `展开完整列表 · ${event.digest.minutes} 分钟摘要`);
      summary.setAttribute('aria-expanded', 'false'); details.append(summary);
      const body = element('div'); details.append(body);
      let loaded = false;
      details.addEventListener('toggle', () => {
        summary.setAttribute('aria-expanded', String(details.open));
        if (!details.open || loaded) return;
        loaded = true;
        void Promise.all(event.digest!.eventIds.map(id => readOriginal(id)
          .then(original => element('p', `${eventAuthor(original)} · ${formatTime(original.createdAt)}：${original.content}`))
          .catch(() => element('p', '这条记录当前不可读')))).then(rows => body.replaceChildren(...rows));
      });
      item.append(preview, details);
    }
    const cite = handoffCitation(event);
    appendHandoffCard(item, event, { answer: answerDrafts, reject: rejectDrafts }, !cite || latestCite.get(`${cite.conversationId}:${cite.taskId}`) === event.id);
    list.append(item);
  }
  syncGroupSpeaker();
  renderMentions();
}
function mentionTargets(): Array<{ label: string }> {
  return [{ label: 'AEEIS' }, { label: '所有人' }, ...groupMembers.map(member => ({ label: participantLabel(member.principalId) }))];
}
function renderMentions(): void {
  const box = $('group-mentions');
  const input = $<HTMLTextAreaElement>('group-text');
  if (!box || !input) return;
  const match = input.value.match(/(?:^|\s)@([^\s@]*)$/);
  const query = match?.[1]?.toLowerCase();
  box.replaceChildren();
  if (query === undefined) { box.hidden = true; return; }
  const hits = mentionTargets().filter(target => target.label.toLowerCase().includes(query));
  box.hidden = hits.length === 0;
  for (const hit of hits) {
    const choice = element('button', `@${hit.label}`) as HTMLButtonElement;
    choice.type = 'button';
    choice.addEventListener('click', () => {
      input.value = input.value.replace(/(?:^|\s)@([^\s@]*)$/, token => /^\s/.test(token) ? ` @${hit.label} ` : `@${hit.label} `);
      box.hidden = true;
      input.focus();
    });
    box.append(choice);
  }
}
function mentionOf(label: string, text: string): boolean {
  const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp(`(?:^|[^\\p{L}\\p{N}_])@${escaped}(?=$|[^\\p{L}\\p{N}_])`, 'iu').test(text.normalize('NFKC'));
}
function mentionedGroupBots(text: string): RosterBot[] {
  const members = new Set(groupMembers.filter(member => member.role === 'agent' && member.status === 'active').map(member => member.principalId));
  return rosterBots().filter(bot => roomReadyBot(bot) && members.has(bot.id) && mentionOf(bot.name, text));
}
const AEEIS_MENTION = /(?:^|[^\p{L}\p{N}_])@aeeis(?=$|[^\p{L}\p{N}_])/giu;
function mentionsAeeis(text: string): boolean {
  AEEIS_MENTION.lastIndex = 0;
  return AEEIS_MENTION.test(text.normalize('NFKC'));
}
function clipEntryText(value: string, max: number): string {
  const sliced = value.slice(0, max);
  const last = sliced.charCodeAt(sliced.length - 1);
  return last >= 0xD800 && last <= 0xDBFF ? sliced.slice(0, -1) : sliced;
}
function memberNeedsReply(bot: RosterBot): boolean {
  const summary = lifeSummary(bot.id);
  return Boolean(summary?.standingInstruction?.trim() || summary?.hasStandingInstruction);
}
function spokenBy(bot: RosterBot, spoken: { type: 'agent' | 'principal'; id: string } | undefined): boolean {
  return spoken?.type === 'agent' && spoken.id === bot.id;
}
function receiptMarks(bots: RosterBot[]): string {
  return bots.map(bot => `${bot.name} 👍`).join('、');
}
function groupAgentBots(): RosterBot[] {
  const ids = new Set(groupMembers.filter(member => member.role === 'agent' && member.status === 'active').map(member => member.principalId));
  const bots = rosterBots().filter(bot => bot.id !== 'aeeis' && ids.has(bot.id) && roomReadyBot(bot));
  const home = botById('aeeis') ?? { id: 'aeeis', name: 'AEEIS', note: '', demo: false };
  return [home, ...bots];
}
function entryMentionTitle(text: string, roomTitle: string, kind: string): string {
  AEEIS_MENTION.lastIndex = 0;
  const stripped = text.normalize('NFKC').replace(AEEIS_MENTION, ' ').replace(/\s+/g, ' ').trim();
  const title = clipEntryText(stripped || `来自${kind}「${roomTitle || kind}」`, 80).trim();
  return title.length >= 2 ? title : '入口请求';
}
function groupIdempotencyKey(): string {
  return `group-${globalThis.crypto?.randomUUID?.() ?? `${Date.now().toString(36)}-${Math.random().toString(16).slice(2)}`}`;
}
function selectedHandoffBot(): RosterBot | undefined {
  if (rosterView() !== 'group') return;
  const id = $<HTMLSelectElement>('group-handoff')?.value.trim() ?? '';
  if (!id) return;
  return handoffChoices().find(bot => bot.id === id);
}
async function recordRosterHandoff(
  bot: RosterBot,
  text: string,
  room: RoomSummary | undefined,
  spoken: { type: 'agent' | 'principal'; id: string } | undefined,
  postSession: (type: 'message' | 'system', content: string, evidenceRefs?: string[]) => Promise<unknown>,
  receipt: (title: string) => string,
  mode: 'intake' | 'entry' | 'handoff',
  announce = true,
  sourceEventId?: string,
): Promise<string> {
  const kind = roomChat(room) === 'direct' ? '私聊' : '群聊';
  const roomTitle = room?.title || kind;
  const title = entryMentionTitle(text, roomTitle, kind);
  const known = bot.id === 'aeeis' ? aeeisThread() : lifeSummary(bot.id);
  if (bot.id === 'aeeis') {
    if (!conversationEnabled || !known) return '这条点名了 AEEIS，入口讨论还没打开，所以只留在会话里。';
    if (conversationBusy || conversationAttempt) return '入口正在发送另一条讨论，这条点名只留在会话里。';
  } else if (!conversationEnabled) return `还没打开${bot.name}的对话，这句话只留在会话里。`;
  else if (conversationBusy || conversationAttempt) return `${bot.name}正在发送另一条讨论，这句话只留在会话里。`;
  const epoch = conversationEpoch;
  conversationBusy = true;
  updateConversationControls();
  let conversationId = known?.id ?? '';
  let taskId = '';
  let handoffError = '';
  let recorded = false;
  try {
    const opensTask = mode !== 'intake';
    let result: ConversationPost;
    if (botDialogueRouting) {
      if (!room?.id || !sourceEventId) throw new Error('缺少频道消息来源，请刷新后重试');
      result = await api<ConversationPost>(`/rooms/${encodeURIComponent(room.id)}/session-events/${encodeURIComponent(sourceEventId)}/deliver`, { botId: bot.id, kind: mode });
      conversationId = result.conversation.id;
    } else {
      let target = known;
      if (!target) {
        const created = await api<ConversationView>('/conversations', { title: bot.name, agentId: bot.id });
        if (epoch !== conversationEpoch) return '';
        rememberLifeSummary(created);
        target = created;
      }
      conversationId = target.id;
      const expectedRevision = conversation?.id === conversationId ? conversation.revision : target.revision;
      result = await api<ConversationPost>(`/conversations/${encodeURIComponent(conversationId)}/messages`, {
        text: clipEntryText(`来自${kind}「${roomTitle}」：${text}`, 7000),
        expectedRevision,
        ...(opensTask ? { newTask: { title } } : { unassigned: true as const }),
        focus: 'keep',
        intent: 'discuss',
        ...(spoken?.type === 'agent' ? { speaker: { role: 'agent' as const, id: spoken.id } } : {}),
      }, 'POST', groupIdempotencyKey());
    }
    taskId = opensTask ? (result.message.route.taskIds.find(item => CITATION_ID.test(item)) ?? '') : '';
    if (epoch === conversationEpoch && result.conversation?.id === conversationId) {
      handoffViews.set(conversationId, result.conversation);
      if (conversation?.id === conversationId) acceptConversation(result.conversation);
      else rememberLifeSummary(result.conversation);
    }
    recorded = epoch === conversationEpoch;
  } catch (error) {
    handoffError = bot.id === 'aeeis'
      ? `会话已留下，入口讨论没有记上。${errorMessage(error)}`
      : `会话已留下，${bot.name}的讨论没有记上。${errorMessage(error)}`;
  } finally {
    if (epoch === conversationEpoch) { conversationBusy = false; updateConversationControls(); }
  }
  if (handoffError || !recorded || !announce) return handoffError;
  const cited = mode === 'handoff' && CITATION_ID.test(conversationId) && CITATION_ID.test(taskId);
  const refs = cited ? [conversationId, taskId, bot.id].filter(item => CITATION_ID.test(item)) : (CITATION_ID.test(conversationId) ? [conversationId] : undefined);
  try {
    await postSession('system', receipt(title), refs);
  } catch (error) {
    return bot.id === 'aeeis'
      ? `入口讨论已记下，回执没有写进会话。${errorMessage(error)}`
      : `已交给${bot.name}，回执没有写进会话。${errorMessage(error)}`;
  }
  return '';
}
async function submitGroupMessage(event: Event): Promise<void> {
  event.preventDefault();
  const input = $<HTMLTextAreaElement>('group-text');
  const text = input?.value.trim() ?? '';
  const roomId = openGroupId;
  if (!text || !roomId) { input?.focus(); return; }
  const room = roomSummaries.find(item => item.id === roomId);
  if (room && room.status !== 'active') { message('这个群聊已经归档。'); return; }
  const listed = await api<GoalSummary[] | { goals?: GoalSummary[] }>(`/rooms/${encodeURIComponent(roomId)}/goals`);
  const goals = Array.isArray(listed) ? listed : (listed.goals ?? []);
  let goal = goals.find(item => item.status === 'active') ?? goals[0];
  if (!goal) goal = await api<GoalSummary>('/goals', { title: room?.title || '群聊', roomId });
  const manifest = await api<{ id: string }>(`/goals/${encodeURIComponent(goal.id)}/context-manifests`, { purpose: roomChat(room) === 'direct' ? '私聊消息' : '群聊消息', audienceMode: 'room' });
  const spoken = selectedRoomSpeaker();
  const postSession = (type: 'message' | 'system', content: string, evidenceRefs?: string[]) => api(`/rooms/${encodeURIComponent(roomId)}/session-events`, {
    goalId: goal.id, type, content, contextManifestId: manifest.id, idempotencyKey: groupIdempotencyKey(),
    ...(type === 'message' && spoken ? { actor: spoken } : {}),
    ...(evidenceRefs?.length ? { evidenceRefs } : {}),
  });
  const sourceEvent = await postSession('message', text) as { id: string };
  if (input) input.value = '';
  let handoffError = '';
  const chosen = selectedHandoffBot();
  const inGroup = roomChat(room) !== 'direct';
  const handTo = (bot: RosterBot, receipt: (title: string) => string, mode: 'intake' | 'entry' | 'handoff', announce = true) => recordRosterHandoff(bot, text, room, spoken, postSession, receipt, mode, announce, sourceEvent.id);
  const home = botById('aeeis');
  if (!inGroup) {
    if (mentionsAeeis(text) && home) handoffError = await handTo(home, title => `已记为入口讨论「${title}」。未执行，讨论焦点不变。`, 'entry');
  } else if (home) {
    const named = mentionedGroupBots(text);
    const addressed = mentionsAeeis(text);
    const everyone = mentionOf('所有人', text) || mentionOf('团队', text);
    const rawPointed = chosen && chosen.id !== 'aeeis' ? [chosen] : (chosen ? [] : named);
    const askedAeeis = Boolean(chosen?.id === 'aeeis' || (addressed && rawPointed.length === 0 && !everyone));
    const broadcast = rawPointed.length === 0 && !askedAeeis;
    const members = groupAgentBots().filter(bot => !spokenBy(bot, spoken));
    const errors: string[] = [];
    if (broadcast) {
      const delivered: RosterBot[] = [];
      for (const bot of members) {
        const error = await handTo(bot, () => '', 'intake', false);
        if (error) errors.push(error);
        else delivered.push(bot);
      }
      // With Bot replies on, AEEIS answers this line itself; a row of 👍 would only repeat that it arrived.
      const acked = botsActive ? [] : delivered.filter(bot => !memberNeedsReply(bot));
      const reminded = delivered.filter(memberNeedsReply);
      const line = [
        acked.length ? `已送到${receiptMarks(acked)}。` : '',
        reminded.length ? `提醒${reminded.map(bot => bot.name).join('、')}按常驻要求看一下。` : '',
      ].filter(Boolean).join('');
      if (line) {
        try {
          await postSession('system', line);
        } catch (error) {
          errors.push(`句子已送到对话，房间里的回执没有写上。${errorMessage(error)}`);
        }
      }
    } else {
      // A Bot that replies on its own answers an @ in the group and proposes the task itself,
      // so the browser does not also open a discussion for it. An explicit 交给 still does.
      const replies = (bot: RosterBot) => botsActive && !chosen && ownedBotRecords.some(item => item.id === bot.id && (item.autonomy ?? 'reply') !== 'quiet');
      const targets = rawPointed.filter(bot => !spokenBy(bot, spoken) && !replies(bot));
      const homeIn = members.some(bot => bot.id === home.id);
      const others = members.filter(bot => bot.id !== 'aeeis' && !rawPointed.some(item => item.id === bot.id));
      const reminded: RosterBot[] = [];
      for (const bot of others.filter(memberNeedsReply)) {
        const error = await handTo(bot, () => '', 'intake', false);
        if (error) errors.push(error);
        else reminded.push(bot);
      }
      const suffix = reminded.length ? `提醒${reminded.map(bot => bot.name).join('、')}按常驻要求看一下。` : '';
      const announced = askedAeeis && homeIn ? 'aeeis' : (targets[targets.length - 1]?.id ?? '');
      let aeeisError = '';
      if (homeIn) {
        const aeeisMode = askedAeeis ? (chosen?.id === 'aeeis' ? 'handoff' as const : 'entry' as const) : 'intake' as const;
        aeeisError = await handTo(home, title => {
          const line = chosen?.id === 'aeeis'
            ? `已交给AEEIS，记为讨论「${title}」。未执行，讨论焦点不变。`
            : askedAeeis
              ? `已记为入口讨论「${title}」。未执行，讨论焦点不变。`
              : `入口收下了这句话「${title}」。已请${rawPointed.map(bot => bot.name).join('、')}回应。`;
          return announced === 'aeeis' ? `${line}${suffix}` : line;
        }, aeeisMode, askedAeeis);
        if (aeeisError) errors.push(aeeisError);
      }
      const pointedErrors = new Map<string, string>();
      for (const bot of targets) {
        const error = await handTo(bot, title => {
          const line = chosen
            ? `已交给${bot.name}，记为讨论「${title}」。这句话也留在入口。`
            : `已请${bot.name}回应，记为讨论「${title}」。这句话也留在入口。`;
          return bot.id === announced ? `${line}${suffix}` : line;
        }, 'handoff');
        if (error) {
          errors.push(error);
          pointedErrors.set(bot.id, error);
        }
      }
      if (!announced && suffix) {
        try {
          await postSession('system', suffix);
        } catch (error) {
          errors.push(`句子已送到对话，房间里的表情没有写上。${errorMessage(error)}`);
        }
      }
      if (chosen && !(chosen.id === 'aeeis' ? aeeisError : pointedErrors.get(chosen.id))) {
        const select = $<HTMLSelectElement>('group-handoff');
        if (select) select.value = '';
      }
    }
    handoffError = errors.filter(Boolean).join(' ');
  }
  await loadGroup(roomId);
  message(handoffError);
}
async function renameGroup(): Promise<void> {
  if (!openGroupId) return;
  const room = roomSummaries.find(item => item.id === openGroupId);
  const title = window.prompt('群聊名称', room?.title ?? '')?.trim();
  if (!title) return;
  const updated = await api<RoomSummary>(`/rooms/${encodeURIComponent(openGroupId)}`, { title, expectedRevision: room?.revision ?? 0 }, 'PATCH');
  roomSummaries = roomSummaries.map(item => item.id === updated.id ? { ...item, ...updated } : item);
  renderGroups(roomSummaries);
}
function machineLine(machine: { state: 'absent' | 'present' | 'released' | 'unknown'; ready: boolean }): string {
  if (machine.state === 'unknown') return '这件工作的机器记录读不出来。看一眼不会执行。';
  if (machine.state === 'released') return '这件工作的机器已经收掉。';
  if (machine.state === 'present' && machine.ready) return '这件工作有一台机器，还在。看一眼不会执行。';
  if (machine.state === 'present') return '这件工作的机器还没准备好。看一眼不会启动它。';
  return '这件工作还没有机器。';
}
function executionLine(execution: { steps: Array<{ title: string; state: 'done' | 'current' | 'waiting' }> }): string {
  const label = (state: 'done' | 'current' | 'waiting') => state === 'done' ? '已完成' : state === 'current' ? '正在做' : '还没到';
  return `执行步骤：${execution.steps.map(step => `${step.title} ${label(step.state)}`).join(' · ')}`;
}
/** One plain word for where a task's Run stands, and the colour that word is shown in. */
function taskStatusWord(task: ConversationTaskView): { word: string; tone: 'quiet' | 'ink' | 'attention' | 'done' | 'stuck' } {
  switch (task.status) {
    case 'preparing': case 'queued': case 'planning': return { word: '起草中', tone: 'quiet' };
    case 'needs_approval': return task.pendingApproval ? { word: '等你确认计划', tone: 'quiet' } : { word: '需要你', tone: 'attention' };
    case 'needs_input': return { word: '需要你', tone: 'attention' };
    case 'running': case 'waiting_external': case 'reviewing': return { word: '执行中', tone: 'ink' };
    case 'succeeded': return { word: '已完成', tone: 'done' };
    case 'failed': case 'unknown': return { word: '卡住了', tone: 'stuck' };
    case 'cancelled': return { word: '已取消', tone: 'quiet' };
    case 'paused': return { word: '已暂停', tone: 'quiet' };
    default: return { word: runStatusLabel(task.status), tone: 'quiet' };
  }
}
/** One sentence on what the Run is doing now, or what it needs. */
function taskActivity(task: ConversationTaskView): string {
  const steps = task.execution?.steps ?? [];
  const index = Math.max(0, steps.findIndex(step => step.state !== 'done'));
  const at = steps.length ? `第 ${Math.min(index + 1, steps.length)} 步 / 共 ${steps.length} 步` : '';
  const title = steps[index]?.title;
  const evidence = task.execution?.evidence?.length ?? 0;
  switch (task.status) {
    case 'preparing': case 'queued': case 'planning': return '正在起草计划。';
    case 'needs_approval': return task.pendingApproval ? '计划好了，点“开始”它就去做。' : `停在${at || '当前这一步'}，等你决定一个动作。`;
    case 'needs_input': return `停在${at || '当前这一步'}，等你回答一个问题。`;
    case 'running': return title ? `正在做${at}：${title}。` : '正在做。';
    case 'waiting_external': return `在等外部回执${at ? `（${at}）` : ''}。`;
    case 'reviewing': return '在复核结果。';
    case 'paused': return `已暂停${at ? `，停在${at}` : ''}。`;
    case 'succeeded': return evidence ? `做完了，留下 ${evidence} 份证据。` : '做完了。';
    case 'failed': return `在${at || '执行中'}卡住了。可以重试，或打开工作台看原因。`;
    case 'unknown': return '有一次调用结果未知，需要你核查后才能继续。';
    case 'cancelled': return '已取消，不会再执行。';
    default: return '';
  }
}
/** A task's Run, shown in the transcript under the message that started it: status, what it is doing, progress and the plan. Its buttons use the same Run commands as the task table. */
function conversationPlanCard(task: ConversationTaskView, feedbackDraft = ''): HTMLElement {
  const card = element('section', '', 'plan-card');
  card.dataset.planTask = task.id;
  card.dataset.state = task.pendingApproval ? 'awaiting' : task.status;
  const status = taskStatusWord(task);
  card.dataset.tone = status.tone;
  card.setAttribute('aria-label', `「${task.title}」的运行`);
  const head = element('div', '', 'plan-card-head');
  head.append(element('strong', task.title, 'plan-card-title'), element('span', status.word, 'plan-card-status'));
  card.append(head);
  const activity = taskActivity(task);
  if (activity) card.append(element('p', activity, 'plan-card-activity'));
  const steps = task.execution?.steps ?? [];
  if (steps.length) {
    const done = steps.filter(step => step.state === 'done').length;
    const strip = element('div', '', 'plan-card-progress');
    strip.setAttribute('role', 'progressbar'); strip.setAttribute('aria-label', '进度');
    strip.setAttribute('aria-valuemin', '0'); strip.setAttribute('aria-valuemax', String(steps.length)); strip.setAttribute('aria-valuenow', String(done));
    strip.setAttribute('aria-valuetext', `${done} / ${steps.length} 步已完成`);
    const fill = element('span'); fill.style.width = `${Math.round((done / steps.length) * 100)}%`;
    strip.append(fill); card.append(strip);
  }
  if (task.pendingApproval) card.append(element('p', task.pendingApproval.summary, 'plan-card-summary'));
  if (steps.length) {
    const list = element('ol', '', 'plan-card-steps');
    for (const step of steps) {
      const item = element('li'); item.dataset.state = step.state;
      const mark = element('span', step.state === 'done' ? '✓' : step.state === 'current' ? '•' : '○', 'plan-card-mark'); mark.setAttribute('aria-hidden', 'true');
      item.append(mark, element('span', step.title), element('span', step.state === 'done' ? '（已完成）' : step.state === 'current' ? '（正在做）' : '', 'sr-only'));
      list.append(item);
    }
    card.append(list);
  }
  if (task.runId && task.pendingApproval) {
    const actions = element('div', '', 'plan-card-actions');
    const start = dashboardButton('开始', () => approveConversationTask(task, 'task'));
    start.className = 'decision-primary'; start.dataset.planStart = task.id;
    const revise = dashboardButton('改一下计划', async () => { revision.hidden = !revision.hidden; if (!revision.hidden) field.focus(); });
    revise.dataset.planRevise = task.id; revise.setAttribute('aria-expanded', 'false');
    const cancel = dashboardButton('算了', () => cancelConversationTask(task));
    cancel.dataset.planCancel = task.id;
    actions.append(start, revise, cancel);
    const revision = element('div', '', 'plan-card-revision');
    const field = element('textarea', '', 'conversation-answer');
    field.rows = 2; field.maxLength = 8000; field.dataset.planFeedback = task.id; field.value = feedbackDraft;
    field.placeholder = '想怎么改？它会按你说的重新出一份计划，仍然等你确认。';
    field.setAttribute('aria-label', `修改「${task.title}」的计划`);
    const submit = dashboardButton('按这个改', () => rejectConversationTask(task, field.value));
    submit.dataset.planReviseSubmit = task.id;
    revision.append(field, submit);
    revision.hidden = !feedbackDraft;
    revise.addEventListener('click', () => revise.setAttribute('aria-expanded', String(!revision.hidden)));
    card.append(actions, revision);
  }
  return card;
}
/** A finished task's answer, said by the Bot in the transcript. The whole result, evidence and steps stay in the workbench. */
function conversationBotReply(answer: ConversationReply, runId: string, title: string): HTMLElement {
  const person = lifePersonId();
  const reply = element('section', '', 'bot-reply');
  reply.dataset.replyRun = runId;
  reply.setAttribute('aria-label', `「${title}」的回答`);
  reply.append(element('small', person ? participantLabel(person) : 'AEEIS', 'message-meta'), element('div', answer.text, 'bot-reply-text'));
  const actions = element('div', '', 'bot-reply-actions');
  const copy = button('复制', async () => { await navigator.clipboard?.writeText(answer.text); copy.textContent = '已复制'; });
  copy.type = 'button';
  const open = button(answer.truncated ? '看完整结果 ↗' : '详情 ↗', async () => openConversationRun(runId));
  open.type = 'button'; open.dataset.replyOpen = runId;
  actions.append(copy, open);
  reply.append(actions);
  return reply;
}
/** What the Run is waiting on from you, shown under its plan: one external action to decide, or one question to answer. */
function conversationDecisionCard(task: ConversationTaskView, answerDraft = ''): HTMLElement | undefined {
  const action = task.runId && task.status === 'needs_approval' ? task.pendingAction : undefined;
  const question = task.runId && task.status === 'needs_input' ? task.pendingQuestion : undefined;
  if (!action && !question) return;
  const card = element('section', '', 'decision-card');
  card.dataset.decisionTask = task.id;
  card.dataset.kind = action ? 'action' : 'question';
  const head = element('div', '', 'decision-card-head');
  head.append(element('span', '需要你', 'decision-card-badge'));
  if (action?.step) head.append(element('span', action.step, 'decision-card-step'));
  card.append(head);
  if (action) {
    card.setAttribute('aria-label', `「${task.title}」等你决定一个动作`);
    card.append(element('strong', action.kind === 'agent' ? `想交给外部代理 ${action.ref}` : `想调用 ${action.ref}`, 'decision-card-title'));
    card.append(element('p', '计划已经批准，这一步里的这个动作要你单独点头。不要时它不会执行，任务会接着做，并知道你没同意。', 'decision-card-note'));
    const why = element('p', action.reason || '没有附带原因。', 'decision-card-reason');
    why.hidden = true; why.id = `decision-reason-${task.id}`;
    const actions = element('div', '', 'decision-card-actions');
    const approve = dashboardButton('批准', () => decideConversationAction(task, 'once'));
    approve.className = 'decision-primary'; approve.dataset.cardDecision = 'once';
    const deny = dashboardButton('不要', () => decideConversationAction(task, 'deny'));
    deny.dataset.cardDecision = 'deny';
    const whyButton = dashboardButton('为什么？', async () => { why.hidden = !why.hidden; whyButton.setAttribute('aria-expanded', String(!why.hidden)); });
    whyButton.dataset.cardWhy = task.id; whyButton.setAttribute('aria-expanded', 'false'); whyButton.setAttribute('aria-controls', why.id);
    const more = element('div', '', 'decision-card-more'); more.hidden = true; more.id = `decision-more-${task.id}`;
    const moreButton = dashboardButton('更多', async () => { more.hidden = !more.hidden; moreButton.setAttribute('aria-expanded', String(!more.hidden)); });
    moreButton.dataset.cardMore = task.id; moreButton.setAttribute('aria-expanded', 'false'); moreButton.setAttribute('aria-controls', more.id);
    const always = dashboardButton('以后都允许', () => decideConversationAction(task, 'always'));
    always.dataset.cardDecision = 'always';
    const block = dashboardButton('以后都阻止', () => decideConversationAction(task, 'block'));
    block.dataset.cardDecision = 'block';
    more.append(always, block);
    actions.append(approve, deny, whyButton, moreButton);
    card.append(actions, why, more);
    return card;
  }
  card.setAttribute('aria-label', `「${task.title}」等你回答`);
  card.append(element('strong', '它需要你补一句', 'decision-card-title'), element('p', question!.text, 'decision-card-question'));
  const field = element('textarea', '', 'conversation-answer');
  field.rows = 2; field.maxLength = 8000; field.dataset.questionAnswer = task.id; field.value = answerDraft;
  field.placeholder = '回答后它从当前这一步接着做';
  field.setAttribute('aria-label', `回答「${task.title}」的问题`);
  const submit = dashboardButton('回答', () => answerConversationTask(task, field.value));
  submit.className = 'decision-primary'; submit.dataset.questionSubmit = task.id;
  const actions = element('div', '', 'decision-card-actions'); actions.append(submit);
  card.append(field, actions);
  return card;
}
async function decideConversationAction(task: ConversationTaskView, decision: 'once' | 'always' | 'deny' | 'block'): Promise<void> {
  const action = task.pendingAction;
  if (!conversation || !task.runId || !action || conversationBusy || conversationAttempt) return;
  const epoch = conversationEpoch, runId = task.runId;
  conversationBusy = true; updateConversationControls();
  try {
    await api(`/runs/${encodeURIComponent(runId)}/approve-action`, { idempotencyKey: action.idempotencyKey, decision });
    if (epoch !== conversationEpoch) return;
    await refreshConversation(false, true);
    if (epoch !== conversationEpoch) return;
    if (currentId === runId) await refresh();
    void refreshHandoffViews();
    if (epoch !== conversationEpoch) return;
    const done: Record<typeof decision, string> = {
      once: `已批准 ${action.ref} 这一次，「${task.title}」接着做。`,
      always: `已允许 ${action.ref}，「${task.title}」接着做。它已加到设置里的动作清单，以后的 Run 不再问。`,
      deny: `没有执行 ${action.ref}，「${task.title}」会接着做，并知道你没同意。`,
      block: `已阻止 ${action.ref}，这件任务和以后的 Run 都不会执行它。可以在设置里的动作清单移除。`,
    };
    $('conversation-status').textContent = done[decision];
    $('conversation-error').textContent = '';
  } catch (error) {
    if (epoch !== conversationEpoch) return;
    $('conversation-error').textContent = errorMessage(error);
    if (error instanceof ApiError && error.status === 409) await refreshConversation(false, true).catch(() => undefined);
  } finally { if (epoch === conversationEpoch) { conversationBusy = false; updateConversationControls(); } }
}
async function cancelConversationTask(task: ConversationTaskView): Promise<void> {
  if (!conversation || !task.runId || conversationBusy || conversationAttempt) return;
  const epoch = conversationEpoch, runId = task.runId;
  conversationBusy = true; updateConversationControls();
  try {
    await api(`/runs/${encodeURIComponent(runId)}/cancel`, { reason: '在计划卡片上选择了“算了”' });
    if (epoch !== conversationEpoch) return;
    await refreshConversation(false, true);
    if (epoch !== conversationEpoch) return;
    if (currentId === runId) await refresh();
    void refreshHandoffViews();
    if (epoch !== conversationEpoch) return;
    $('conversation-status').textContent = `已取消「${task.title}」，这份计划不会执行。`;
    $('conversation-error').textContent = '';
  } catch (error) {
    if (epoch !== conversationEpoch) return;
    $('conversation-error').textContent = errorMessage(error);
    if (error instanceof ApiError && error.status === 409) await refreshConversation(false, true).catch(() => undefined);
  } finally { if (epoch === conversationEpoch) { conversationBusy = false; updateConversationControls(); } }
}
function renderConversation(): void {
  $('conversation-panel').hidden = !conversationEnabled;
  document.body.classList.toggle('conversation-mode', conversationEnabled);
  if (!conversationEnabled) return;
  const select = $<HTMLSelectElement>('conversation-select');
  const choicesSignature = JSON.stringify(conversationList.map(item => [item.id, item.title]));
  if (select.dataset.signature !== choicesSignature) {
    select.dataset.signature = choicesSignature; select.replaceChildren();
    if (!conversationList.length) { const option = element('option', '还没有对话，请新建'); option.value = ''; select.append(option); }
    for (const item of conversationList) { const option = element('option', item.title); option.value = item.id; select.append(option); }
  }
  select.value = conversation?.id ?? '';
  $('conversation-focus').textContent = `讨论焦点：${conversation?.focusTaskId ? conversationTaskName(conversation.focusTaskId) : '未选择任务（一般讨论）'}`;
  const signature = JSON.stringify(conversation);
  if (signature !== conversationRenderSignature) {
    conversationRenderSignature = signature ?? '';
    const target = $<HTMLSelectElement>('conversation-target'), previousTarget = target.value;
    target.replaceChildren();
    for (const [value, text] of [['', '自动识别 / 当前讨论焦点'], ['__new', '新建任务（独立 Thread）'], ...(conversation?.tasks ?? []).map(task => [task.id, task.title])]) {
      const option = element('option', text); option.value = value!; target.append(option);
    }
    target.value = [...target.options].some(option => option.value === previousTarget) ? previousTarget : '';
    const taskBody = $('conversation-tasks').querySelector('tbody');
    const answerDrafts = new Map<string, string>();
    const reconcileDrafts = new Map<string, string>();
    const rejectDrafts = new Map<string, string>();
    taskBody?.querySelectorAll<HTMLTextAreaElement>('textarea[data-answer]').forEach(field => {
      if (field.dataset.answer) answerDrafts.set(field.dataset.answer, field.value);
    });
    taskBody?.querySelectorAll<HTMLTextAreaElement>('textarea[data-reconcile]').forEach(field => {
      if (field.dataset.reconcile) reconcileDrafts.set(field.dataset.reconcile, field.value);
    });
    taskBody?.querySelectorAll<HTMLTextAreaElement>('textarea[data-reject]').forEach(field => {
      if (field.dataset.reject) rejectDrafts.set(field.dataset.reject, field.value);
    });
    taskBody?.replaceChildren();
    const ordered = conversationTaskOrder(conversation?.tasks ?? []);
    ordered.forEach((task, index) => {
      const row = document.createElement('tr'); row.className = 'conversation-task'; row.dataset.focused = String(task.id === conversation?.focusTaskId); row.dataset.taskId = task.id;
      const rank = document.createElement('td'); rank.append(element('strong', String(index + 1)));
      const name = document.createElement('td'); name.append(element('strong', task.title));
      if (task.memory) {
        const memoryText = task.memory.activeSummaries
          ? `工作记忆：${task.memory.activeSummaries} 份压缩摘要，${task.memory.originals} 份原文。摘要不是证据，也不改变讨论焦点。`
          : `工作记忆：${task.memory.originals} 份原文，尚未压缩。`;
        name.append(element('small', memoryText, 'conversation-memory'));
      }
      if (task.pendingApproval) {
        const preview = element('small', `待批计划：${task.pendingApproval.summary}`, 'conversation-plan');
        preview.title = task.pendingApproval.summary;
        name.append(preview);
      }
      if (task.pendingQuestion) name.append(element('small', `待回答：${task.pendingQuestion.text}`, 'conversation-question'));
      if (task.execution?.steps.length) {
        name.append(element('small', executionLine(task.execution), 'conversation-steps'));
        if (task.execution.evidence?.length) name.append(element('small', `证据：${task.execution.evidence.join('、')}`, 'conversation-evidence'));
      }
      if (task.machine) name.append(element('small', machineLine(task.machine), 'conversation-machine'));
      const status = document.createElement('td');
      status.append(element('span', task.status === 'discussion' ? '仅讨论，未执行' : task.status === 'preparing' ? '正在准备执行' : runStatusLabel(task.status)));
      if (task.column) status.append(element('small', ({ capture: '收下', ready: '待领取', doing: '进行中', blocked: '阻塞', review: '待验收', done: '已验收', failed: '失败 / 取消' } as Record<string,string>)[task.column] ?? task.column));
      const actions = document.createElement('td');
      const raise = dashboardButton('提高优先级', () => changeConversationPriority(task.id, 'higher'));
      raise.dataset.priority = 'higher'; raise.dataset.boundary = String(index === 0); raise.title = index === 0 ? '已经是最高优先级' : '把这项任务提前一位';
      const lower = dashboardButton('降低优先级', () => changeConversationPriority(task.id, 'lower'));
      lower.dataset.priority = 'lower'; lower.dataset.boundary = String(index === ordered.length - 1); lower.title = index === ordered.length - 1 ? '已经是最低优先级' : '把这项任务后移一位';
      const focus = button('设为讨论焦点', async () => changeConversationFocus(task.id)); focus.type = 'button'; focus.dataset.changeFocus = task.id;
      actions.append(raise, lower, focus);
      const runId = task.runId ?? task.latestRunId;
      if (runId && task.pendingApproval) {
        const approve = dashboardButton('批准并执行', () => approveConversationTask(task, 'task'));
        approve.dataset.approve = task.id; approve.className = 'decision-primary';
        const once = dashboardButton('仅这一次', () => approveConversationTask(task, 'once'));
        once.dataset.approveOnce = task.id;
        once.title = '记在这次批准记录上。这次仍按当前计划执行，以后的计划仍要再批。';
        const field = document.createElement('textarea');
        field.className = 'conversation-answer'; field.maxLength = 8000; field.rows = 2;
        field.placeholder = '写下拒绝原因。拒绝后重新规划，新计划仍停在等待批准，不会按这份计划执行。';
        field.dataset.reject = task.id;
        const draft = rejectDrafts.get(task.id);
        if (draft) field.value = draft;
        const reject = dashboardButton('拒绝并说明', () => rejectConversationTask(task, field.value));
        reject.dataset.rejectSubmit = task.id;
        actions.append(approve, once, field, reject);
      }
      if (runId && task.status === 'needs_input' && task.pendingQuestion) {
        const field = document.createElement('textarea');
        field.className = 'conversation-answer'; field.maxLength = 8000; field.rows = 2;
        field.placeholder = '回答后从当前节点继续'; field.dataset.answer = task.id;
        field.setAttribute('aria-label', `回答「${task.title}」`);
        const draft = answerDrafts.get(task.id);
        if (draft) field.value = draft;
        const submit = dashboardButton('提交回答', () => answerConversationTask(task, field.value));
        submit.dataset.answerSubmit = task.id;
        actions.append(field, submit);
      }
      if (runId && task.status === 'failed') {
        const retry = dashboardButton('重试', () => retryConversationTask(task));
        retry.dataset.retry = task.id;
        actions.append(retry);
      }
      if (runId && ['queued', 'planning', 'running', 'reviewing'].includes(task.status)) {
        const pause = dashboardButton('暂停', () => controlConversationRun(task, 'pause'));
        pause.dataset.runPause = task.id;
        actions.append(pause);
      }
      if (runId && task.status === 'paused' && task.takenOver) actions.append(element('small', '人已接管。做完后在工作台写说明交还。'));
      else if (runId && task.status === 'paused') {
        const resume = dashboardButton('继续', () => controlConversationRun(task, 'resume'));
        resume.dataset.runResume = task.id;
        actions.append(resume);
      }
      if (runId && (task.status === 'unknown' || task.status === 'waiting_external')) {
        const field = document.createElement('textarea');
        field.className = 'conversation-answer'; field.maxLength = 2000; field.rows = 2;
        field.placeholder = '写下你确认的结果。提交后这件 Run 会继续；如果有一次结果未知的模型调用，会把那次调用再发一遍。'; field.dataset.reconcile = task.id;
        field.setAttribute('aria-label', `核查「${task.title}」`);
        const draft = reconcileDrafts.get(task.id);
        if (draft) field.value = draft;
        const submit = dashboardButton('提交核查并继续', () => controlConversationRun(task, 'reconcile', { reason: field.value.trim() }));
        submit.dataset.reconcileSubmit = task.id;
        actions.append(field, submit);
      }
      if (runId) { const view = button('查看运行', async () => openConversationRun(runId)); view.type = 'button'; actions.append(view); }
      if (runId && task.memory?.activeSummaries) { const memory = button('查看任务记忆', async () => openConversationMemory(runId)); memory.type = 'button'; actions.append(memory); }
      row.append(rank, name, status, actions); taskBody?.append(row);
    });
    $('conversation-tasks').hidden = ordered.length === 0;
    const waiting = ordered.filter(task => ['needs_approval', 'needs_input', 'unknown', 'failed'].includes(task.status)).length;
    $('conversation-task-count').textContent = ordered.length ? `${ordered.length} 件${waiting ? ` · ${waiting} 件等你` : ''}` : '';
    const messages = $('conversation-messages');
    const planDrafts = new Map<string, string>();
    messages.querySelectorAll<HTMLTextAreaElement>('textarea[data-plan-feedback]').forEach(field => {
      if (field.dataset.planFeedback && field.value) planDrafts.set(field.dataset.planFeedback, field.value);
    });
    const questionDrafts = new Map<string, string>();
    messages.querySelectorAll<HTMLTextAreaElement>('textarea[data-question-answer]').forEach(field => {
      if (field.dataset.questionAnswer && field.value) questionDrafts.set(field.dataset.questionAnswer, field.value);
    });
    messages.replaceChildren();
    // One plan card per task, under the latest message that asked it to run.
    const planMessage = new Map<string, string>();
    for (const item of conversation?.messages ?? []) if (item.execution && item.execution.state !== 'cancelled') planMessage.set(item.execution.taskId, item.id);
    for (const item of conversation?.messages ?? []) {
      const row = element('li', '', 'conversation-message'); row.dataset.role = item.role; row.dataset.messageId = item.id;
      if (item.speaker) { row.dataset.speaker = item.speaker.role; row.dataset.speakerId = item.speaker.id; }
      row.append(element('small', `${messageAuthor(item)}${messageSource(item)} · ${formatTime(item.createdAt)}`, 'message-meta'), element('p', item.text, 'message-text'));
      if (item.replyTo) row.append(element('small', `回复：${conversation?.messages.find(message => message.id === item.replyTo)?.text.slice(0, 100) ?? item.replyTo}`, 'message-reply-to'));
      // Routing, execution receipts and the message's own actions stay one click away, so the transcript reads as a conversation.
      const details = element('details', '', 'message-details');
      details.append(element('summary', '详情'));
      row.append(details);
      const corrected = Boolean(item.effectiveTaskIds && (JSON.stringify(item.effectiveTaskIds) !== JSON.stringify(item.route.taskIds) || conversation?.messages.some(message => message.correctsMessageId === item.id)));
      if (corrected) details.append(element('small', `当前有效归属（已纠正）：${item.effectiveTaskIds!.map(conversationTaskName).join('、')}。仅影响后续消息和新执行上下文。`));
      if (item.correctsMessageId) details.append(element('small', `归属纠正记录：${item.correctsMessageId}；原始路由和已有执行记录不变。`));
      const routeLabel = item.route.status === 'clarify' ? '待澄清：未执行，请明确选择任务' : item.route.status === 'general' ? '一般讨论：已记录，未调用模型' : `${corrected ? '原始关联任务（审计）' : '关联任务'}：${item.route.taskIds.map(conversationTaskName).join('、')}`;
      details.append(element('small', `${routeLabel} · 路由：${item.route.reason} · ${item.route.focusEffect === 'switch' && item.route.status === 'routed' ? '已切换讨论焦点' : '保持讨论焦点'}`));
      if (item.execution?.state === 'cancelled') details.append(element('small', '这次执行没有创建，请重新发送。'));
      else if (item.execution) details.append(element('small', `执行请求：${item.execution.state} · ${item.execution.runId}（不代表计划已批准）`));
      else if (item.role === 'user' && item.route.status === 'routed') details.append(element('small', '已记录讨论，未调用模型。'));
      const reply = button('回复这条消息', async () => prepareConversationReply(item)); reply.type = 'button'; details.append(reply);
      if (item.role === 'user' && !item.execution && !item.correctsMessageId) {
        const correct = button('纠正归属', async () => {
          if (conversationBusy || conversationAttempt) return;
          conversationCorrectionId = item.id; conversationReplyId = undefined;
          $<HTMLSelectElement>('conversation-target').value = '';
          $<HTMLSelectElement>('conversation-focus-effect').value = 'keep';
          $<HTMLTextAreaElement>('conversation-text').value = '纠正这条讨论的任务归属';
          $('conversation-correction-label').textContent = `纠正归属：${item.text.slice(0, 160)}`;
          updateConversationControls(); openConversationRoute(); $<HTMLSelectElement>('conversation-target').focus();
        }); correct.type = 'button'; details.append(correct);
      }
      if (item.route.status === 'clarify' && !corrected) {
        for (const id of item.route.candidateTaskIds) {
          const choice = button(`选择任务：${conversationTaskName(id)}`, async () => {
            if (conversationBusy || conversationAttempt) return;
            prepareConversationReply(item); $<HTMLSelectElement>('conversation-target').value = id;
            $<HTMLTextAreaElement>('conversation-text').value = item.text; openConversationRoute(); updateConversationControls();
            $('conversation-status').textContent = '已选择任务。请检查内容，再点击“发送”交给它去做，或“只记下来”；尚未执行。';
          }); choice.type = 'button'; row.append(choice);
        }
      }
      const runId = item.notificationRunId ?? item.execution?.runId;
      if (runId) { const view = button('查看此次运行', async () => openConversationRun(runId)); view.type = 'button'; details.append(view); }
      const planTask = item.execution && planMessage.get(item.execution.taskId) === item.id ? conversation?.tasks.find(task => task.id === item.execution!.taskId) : undefined;
      if (planTask && (planTask.runId === item.execution!.runId || planTask.status === 'preparing')) {
        if (!(item.reply && planTask.status === 'succeeded')) row.append(conversationPlanCard(planTask, planDrafts.get(planTask.id)));
        const decision = conversationDecisionCard(planTask, questionDrafts.get(planTask.id));
        if (decision) row.append(decision);
      }
      if (item.reply && item.execution) row.append(conversationBotReply(item.reply, item.execution.runId, conversationTaskName(item.execution.taskId)));
      messages.append(row);
    }
    $('conversation-earlier').hidden = !conversation?.hasEarlierMessages;
    $('conversation-empty').hidden = Boolean(conversation?.messages.length);
    $('conversation-tasks-empty').hidden = Boolean(conversation?.tasks.length);
  }
  updateConversationControls();
}
function rememberLifeSummary(view: ConversationView): void {
  const index = conversationList.findIndex(item => item.id === view.id);
  if (index < 0) conversationList.unshift(view); else conversationList[index] = view;
  if (view.agentId === 'aeeis') {
    aeeisConversationId = view.id;
    localStorage.setItem(LIFE_HOME, view.id);
  }
  renderBotRoster();
}
function acceptConversation(view: ConversationView): void {
  if (conversation?.id === view.id && conversation.revision > view.revision) return;
  // A task that finishes while you watch opens its results in the workbench, unless its answer is already in the chat.
  // A first load or another conversation never does.
  const before = conversation?.id === view.id ? new Map(conversation.tasks.map(task => [task.id, task.status])) : undefined;
  const finished = before ? view.tasks.find(task => task.status === 'succeeded' && task.runId && !view.messages.some(message => message.execution?.runId === task.runId && message.reply) && before.has(task.id) && !['succeeded', 'failed', 'cancelled', 'discussion', 'unreadable'].includes(before.get(task.id)!)) : undefined;
  if (conversation?.id === view.id && conversation.revision === view.revision && conversation.messages.length > view.messages.length) {
    const ids = new Set(view.messages.map(message => message.id));
    view = { ...view, messages: [...conversation.messages.filter(message => !ids.has(message.id)), ...view.messages], ...(conversation.hasEarlierMessages === undefined ? {} : { hasEarlierMessages: conversation.hasEarlierMessages }) };
  }
  conversation = view;
  if (finished?.runId && rosterView() === 'entry') void revealFinishedRun(finished.runId).catch(() => undefined);
  rememberLifeSummary(view);
  localStorage.setItem(CONVERSATION_SELECTION, view.id); localStorage.setItem(CONVERSATION_SCOPE, conversationScope);
  renderConversation();
}
async function initializeConversations(status: RuntimeStatus): Promise<void> {
  botDialogueRouting = status.botDialogueRouting === true;
  canCreateChannels = Boolean(status.roles?.includes('owner'));
  conversationEnabled = status.conversationRouting === true && !linkedRunId && !linkedThreadId && !readOnlyShare;
  if (!conversationEnabled) { renderConversation(); return; }
  const scope = JSON.stringify([status.mode, status.tenantId ?? '', status.principal ?? '']);
  if (conversationScope && conversationScope !== scope) dialogueRoomIds.clear();
  if (conversationScope && conversationScope !== scope || localStorage.getItem(CONVERSATION_SCOPE) && localStorage.getItem(CONVERSATION_SCOPE) !== scope) resetConversation();
  conversationScope = scope;
  const epoch = conversationEpoch;
  try {
    const list = await api<ConversationSummary[]>('/conversations');
    if (epoch !== conversationEpoch) return;
    conversationList = list;
    const selectedId = conversation?.id ?? localStorage.getItem(CONVERSATION_SELECTION);
    const selected = list.find(item => item.id === selectedId) ?? list[0];
    if (selected) {
      let view = await api<ConversationView>(`/conversations/${encodeURIComponent(selected.id)}`);
      if (botDialogueRouting && (view.agentId === 'aeeis' || view.agentId?.startsWith('bot_'))) {
        const binding = await api<{ conversationId: string; roomId: string }>(`/bots/${encodeURIComponent(view.agentId)}/dialogue`, {});
        dialogueRoomIds.set(binding.conversationId, binding.roomId);
        view = await api<ConversationView>(`/conversations/${encodeURIComponent(binding.conversationId)}`);
      }
      if (epoch !== conversationEpoch) return;
      acceptConversation(view);
      rememberAeeisHome(conversationList, view);
      if (!conversationAttempt) {
        try {
          const saved = JSON.parse(sessionStorage.getItem(CONVERSATION_PENDING) ?? 'null') as ConversationAttempt | null;
          if (saved?.scope === scope && saved.conversationId === view.id && typeof saved.key === 'string' && typeof saved.body === 'string') {
            const body = JSON.parse(saved.body); conversationAttempt = saved;
            conversationCorrectionId = body.correctsMessageId; conversationReplyId = body.replyTo;
            $<HTMLTextAreaElement>('conversation-text').value = body.text ?? '';
            $<HTMLSelectElement>('conversation-target').value = body.newTask ? '__new' : body.taskIds?.[0] ?? '';
            $<HTMLInputElement>('conversation-task-title').value = body.newTask?.title ?? '';
            $<HTMLSelectElement>('conversation-focus-effect').value = body.focus ?? 'keep';
            if (conversationCorrectionId) $('conversation-correction-label').textContent = `纠正归属：${view.messages.find(item => item.id === conversationCorrectionId)?.text.slice(0, 160) ?? conversationCorrectionId}`;
            if (conversationReplyId) $('conversation-reply-label').textContent = `回复：${view.messages.find(item => item.id === conversationReplyId)?.text.slice(0, 160) ?? conversationReplyId}`;
            $('conversation-status').textContent = '已恢复尚未确认的请求。请重试原请求以确认结果。';
          }
        } catch { sessionStorage.removeItem(CONVERSATION_PENDING); }
      }
    } else {
      const view = await api<ConversationView>('/conversations', {});
      if (epoch !== conversationEpoch) return;
      acceptConversation(view);
      rememberAeeisHome(conversationList, view);
    }
    renderConversation();
  } catch (error) {
    if (epoch !== conversationEpoch) return;
    if (error instanceof ApiError && [401, 403, 404].includes(error.status)) resetConversation();
    $('conversation-error').textContent = `无法读取对话：${errorMessage(error)}。请重新连接。`; renderConversation();
  }
}
async function refreshConversation(sync = false, force = false): Promise<void> {
  if (!conversationEnabled || !conversation || conversationRefreshing || (!force && conversationBusy)) return;
  const epoch = conversationEpoch, id = conversation.id;
  conversationRefreshing = true; updateConversationControls();
  try {
    const view = await api<ConversationView>(`/conversations/${encodeURIComponent(id)}${sync ? '/notifications/sync' : ''}`, sync ? {} : undefined);
    if (epoch !== conversationEpoch || conversation?.id !== id) return;
    acceptConversation(view);
  } catch (error) {
    if (epoch !== conversationEpoch) return;
    if (error instanceof ApiError && [401, 403, 404].includes(error.status)) resetConversation();
    throw error;
  } finally { if (epoch === conversationEpoch) { conversationRefreshing = false; updateConversationControls(); } }
}
function prepareConversationReply(item: ConversationMessageView): void {
  if (conversationBusy || conversationAttempt) return;
  if (conversationCorrectionId) $<HTMLTextAreaElement>('conversation-text').value = '';
  conversationReplyId = item.id; conversationCorrectionId = undefined;
  $<HTMLSelectElement>('conversation-target').value = '';
  $<HTMLSelectElement>('conversation-focus-effect').value = 'keep';
  $('conversation-reply-label').textContent = `回复：${item.text.slice(0, 160)}`;
  updateConversationControls(); $<HTMLTextAreaElement>('conversation-text').focus();
}
async function changeConversationPriority(taskId: string, direction: 'higher' | 'lower'): Promise<void> {
  if (!conversation || conversationBusy || conversationAttempt || conversationNeedsRefresh) return;
  const epoch = conversationEpoch, id = conversation.id, focus = conversation.focusTaskId;
  conversationBusy = true; updateConversationControls();
  try {
    const view = await api<ConversationView>(`/conversations/${encodeURIComponent(id)}/tasks/${encodeURIComponent(taskId)}/priority`, { expectedRevision: conversation.revision, direction });
    if (epoch === conversationEpoch) {
      acceptConversation(view);
      $('conversation-status').textContent = '任务优先级已更新。讨论焦点和运行状态都没有改变；几个任务都能推进时，排在前面的先走一步。';
      if (conversation?.focusTaskId !== focus) $('conversation-error').textContent = '优先级更新后讨论焦点发生变化，请刷新核对。';
    }
  } catch (error) {
    if (epoch === conversationEpoch) {
      conversationNeedsRefresh = error instanceof ApiError && error.status === 409 && /刷新/.test(errorMessage(error));
      $('conversation-error').textContent = `${errorMessage(error)}${conversationNeedsRefresh ? '。请先刷新对话，再调整优先级。' : ''}`;
    }
  } finally { if (epoch === conversationEpoch) { conversationBusy = false; updateConversationControls(); } }
}
async function answerConversationTask(task: ConversationTaskView, answer: string): Promise<void> {
  const text = answer.trim();
  if (!conversation || !task.runId || !text || conversationBusy || conversationAttempt) {
    if (conversation && !text) $('conversation-error').textContent = '请先写下回答，再提交。';
    return;
  }
  const epoch = conversationEpoch, id = conversation.id, focus = conversation.focusTaskId, runId = task.runId;
  conversationBusy = true; updateConversationControls();
  try {
    await api(`/runs/${encodeURIComponent(runId)}/answer`, { answer: text });
    if (epoch !== conversationEpoch) return;
    await refreshConversation(false, true);
    if (epoch !== conversationEpoch) return;
    if (currentId === runId) await refresh();
    void refreshHandoffViews();
    if (epoch !== conversationEpoch) return;
    $('conversation-status').textContent = `已回答「${task.title}」。讨论焦点没有改变。`;
    $('conversation-error').textContent = conversation?.id === id && conversation.focusTaskId !== focus ? '回答后讨论焦点发生变化，请刷新核对。' : '';
  } catch (error) {
    if (epoch !== conversationEpoch) return;
    $('conversation-error').textContent = errorMessage(error);
    if (error instanceof ApiError && error.status === 409) await refreshConversation(false, true).catch(() => undefined);
  } finally { if (epoch === conversationEpoch) { conversationBusy = false; updateConversationControls(); } }
}
async function controlConversationRun(task: ConversationTaskView, action: 'pause' | 'resume' | 'reconcile', body: Record<string, string> = {}): Promise<void> {
  const runId = task.runId;
  if (!conversation || !runId || conversationBusy || conversationAttempt) return;
  const allowed = action === 'pause' ? ['queued', 'planning', 'running', 'reviewing'] : action === 'resume' ? ['paused'] : ['unknown', 'waiting_external'];
  if (!allowed.includes(task.status)) return;
  if (action === 'reconcile' && !body.reason?.trim()) {
    $('conversation-error').textContent = '请先写下核查说明，再提交。';
    return;
  }
  const epoch = conversationEpoch, id = conversation.id, focus = conversation.focusTaskId;
  conversationBusy = true; updateConversationControls();
  try {
    await api(`/runs/${encodeURIComponent(runId)}/${action}`, body);
    if (epoch !== conversationEpoch) return;
    await refreshConversation(false, true);
    if (epoch !== conversationEpoch) return;
    if (currentId === runId) await refresh();
    if (epoch !== conversationEpoch) return;
    const receipt = action === 'pause' ? `已暂停「${task.title}」。讨论焦点没有改变。` : action === 'resume' ? `已继续「${task.title}」。讨论焦点没有改变。` : `已核查「${task.title}」并继续这件 Run。若有一次结果未知的模型调用，会再发一遍。讨论焦点没有改变。`;
    $('conversation-status').textContent = receipt;
    $('conversation-error').textContent = conversation?.id === id && conversation.focusTaskId !== focus ? '这一步之后讨论焦点发生变化，请刷新核对。' : '';
  } catch (error) {
    if (epoch !== conversationEpoch) return;
    $('conversation-error').textContent = errorMessage(error);
    if (error instanceof ApiError && error.status === 409) await refreshConversation(false, true).catch(() => undefined);
  } finally { if (epoch === conversationEpoch) { conversationBusy = false; updateConversationControls(); } }
}
async function retryConversationTask(task: ConversationTaskView): Promise<void> {
  if (!conversation || !task.runId || task.status !== 'failed' || conversationBusy || conversationAttempt) return;
  const epoch = conversationEpoch, id = conversation.id, focus = conversation.focusTaskId, runId = task.runId;
  conversationBusy = true; updateConversationControls();
  try {
    await api(`/runs/${encodeURIComponent(runId)}/retry`, {});
    if (epoch !== conversationEpoch) return;
    await refreshConversation(false, true);
    if (epoch !== conversationEpoch) return;
    if (currentId === runId) await refresh();
    if (epoch !== conversationEpoch) return;
    $('conversation-status').textContent = `已请求重试「${task.title}」。讨论焦点没有改变。`;
    $('conversation-error').textContent = conversation?.id === id && conversation.focusTaskId !== focus ? '重试后讨论焦点发生变化，请刷新核对。' : '';
  } catch (error) {
    if (epoch !== conversationEpoch) return;
    $('conversation-error').textContent = errorMessage(error);
    if (error instanceof ApiError && error.status === 409) await refreshConversation(false, true).catch(() => undefined);
  } finally { if (epoch === conversationEpoch) { conversationBusy = false; updateConversationControls(); } }
}
async function approveConversationTask(task: ConversationTaskView, duration: 'task' | 'once' = 'task'): Promise<void> {
  if (!conversation || !task.runId || !task.pendingApproval || conversationBusy || conversationAttempt) return;
  const epoch = conversationEpoch, id = conversation.id, focus = conversation.focusTaskId, runId = task.runId;
  conversationBusy = true; updateConversationControls();
  try {
    await api(`/runs/${encodeURIComponent(runId)}/approve`, { planHash: task.pendingApproval.planHash, planVersion: task.pendingApproval.planVersion, ...(duration === 'once' ? { duration: 'once' } : {}) });
    if (epoch !== conversationEpoch) return;
    await refreshConversation(false, true);
    if (epoch !== conversationEpoch) return;
    if (currentId === runId) await refresh();
    void refreshHandoffViews();
    if (epoch !== conversationEpoch) return;
    $('conversation-status').textContent = duration === 'once'
      ? `已批准「${task.title}」的当前计划并开始执行。这次批准记录标为仅这一次，以后的计划仍要再批。讨论焦点没有改变。`
      : `已批准「${task.title}」的当前计划并开始执行。讨论焦点没有改变。`;
    $('conversation-error').textContent = conversation?.id === id && conversation.focusTaskId !== focus ? '批准后讨论焦点发生变化，请刷新核对。' : '';
  } catch (error) {
    if (epoch !== conversationEpoch) return;
    $('conversation-error').textContent = errorMessage(error);
    if (error instanceof ApiError && error.status === 409) await refreshConversation(false, true).catch(() => undefined);
  } finally { if (epoch === conversationEpoch) { conversationBusy = false; updateConversationControls(); } }
}
async function rejectConversationTask(task: ConversationTaskView, feedback: string): Promise<void> {
  const text = feedback.trim();
  if (!conversation || !task.runId || !task.pendingApproval || conversationBusy || conversationAttempt) return;
  if (!text) { $('conversation-error').textContent = '请先写下拒绝原因，再提交。'; return; }
  const epoch = conversationEpoch, id = conversation.id, focus = conversation.focusTaskId, runId = task.runId;
  conversationBusy = true; updateConversationControls();
  try {
    await api(`/runs/${encodeURIComponent(runId)}/revise-plan`, { planVersion: task.pendingApproval.planVersion, feedback: text });
    if (epoch !== conversationEpoch) return;
    await refreshConversation(false, true);
    if (epoch !== conversationEpoch) return;
    if (currentId === runId) await refresh();
    void refreshHandoffViews();
    if (epoch !== conversationEpoch) return;
    $('conversation-status').textContent = `已拒绝「${task.title}」的当前计划，并请它重新规划。讨论焦点没有改变。`;
    $('conversation-error').textContent = conversation?.id === id && conversation.focusTaskId !== focus ? '拒绝后讨论焦点发生变化，请刷新核对。' : '';
  } catch (error) {
    if (epoch !== conversationEpoch) return;
    $('conversation-error').textContent = errorMessage(error);
    if (error instanceof ApiError && error.status === 409) await refreshConversation(false, true).catch(() => undefined);
  } finally { if (epoch === conversationEpoch) { conversationBusy = false; updateConversationControls(); } }
}
async function changeConversationFocus(taskId: string | null): Promise<void> {
  if (!conversation || conversationBusy || conversationAttempt) return;
  const epoch = conversationEpoch, id = conversation.id;
  conversationBusy = true; updateConversationControls();
  try {
    const view = await api<ConversationView>(`/conversations/${encodeURIComponent(id)}/focus`, { taskId, expectedRevision: conversation.revision });
    if (epoch === conversationEpoch) { acceptConversation(view); $('conversation-status').textContent = '讨论焦点已更新；没有启动或切换运行。'; }
  } catch (error) { if (epoch === conversationEpoch) { conversationNeedsRefresh = error instanceof ApiError && error.status === 409; $('conversation-error').textContent = `${errorMessage(error)}${conversationNeedsRefresh ? '。请先刷新对话，再明确选择焦点。' : ''}`; } }
  finally { if (epoch === conversationEpoch) { conversationBusy = false; updateConversationControls(); } }
}
let openMemoryForRunId = '';
async function openConversationMemory(runId: string): Promise<void> {
  openMemoryForRunId = runId;
  await openConversationRun(runId);
}
/** Loads a finished Run into the workbench and opens it, without scrolling or moving keyboard focus. */
async function revealFinishedRun(runId: string): Promise<void> {
  const epoch = conversationEpoch;
  const run = await api<RunView>(`/runs/${encodeURIComponent(runId)}`);
  const [graphs, explanation] = await Promise.all([api<RunGraphsView>(`/runs/${encodeURIComponent(runId)}/graphs`), api<RunExplanation>(`/runs/${encodeURIComponent(runId)}/explanation`)]);
  if (epoch !== conversationEpoch || rosterView() !== 'entry') return;
  currentId = runId; current = { ...run, graphs }; localStorage.setItem('aeeis.run', runId);
  setCurrentRunOpen(true); render(current); renderExplanation(explanation);
  // Open the run pane for now only; setRunDetailsMode would also remember it for every later visit.
  runDetailsMode = true; document.body.classList.add('run-details-mode'); syncRunDetailsToggleLabel();
  setComputerOpen(true, 'run');
}
async function openConversationRun(runId: string): Promise<void> {
  const epoch = conversationEpoch;
  const run = await api<RunView>(`/runs/${encodeURIComponent(runId)}`);
  const [graphs, explanation] = await Promise.all([api<RunGraphsView>(`/runs/${encodeURIComponent(runId)}/graphs`), api<RunExplanation>(`/runs/${encodeURIComponent(runId)}/explanation`)]);
  if (epoch !== conversationEpoch) return;
  currentId = runId; current = { ...run, graphs }; localStorage.setItem('aeeis.run', runId);
  setCurrentRunOpen(true); render(current); renderExplanation(explanation);
  if (!['succeeded', 'failed', 'cancelled'].includes(run.status)) ensureRunEventStream(run.id);
  $('run-workspace').scrollIntoView({ behavior: 'smooth', block: 'start' });
  $('run-title').focus({ preventScroll: true });
}
async function acceptPractice(text: string): Promise<void> {
  const surface = rosterView();
  if (surface !== 'entry' && surface !== 'bot') return;
  const delivery = conversation?.lastDelivery;
  if (!conversation || !delivery || conversationBusy || conversationAttempt) return;
  const trimmed = text.trim();
  if (!trimmed) {
    $('conversation-error').textContent = '先写下这句做法。';
    return;
  }
  if (trimmed.length > 500) {
    $('conversation-error').textContent = '这句话最多 500 字。';
    return;
  }
  const epoch = conversationEpoch;
  const id = conversation.id;
  conversationBusy = true;
  updateConversationControls();
  try {
    const view = await api<ConversationView>(`/conversations/${encodeURIComponent(id)}/practice`, { expectedRevision: conversation.revision, text: trimmed, runId: delivery.runId });
    if (epoch !== conversationEpoch || !view || view.id !== id) return;
    acceptConversation(view);
    $('conversation-status').textContent = '已收下这句做法。讨论不会改它。下一次明确创建 Run 时，会作为不可信材料带进去。';
    $('conversation-error').textContent = '';
    conversationNeedsRefresh = false;
  } catch (error) {
    if (epoch !== conversationEpoch) return;
    conversationNeedsRefresh = error instanceof ApiError && error.status === 409;
    $('conversation-error').textContent = `${errorMessage(error)}${conversationNeedsRefresh ? '。请先刷新，再收下这句。' : ''}`;
  } finally {
    if (epoch === conversationEpoch) { conversationBusy = false; updateConversationControls(); }
  }
}
async function retractPractice(): Promise<void> {
  const surface = rosterView();
  if (surface !== 'entry' && surface !== 'bot') return;
  const practice = conversation?.acceptedPractice;
  if (!conversation || !practice || conversationBusy || conversationAttempt) return;
  const epoch = conversationEpoch;
  const id = conversation.id;
  conversationBusy = true;
  updateConversationControls();
  try {
    const view = await api<ConversationView>(`/conversations/${encodeURIComponent(id)}/practice/retract`, { expectedRevision: conversation.revision, claimId: practice.claimId });
    if (epoch !== conversationEpoch || !view || view.id !== id) return;
    acceptConversation(view);
    $('conversation-status').textContent = '已撤回这句做法。之后的 Run 不再带上它。';
    $('conversation-error').textContent = '';
    conversationNeedsRefresh = false;
  } catch (error) {
    if (epoch !== conversationEpoch) return;
    conversationNeedsRefresh = error instanceof ApiError && error.status === 409;
    $('conversation-error').textContent = `${errorMessage(error)}${conversationNeedsRefresh ? '。请先刷新，再撤回这句。' : ''}`;
  } finally {
    if (epoch === conversationEpoch) { conversationBusy = false; updateConversationControls(); }
  }
}
async function postTaskSetting(path: string, body: Record<string, unknown>, success: string, refreshHint: string): Promise<void> {
  const surface = rosterView();
  if (surface !== 'entry' && surface !== 'bot') return;
  if (!conversation || conversationBusy || conversationAttempt) return;
  const epoch = conversationEpoch;
  const id = conversation.id;
  conversationBusy = true;
  updateConversationControls();
  try {
    const view = await api<ConversationView>(`/conversations/${encodeURIComponent(id)}/${path}`, { expectedRevision: conversation.revision, ...body });
    if (epoch !== conversationEpoch || !view || view.id !== id) return;
    taskModelBound = '';
    acceptConversation(view);
    $('conversation-status').textContent = success;
    $('conversation-error').textContent = '';
    conversationNeedsRefresh = false;
  } catch (error) {
    if (epoch !== conversationEpoch) return;
    conversationNeedsRefresh = error instanceof ApiError && error.status === 409;
    $('conversation-error').textContent = `${errorMessage(error)}${conversationNeedsRefresh ? `。${refreshHint}` : ''}`;
  } finally {
    if (epoch === conversationEpoch) { conversationBusy = false; updateConversationControls(); }
  }
}
async function saveTaskModel(): Promise<void> {
  const taskKind = currentTaskKind();
  if (!taskKind) {
    $('conversation-error').textContent = '先写任务种类。';
    return;
  }
  const model = $<HTMLInputElement>('task-model').value.trim();
  const provider = $<HTMLInputElement>('task-model-provider').value.trim();
  if (!model) {
    $('conversation-error').textContent = '先写下这种任务要用的模型，或改回默认。';
    return;
  }
  await postTaskSetting('task-model', { taskKind, model, ...(provider ? { provider } : {}) }, '已记下这个任务种类的模型。讨论不会改它。下一次明确创建这种任务的 Run 时，会冻进那次模型决定。', '请先刷新，再改这个模型。');
}
async function clearTaskModel(): Promise<void> {
  const taskKind = currentTaskKind();
  if (!taskKind) return;
  await postTaskSetting('task-model', { taskKind }, '已改回默认。这个任务种类不再指定模型。', '请先刷新，再改这个模型。');
}
async function promoteSkillProfile(): Promise<void> {
  const taskKind = currentTaskKind();
  const runId = promotionRunId();
  if (!taskKind) {
    $('conversation-error').textContent = '先写任务种类。';
    return;
  }
  if (!runId) return;
  await postTaskSetting('skill-profile', { taskKind, runId }, '已晋升这次技能。讨论不会改它。下一次明确创建这种任务的 Run 时，会作为不可信材料带进去。', '请先刷新，再晋升。');
}
async function keepTaskProfile(): Promise<void> {
  const taskKind = currentTaskKind();
  if (!taskKind) return;
  await postTaskSetting('task-kind/keep', { taskKind }, '已留下这份档案。这次做成不会替换它。讨论不会改它。', '请先刷新，再留下这份档案。');
}
async function proposeTaskKind(): Promise<void> {
  const taskKind = currentTaskKind();
  if (!taskKind) return;
  await postTaskSetting('task-kind/propose', { taskKind }, '已送去评测。这次只建立了 proposed 候选。后面还有评估、批准和晋升。', '请先刷新，再送去评测。');
}
async function rollbackSkillProfile(): Promise<void> {
  const taskKind = currentTaskKind();
  const reason = $<HTMLInputElement>('skill-rollback-reason').value.trim();
  if (!taskKind) return;
  if (!reason) {
    $('conversation-error').textContent = '先写下回滚原因。';
    return;
  }
  await postTaskSetting('skill-profile/rollback', { taskKind, reason }, '已回滚到上一版技能。之后这种任务带上的是上一版。', '请先刷新，再回滚。');
}
async function retractSkillProfile(): Promise<void> {
  const taskKind = currentTaskKind();
  const skill = conversation?.taskSettings?.skills.find(item => item.taskKind === taskKind);
  if (!taskKind || !skill) return;
  await postTaskSetting('skill-profile/retract', { taskKind, claimId: skill.claimId }, '已撤回这份技能档案。之后这种任务不再带上它。', '请先刷新，再撤回这份档案。');
}
async function saveStandingInstruction(text: string): Promise<void> {
  const surface = rosterView();
  if (surface !== 'entry' && surface !== 'bot') return;
  if (!conversation || conversationBusy || conversationAttempt) return;
  const trimmed = text.trim();
  if (trimmed.length > 500) {
    $('conversation-error').textContent = '这句话最多 500 字。';
    return;
  }
  const epoch = conversationEpoch;
  const id = conversation.id;
  conversationBusy = true;
  updateConversationControls();
  try {
    const view = await api<ConversationView>(`/conversations/${encodeURIComponent(id)}/standing`, { expectedRevision: conversation.revision, text: trimmed });
    if (epoch !== conversationEpoch || !view || view.id !== id) return;
    acceptConversation(view);
    const field = $<HTMLTextAreaElement>('standing-text');
    if (field) field.value = view.standingInstruction ?? '';
    standingBoundId = view.id;
    $('conversation-status').textContent = trimmed ? '已记住这句话。讨论不会改它。下一次明确创建 Run 时，它会作为不可信材料带进去。' : '已忘掉这句话。之后的 Run 不再带上它。';
    $('conversation-error').textContent = '';
    conversationNeedsRefresh = false;
  } catch (error) {
    if (epoch !== conversationEpoch) return;
    conversationNeedsRefresh = error instanceof ApiError && error.status === 409;
    $('conversation-error').textContent = `${errorMessage(error)}${conversationNeedsRefresh ? '。请先刷新，再改这句话。' : ''}`;
  } finally {
    if (epoch === conversationEpoch) { conversationBusy = false; updateConversationControls(); }
  }
}
async function sendConversation(intent: 'discuss' | 'execute', retry = false): Promise<void> {
  const surface = rosterView();
  if (surface !== 'entry' && surface !== 'bot') return;
  if (!conversation || conversationBusy || (!retry && (conversationAttempt || conversationNeedsRefresh))) return;
  if (!retry) {
    const form = $<HTMLFormElement>('conversation-composer');
    if (!form.reportValidity()) return;
    if (intent === 'execute' && conversationSendIntent() !== 'execute') return;
    const target = $<HTMLSelectElement>('conversation-target').value;
    if (conversationCorrectionId && (intent !== 'discuss' || !conversation.tasks.some(task => task.id === target))) return;
    const lifeSpeaker = selectedLifeSpeaker();
    const text = $<HTMLTextAreaElement>('conversation-text').value.trim();
    // A send that names no task starts a new one and makes it the focus, so the next message (a change to the plan, a follow-up) lands on it.
    const autoTitle = intent === 'execute' && !target && !conversationReplyId && !conversation.focusTaskId ? autoTaskTitle(text) : '';
    if (intent === 'execute' && !target && !conversationReplyId && !conversation.focusTaskId && autoTitle.length < 2) intent = 'discuss';
    const body = conversationCorrectionId
      ? { text: '纠正这条讨论的任务归属', expectedRevision: conversation.revision, taskIds: [target], correctsMessageId: conversationCorrectionId, intent: 'discuss', focus: 'keep' }
      : { text, expectedRevision: conversation.revision,
        ...(lifeSpeaker ? { speaker: lifeSpeaker } : {}),
        ...(target === '__new' ? { newTask: { title: $<HTMLInputElement>('conversation-task-title').value.trim() } } : autoTitle.length >= 2 && intent === 'execute' ? { newTask: { title: autoTitle } } : { ...(target ? { taskIds: [target] } : intent === 'execute' && !conversationReplyId && conversation.focusTaskId ? { taskIds: [conversation.focusTaskId] } : {}), ...(conversationReplyId ? { replyTo: conversationReplyId } : {}) }),
        focus: autoTitle.length >= 2 && intent === 'execute' ? 'switch' : $<HTMLSelectElement>('conversation-focus-effect').value, intent, ...(intent === 'execute' ? { ...(currentTaskKind() ? { taskKind: currentTaskKind() } : {}), runOptions: runOptions(true, conversationExecutionGoal()) } : {}) };
    if (!body.text) return;
    conversationAttempt = { conversationId: conversation.id, scope: conversationScope, key: crypto.randomUUID(), body: JSON.stringify(body) };
    saveConversationAttempt();
  }
  const attempt = conversationAttempt;
  if (!attempt) return;
  const epoch = conversationEpoch;
  conversationBusy = true; $('conversation-error').textContent = ''; $('conversation-status').textContent = '正在发送…'; updateConversationControls();
  try {
    const result = await api<ConversationPost>(`/conversations/${encodeURIComponent(attempt.conversationId)}/messages`, JSON.parse(attempt.body), 'POST', attempt.key);
    if (epoch !== conversationEpoch) return;
    if (!result.conversation || result.conversation.id !== attempt.conversationId || !Array.isArray(result.conversation.messages) || !result.message || typeof result.response !== 'string') throw new Error('服务端回执不完整');
    conversationAttempt = undefined; saveConversationAttempt(); conversationReplyId = undefined; conversationCorrectionId = undefined;
    $<HTMLFormElement>('conversation-composer').reset();
    acceptConversation(result.conversation);
    $('conversation-status').textContent = `系统回执：${result.response}`;
    // A Run is only opened on a separate explicit view action. Receiving a notification never steals focus.
  } catch (error) {
    if (epoch !== conversationEpoch) return;
    if (error instanceof ApiError && error.status >= 400 && error.status < 500 && !error.retrySameRequest) {
      conversationAttempt = undefined; saveConversationAttempt();
      conversationNeedsRefresh = error.status === 409;
      if ([401, 403].includes(error.status)) { resetConversation(); $('conversation-status').textContent = '身份或权限已变化，请重新连接。'; }
    }
    $('conversation-error').textContent = `${errorMessage(error)}${conversationNeedsRefresh ? '。请点击“刷新对话”，核对焦点后再明确发送；不会自动执行。' : conversationAttempt ? '。结果尚未确认，请重试原请求。' : ''}`;
    $('conversation-status').textContent = '';
  } finally { if (epoch === conversationEpoch) { conversationBusy = false; updateConversationControls(); } }
}
$('conversation-text').addEventListener('keydown', event => {
  if (event.key !== 'Enter' || event.shiftKey || event.altKey || event.ctrlKey || event.metaKey || event.isComposing || event.keyCode === 229) return;
  event.preventDefault();
  if (!$<HTMLButtonElement>('conversation-send').disabled) $<HTMLFormElement>('conversation-composer').requestSubmit();
});
$('conversation-composer').addEventListener('submit', event => { event.preventDefault(); void sendConversation(conversationSendIntent()).catch(error => { $('conversation-error').textContent = errorMessage(error); }); });
for (const id of ['execution-review', 'model-budget-usd', 'model-budget-tokens', 'allowed-tools', 'privacy']) {
  $(id)?.addEventListener('input', () => syncEntryDefaults());
  $(id)?.addEventListener('change', () => syncEntryDefaults());
}
$('entry-defaults-edit')?.addEventListener('click', () => {
  setDetailsMode(true, { reveal: true });
  window.requestAnimationFrame(() => $('run-options')?.scrollIntoView({ behavior: 'smooth', block: 'start' }));
});
$('conversation-note').addEventListener('click', () => { void sendConversation('discuss').catch(error => { $('conversation-error').textContent = errorMessage(error); }); });
$('routine-form')?.addEventListener('submit', event => {
  event.preventDefault();
  $('routine-error').textContent = '';
  const add = $<HTMLButtonElement>('routine-add');
  add.disabled = true;
  void addRoutine().catch(error => { $('routine-error').textContent = errorMessage(error); }).finally(() => { add.disabled = false; });
});
$('routine-kind')?.addEventListener('change', () => renderRoutines());
$('standing-form')?.addEventListener('submit', event => {
  event.preventDefault();
  void saveStandingInstruction($<HTMLTextAreaElement>('standing-text').value).catch(error => { $('conversation-error').textContent = errorMessage(error); });
});
$('standing-clear')?.addEventListener('click', () => {
  void saveStandingInstruction('').catch(error => { $('conversation-error').textContent = errorMessage(error); });
});
$('last-delivery-pin')?.addEventListener('click', () => pinLastDelivery());
$('practice-accept')?.addEventListener('click', () => {
  void acceptPractice($<HTMLTextAreaElement>('practice-text').value).catch(error => { $('conversation-error').textContent = errorMessage(error); });
});
$('task-kind')?.addEventListener('change', () => { taskModelBound = ''; syncTaskSettings(); });
$('task-kind')?.addEventListener('input', () => { taskModelBound = ''; syncTaskSettings(); });
$('task-model-save')?.addEventListener('click', () => { void saveTaskModel().catch(error => { $('conversation-error').textContent = errorMessage(error); }); });
$('task-model-clear')?.addEventListener('click', () => { void clearTaskModel().catch(error => { $('conversation-error').textContent = errorMessage(error); }); });
$('skill-promote')?.addEventListener('click', () => { void promoteSkillProfile().catch(error => { $('conversation-error').textContent = errorMessage(error); }); });
$('task-kind-keep')?.addEventListener('click', () => { void keepTaskProfile().catch(error => { $('conversation-error').textContent = errorMessage(error); }); });
$('task-kind-propose')?.addEventListener('click', () => { void proposeTaskKind().catch(error => { $('conversation-error').textContent = errorMessage(error); }); });
$('skill-rollback')?.addEventListener('click', () => { void rollbackSkillProfile().catch(error => { $('conversation-error').textContent = errorMessage(error); }); });
$('skill-retract')?.addEventListener('click', () => { void retractSkillProfile().catch(error => { $('conversation-error').textContent = errorMessage(error); }); });
$('accepted-practice-retract')?.addEventListener('click', () => {
  void retractPractice().catch(error => { $('conversation-error').textContent = errorMessage(error); });
});
$('execution-review')?.addEventListener('change', () => {
  localStorage.setItem('aeeis.execution-review', selectedWorkGrant() ? `grant:${selectedWorkGrant()!.grantId}` : executionReviewValue());
  updateConversationControls();
});
for (const id of ['conversation-text', 'conversation-task-title', 'allowed-tools', 'allowed-agents', 'builtin-skill', 'external-budget-calls', 'external-budget-tokens', 'external-budget-usd']) {
  $(id)?.addEventListener('input', () => updateConversationControls());
  $(id)?.addEventListener('change', () => updateConversationControls());
}
$('conversation-retry').addEventListener('click', () => { void sendConversation('discuss', true).catch(error => { $('conversation-error').textContent = errorMessage(error); }); });
$('conversation-target').addEventListener('change', () => {
  if ($<HTMLSelectElement>('conversation-target').value === '__new') { conversationReplyId = undefined; openConversationRoute(); }
  updateConversationControls();
});
$('conversation-cancel-correction').addEventListener('click', () => {
  if (conversationBusy || conversationAttempt) return;
  conversationCorrectionId = undefined; $<HTMLTextAreaElement>('conversation-text').value = ''; updateConversationControls();
});
$('conversation-cancel-reply').addEventListener('click', () => { conversationReplyId = undefined; updateConversationControls(); });
$('conversation-clear-focus').addEventListener('click', () => { void changeConversationFocus(null); });
for (const [id, sync] of [['conversation-refresh', false], ['conversation-sync', true]] as const) {
  $(id).addEventListener('click', () => {
    void refreshConversation(sync).then(() => {
      conversationNeedsRefresh = false; $('conversation-error').textContent = '';
      $('conversation-status').textContent = sync ? '任务通知已同步；讨论焦点由服务端保留。' : '已刷新。请核对讨论焦点和任务，再明确发送。'; updateConversationControls();
    }).catch(error => { $('conversation-error').textContent = errorMessage(error); });
  });
}
$('conversation-select').addEventListener('change', async () => {
  if (conversationBusy || conversationAttempt) return;
  const id = $<HTMLSelectElement>('conversation-select').value, epoch = ++conversationEpoch;
  conversationBusy = true; updateConversationControls();
  try {
    const view = await api<ConversationView>(`/conversations/${encodeURIComponent(id)}`);
    if (epoch !== conversationEpoch) return;
    conversation = undefined; conversationReplyId = undefined; conversationCorrectionId = undefined; conversationNeedsRefresh = false;
    $<HTMLFormElement>('conversation-composer').reset(); $('conversation-status').textContent = ''; $('conversation-error').textContent = ''; acceptConversation(view);
  } catch (error) { if (epoch === conversationEpoch) $('conversation-error').textContent = errorMessage(error); }
  finally { if (epoch === conversationEpoch) { conversationBusy = false; renderConversation(); } }
});
$('conversation-new').addEventListener('click', async () => {
  if (!conversationEnabled || conversationBusy || conversationAttempt) return;
  const epoch = conversationEpoch; conversationBusy = true; updateConversationControls();
  try {
    const view = await api<ConversationView>('/conversations', {});
    if (epoch !== conversationEpoch) return;
    conversationReplyId = undefined; conversationCorrectionId = undefined; conversationNeedsRefresh = false; $<HTMLFormElement>('conversation-composer').reset();
    $('conversation-status').textContent = '新对话已建立。'; $('conversation-error').textContent = ''; acceptConversation(view);
  } catch (error) { if (epoch === conversationEpoch) $('conversation-error').textContent = errorMessage(error); }
  finally { if (epoch === conversationEpoch) { conversationBusy = false; updateConversationControls(); } }
});
$('bots')?.addEventListener('click', event => {
  const target = (event.target as HTMLElement | null)?.closest('button');
  if (!target || !$('bots')?.contains(target)) return;
  if (target.dataset.botId) selectBot(target.dataset.botId);
  else if (target.dataset.roomId) void openGroup(target.dataset.roomId).catch(error => message(errorMessage(error)));
  else if (target.dataset.groupId) renameBotGroup(target.dataset.groupId);
});
$('bot-group-draft')?.addEventListener('submit', createBotGroup);
$('gb-new-bot-group')?.addEventListener('click', () => {
  const draft = $('bot-group-draft');
  if (!draft) return;
  draft.hidden = !draft.hidden;
  if (!draft.hidden) $<HTMLInputElement>('bot-group-name')?.focus();
});
let botCreateMark: BotMark = 'letter';
let botCreateColor = BOT_COLORS[0]!;
let botEditId = '';
let botCreateTicket = 0;
let botCreateBusy = false;
function paintBotCreate(): void {
  const preview = $('bot-create-preview');
  const name = $<HTMLInputElement>('bot-create-name')?.value.trim() ?? '';
  if (preview) {
    preview.dataset.mark = botCreateMark;
    preview.style.background = botCreateColor;
    preview.textContent = botCreateMark === 'letter' ? (name.slice(0, 1) || 'B') : '';
  }
  document.querySelectorAll<HTMLButtonElement>('#bot-create-marks button').forEach(button => {
    button.setAttribute('aria-pressed', String(button.dataset.mark === botCreateMark));
  });
  document.querySelectorAll<HTMLButtonElement>('#bot-create-colors button').forEach(button => {
    button.setAttribute('aria-pressed', String(button.dataset.color === botCreateColor));
  });
}
function renderBotCreateChoices(): void {
  const marks = $('bot-create-marks');
  const colors = $('bot-create-colors');
  if (!marks || !colors || marks.childElementCount) return;
  for (const mark of BOT_MARKS) {
    const button = document.createElement('button');
    button.type = 'button';
    button.dataset.mark = mark;
    button.className = 'roster-avatar';
    button.style.background = BOT_COLORS[0]!;
    button.textContent = mark === 'letter' ? '名' : '';
    button.setAttribute('aria-label', BOT_MARK_LABEL[mark]);
    button.addEventListener('click', () => { botCreateMark = mark; paintBotCreate(); });
    marks.append(button);
  }
  for (const color of BOT_COLORS) {
    const button = document.createElement('button');
    button.type = 'button';
    button.dataset.color = color;
    button.style.background = color;
    button.setAttribute('aria-label', color);
    button.addEventListener('click', () => { botCreateColor = color; paintBotCreate(); });
    colors.append(button);
  }
}
function botCreateStatus(text: string): void {
  const status = $('bot-create-status');
  if (status) status.textContent = text;
}
function setBotCreatePending(pending: boolean): void {
  botCreateBusy = pending;
  const generate = $<HTMLButtonElement>('bot-create-generate');
  const save = $<HTMLButtonElement>('bot-create-save');
  if (generate) generate.disabled = pending;
  if (save) save.disabled = pending;
}
function openBotCreate(): void {
  const panel = $('bot-create');
  if (!panel) return;
  botEditId = '';
  botCreateTicket += 1;
  setBotCreatePending(false);
  renderBotCreateChoices();
  botCreateMark = 'letter';
  botCreateColor = BOT_COLORS[0]!;
  $<HTMLFormElement>('bot-create-form')?.reset();
  botCreateStatus('');
  panel.hidden = false;
  paintBotCreate();
  $<HTMLInputElement>('bot-create-name')?.focus();
}
function closeBotCreate(): void {
  botEditId = '';
  botCreateTicket += 1;
  setBotCreatePending(false);
  const panel = $('bot-create');
  if (panel) panel.hidden = true;
}
function openBotEdit(bot: RosterBot): void {
  const panel = $('bot-create');
  if (!panel) return;
  botEditId = bot.id;
  botCreateTicket += 1;
  setBotCreatePending(false);
  renderBotCreateChoices();
  botCreateMark = bot.mark ?? 'letter';
  botCreateColor = bot.color ?? BOT_COLORS[0]!;
  $<HTMLFormElement>('bot-create-form')?.reset();
  const name = $<HTMLInputElement>('bot-create-name');
  const role = $<HTMLInputElement>('bot-create-role');
  const background = $<HTMLTextAreaElement>('bot-create-background');
  if (name) name.value = bot.name;
  if (role) role.value = bot.role ?? '';
  if (background) background.value = bot.background ?? '';
  botCreateStatus('');
  panel.hidden = false;
  paintBotCreate();
  name?.focus();
}
async function removeOwnedBot(id: string): Promise<void> {
  const bot = ownedBotRecords.find(item => item.id === id);
  if (!bot) return;
  if (!window.confirm(`移除${bot.name}。这位会从房间里撤下，名额空出来。这个编号留下。还要人处理的事会交给 AEEIS。`)) return;
  await api(`/bots/${encodeURIComponent(id)}`, undefined, 'DELETE');
  ownedBotRecords = ownedBotRecords.filter(item => item.id !== id);
  if (selectedBotId === id) { selectedBotId = 'aeeis'; localStorage.setItem('aeeis.bot', 'aeeis'); }
  renderBotRoster();
  selectBot('aeeis');
}
function sameBotName(left: string, right: string): boolean {
  return left.localeCompare(right, 'zh', { sensitivity: 'accent' }) === 0;
}
function backgroundFailure(error: unknown): string {
  const text = errorMessage(error);
  return text === '模型尚未就绪' ? '模型尚未就绪。可以自己写背景。' : text;
}
async function generatedBackground(role: string): Promise<string> {
  if (!modelConfigured) throw new Error('模型尚未就绪。可以自己写背景。');
  const drafted = await api<{ background?: string }>('/bots/background', { role }, 'POST', `bot-background-${globalThis.crypto?.randomUUID?.() ?? Date.now().toString(36)}`);
  const background = drafted.background?.trim().slice(0, 800) ?? '';
  if (!background) throw new Error('背景没有生成');
  return background;
}
async function saveCreatedBot(event: Event): Promise<void> {
  event.preventDefault();
  if (botCreateBusy) return;
  const name = $<HTMLInputElement>('bot-create-name')?.value.trim().slice(0, 40) ?? '';
  const role = $<HTMLInputElement>('bot-create-role')?.value.trim().slice(0, 120) ?? '';
  const background = $<HTMLTextAreaElement>('bot-create-background')?.value.trim().slice(0, 800) ?? '';
  if (!name) { botCreateStatus('先写下名字。'); $<HTMLInputElement>('bot-create-name')?.focus(); return; }
  if (reservedBotName(name)) { botCreateStatus('请换一个名字。所有人、团队和 AEEIS 留给群里的点名。'); return; }
  if (rosterBots().some(bot => bot.id !== botEditId && sameBotName(bot.name, name))) { botCreateStatus('这个名字已经在名单上。'); return; }
  if (!botEditId && ownedBotRecords.length >= CUSTOM_BOT_CAP) { botCreateStatus(`这个账号最多留下 ${CUSTOM_BOT_CAP} 位。`); return; }
  if (!background) { botCreateStatus('先写下背景，或给出角色定位再生成。'); $<HTMLTextAreaElement>('bot-create-background')?.focus(); return; }
  setBotCreatePending(true);
  botCreateStatus('正在保存。');
  const editing = botEditId;
  try {
    const saved = editing
      ? await api<OwnedBotView>(`/bots/${encodeURIComponent(editing)}`, { name, mark: botCreateMark, color: botCreateColor, background, ...(role ? { role } : {}) }, 'PATCH')
      : await api<OwnedBotView>('/bots', { name, mark: botCreateMark, color: botCreateColor, background, ...(role ? { role } : {}) });
    rememberOwnedBot(saved);
    closeBotCreate();
    renderBotRoster();
    selectBot(saved.id);
  } catch (error) {
    setBotCreatePending(false);
    botCreateStatus(errorMessage(error));
  }
}
async function generateBotBackground(): Promise<void> {
  if (botCreateBusy) return;
  const role = $<HTMLInputElement>('bot-create-role')?.value.trim() ?? '';
  if (!role) { botCreateStatus('先写下角色定位。'); $<HTMLInputElement>('bot-create-role')?.focus(); return; }
  const ticket = ++botCreateTicket;
  setBotCreatePending(true);
  botCreateStatus('正在生成背景。');
  try {
    const background = await generatedBackground(role);
    if (ticket !== botCreateTicket || $('bot-create')?.hidden) return;
    const field = $<HTMLTextAreaElement>('bot-create-background');
    if (field) field.value = background;
    botCreateStatus('背景已生成。看过之后再保存。');
  } catch (error) {
    if (ticket !== botCreateTicket || $('bot-create')?.hidden) return;
    botCreateStatus(backgroundFailure(error));
  } finally {
    if (ticket === botCreateTicket) setBotCreatePending(false);
  }
}
$('gb-new-bot')?.addEventListener('click', () => openBotCreate());
$('bot-local-claim')?.addEventListener('click', () => { void claimLocalBots().catch(error => { localBotNote = errorMessage(error); renderLocalBotNote(); }); });
$('bot-profile-edit')?.addEventListener('click', () => { const bot = botById(activeBotId()); if (bot) openBotEdit(bot); });
$('bot-autonomy')?.addEventListener('change', () => { void saveBotAutonomy().catch(error => message(errorMessage(error))); });
$('bot-side-threads')?.addEventListener('toggle', () => { if ($<HTMLDetailsElement>('bot-side-threads')?.open) void loadBotSideThreads().catch(error => message(errorMessage(error))); });
$('bot-profile-remove')?.addEventListener('click', () => { void removeOwnedBot(activeBotId()).catch(error => message(errorMessage(error))); });
$('bot-create-cancel')?.addEventListener('click', () => closeBotCreate());
$('bot-create-generate')?.addEventListener('click', () => { void generateBotBackground(); });
$('bot-create-name')?.addEventListener('input', () => paintBotCreate());
$('bot-create-form')?.addEventListener('submit', event => { void saveCreatedBot(event).catch(error => botCreateStatus(backgroundFailure(error))); });
$('gb-new-group')?.addEventListener('click', () => showGroupDraft());
$('group-add-person')?.addEventListener('click', () => addDraftPerson());
$('group-reuse')?.addEventListener('click', () => reuseRoster());
$('group-cap')?.addEventListener('input', () => commitGroupCap(false));
$('group-cap')?.addEventListener('change', () => commitGroupCap(true));
$('group-newcomer-reason')?.addEventListener('input', () => {
  const proposal = $('group-proposal');
  if (proposal) proposal.textContent = groupProposalText();
});
$('group-create')?.addEventListener('submit', event => { void createGroup(event).catch(error => message(errorMessage(error))); });
$('group-composer')?.addEventListener('submit', event => { void submitGroupMessage(event).catch(error => message(errorMessage(error))); });
$('channel-artifact-close')?.addEventListener('click', () => hideChannelArtifact());
const MEMORY_KIND_LABEL: Record<string, string> = { fact: '事实', preference: '偏好', decision: '决定', note: '备注' };
async function listedChannelGoal(): Promise<GoalSummary | undefined> {
  const roomId = openGroupId;
  if (!roomId) return;
  const listed = await api<GoalSummary[] | { goals?: GoalSummary[] }>(`/rooms/${encodeURIComponent(roomId)}/goals`);
  const goals = Array.isArray(listed) ? listed : (listed.goals ?? []);
  return goals.find(item => item.status === 'active') ?? goals[0];
}
async function channelGoal(): Promise<GoalSummary | undefined> {
  const existing = await listedChannelGoal();
  if (existing || !openGroupId) return existing;
  const roomId = openGroupId;
  const room = roomSummaries.find(item => item.id === roomId);
  return api<GoalSummary>('/goals', { title: room?.title || '群聊', roomId });
}
async function renderChannelMemory(): Promise<void> {
  const list = $('channel-memory-list');
  const roomId = openGroupId;
  if (!list || !roomId) return;
  list.replaceChildren(element('p', '正在读取这个频道记住的事。'));
  const goal = await listedChannelGoal();
  if (openGroupId !== roomId) return;
  const memories = goal ? await api<MemoryView[]>(`/goals/${encodeURIComponent(goal.id)}/memories?limit=50`).catch(() => [] as MemoryView[]) : [];
  if (openGroupId !== roomId) return;
  list.replaceChildren();
  const active = memories.filter(item => item.state !== 'retracted' && item.state !== 'superseded');
  if (!active.length) list.append(element('p', '这个频道还没有记下的事实。'));
  for (const memory of active) {
    const row = element('article', '');
    row.dataset.memoryId = memory.id;
    row.append(element('strong', `${MEMORY_KIND_LABEL[memory.kind] ?? memory.kind} · ${privacyLabel(memory.classification)}`), element('p', memory.content), element('small', `来源：${memory.source || '未标明'}`));
    const correction = document.createElement('textarea');
    correction.maxLength = 2000;
    correction.rows = 2;
    correction.value = memory.content;
    correction.setAttribute('aria-label', '修正这条记忆');
    const correct = dashboardButton('修正', async () => {
      const content = correction.value.trim();
      if (!content || !goal) return;
      await api(`/goals/${encodeURIComponent(goal.id)}/memories/${encodeURIComponent(memory.id)}/correct`, {
        kind: memory.kind, content, scope: memory.scope, classification: memory.classification, source: memory.source, confidence: memory.confidence,
      });
      message('已修正这条频道记忆。旧的一版还留着。');
      await renderChannelMemory();
    });
    const reason = document.createElement('input');
    reason.maxLength = 500;
    reason.placeholder = '撤回原因';
    reason.setAttribute('aria-label', '撤回原因');
    const retract = dashboardButton('撤回', async () => {
      const why = reason.value.trim();
      if (!why) { message('请先写下撤回原因。'); return; }
      if (!goal) return;
      await api(`/goals/${encodeURIComponent(goal.id)}/memories/${encodeURIComponent(memory.id)}/retract`, { reason: why });
      message('已撤回这条频道记忆。');
      await renderChannelMemory();
    });
    row.append(correction, correct, reason, retract);
    list.append(row);
  }
}
async function openChannelMemory(): Promise<void> {
  const panel = $('channel-memory');
  if (!panel || !openGroupId) return;
  panel.hidden = false;
  await renderChannelMemory();
}
async function saveChannelMemory(event: Event): Promise<void> {
  event.preventDefault();
  const roomId = openGroupId;
  const text = $<HTMLTextAreaElement>('channel-memory-text')?.value.trim() ?? '';
  if (!roomId || !text) return;
  const room = roomSummaries.find(item => item.id === roomId);
  const source = $<HTMLInputElement>('channel-memory-source')?.value.trim() || `频道：${room?.title || '群聊'}`;
  if (source.startsWith('团队规则') || source.startsWith('带教：')) {
    message('团队规则从复盘里收，带教从带教里记。这条请换一个来源。');
    return;
  }
  const goal = await channelGoal();
  if (!goal || openGroupId !== roomId) return;
  const kind = $<HTMLSelectElement>('channel-memory-kind')?.value || 'fact';
  const classification = $<HTMLSelectElement>('channel-memory-class')?.value || 'internal';
  await api(`/goals/${encodeURIComponent(goal.id)}/memories`, { kind, content: text, scope: 'project', classification, source, confidence: 1 });
  const field = $<HTMLTextAreaElement>('channel-memory-text');
  if (field) field.value = '';
  message('已记下这条频道记忆。看一眼不会执行。');
  await renderChannelMemory();
}
async function openChannelBot(agentId: string): Promise<void> {
  const panel = $('channel-bot');
  const title = $('channel-bot-title');
  const body = $('channel-bot-body');
  if (!panel || !body) return;
  const bot = botById(agentId);
  const name = bot?.name ?? participantLabel(agentId);
  if (title) title.textContent = `${name}的档案`;
  body.replaceChildren(element('p', '正在读取这份档案。看一眼不会执行。'));
  panel.hidden = false;
  const summary = agentId === 'aeeis' ? aeeisThread() : lifeSummary(agentId);
  let view = summary ? handoffViews.get(summary.id) : undefined;
  if (summary && !view) {
    try { view = await api<ConversationView>(`/conversations/${encodeURIComponent(summary.id)}`); if (view) handoffViews.set(view.id, view); }
    catch { view = undefined; }
  }
  body.replaceChildren();
  body.append(element('p', `${name} · ${botDutyLine(bot)}`));
  body.append(element('small', lifePresenceLabel(agentId)));
  body.append(element('small', '权限仍是现在这套：讨论不授权，执行要单独创建 Run。批准、登录和密钥留在和 AEEIS 的对话里。'));
  const remembered = view?.standingInstruction?.trim();
  body.append(element('small', remembered ? `这个人记得：${remembered}` : '这个人还没有长期嘱咐。'));
  body.append(element('small', view?.acceptedPractice ? `收下的做法：${view.acceptedPractice.text}` : '还没有收下的做法。'));
  const models = view?.taskSettings?.models ?? [];
  const skills = view?.taskSettings?.skills ?? [];
  body.append(element('small', models.length ? `设置：${models.map(item => `${item.taskKind}用 ${item.model}`).join('、')}` : '还没有按任务种类选定模型。'));
  if (skills.length) body.append(element('small', `技能：${skills.map(item => `${item.taskKind} ${item.methodId} ${item.version}`).join('、')}`));
  const recent = channelCitations().filter(cite => (cite.agentId ?? handoffViews.get(cite.conversationId)?.agentId) === agentId);
  body.append(element('small', recent.length ? `最近：${recent.map(cite => handoffViews.get(cite.conversationId)?.tasks.find(task => task.id === cite.taskId)?.title ?? cite.taskId).join('、')}` : '这个频道里还没有交给这个人的事。'));
  body.append(element('small', '档案只读。要改嘱咐、做法或模型，打开这个人。看一眼不会执行。'));
  const open = dashboardButton('打开这个人', () => openLifeThread(agentId));
  open.dataset.openLife = agentId;
  body.append(open);
}
function openChannelInbox(): void {
  const toggle = $('attention-toggle') as HTMLButtonElement | null;
  if (!toggle || toggle.hidden) { message('现在没有待处理的事。'); return; }
  if (!attentionInboxOpen) toggle.click();
  else $('attention-inbox')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}
interface StudioHop { id: string; fromId: string; toId: string; fromName: string; toName: string; at: string; content: string; conversationId: string; taskId: string }
function studioRoster(): Array<{ id: string; name: string; seat: 'meet' | 'desk' }> {
  const people: Array<{ id: string; name: string; seat: 'meet' | 'desk' }> = [{ id: 'aeeis', name: 'AEEIS', seat: 'meet' }];
  for (const member of groupMembers) {
    if (member.status !== 'active' || member.principalId === 'aeeis' || people.some(person => person.id === member.principalId)) continue;
    people.push({ id: member.principalId, name: participantLabel(member.principalId), seat: 'desk' });
  }
  return people;
}
function studioWork(agentId: string): Array<{ title: string; column: string }> {
  return (boardState()?.cards ?? []).flatMap(card => {
    const owner = card.decision.released ? '' : (card.ownerId || handoffViews.get(card.conversationId)?.agentId || '');
    if (owner !== agentId) return [];
    const view = handoffViews.get(card.conversationId);
    const task = view?.tasks.find(item => item.id === card.taskId);
    if (!view || !task) return [{ title: card.title ?? card.taskId, column: 'capture' }];
    return [{ title: task.title, column: boardColumn(task.status, card.decision, taskRunId(task)) }];
  });
}
function studioLabel(agentId: string): { label: string; task: string } {
  const work = studioWork(agentId);
  const pick = (column: string) => work.find(item => item.column === column);
  const blocked = pick('blocked');
  if (blocked) return { label: '需要你', task: blocked.title };
  const doing = pick('doing');
  if (doing) return { label: '执行中', task: doing.title };
  const review = pick('review');
  if (review) return { label: '待验收', task: review.title };
  const ready = pick('ready');
  if (ready) return { label: '等待', task: ready.title };
  const done = pick('done');
  if (done) return { label: '完成', task: done.title };
  const any = work[0];
  if (any) return { label: '待整理', task: any.title };
  return { label: '空闲', task: '现在没有交给这个人的事' };
}
/** Who handed what to whom, in order. A person's own receipt goes from 你 to the member it
 * names; a Bot's proposal for someone else goes from the proposer; an assignment or transfer
 * goes from the task's holder at the time. Lines the server wrote for the Bots only echo these. */
function studioHops(): StudioHop[] {
  const board = boardState();
  if (!board) return [];
  type Step = { sequence: number; cite?: (typeof board.citations)[number]; action?: (typeof board.actions)[number] };
  const steps: Step[] = [
    ...board.citations.map((cite, index) => ({ sequence: cite.sequence ?? index, cite })),
    ...board.actions.map((action, index) => ({ sequence: action.sequence ?? index, action })),
  ].sort((left, right) => left.sequence - right.sequence);
  const contentOf = new Map(board.citations.map(cite => [cite.eventId, cite.content]));
  const holders = new Map<string, string>();
  const hops: StudioHop[] = [];
  const add = (id: string, at: string | undefined, conversationId: string, taskId: string, fromId: string, toId: string, content: string) => {
    hops.push({ id, fromId, toId, fromName: fromId === 'you' ? '你' : participantLabel(fromId), toName: participantLabel(toId), at: at ?? '', content, conversationId, taskId });
  };
  for (const step of steps) {
    if (step.cite) {
      const cite = step.cite;
      const key = `${cite.conversationId}:${cite.taskId}`;
      const agentId = cite.agentId && botById(cite.agentId) ? cite.agentId : undefined;
      if (!agentId) continue;
      if (!holders.has(key)) holders.set(key, agentId);
      if (!cite.automatic && cite.actorType !== 'agent') add(cite.eventId, cite.at, cite.conversationId, cite.taskId, 'you', agentId, cite.content);
      continue;
    }
    const action = step.action!;
    const key = `${action.conversationId}:${action.taskId}`;
    const holder = holders.get(key);
    const content = contentOf.get(action.eventId) ?? '';
    if ((action.kind === 'assign' || action.kind === 'transfer') && action.agentId) {
      if (holder !== action.agentId) add(action.eventId, action.at, action.conversationId, action.taskId, holder ?? 'you', action.agentId, content || `交给${participantLabel(action.agentId)}`);
      holders.set(key, action.agentId);
    } else if (action.kind === 'claim' && action.agentId) holders.set(key, action.agentId);
    else if (action.kind === 'release') holders.delete(key);
    else if (action.kind === 'propose' && action.agentId && holder && action.agentId !== holder) add(action.eventId, action.at, action.conversationId, action.taskId, action.agentId, holder, content || `${participantLabel(action.agentId)}提议交给${participantLabel(holder)}`);
  }
  return hops;
}
function studioEdges(): Array<{ fromId: string; toId: string; fromName: string; toName: string; count: number; latest: StudioHop }> {
  const map = new Map<string, { fromId: string; toId: string; fromName: string; toName: string; count: number; latest: StudioHop }>();
  for (const hop of studioHops()) {
    const key = `${hop.fromId}\0${hop.toId}`;
    const current = map.get(key);
    if (current) { current.count += 1; current.latest = hop; }
    else map.set(key, { fromId: hop.fromId, toId: hop.toId, fromName: hop.fromName, toName: hop.toName, count: 1, latest: hop });
  }
  return [...map.values()];
}
function studioCaption(): string {
  const hops = studioHops();
  if (!hops.length) return '这个频道还没有交接可以回放。空格暂停，左右键单步。';
  const hop = studioIndex >= 0 ? hops[studioIndex] : undefined;
  if (!hop) return `可以回放 ${hops.length} 次交接。空格暂停，左右键单步。`;
  const detail = studioPrivacy ? `${hop.fromName} 和 ${hop.toName} 在协作` : `${hop.fromName} → ${hop.toName}：${hop.content}`;
  return `${studioIndex + 1} / ${hops.length} · ${detail}`;
}
function studioSignature(): string {
  const people = studioRoster().map(person => { const state = studioLabel(person.id); return `${person.id}:${state.label}:${state.task}`; }).join('\n');
  const hops = studioHops().map(hop => `${hop.id}:${hop.fromName}:${hop.toName}:${studioPrivacy ? '' : hop.content}`).join('\n');
  return `${studioView}\u0000${studioPrivacy}\u0000${studioIndex}\u0000${people}\u0000${hops}`;
}
function stopStudioPlay(): void {
  studioPlaying = false;
  if (studioTimer !== undefined) window.clearInterval(studioTimer);
  studioTimer = undefined;
}
function motionReduced(): boolean {
  return window.matchMedia?.('(prefers-reduced-motion: reduce)').matches === true;
}
function startStudioTimer(): void {
  if (studioTimer !== undefined) window.clearInterval(studioTimer);
  studioTimer = window.setInterval(() => {
    if (studioIndex >= studioHops().length - 1) { stopStudioPlay(); renderStudio(); return; }
    studioIndex += 1;
    renderStudio();
  }, studioSpeed === 2 ? 700 : 1400);
}
function studioStep(delta: number): void {
  const hops = studioHops();
  if (!hops.length) { studioIndex = -1; renderStudio(); return; }
  studioIndex = Math.min(hops.length - 1, Math.max(0, studioIndex + delta));
  renderStudio();
}
function playStudio(): void {
  if (!studioHops().length) { message('这个频道还没有交接可以回放。'); return; }
  if (motionReduced()) { stopStudioPlay(); studioStep(1); message('已按单步回放。'); return; }
  if (studioIndex >= studioHops().length - 1) studioIndex = -1;
  studioPlaying = true;
  startStudioTimer();
  studioStep(1);
}
function studioPersonButton(person: { id: string; name: string }): HTMLButtonElement {
  const state = studioLabel(person.id);
  const button = element('button', '', 'studio-person') as HTMLButtonElement;
  button.type = 'button';
  button.dataset.studioPerson = person.id;
  button.append(element('strong', person.name), element('small', state.label), element('small', state.task));
  button.addEventListener('click', () => { void openChannelBot(person.id).catch(error => message(errorMessage(error))); });
  return button;
}
function studioHopButton(hop: StudioHop, index: number): HTMLButtonElement {
  const button = element('button', '', 'studio-hop') as HTMLButtonElement;
  button.type = 'button';
  button.dataset.hopIndex = String(index);
  if (index === studioIndex) button.classList.add('studio-live');
  const detail = studioPrivacy ? `${hop.fromName} 和 ${hop.toName} 在协作` : hop.content;
  button.append(element('strong', `${hop.fromName} → ${hop.toName}`), element('small', formatTime(hop.at)), element('small', detail));
  button.addEventListener('click', () => {
    studioIndex = index;
    stopStudioPlay();
    const view = handoffViews.get(hop.conversationId);
    const task = view?.tasks.find(item => item.id === hop.taskId);
    renderStudio();
    if (!view || !task) { message('正在读取这件事。看一眼不会执行。'); return; }
    openChannelTask(view, task, hop.toName);
  });
  return button;
}
function studioTable(): HTMLTableElement {
  const table = document.createElement('table');
  table.className = 'studio-status';
  const caption = document.createElement('caption');
  caption.textContent = '团队状态';
  const head = document.createElement('thead');
  const headRow = document.createElement('tr');
  for (const label of ['人', '状态', '当前的事']) { const cell = document.createElement('th'); cell.textContent = label; headRow.append(cell); }
  head.append(headRow);
  const body = document.createElement('tbody');
  for (const person of studioRoster()) {
    const state = studioLabel(person.id);
    const row = document.createElement('tr');
    for (const value of [person.name, state.label, state.task]) { const cell = document.createElement('td'); cell.textContent = value; row.append(cell); }
    body.append(row);
  }
  table.append(caption, head, body);
  return table;
}
function renderStudio(): void {
  const body = $('channel-studio-body');
  const caption = $('studio-replay-caption');
  const play = $('studio-play');
  const speed = $('studio-speed');
  if (caption) caption.textContent = studioCaption();
  if (play) play.textContent = studioPlaying ? '回放中' : '回放';
  if (speed) speed.textContent = `速度 ${studioSpeed}×`;
  if (!body) return;
  const key = studioSignature();
  if (key === studioKey && body.childElementCount) return;
  studioKey = key;
  body.replaceChildren();
  const stage = element('div', '', 'studio-stage');
  stage.id = 'channel-studio-stage';
  stage.append(element('p', studioSummary()));
  if (studioView === 'graph') appendStudioGraph(stage);
  else if (studioView === 'timeline') appendStudioTimeline(stage);
  else appendStudioFloor(stage);
  body.append(stage, studioTable());
}
function studioSummary(): string {
  const people = studioRoster();
  const busy = people.filter(person => studioLabel(person.id).label !== '空闲').length;
  return `${busy} 人在忙 · ${people.length - busy} 人空闲`;
}
function appendStudioFloor(stage: HTMLElement): void {
  const floor = element('div', '', 'studio-floor');
  const meet = element('section', '', 'studio-seat');
  const desks = element('section', '', 'studio-seat');
  meet.append(element('h3', '会议室'));
  desks.append(element('h3', '工位区'));
  const roster = studioRoster();
  for (const person of roster) (person.seat === 'meet' ? meet : desks).append(studioPersonButton(person));
  if (!roster.some(person => person.seat === 'desk')) desks.append(element('small', '工位区还空着。'));
  floor.append(meet, desks);
  stage.append(floor);
  const hops = studioHops();
  if (!hops.length) stage.append(element('p', '这个频道还没有交接。'));
  hops.forEach((hop, index) => stage.append(studioHopButton(hop, index)));
}
function appendStudioGraph(stage: HTMLElement): void {
  const edges = studioEdges();
  if (!edges.length) { stage.append(element('p', '这个频道还没有交接。')); return; }
  for (const edge of edges) {
    const reverse = edges.some(item => item.fromId === edge.toId && item.toId === edge.fromId);
    const button = element('button', '', 'studio-edge') as HTMLButtonElement;
    button.type = 'button';
    button.append(element('strong', `${edge.fromName} → ${edge.toName}`), element('small', reverse ? `${edge.count} 次` : `${edge.count} 次 · 单向`));
    button.append(element('small', studioPrivacy ? `${edge.fromName} 和 ${edge.toName} 在协作` : edge.latest.content));
    if (studioHops()[studioIndex]?.id === edge.latest.id) button.classList.add('studio-live');
    button.addEventListener('click', () => {
      studioIndex = studioHops().findIndex(hop => hop.id === edge.latest.id);
      stopStudioPlay();
      renderStudio();
    });
    stage.append(button);
  }
}
function appendStudioTimeline(stage: HTMLElement): void {
  const hops = studioHops();
  for (const person of studioRoster()) {
    const row = element('section', '', 'studio-seat');
    row.append(element('h3', person.name));
    const mine = hops.map((hop, index) => ({ hop, index })).filter(item => item.hop.toId === person.id || item.hop.fromId === person.id);
    if (!mine.length) row.append(element('small', '这一行还没有交接。'));
    for (const item of mine) row.append(studioHopButton(item.hop, item.index));
    stage.append(row);
  }
}
async function ensureCitedViews(roomId: string): Promise<void> {
  await loadChannelBoardState(roomId).catch(() => undefined);
  if (openGroupId !== roomId) return;
  await Promise.all(channelBoardIds().map(async id => {
    if (handoffViews.has(id)) return;
    try {
      const view = await api<ConversationView>(`/conversations/${encodeURIComponent(id)}`);
      if (openGroupId === roomId && view) handoffViews.set(view.id, view);
    } catch { return undefined; }
  }));
}
async function openChannelStudio(): Promise<void> {
  const roomId = openGroupId;
  const panel = $('channel-studio');
  if (!roomId || !panel) return;
  panel.hidden = false;
  studioKey = '';
  trackUi('ui.studio.open', roomId);
  await ensureCitedViews(roomId);
  if (openGroupId !== roomId) return;
  renderStudio();
}
function inDigestWindow(iso: string | undefined, span: DigestWindow): boolean {
  const time = Date.parse(iso ?? '');
  if (!Number.isFinite(time)) return false;
  const when = new Date(time);
  const now = new Date();
  if (when.getTime() > now.getTime() + 60_000) return false;
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  if (span === 'day') return when.getTime() >= today.getTime();
  const week = new Date(today);
  const weekday = week.getDay();
  week.setDate(week.getDate() - (weekday === 0 ? 6 : weekday - 1));
  return when.getTime() >= week.getTime();
}
function digestNeedsYou(): number {
  const seen = new Set<string>();
  let count = 0;
  for (const cite of channelCitations()) {
    const key = `${cite.conversationId}\0${cite.taskId}`;
    if (seen.has(key)) continue;
    seen.add(key);
    const view = handoffViews.get(cite.conversationId);
    const task = view?.tasks.find(item => item.id === cite.taskId);
    if (!view || !task) continue;
    if (boardColumn(task.status, boardDecision(view.id, task.id), taskRunId(task)) === 'blocked') count += 1;
  }
  return count;
}
function digestTaskCount(kind: string): number {
  const seen = new Set<string>();
  for (const action of boardState()?.actions ?? []) {
    if (action.kind === kind && inDigestWindow(action.at, digestWindow)) seen.add(`${action.conversationId}\0${action.taskId}`);
  }
  return seen.size;
}
function renderDigestBody(): void {
  const body = $('channel-digest-body');
  if (!body) return;
  const handoffs = (boardState()?.citations ?? []).filter(cite => inDigestWindow(cite.at, digestWindow)).length;
  const blocked = digestTaskCount('block');
  const done = digestTaskCount('accept');
  const label = digestWindow === 'day' ? '今日' : '本周';
  const spend = element('p', '正在汇总耗时和花费。');
  spend.dataset.digestCost = digestWindow;
  body.replaceChildren(element('p', `${label}：交接 ${handoffs}，阻塞 ${blocked}，完成 ${done}。现在需要你 ${digestNeedsYou()}。`), spend, element('small', '今日和本周按这台机器的本地日历，一周从周一开始。耗时只算 Run 在执行的时间，等人不算。'));
  if (openGroupId) void renderDigestCost(openGroupId, digestWindow, spend).catch(error => { spend.textContent = errorMessage(error); });
}
/** Start of the local calendar day or week (Monday) the digest covers. */
function digestWindowStart(span: DigestWindow): Date {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  if (span === 'week') { const weekday = start.getDay(); start.setDate(start.getDate() - (weekday === 0 ? 6 : weekday - 1)); }
  return start;
}
function formatDuration(ms: number): string {
  const minutes = Math.round(ms / 60_000);
  if (minutes < 1) return `${Math.max(0, Math.round(ms / 1000))} 秒`;
  if (minutes < 60) return `${minutes} 分钟`;
  const hours = ms / 3_600_000;
  return hours < 48 ? `${hours.toFixed(1)} 小时` : `${(hours / 24).toFixed(1)} 天`;
}
/** §8.8: the time and money behind the digest window, from the server. */
async function renderDigestCost(roomId: string, span: DigestWindow, line: HTMLElement): Promise<void> {
  const from = digestWindowStart(span).toISOString(), to = new Date(Date.now() + 1000).toISOString();
  const cost = await api<{ runs: number; runTimeMs: number; cycleMs?: number; accepted: number; tokens: number; moneyUsd?: number; credits: number; unreportedCalls: number }>(`/rooms/${encodeURIComponent(roomId)}/digest?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`);
  if (openGroupId !== roomId || digestWindow !== span || !line.isConnected) return;
  if (typeof cost.tokens !== 'number' || typeof cost.runTimeMs !== 'number') { line.textContent = '这台服务还不能汇总耗时和花费。'; return; }
  const time = cost.runs ? `耗时：${cost.runs} 件 Run 执行了 ${formatDuration(cost.runTimeMs)}${cost.cycleMs !== undefined ? `，验收的事从开口到验收中位 ${formatDuration(cost.cycleMs)}` : ''}。` : '耗时：这段时间没有 Run 在执行。';
  const money = [`${cost.tokens.toLocaleString('zh-CN')} tokens`, ...(cost.moneyUsd !== undefined ? [`约 $${cost.moneyUsd.toFixed(2)}`] : []), ...(cost.credits ? [`工具 ${cost.credits} credits`] : [])].join(' · ');
  line.textContent = `${time}花费：${money}${cost.unreportedCalls ? `（${cost.unreportedCalls} 次调用没报用量，没算进去）` : ''}。`;
}
async function scopedMemories(selector: { exact?: string; prefix?: string; kind?: string }): Promise<{ goal?: GoalSummary; items: MemoryView[] }> {
  const goal = await listedChannelGoal();
  if (!goal) return { items: [] };
  const memories = await api<MemoryView[]>(`/goals/${encodeURIComponent(goal.id)}/memories?limit=50`).catch(() => [] as MemoryView[]);
  return { goal, items: memories.filter(item => item.state !== 'retracted' && item.state !== 'superseded' && (!selector.kind || item.kind === selector.kind) && (selector.exact ? item.source === selector.exact : Boolean(selector.prefix && item.source.startsWith(selector.prefix)))) };
}
function renderScopedMemories(list: HTMLElement, goal: GoalSummary | undefined, items: MemoryView[], empty: string, reload: () => Promise<void>): void {
  list.replaceChildren();
  if (!items.length) { list.append(element('p', empty)); return; }
  for (const memory of items) {
    const row = element('article');
    row.append(element('p', memory.content), element('small', `来源：${memory.source}`));
    const reason = document.createElement('input');
    reason.maxLength = 500;
    reason.placeholder = '撤回原因';
    reason.setAttribute('aria-label', '撤回原因');
    const retract = dashboardButton('撤回', async () => {
      const why = reason.value.trim();
      if (!why) { message('请先写下撤回原因。'); return; }
      if (!goal) return;
      await api(`/goals/${encodeURIComponent(goal.id)}/memories/${encodeURIComponent(memory.id)}/retract`, { reason: why });
      message('已撤回。');
      await reload();
    });
    row.append(reason, retract);
    list.append(row);
  }
}
async function renderTeamRules(): Promise<void> {
  const list = $('channel-rule-list');
  const roomId = openGroupId;
  if (!list || !roomId) return;
  const loaded = await scopedMemories({ exact: '团队规则', kind: 'decision' });
  if (openGroupId !== roomId) return;
  renderScopedMemories(list, loaded.goal, loaded.items, '这个频道还没有团队规则。', renderTeamRules);
}
async function openChannelDigest(): Promise<void> {
  const roomId = openGroupId;
  const panel = $('channel-digest');
  if (!roomId || !panel) return;
  panel.hidden = false;
  trackUi('ui.digest.view', roomId);
  await ensureCitedViews(roomId);
  if (openGroupId !== roomId) return;
  renderDigestBody();
  await Promise.all([renderTeamRules(), renderChannelMetrics(roomId)]);
}
interface ChannelIndicatorView { key: string; value?: number; unit: 'ratio' | 'ms' | 'count'; samples: number; ok?: boolean; detail?: Record<string, number> }
const INDICATOR_COPY: Record<string, [string, string]> = {
  completion_rate: ['任务完成率', '建立基线'],
  first_reply: ['首响时间（中位）', '目标 < 30 秒'],
  cycle_time: ['任务周期（中位）', '建立基线'],
  handoff_depth: ['交接深度（中位）', '目标中位 1–2，最多 5'],
  parallel_use: ['并行利用率', '建立基线'],
  interventions: ['每件的人工介入', '目标 < 0.5'],
  intervened_share: ['有人介入的任务占比', '目标 < 50%'],
  blocked_time: ['阻塞时长（p90）', '目标 < 4 小时'],
  noise: ['每件的 Bot 消息数', '目标 < 6'],
  evidence_open_rate: ['证据打开率', '目标 > 30%'],
  duplicate_effects: ['重复副作用', '目标 0'],
  handoff_failure_rate: ['交接失败率', '目标 < 5%'],
};
function formatIndicator(item: ChannelIndicatorView): string {
  if (item.value === undefined) return '还没有数据';
  if (item.unit === 'ratio') return `${Math.round(item.value * 100)}%`;
  if (item.unit === 'count') return Number.isInteger(item.value) ? String(item.value) : item.value.toFixed(1);
  const seconds = item.value / 1000;
  if (seconds < 60) return `${Math.round(seconds)} 秒`;
  if (seconds < 3600) return `${Math.round(seconds / 60)} 分钟`;
  if (seconds < 86_400) return `${(seconds / 3600).toFixed(1)} 小时`;
  return `${(seconds / 86_400).toFixed(1)} 天`;
}
/** §18.1 for this channel over the last 7 days, computed on the server from what the room and its Runs recorded. */
async function renderChannelMetrics(roomId: string): Promise<void> {
  const box = $('channel-metrics');
  if (!box) return;
  box.replaceChildren(element('p', '正在汇总。'));
  try {
    const metrics = await api<{ tasks: { created: number; done: number }; indicators: ChannelIndicatorView[] }>(`/rooms/${encodeURIComponent(roomId)}/metrics?days=7`);
    if (openGroupId !== roomId) return;
    const list = element('dl', '', 'channel-metrics-list');
    for (const item of metrics.indicators) {
      const [label, target] = INDICATOR_COPY[item.key] ?? [item.key, ''];
      const verdict = item.value === undefined ? '' : item.ok === undefined ? '' : item.ok ? ' · 达标' : ' · 未达标';
      const extra = item.key === 'handoff_depth' && item.detail?.max !== undefined ? `，最多 ${item.detail.max}` : '';
      const term = element('dt', label);
      const value = element('dd', `${formatIndicator(item)}${extra}${verdict}`);
      value.dataset.indicator = item.key;
      if (item.ok !== undefined && item.value !== undefined) value.dataset.state = item.ok ? 'ok' : 'attention';
      value.append(element('small', ` ${target} · ${item.samples} 个样本`));
      list.append(term, value);
    }
    box.replaceChildren(element('p', `近 7 天：记下 ${metrics.tasks.created} 件，验收 ${metrics.tasks.done} 件。`), list,
      element('small', '只统计结构、时长和次数，不读消息正文、证据内容和模型输出。'));
  } catch (error) {
    if (openGroupId === roomId) box.replaceChildren(element('p', errorMessage(error)));
  }
}
async function saveTeamRule(event: Event): Promise<void> {
  event.preventDefault();
  const text = $<HTMLTextAreaElement>('channel-rule-text')?.value.trim() ?? '';
  const roomId = openGroupId;
  if (!text || !roomId) return;
  const goal = await channelGoal();
  if (!goal || openGroupId !== roomId) return;
  await api(`/goals/${encodeURIComponent(goal.id)}/memories`, { kind: 'decision', content: text, scope: 'project', classification: 'internal', source: '团队规则', confidence: 1 });
  const field = $<HTMLTextAreaElement>('channel-rule-text');
  if (field) field.value = '';
  message('已收成这个频道的团队规则。看一眼不会执行。');
  await renderTeamRules();
}
function teachingSteps(): string[] {
  return ($<HTMLTextAreaElement>('channel-teach-steps')?.value ?? '').split('\n').map(line => line.trim()).filter(Boolean).slice(0, 12);
}
function teachingDraft(): string {
  return teachingSteps().map((line, index) => `${index + 1}. ${line}`).join('\n');
}
function renderTeachingPreview(): void {
  const list = $('channel-teach-preview');
  if (!list) return;
  const steps = teachingSteps();
  list.replaceChildren();
  if (!steps.length) { list.append(element('li', '写下步骤后再生成草案。')); return; }
  for (const step of steps) list.append(element('li', step));
}
function renderTeachPeople(): void {
  const select = $<HTMLSelectElement>('channel-teach-person');
  if (!select) return;
  const previous = select.value;
  select.replaceChildren();
  for (const person of studioRoster()) {
    const option = document.createElement('option');
    option.value = person.id;
    option.textContent = person.name;
    select.append(option);
  }
  if ([...select.options].some(option => option.value === previous)) select.value = previous;
}
async function renderTeachingSaved(): Promise<void> {
  const list = $('channel-teach-saved');
  const roomId = openGroupId;
  if (!list || !roomId) return;
  const loaded = await scopedMemories({ prefix: '带教：', kind: 'note' });
  if (openGroupId !== roomId) return;
  renderScopedMemories(list, loaded.goal, loaded.items, '这个频道还没有带教草案。', renderTeachingSaved);
}
async function openChannelTeach(): Promise<void> {
  const panel = $('channel-teach');
  if (!panel || !openGroupId) return;
  panel.hidden = false;
  renderTeachPeople();
  await Promise.all([renderTeachingSaved(), renderTeachings(openGroupId)]);
}
interface TeachingView {
  id: string; agentId: string; agentName: string; startedAt: string; stoppedAt?: string; routineId?: string;
  state: 'recording' | 'recorded' | 'adopted' | 'revoked';
  draft?: { steps: Array<{ at: string; text: string; source: 'message' | 'action' | 'run'; decision: boolean }>; decisions: string[]; tools: string[]; prompt: string; executionReview: 'required' | 'auto' };
}
const TEACHING_STATES: Record<TeachingView['state'], string> = { recording: '正在录', recorded: '待确认', adopted: '已收成例程', revoked: '已撤销' };
const teachingReplay = new Map<string, number>();
/** Interaction-design §8.7: demonstrations recorded in this group, each a routine draft for one Bot. */
async function renderTeachings(roomId: string): Promise<void> {
  const list = $('channel-teachings');
  if (!list) return;
  const loaded = await api<{ items?: TeachingView[] }>(`/rooms/${encodeURIComponent(roomId)}/teachings`);
  if (openGroupId !== roomId) return;
  // A server without recorded teaching answers without a list.
  const items = Array.isArray(loaded.items) ? loaded.items : [];
  renderTeachPeople();
  const recording = items.find(item => item.state === 'recording');
  const start = $<HTMLButtonElement>('channel-teach-start'), stop = $<HTMLButtonElement>('channel-teach-stop');
  if (start) start.hidden = Boolean(recording);
  if (stop) { stop.hidden = !recording; stop.dataset.teaching = recording?.id ?? ''; stop.textContent = recording ? `结束示范（教给${recording.agentName}）` : '结束示范'; }
  list.replaceChildren(...items.map(item => teachingCard(item, roomId)));
  if (!items.length) list.append(element('p', '这个群里还没有录过示范。', 'muted'));
}
function teachingCard(item: TeachingView, roomId: string): HTMLElement {
  const card = element('article', '', 'teaching-card');
  card.dataset.teaching = item.id; card.dataset.state = item.state;
  card.append(element('strong', `教给${item.agentName}`), element('small', `${TEACHING_STATES[item.state]} · ${formatTime(item.startedAt)} 开始${item.stoppedAt ? `，${formatTime(item.stoppedAt)} 结束` : ''}`));
  const reload = async () => { await renderTeachings(roomId); void refresh(); };
  const steps = item.draft?.steps ?? [];
  if (item.state === 'recording') card.append(element('p', '正在录。照常在群里做，做完点上面的「结束示范」。'));
  if (item.draft && !steps.length) card.append(element('p', '这段示范里没有记下步骤。'));
  if (steps.length) {
    // Replay: one step at a time, with when it happened and whether a person decided there.
    const index = Math.min(teachingReplay.get(item.id) ?? 0, steps.length - 1);
    const step = steps[index]!;
    const replay = element('div', '', 'teaching-replay');
    const caption = element('p', `第 ${index + 1} / ${steps.length} 步 · ${formatTime(step.at)}${step.decision ? ' · 要人确认' : ''}：${step.text}`);
    caption.dataset.teachingStep = String(index);
    const move = (delta: number) => { teachingReplay.set(item.id, Math.max(0, Math.min(steps.length - 1, index + delta))); card.replaceWith(teachingCard(item, roomId)); };
    const back = button('上一步', async () => move(-1)); back.type = 'button'; back.disabled = index === 0;
    const next = button('下一步', async () => move(1)); next.type = 'button'; next.disabled = index === steps.length - 1;
    replay.append(caption, back, next);
    card.append(replay);
    const all = element('ol', '', 'teaching-steps');
    for (const [position, entry] of steps.entries()) {
      const row = element('li', `${entry.text}${entry.decision ? '（要人确认）' : ''}`);
      if (position === index) row.dataset.current = 'true';
      all.append(row);
    }
    card.append(all);
    if (item.draft?.tools.length) card.append(element('small', `用到的工具：${item.draft.tools.join('、')}`));
  }
  if (item.state === 'recorded' && item.draft && steps.length) {
    const form = element('div', '', 'teaching-adopt');
    const name = document.createElement('input'); name.maxLength = 80; name.value = `${item.agentName}的示范`; name.setAttribute('aria-label', '例程名字'); name.dataset.teachingName = item.id;
    const prompt = document.createElement('textarea'); prompt.maxLength = 4000; prompt.rows = 6; prompt.value = item.draft.prompt; prompt.setAttribute('aria-label', '例程要做的事'); prompt.dataset.teachingPrompt = item.id;
    const review = document.createElement('select'); review.setAttribute('aria-label', '执行时怎么批'); review.dataset.teachingReview = item.id;
    for (const value of ['required', 'auto', 'yolo'] as const) { const option = document.createElement('option'); option.value = value; option.textContent = ROUTINE_REVIEW[value]; review.append(option); }
    review.value = item.draft.executionReview;
    const adopt = dashboardButton('收成例程', async () => {
      await api(`/rooms/${encodeURIComponent(roomId)}/teachings/${encodeURIComponent(item.id)}/adopt`, { name: name.value.trim(), prompt: prompt.value.trim(), executionReview: review.value });
      message(`已收进${item.agentName}的例程。叫它时才做。`);
      await reload();
    });
    adopt.dataset.teachingAction = 'adopt';
    form.append(name, prompt, review, adopt);
    card.append(form);
  }
  if (item.state === 'adopted' && item.routineId) {
    const routineId = item.routineId;
    const run = dashboardButton('让它做一次', async () => { await runRoutineNow(routineId, `${item.agentName}学会的这段示范`); });
    run.dataset.teachingAction = 'run';
    card.append(run);
  }
  if (item.state === 'recorded' || item.state === 'adopted') {
    const reason = document.createElement('textarea'); reason.rows = 2; reason.maxLength = 500; reason.dataset.teachingReason = item.id;
    reason.placeholder = item.routineId ? '撤销前写下原因。收成的例程会一起删除。' : '撤销前写下原因。';
    const revoke = dashboardButton('撤销', async () => {
      const text = reason.value.trim();
      if (!text) { message('撤销前写下原因。'); reason.focus(); return; }
      await api(`/rooms/${encodeURIComponent(roomId)}/teachings/${encodeURIComponent(item.id)}/revoke`, { reason: text });
      message('已撤销这段带教。');
      await reload();
    });
    revoke.dataset.teachingAction = 'revoke';
    card.append(reason, revoke);
  }
  return card;
}
async function startTeaching(): Promise<void> {
  const roomId = openGroupId;
  const agentId = $<HTMLSelectElement>('channel-teach-person')?.value ?? '';
  if (!roomId || !agentId) { message('先选教给谁。'); return; }
  await api(`/rooms/${encodeURIComponent(roomId)}/teachings`, { agentId });
  message(`开始示范，教给${participantLabel(agentId)}。照常在群里做，做完点「结束示范」。`);
  await renderTeachings(roomId); void refresh();
}
async function stopTeaching(): Promise<void> {
  const roomId = openGroupId;
  const id = $<HTMLButtonElement>('channel-teach-stop')?.dataset.teaching ?? '';
  if (!roomId || !id) return;
  await api(`/rooms/${encodeURIComponent(roomId)}/teachings/${encodeURIComponent(id)}/stop`, {});
  message('示范结束，草案在下面，看过再收成例程。');
  await renderTeachings(roomId); void refresh();
}
async function saveTeachingDraft(): Promise<void> {
  const text = teachingDraft();
  const roomId = openGroupId;
  const agentId = $<HTMLSelectElement>('channel-teach-person')?.value ?? '';
  if (!text || !roomId || !agentId) { message('先生成草案。'); return; }
  const goal = await channelGoal();
  if (!goal || openGroupId !== roomId) return;
  const name = participantLabel(agentId);
  await api(`/goals/${encodeURIComponent(goal.id)}/memories`, { kind: 'note', content: text, scope: 'project', classification: 'internal', source: `带教：${name}`, confidence: 1 });
  message(`已把草案记在这个频道，教给${name}。只影响这个频道。`);
  await renderTeachingSaved();
}
async function keepTeachingProfile(): Promise<void> {
  const text = teachingDraft();
  if (!text) { message('先生成草案。'); return; }
  if (text.length > 500) { message('收进档案的做法最多 500 字。草案可以先记在这个频道。'); return; }
  const agentId = $<HTMLSelectElement>('channel-teach-person')?.value ?? '';
  const summary = agentId === 'aeeis' ? aeeisThread() : lifeSummary(agentId);
  if (!summary) { message('这个人还没有自己的对话。草案可以先记在这个频道。'); return; }
  const view = await api<ConversationView>(`/conversations/${encodeURIComponent(summary.id)}`);
  const runId = view.lastDelivery?.runId;
  if (!runId) { message('这个人还没有一次做成的交付。草案先留在这个频道。'); return; }
  try {
    const next = await api<ConversationView>(`/conversations/${encodeURIComponent(summary.id)}/practice`, { expectedRevision: view.revision, text, runId });
    if (next) handoffViews.set(next.id, next);
    message(`已收进${participantLabel(agentId)}的档案。只影响这个人。`);
  } catch (error) { message(errorMessage(error)); }
}
$('channel-board-open')?.addEventListener('click', () => { void showChannelBoard().catch(error => message(errorMessage(error))); });
$('channel-board-more')?.addEventListener('click', () => { void showChannelBoard().catch(error => message(errorMessage(error))); });
$('channel-board-close')?.addEventListener('click', () => { hideChannelBoard(); renderGroupTranscript(); });
$('channel-memory-open')?.addEventListener('click', () => { void openChannelMemory().catch(error => message(errorMessage(error))); });
$('channel-memory-close')?.addEventListener('click', () => { const panel = $('channel-memory'); if (panel) panel.hidden = true; });
$('channel-memory-form')?.addEventListener('submit', event => { void saveChannelMemory(event).catch(error => message(errorMessage(error))); });
$('channel-studio-open')?.addEventListener('click', () => { void openChannelStudio().catch(error => message(errorMessage(error))); });
$('channel-studio-close')?.addEventListener('click', () => { stopStudioPlay(); const panel = $('channel-studio'); if (panel) panel.hidden = true; });
$('channel-studio')?.addEventListener('click', event => {
  const target = (event.target as HTMLElement | null)?.closest<HTMLButtonElement>('[data-studio-view]');
  if (!target || !$('channel-studio')?.contains(target)) return;
  const view = target.dataset.studioView;
  if (view !== 'floor' && view !== 'graph' && view !== 'timeline') return;
  studioView = view;
  studioKey = '';
  for (const button of document.querySelectorAll<HTMLButtonElement>('[data-studio-view]')) button.setAttribute('aria-pressed', button === target ? 'true' : 'false');
  renderStudio();
});
$('studio-privacy')?.addEventListener('change', () => {
  studioPrivacy = $<HTMLInputElement>('studio-privacy')?.checked === true;
  studioKey = '';
  renderStudio();
});
$('studio-play')?.addEventListener('click', () => playStudio());
$('studio-pause')?.addEventListener('click', () => { stopStudioPlay(); renderStudio(); });
$('studio-prev')?.addEventListener('click', () => { stopStudioPlay(); studioStep(-1); });
$('studio-next')?.addEventListener('click', () => { stopStudioPlay(); studioStep(1); });
$('studio-speed')?.addEventListener('click', () => {
  studioSpeed = studioSpeed === 1 ? 2 : 1;
  if (studioPlaying) startStudioTimer();
  renderStudio();
});
document.addEventListener('keydown', event => {
  const panel = $('channel-studio');
  if (!panel || panel.hidden) return;
  const target = event.target instanceof HTMLElement ? event.target : null;
  if (target?.closest('button, a, input, textarea, select, summary, [contenteditable="true"]')) return;
  const role = target?.getAttribute('role');
  if (role === 'button' || role === 'link' || role === 'checkbox' || role === 'switch' || role === 'textbox') return;
  const atRoot = !target || target === document.body || target === document.documentElement;
  if (!atRoot && !panel.contains(target)) return;
  if (event.key === ' ') {
    event.preventDefault();
    if (studioPlaying) { stopStudioPlay(); renderStudio(); }
    else playStudio();
  } else if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') {
    event.preventDefault();
    stopStudioPlay();
    studioStep(event.key === 'ArrowRight' ? 1 : -1);
  }
});
$('channel-digest-open')?.addEventListener('click', () => { void openChannelDigest().catch(error => message(errorMessage(error))); });
$('channel-digest-close')?.addEventListener('click', () => { const panel = $('channel-digest'); if (panel) panel.hidden = true; });
$('channel-digest')?.addEventListener('click', event => {
  const target = (event.target as HTMLElement | null)?.closest<HTMLButtonElement>('[data-digest-window]');
  if (!target || !$('channel-digest')?.contains(target)) return;
  const next = target.dataset.digestWindow;
  if (next !== 'day' && next !== 'week') return;
  digestWindow = next;
  for (const button of document.querySelectorAll<HTMLButtonElement>('[data-digest-window]')) button.setAttribute('aria-pressed', button === target ? 'true' : 'false');
  renderDigestBody();
});
$('channel-rule-form')?.addEventListener('submit', event => { void saveTeamRule(event).catch(error => message(errorMessage(error))); });
$('channel-teach-open')?.addEventListener('click', () => { void openChannelTeach().catch(error => message(errorMessage(error))); });
$('channel-teach-close')?.addEventListener('click', () => { const panel = $('channel-teach'); if (panel) panel.hidden = true; });
$('channel-teach-draft')?.addEventListener('click', () => renderTeachingPreview());
$('channel-teach-start')?.addEventListener('click', () => { void startTeaching().catch(error => message(errorMessage(error))); });
$('channel-teach-stop')?.addEventListener('click', () => { void stopTeaching().catch(error => message(errorMessage(error))); });
$('channel-teach-save')?.addEventListener('click', () => { void saveTeachingDraft().catch(error => message(errorMessage(error))); });
$('channel-teach-profile')?.addEventListener('click', () => { void keepTeachingProfile().catch(error => message(errorMessage(error))); });
$('channel-bot-close')?.addEventListener('click', () => { const panel = $('channel-bot'); if (panel) panel.hidden = true; });
$('channel-inbox')?.addEventListener('click', () => openChannelInbox());
$('channel-task-close')?.addEventListener('click', () => {
  const task = $('channel-task');
  if (task) task.hidden = true;
  $('channel-task-body')?.replaceChildren();
});
$('group-text')?.addEventListener('input', () => renderMentions());
$('group-rename')?.addEventListener('click', () => { void renameGroup().catch(error => message(errorMessage(error))); });
$('chat-archive')?.addEventListener('click', () => { void archiveOpenChat().catch(error => message(errorMessage(error))); });
$('entry-back')?.addEventListener('click', () => showRoster(true));
$('entry-computer')?.addEventListener('click', () => {
  if (computerOpen) closeComputer();
  else if (current || currentId) setRunDetailsMode(true);
  else setComputerOpen(true, 'setup');
});

function attentionCopy(status: string): [string, string] {
  const copy: Record<string, [string, string]> = {
    needs_approval: ['等待批准', '查看计划、预算和外部调用边界后批准执行'],
    needs_input: ['需要补充信息', '回答当前问题，Agent 会从原节点继续'],
    waiting_external: ['等待外部回执', '核查供应方结果，确认后再恢复运行'],
    unknown: ['结果需要核查', '确认原调用是否完成，再决定是否重试'],
    failed: ['运行失败', '查看错误后重试失败步骤，或重新规划'],
  };
  return copy[status] ?? ['需要关注', '打开运行查看下一步'];
}
async function openAttentionRun(run: RunSummary): Promise<void> {
  if (document.body.classList.contains('group-open')) {
    // The workbench is hidden in a group: answer or approve on this group's own card, else leave the group for the workbench.
    const cardFor = () => [...document.querySelectorAll<HTMLElement>('#group-transcript [data-run]')].find(item => item.dataset.run === run.id);
    if (cardFor()) {
      setAttentionInboxOpen(false);
      hideChannelSurfaces();
      renderGroupTranscript();
      const card = cardFor();
      card?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      card?.querySelector<HTMLElement>('textarea[data-answer], button')?.focus();
      return;
    }
    leaveGroup();
  }
  currentId = run.id;
  localStorage.setItem('aeeis.run', run.id);
  current = undefined;
  setCurrentRunOpen(true);
  await refresh();
  $('run-workspace')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  if (run.status === 'needs_input' || run.status === 'unknown') {
    openInputPanel(run.status === 'unknown' ? 'reconcile' : 'answer');
  } else if (run.status === 'needs_approval') {
    $('decision-review')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
}
function openInputPanel(mode: InputPanelMode): void {
  inputPanelMode = mode;
  const panel = $('input-panel');
  const heading = panel.querySelector('h2');
  const submit = panel.querySelector('button');
  const answer = $<HTMLTextAreaElement>('answer');
  if (heading) heading.textContent = mode === 'answer' ? '需要你的信息' : '核查外部结果';
  if (submit) submit.textContent = mode === 'answer' ? '提交并继续' : '提交核查并继续';
  if (answer) answer.placeholder = mode === 'answer' ? '可直接粘贴资料、约束、链接或补充说明…' : '说明外部调用是否已经完成，或提供核查依据…';
  panel.hidden = false;
  panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
  answer.focus();
}
type InboxKind = 'approval' | 'question' | 'unknown' | 'failure' | 'mention' | 'derivation';
function inboxKind(status: string): InboxKind | undefined {
  if (status === 'needs_approval') return 'approval';
  if (status === 'needs_input' || status === 'waiting_external' || status === 'paused') return 'question';
  if (status === 'unknown') return 'unknown';
  if (status === 'failed') return 'failure';
  return undefined;
}
function inboxSeverity(kind: InboxKind): number {
  if (kind === 'approval' || kind === 'question') return 1;
  if (kind === 'unknown' || kind === 'derivation') return 2;
  return 3;
}
function inboxAge(at: string | undefined, kind: InboxKind): { label: string; level: 'normal' | 'remind' | 'escalate' } {
  const stamp = at && Number.isFinite(Date.parse(at)) ? Date.parse(at) : Date.now();
  const hours = Math.max(0, Date.now() - stamp) / 3_600_000;
  const [remind, escalate] = kind === 'approval' || kind === 'question' ? [1, 4] : kind === 'unknown' || kind === 'derivation' ? [2, 8] : [24, 72];
  if (hours < remind) return { label: '正常', level: 'normal' };
  if (hours < escalate) return { label: '提醒', level: 'remind' };
  return { label: '升级', level: 'escalate' };
}
function inboxKindLabel(kind: InboxKind): string {
  if (kind === 'approval') return '审批';
  if (kind === 'question') return '提问';
  if (kind === 'unknown') return '结果不明';
  if (kind === 'failure') return '失败';
  if (kind === 'derivation') return '自动派生已停止';
  return '点名';
}
const NOTIFY_PREFERENCE = 'aeeis.notify-s1';
const NOTIFIED_ITEMS = 'aeeis.notified-s1';
/** Inbox items that need a person's decision now (§9.1 S1): an approval, a question, a channel block. */
const S1_STATUSES = new Set(['needs_approval', 'needs_input', 'blocked', 'derivation_blocked']);
let lastInboxRuns: RunSummary[] = [];
let lastTypedAt = 0;
let inboxHold = 0;
document.addEventListener('keydown', event => { if (textEntry(event.target)) lastTypedAt = Date.now(); }, true);
function textEntry(target: EventTarget | null): boolean {
  if (!(target instanceof HTMLElement)) return false;
  if (target.isContentEditable || target instanceof HTMLTextAreaElement) return true;
  return target instanceof HTMLInputElement && ['text', 'search', 'email', 'url', ''].includes(target.type);
}
/** §9.4: while someone is typing, new inbox items wait so nothing moves under their cursor. */
function typingNow(): boolean { return textEntry(document.activeElement) && Date.now() - lastTypedAt < 4000; }
function notificationsWanted(): boolean { try { return localStorage.getItem(NOTIFY_PREFERENCE) === '1'; } catch { return false; } }
function notifiedItems(): Set<string> { try { return new Set(JSON.parse(localStorage.getItem(NOTIFIED_ITEMS) ?? '[]') as string[]); } catch { return new Set(); } }
function rememberNotified(keys: string[]): void { try { localStorage.setItem(NOTIFIED_ITEMS, JSON.stringify(keys.slice(0, 200))); } catch { /* storage may be unavailable */ } }
/**
 * §9.4: browser notifications are opt-in and only for S1. Each item notifies once; an item that leaves the inbox
 * and comes back is a new event. Only the keys currently waiting are remembered, so turning notifications on does
 * not announce the backlog, and nothing is repeated to nag. A visible, focused page already shows the inbox.
 */
function notifyNewDecisions(entries: ReadonlyArray<{ key: string; kind: InboxKind; status: string; title: string; detail: string; open: () => Promise<void> }>): void {
  const waiting = entries.filter(entry => S1_STATUSES.has(entry.status));
  const seen = notifiedItems();
  const fresh = waiting.filter(entry => !seen.has(entry.key));
  rememberNotified(waiting.map(entry => entry.key));
  if (!fresh.length || !notificationsWanted() || typeof Notification === 'undefined' || Notification.permission !== 'granted') return;
  // With push on, the service worker already shows these, page open or not; showing them here too would be twice.
  if (pushSubscriptionId()) return;
  if (document.visibilityState === 'visible' && document.hasFocus()) return;
  for (const entry of fresh.slice(0, 3)) {
    const note = new Notification(`${inboxKindLabel(entry.kind)}：${entry.title.slice(0, 80)}`, { body: entry.detail.slice(0, 160), tag: entry.key });
    note.onclick = () => { window.focus(); note.close(); void entry.open().catch(error => message(errorMessage(error))); };
  }
}
const PUSH_SUBSCRIPTION = 'aeeis.push-subscription';
function pushSubscriptionId(): string { try { return localStorage.getItem(PUSH_SUBSCRIPTION) ?? ''; } catch { return ''; } }
const pushSupported = () => typeof navigator !== 'undefined' && 'serviceWorker' in navigator && typeof window !== 'undefined' && 'PushManager' in window && typeof Notification !== 'undefined';
/** iPhone and iPad deliver Web Push only to an app added to the home screen (iOS 16.4 and later). */
const needsHomeScreen = () => /iPhone|iPad|iPod/.test(navigator.userAgent) && !(window.matchMedia?.('(display-mode: standalone)').matches || (navigator as Navigator & { standalone?: boolean }).standalone);
function pushKeyBytes(value: string): Uint8Array {
  const raw = atob((value + '='.repeat((4 - value.length % 4) % 4)).replace(/-/g, '+').replace(/_/g, '/'));
  return Uint8Array.from(raw, character => character.charCodeAt(0));
}
async function syncPushToggle(): Promise<void> {
  const toggle = $<HTMLInputElement>('push-notify');
  const note = $('push-notify-note');
  if (!toggle || !note) return;
  if (!pushSupported()) { toggle.disabled = true; toggle.checked = false; note.textContent = needsHomeScreen() ? '在 iPhone 上先用 Safari 的「添加到主屏幕」装上 AEEIS，再从主屏幕打开，才能收到推送。' : '这个浏览器不支持推送。'; return; }
  const config = await api<{ web: { publicKey: string } | null }>('/push/config').catch(() => ({ web: null }));
  if (!config.web) { toggle.disabled = true; toggle.checked = false; note.textContent = '这个 AEEIS 没有打开推送。'; return; }
  const registration = await navigator.serviceWorker.getRegistration('/');
  const subscription = await registration?.pushManager.getSubscription();
  toggle.disabled = Notification.permission === 'denied';
  toggle.checked = Boolean(subscription && pushSubscriptionId());
  note.textContent = Notification.permission === 'denied' ? '浏览器拒绝了通知，要在浏览器设置里打开。' : toggle.checked ? '已打开：页面关着也会推到这台设备，同一件事只推一次。' : '默认关闭。打开后，页面关着也能收到审批、提问和阻塞。';
}
async function changePush(): Promise<void> {
  const toggle = $<HTMLInputElement>('push-notify');
  if (!toggle || !pushSupported()) return;
  const registration = await navigator.serviceWorker.register('/sw.js', { scope: '/' });
  const existing = await registration.pushManager.getSubscription();
  if (!toggle.checked) {
    const id = pushSubscriptionId();
    if (id) await api(`/push/subscriptions/${encodeURIComponent(id)}`, undefined, 'DELETE').catch(() => undefined);
    await existing?.unsubscribe();
    try { localStorage.removeItem(PUSH_SUBSCRIPTION); } catch { /* storage may be unavailable */ }
    await syncPushToggle(); return;
  }
  try {
    if (Notification.permission !== 'granted' && await Notification.requestPermission() !== 'granted') { await syncPushToggle(); return; }
    const config = await api<{ web: { publicKey: string } | null }>('/push/config');
    if (!config.web) { await syncPushToggle(); return; }
    await navigator.serviceWorker.ready;
    const subscription = existing ?? await registration.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: pushKeyBytes(config.web.publicKey) as BufferSource });
    const json = subscription.toJSON() as { endpoint?: string; keys?: { p256dh?: string; auth?: string } };
    const label = /iPhone|iPad/.test(navigator.userAgent) ? 'iPhone 主屏幕' : /Android/.test(navigator.userAgent) ? 'Android 浏览器' : '这台电脑的浏览器';
    const created = await api<{ id: string }>('/push/subscriptions', { channel: 'web', label, endpoint: json.endpoint, keys: { p256dh: json.keys?.p256dh, auth: json.keys?.auth } });
    try { localStorage.setItem(PUSH_SUBSCRIPTION, created.id); } catch { /* storage may be unavailable */ }
  } finally { await syncPushToggle(); }
}
$('push-notify')?.addEventListener('change', () => { void changePush().catch(error => { message(errorMessage(error)); void syncPushToggle(); }); });
// The service worker makes AEEIS installable; a push click focuses an open page and asks it to open the item.
if (!readOnlyShare && typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
  void navigator.serviceWorker.register('/sw.js', { scope: '/' }).then(() => syncPushToggle()).catch(() => undefined);
  navigator.serviceWorker.addEventListener('message', event => {
    const data = event.data as { type?: string; url?: string } | undefined;
    if (data?.type === 'aeeis.open' && typeof data.url === 'string' && new URL(data.url, window.location.origin).origin === window.location.origin) window.location.assign(data.url);
  });
} else if (!readOnlyShare) void syncPushToggle();
/** A push for a channel block links to `/#room=<id>`. */
async function openLinkedRoom(): Promise<void> {
  const roomId = /^#room=([^&]+)$/.exec(window.location.hash)?.[1];
  if (!roomId) return;
  window.history.replaceState(null, '', window.location.pathname + window.location.search);
  await openGroup(decodeURIComponent(roomId)).catch(error => message(errorMessage(error)));
}
function syncNotifyToggle(): void {
  const toggle = $<HTMLInputElement>('attention-notify');
  const note = $('attention-notify-note');
  if (!toggle || !note) return;
  const supported = typeof Notification !== 'undefined';
  toggle.disabled = !supported || Notification.permission === 'denied';
  toggle.checked = supported && notificationsWanted() && Notification.permission === 'granted';
  note.textContent = !supported ? '这个浏览器不支持通知。' : Notification.permission === 'denied' ? '浏览器拒绝了通知，要在浏览器设置里打开。' : toggle.checked ? '只在页面不在前台时提醒，同一件事只提醒一次。' : '默认关闭。';
}
async function changeNotifications(): Promise<void> {
  const toggle = $<HTMLInputElement>('attention-notify');
  if (!toggle) return;
  const wanted = toggle.checked && typeof Notification !== 'undefined' && (Notification.permission === 'granted' || await Notification.requestPermission() === 'granted');
  try { localStorage.setItem(NOTIFY_PREFERENCE, wanted ? '1' : '0'); } catch { /* storage may be unavailable */ }
  syncNotifyToggle();
}
$('attention-notify')?.addEventListener('change', () => { void changeNotifications().catch(error => message(errorMessage(error))); });
syncNotifyToggle();
function renderAttentionInbox(runs: RunSummary[]): void {
  lastInboxRuns = runs;
  if (typingNow()) {
    if (!inboxHold) inboxHold = window.setTimeout(function release() { inboxHold = typingNow() ? window.setTimeout(release, 1000) : 0; if (!inboxHold) renderAttentionInbox(lastInboxRuns); }, 1000);
    return;
  }
  const panel = $('attention-inbox');
  const list = $('attention-items');
  const count = $('attention-count');
  if (!panel || !list || !count) return;
  const items: Array<{ key: string; kind: InboxKind; title: string; detail: string; at?: string | undefined; status: string; selected: boolean; open: () => Promise<void>; quick: string; act: () => Promise<void> }> = [];
  for (const run of runs) {
    const kind = inboxKind(run.status);
    if (!kind) continue;
    const [label, next] = attentionCopy(run.status);
    items.push({
      key: `run:${run.id}:${run.status}`, kind, title: runTitle(run), detail: `${label} · ${next}`, at: run.updatedAt, status: run.status, selected: run.id === currentId,
      open: () => openAttentionRun(run),
      quick: kind === 'failure' ? '查看原因' : kind === 'approval' ? '查看计划' : kind === 'unknown' ? '核查' : '补充',
      act: () => openAttentionRun(run),
    });
  }
  // The derivation depth limit stopped an automatic chain at this Run. It
  // waits until its owner acknowledges it; acknowledging never resumes it.
  for (const run of runs) {
    const block = run.derivationBlocked;
    if (!block || block.acknowledgedAt) continue;
    const acknowledge = async () => { await api(`/runs/${encodeURIComponent(run.id)}/derivation-block/acknowledge`, {}, 'POST'); await refresh(true); };
    items.push({
      key: `derivation:${run.id}:${block.at}`, kind: 'derivation', title: runTitle(run),
      detail: `自动派生链已到 ${block.limit} 跳上限，没有再创建${block.kind === 'project_pulse' ? '后续计划' : '协作'}。要继续就手动开始一次。`,
      at: block.at, status: 'derivation_blocked', selected: run.id === currentId,
      open: () => openAttentionRun(run), quick: '知道了', act: acknowledge,
    });
  }
  // A channel block waits for a person even when no Run asks; it counts as a question.
  for (const hold of boardHoldings) {
    if (!hold.blocked) continue;
    const open = async () => { await openGroup(hold.roomId); await showChannelBoard(); };
    items.push({
      key: `block:${hold.roomId}:${hold.conversationId}:${hold.taskId}:${hold.blockedAt ?? ''}`, kind: 'question', title: hold.title ?? '频道里的事', detail: `阻塞：${hold.blocked}${hold.roomTitle ? ` · ${hold.roomTitle}` : ''}`, at: hold.blockedAt, status: 'blocked', selected: false,
      open, quick: '去处理', act: open,
    });
  }
  for (const message of conversation?.messages ?? []) {
    if (message.route.status !== 'clarify') continue;
    if (conversation?.messages.some(item => item.correctsMessageId === message.id)) continue;
    items.push({
      key: `mention:${message.id}`, kind: 'mention', title: message.text, detail: '需要你明确选择任务。还没有执行。', at: message.createdAt, status: 'mention', selected: false,
      open: async () => { prepareConversationReply(message); openConversationRoute(); },
      quick: '查看',
      act: async () => { prepareConversationReply(message); openConversationRoute(); },
    });
  }
  const stamp = (at?: string) => { const value = Date.parse(at ?? ''); return Number.isFinite(value) ? value : 0; };
  items.sort((left, right) => inboxSeverity(left.kind) - inboxSeverity(right.kind) || stamp(left.at) - stamp(right.at));
  notifyNewDecisions(items);
  syncNotifyToggle();
  const attention = items.slice(0, 8);
  if (!attention.length) attentionInboxOpen = false;
  const attentionToggle = $('attention-toggle') as HTMLButtonElement | null;
  if (attentionToggle) {
    attentionToggle.hidden = attention.length === 0;
    attentionToggle.dataset.count = String(attention.length);
    attentionToggle.dataset.state = attention.length ? 'attention' : 'idle';
  }
  setAttentionInboxOpen(attentionInboxOpen);
  panel.hidden = attention.length === 0 || !attentionInboxOpen;
  count.textContent = attention.length ? `${attention.length} 项待处理` : '';
  const paletteCount = $('command-attention-count');
  if (paletteCount) paletteCount.textContent = attention.length ? `${attention.length} 项` : '暂无';
  list.replaceChildren();
  for (const entry of attention) {
    const age = inboxAge(entry.at, entry.kind);
    const item = element('div', '', `attention-item ${entry.status}${entry.selected ? ' is-selected' : ''}`);
    item.dataset.inbox = entry.kind;
    item.dataset.age = age.level;
    item.setAttribute('role', 'button');
    item.tabIndex = 0;
    item.onclick = () => void entry.open().catch(error => message(errorMessage(error)));
    item.onkeydown = event => {
      if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); void entry.open().catch(error => message(errorMessage(error))); }
    };
    item.setAttribute('aria-label', `${inboxKindLabel(entry.kind)}：${entry.title}`);
    const marker = element('span', '', 'attention-marker');
    const body = element('span', '', 'attention-body');
    const heading = element('span', '', 'attention-heading');
    heading.append(element('strong', inboxKindLabel(entry.kind)), element('small', age.label));
    body.append(heading, element('span', entry.title.slice(0, 120), 'attention-goal'), element('small', entry.detail, 'attention-next'));
    const meta = entry.at && Number.isFinite(Date.parse(entry.at)) ? formatTime(entry.at) : '刚刚更新';
    const quickAction = button(entry.quick, () => entry.act());
    quickAction.className = 'attention-quick-action';
    // Stop at the bubble phase: stopping in a capture listener on the button itself
    // also cancels the button's own click handler.
    quickAction.addEventListener('click', event => event.stopPropagation());
    item.append(marker, body, element('time', meta, 'attention-time'), quickAction, element('span', '↗', 'attention-arrow'));
    list.append(item);
  }
}
function runMatchesFilter(run: RunSummary): boolean {
  if (runFilter === 'active') return ACTIVE_STATUSES.has(run.status);
  if (runFilter === 'attention') return ATTENTION_STATUSES.has(run.status);
  if (runFilter === 'done') return DONE_STATUSES.has(run.status);
  return true;
}
function timelineMatchesFilter(type: string): boolean {
  return timelineFilter === 'all' || timelineTone(type) === timelineFilter;
}
function renderTimelineFilterState(): void {
  document.querySelectorAll<HTMLButtonElement>('#timeline-filters [data-timeline-filter]').forEach(control => {
    const active = control.dataset.timelineFilter === timelineFilter;
    control.classList.toggle('is-active', active);
    control.setAttribute('aria-pressed', String(active));
  });
}
function renderRunQueue(runs: RunSummary[]): void {
  const list = $('runs');
  if (!list) return;
  const visible = runs.filter(runMatchesFilter);
  list.replaceChildren();
  for (const run of visible) {
    const item = button('', async () => {
      leaveGroup();
      document.body.classList.remove('roster-focus');
      document.body.classList.add('draft-open');
      if (currentId === run.id && current) {
        setCurrentRunOpen(true);
        $('run-workspace')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
      }
      currentId = run.id;
      localStorage.setItem('aeeis.run', run.id);
      current = undefined;
      await refresh();
    });
    item.className = `roster-row task-row${run.id === currentId && currentRunOpen && !openGroupId ? ' selected' : ''}`;
    item.dataset.status = run.status;
    const presence = presenceOf(run.status);
    const dot = element('span', '', 'task-dot');
    dot.dataset.state = presence.state;
    const copy = element('span', '', 'roster-copy');
    copy.append(element('strong', runTitle(run)), element('small', presence.label));
    item.append(dot, copy);
    list.append(item);
  }
  syncBotRow();
  const count = $('run-count');
  if (count) count.textContent = `${visible.length} / ${runs.length} 项任务`;
  const empty = $('runs-empty');
  if (empty) {
    empty.hidden = visible.length > 0;
    empty.textContent = runs.length ? '当前筛选没有任务。' : '还没有任务。先发一条消息。';
  }
  document.querySelectorAll<HTMLButtonElement>('#run-filters [data-run-filter]').forEach(control => {
    const active = control.dataset.runFilter === runFilter;
    control.classList.toggle('is-active', active);
    control.setAttribute('aria-pressed', String(active));
  });
}
function renderMinimalRecentRuns(runs: RunSummary[]): void {
  const container = $('minimal-recent-runs');
  const toggle = $('recent-runs-toggle') as HTMLButtonElement | null;
  if (!container) return;
  const recent = runs.slice(0, 5);
  if (!recent.length) {
    setRecentRunsOpen(false);
    if (toggle) toggle.hidden = true;
    container.hidden = true;
    container.replaceChildren();
    return;
  }
  if (toggle) {
    toggle.hidden = false;
    toggle.textContent = recentRunsOpen ? '隐藏最近运行' : `最近运行 · ${recent.length}`;
  }
  container.hidden = !recentRunsOpen;
  container.replaceChildren();
  container.append(element('span', '最近运行', 'minimal-recent-label'));
  for (const run of recent) {
    const item = button('', async () => {
      if (currentId === run.id && current) {
        setCurrentRunOpen(true);
        $('run-workspace')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
      }
      setCurrentRunOpen(true);
      currentId = run.id;
      current = undefined;
      localStorage.setItem('aeeis.run', currentId);
      setRecentRunsOpen(false);
      await refresh();
      $('run-workspace')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
    item.className = `minimal-run-chip${run.id === currentId ? ' is-selected' : ''}`;
    item.dataset.status = run.status;
    item.title = runTitle(run);
    item.append(element('strong', runTitle(run).slice(0, 44)), element('small', runStatusLabel(run.status)));
    container.append(item);
  }
}
function setLiveConnection(state: 'idle' | 'connecting' | 'connected' | 'reconnecting' | 'offline'): void {
  const live = $('live-connection');
  if (!live) return;
  const labels: Record<typeof state, string> = {
    idle: '等待运行', connecting: '连接中…', connected: '实时同步', reconnecting: '重连中…', offline: '浏览器离线',
  };
  live.dataset.state = state;
  const label = live.querySelector('span');
  if (label) label.textContent = labels[state];
}
function setSystemSignal(state: 'loading' | 'connected' | 'attention' | 'offline'): void {
  const signal = $('system-signal');
  if (!signal) return;
  const labels: Record<typeof state, string> = {
    loading: '正在检查运行服务…',
    connected: '运行服务已连接 · 可以开始任务',
    attention: '运行服务未就绪 · 打开设置查看',
    offline: '无法连接运行服务 · 稍后重试',
  };
  signal.dataset.state = state;
  const label = signal.querySelector('span');
  if (label) label.textContent = labels[state];
}
function renderThreadTimeline(page: ThreadPage, throughSequence?: number): void {
  $('thread-panel').hidden = false;
  $('thread-title').textContent = page.title ?? '对话 Thread';
  $('thread-meta').textContent = throughSequence === undefined ? page.id : `只读分享 · 截至运行 #${throughSequence}`;
  const list = $('thread-timeline'); list.replaceChildren();
  for (const run of page.runs) {
    const item = element('li', '', 'fact-row');
    item.append(element('strong', `#${run.threadSequence} · ${runStatusLabel(run.status)} · ${runTitle(run)}`));
    if (run.outputExcerpt) item.append(element('pre', run.outputExcerpt.slice(0, 1000)));
    if (run.parentRunId) {
      if (readOnlyShare) item.append(element('small', `父运行 #${page.runs.find(parent => parent.id === run.parentRunId)?.threadSequence ?? ''}`));
      else { const link = element('a', '父运行'); link.href = `/runs/${run.parentRunId}`; item.append(link); }
    }
    if (!readOnlyShare) { const link = element('a', '打开运行'); link.href = `/runs/${run.id}`; item.append(link); }
    item.append(button(run.status === 'needs_input' && !readOnlyShare ? '回答当前问题' : '查看运行', async () => {
      currentId = run.id; await refresh();
      if (run.status === 'needs_input' && !readOnlyShare) openInputPanel('answer');
      else $('run-title').focus();
    }));
    list.append(item);
  }
  if (!page.runs.length) list.append(element('li', '还没有可显示的运行。', 'muted'));
  $('thread-followup').hidden = readOnlyShare;
  $('thread-share-controls').hidden = readOnlyShare;
  $('thread-more').hidden = readOnlyShare || page.nextAfterSequence === undefined;
  if (readOnlyShare) return;
  // Preserve the parent's selection while an ambiguous POST can be retried,
  // including a root POST whose run has appeared since its response was lost.
  if (pendingFollowup) { $<HTMLButtonElement>('thread-submit').disabled = followupSubmitting; return; }
  const select = $<HTMLSelectElement>('thread-parent'), previous = select.value;
  const parents = page.runs.filter(run => ['succeeded', 'failed', 'cancelled'].includes(run.status));
  select.replaceChildren(...parents.map(run => { const option = element('option', `#${run.threadSequence} · ${runTitle(run)}`); option.value = run.id; return option; }));
  if (parents.some(run => run.id === previous)) select.value = previous;
  else if (parents.length) {
    select.value = parents.at(-1)!.id;
    $<HTMLSelectElement>('thread-privacy').value = parents.at(-1)!.privacy ?? 'internal';
  }
  select.disabled = !parents.length;
  $<HTMLButtonElement>('thread-submit').disabled = Boolean(page.runs.length && !parents.length);
  $('thread-followup-note').textContent = !page.runs.length ? '提交后创建第一个运行。' : parents.length ? '后续消息会创建新运行。' : '运行结束后可以继续；当前问题请使用「回答当前问题」。';
}
async function refreshThread(): Promise<void> {
  try {
    const pages = await Promise.all(threadPagesAfter.map(after => api<ThreadPage>(`/threads/${linkedThreadId}?limit=50&afterSequence=${after}`)));
    threadRuns = pages.flatMap(page => page.runs);
    threadNextAfter = pages.at(-1)!.nextAfterSequence;
    renderThreadTimeline({ ...pages[0]!, runs: threadRuns, ...(threadNextAfter === undefined ? {} : { nextAfterSequence: threadNextAfter }) });
    currentId ||= threadRuns.at(-1)?.id ?? '';
    if (!currentId) { stopRunEventStream(); $('detail').hidden = true; return; }
    const run = await api<RunView>(`/runs/${currentId}`);
    if (['succeeded', 'failed', 'cancelled'].includes(run.status)) stopRunEventStream(); else ensureRunEventStream(run.id);
    const [graphs, explanation] = await Promise.all([api<RunGraphsView>(`/runs/${run.id}/graphs`), api<RunExplanation>(`/runs/${run.id}/explanation`)]);
    current = { ...run, graphs }; setCurrentRunOpen(true); render(current); renderExplanation(explanation);
  } catch (error) {
    stopRunEventStream(); current = undefined; $('detail').hidden = true; $('thread-panel').hidden = true;
    throw error;
  }
}
/** Lists that change rarely and panels people seldom open. The 2-second background
 * tick reuses them and reads them again every 30 seconds; any other refresh reads all. */
const SLOW_REFRESH_MS = 30_000;
let slowRefreshAt = 0;
let slowLists: { candidates: EvolutionSummary[]; signals: ImprovementSignalSummary[]; competitions: CompetitionSummary[]; debates: DebateSummary[]; projections: ProjectionSummary[]; agents: AgentSummary[]; triggerPolicies: TriggerPolicySummary[]; triggerDecisions: TriggerDecisionSummary[]; reminderPage: ReminderPage } | undefined;
async function refresh(background = false): Promise<void> {
  if (readOnlyShare) {
    try {
      const view = await api<(RunView & { explanation: RunExplanation }) | ThreadShareView>(`/share/${shareToken}`);
      if ('kind' in view && view.kind === 'thread') {
        document.body.classList.add('thread-page');
        renderThreadTimeline({ ...view.thread, runs: view.runs.map(run => ({ ...run, threadSequence: run.threadSequence!, outputExcerpt: run.artifacts.at(-1)?.content ?? '' })) }, view.throughSequence);
        const run = view.runs.find(run => run.id === currentId) ?? view.runs.at(-1);
        if (!run) { current = undefined; currentId = ''; $('detail').hidden = true; return; }
        currentId = run.id; current = run;
        setCurrentRunOpen(true); setRunDetailsMode(true); render(run); renderExplanation(run.explanation);
      } else {
        const run = view as RunView & { explanation: RunExplanation };
        currentId = run.id; current = run;
        setCurrentRunOpen(true); setRunDetailsMode(true);
        render(run); renderExplanation(run.explanation);
      }
      $('controls').replaceChildren();
      $('decision-review-actions').replaceChildren();
      $('decision-next-button').hidden = true;
      $('input-panel').hidden = true;
    } catch (error) {
      current = undefined; $('detail').hidden = true; $('thread-panel').hidden = true;
      throw error;
    }
    return;
  }
  if (linkedThreadId) { await refreshThread(); return; }
  if (conversationEnabled) await refreshConversation().catch(error => { $('conversation-error').textContent = errorMessage(error); });
  const reminderQuery = reminderStatusFilter ? `&status=${encodeURIComponent(reminderStatusFilter)}` : '';
  const full = !background || !slowLists || Date.now() - slowRefreshAt >= SLOW_REFRESH_MS;
  const slow = full
    ? Promise.all([
      api<EvolutionSummary[]>('/evolution/candidates?limit=50'), api<ImprovementSignalSummary[]>('/evolution/signals?limit=50').catch(() => []),
      api<{ items: CompetitionSummary[] }>('/collaborations/competitions/page?limit=12').then(page => page.items), api<{ items: DebateSummary[] }>('/collaborations/debates/page?limit=12').then(page => page.items), api<ProjectionSummary[]>('/collaborations/projections?limit=12'), api<AgentSummary[]>('/agents?limit=50').catch(() => []),
      api<TriggerPolicySummary[]>('/collaborations/triggers/policies?limit=12').catch(() => []), api<TriggerDecisionSummary[]>('/collaborations/triggers/decisions?limit=20').catch(() => []), api<ReminderPage>(`/reminders/page?limit=20${reminderQuery}`).catch(() => ({ items: [] } as ReminderPage)),
    ]).then(([candidates, signals, competitions, debates, projections, agents, triggerPolicies, triggerDecisions, reminderPage]) => ({ candidates, signals, competitions, debates, projections, agents, triggerPolicies, triggerDecisions, reminderPage }))
    : Promise.resolve(slowLists!);
  const [runPage, goals, allRooms, owned, lists] = await Promise.all([
    api<RunPage>('/runs/page?limit=50'), api<GoalPage>('/goals/page?limit=50').then(page => page.goals), api<RoomSummary[]>('/rooms'),
    api<OwnedBotView[]>('/bots').catch(() => null), slow,
  ]);
  if (full) { slowLists = lists; slowRefreshAt = Date.now(); }
  const { candidates, signals, competitions, debates, projections, agents, triggerPolicies, triggerDecisions, reminderPage } = lists;
  const runs = runPage.items;
  runSummaries = runs;
  sideThreadRooms = allRooms.filter(room => room.description === SIDE_THREAD);
  const rooms = allRooms.filter(room => room.description !== SIDE_THREAD);
  roomSummaries = rooms;
  agentSummaries = agents;
  agentsLoaded = true;
  if (owned) {
    ownedBotRecords = owned.map(ownedRosterBot);
    if (conversationEnabled) updateConversationControls();
  }
  await adoptLocalBots();
  reminderItems = reminderPage.items; reminderNextCursor = reminderPage.nextCursor;
  await loadBoardHoldings();
  renderAttentionInbox(runs);
  if (full && openGroupId) void renderChannelUpgrades(openGroupId).catch(error => message(errorMessage(error)));
  if (full) { await renderRooms(rooms); await renderGoals(goals, runs, rooms); renderCandidates(candidates); renderImprovementSignals(signals); renderCollaborations(competitions, debates, projections, triggerPolicies, triggerDecisions); renderAgents(agents); renderReminders(reminderItems); }
  renderBotRoster();
  renderGroups(rooms);
  updateConversationControls();
  if (selectedCandidateId) await renderCandidateDetail().catch(error => message(errorMessage(error)));
  renderRunQueue(runs);
  renderMinimalRecentRuns(runs);
  const requestedId = currentId;
  const epoch = entryEpoch;
  if (!requestedId) { stopRunEventStream(); setCurrentRunOpen(false); return; }
  let run: RunView;
  try { run = await api<RunView>(`/runs/${requestedId}`); }
  catch (error) {
    // A local data directory or tenant can change between sessions. Do not
    // leave the workbench stuck on a stale selection when its Run disappeared.
    if (error instanceof Error && /Unknown run|HTTP 404/.test(error.message)) {
      if (currentId === requestedId && entryEpoch === epoch) {
        currentId = ''; current = undefined; localStorage.removeItem('aeeis.run'); setCurrentRunOpen(false);
      }
      return;
    }
    throw error;
  }
  if (currentId !== requestedId || entryEpoch !== epoch) return;
  if (DONE_STATUSES.has(run.status)) stopRunEventStream();
  else ensureRunEventStream(requestedId);
  const [graphs, explanation] = await Promise.all([
    api<RunGraphsView>(`/runs/${requestedId}/graphs`),
    api<RunExplanation>(`/runs/${requestedId}/explanation`),
  ]);
  if (currentId !== requestedId || entryEpoch !== epoch) return;
  const keepGroup = Boolean(openGroupId) || document.body.classList.contains('group-draft');
  if (current?.id === run.id && current.revision === run.revision) {
    if (!currentRunOpen && !keepGroup) {
      setCurrentRunOpen(true);
      render(current);
      renderExplanation(explanation);
    }
    return;
  }
  current = { ...run, graphs };
  if (keepGroup) return;
  if (!currentRunOpen) setCurrentRunOpen(true);
  render(current); renderExplanation(explanation);
}

function reminderQueryString(cursor?: string): string {
  const params = new URLSearchParams({ limit: '20' });
  if (cursor) params.set('cursor', cursor);
  if (reminderStatusFilter) params.set('status', reminderStatusFilter);
  return `?${params}`;
}
function renderReminders(items: ReminderSummary[]): void {
  const list = $('reminders'); if (!list) return;
  list.replaceChildren(); $('reminders-empty').hidden = items.length > 0;
  for (const reminder of items) {
    const item = element('div', '', `fact-row reminder-${reminder.status}`);
    item.append(element('strong', `${runStatusLabel(reminder.status)} · ${reminder.title}`), element('small', `${formatTime(reminder.dueAt)} · ${reminder.delivery.channel} → ${reminder.delivery.destination} · ${privacyLabel(reminder.privacy)}`), element('small', reminder.message));
    if (reminder.recurrence) {
      const rule = reminder.recurrence.calendar;
      const schedule = rule ? `${frequencyLabel(rule.frequency)} · ${rule.timeZone} ${rule.time}${rule.daysOfWeek ? ` · 星期 ${rule.daysOfWeek.join(',')}` : ''}${rule.dayOfMonth ? ` · 每月 ${rule.dayOfMonth} 日` : ''}` : `每 ${reminder.recurrence.intervalMs! / 60_000} 分钟`;
      item.append(element('small', `${schedule} · 已投影 ${reminder.occurrence}${reminder.recurrence.maxOccurrences ? ` / ${reminder.recurrence.maxOccurrences}` : ''} 次`));
    }
    if (reminder.lastError) item.append(element('small', `错误：${reminder.lastError}`, 'failure'));
    const controls = element('div', '', 'collaboration-actions');
    if (['scheduled', 'failed'].includes(reminder.status)) controls.append(button('取消', async () => { await api(`/reminders/${encodeURIComponent(reminder.id)}/cancel`, {}); await refresh(); }));
    if (['failed', 'cancelled'].includes(reminder.status)) controls.append(button('重试', async () => { await api(`/reminders/${encodeURIComponent(reminder.id)}/retry`, {}); await refresh(); }));
    if (controls.childElementCount) item.append(controls);
    list.append(item);
  }
  const more = $('reminders-more') as HTMLButtonElement;
  if (more) { more.hidden = !reminderNextCursor; more.disabled = false; }
}
async function loadMoreReminders(): Promise<void> {
  if (!reminderNextCursor) return;
  const page = await api<ReminderPage>(`/reminders/page${reminderQueryString(reminderNextCursor)}`);
  reminderItems = [...reminderItems, ...page.items]; reminderNextCursor = page.nextCursor; renderReminders(reminderItems);
}

function queueEventStreamRefresh(): void {
  if (eventStreamRefreshQueued) return;
  eventStreamRefreshQueued = true;
  setTimeout(() => {
    eventStreamRefreshQueued = false;
    if (!document.hidden && currentId) void refresh().catch(error => message(errorMessage(error)));
  }, 0);
}

function waitForOnline(signal: AbortSignal): Promise<void> {
  if (navigator.onLine) return Promise.resolve();
  return new Promise(resolve => {
    const onOnline = (): void => { cleanup(); resolve(); };
    const onAbort = (): void => { cleanup(); resolve(); };
    const cleanup = (): void => {
      window.removeEventListener('online', onOnline);
      signal.removeEventListener('abort', onAbort);
    };
    window.addEventListener('online', onOnline, { once: true });
    signal.addEventListener('abort', onAbort, { once: true });
  });
}

async function consumeRunEventStream(runId: string, generation: number): Promise<void> {
  const controller = eventStreamAbort;
  if (!controller) return;
  setLiveConnection('connecting');
  let reconnectDelay = 500;
  let reconnectNoticeShown = false;
  while (!controller.signal.aborted && generation === eventStreamGeneration && currentId === runId) {
    const params = new URLSearchParams({ limit: '100', waitMs: '25000', heartbeatMs: '10000' });
    if (eventStreamCursor) params.set('cursor', eventStreamCursor);
    try {
      const token = getToken();
      const response = await fetch(`/api/runs/${encodeURIComponent(runId)}/events/stream?${params}`, { headers: token ? { authorization: `Bearer ${token}` } : {}, signal: controller.signal });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      if (!response.body) throw new Error('Run event stream has no response body');
      setLiveConnection('connected');
      reconnectDelay = 500;
      reconnectNoticeShown = false;
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      for (;;) {
        const next = await reader.read();
        if (next.done) break;
        buffer += decoder.decode(next.value, { stream: true });
        let boundary = buffer.indexOf('\n\n');
        while (boundary >= 0) {
          const frame = buffer.slice(0, boundary); buffer = buffer.slice(boundary + 2); boundary = buffer.indexOf('\n\n');
          let id: string | undefined; let name = 'message';
          for (const line of frame.split(/\r?\n/)) {
            if (line.startsWith('id: ')) id = line.slice(4).trim();
            else if (line.startsWith('event: ')) name = line.slice(7).trim();
          }
          if (id && /^\d+$/.test(id)) eventStreamCursor = btoa(JSON.stringify({ seq: Number(id) })).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
          // Any event refreshes the Run; the timeline and the transcript card show what changed.
          if (name !== 'heartbeat' && name !== 'timeout') queueEventStreamRefresh();
        }
      }
    } catch (error) {
      if (controller.signal.aborted || generation !== eventStreamGeneration) return;
      if (!navigator.onLine) {
        setLiveConnection('offline');
        await waitForOnline(controller.signal);
        if (controller.signal.aborted || generation !== eventStreamGeneration) return;
        setLiveConnection('connecting');
        continue;
      }
      setLiveConnection('reconnecting');
      if (!reconnectNoticeShown && error instanceof Error && error.name !== 'AbortError') {
        reconnectNoticeShown = true;
        message(`Run 事件流暂时不可用，正在重连：${errorMessage(error)}`);
      }
      await new Promise(resolve => setTimeout(resolve, reconnectDelay));
      reconnectDelay = Math.min(5000, reconnectDelay * 2);
    }
  }
}

let eventStreamGeneration = 0;
function ensureRunEventStream(runId: string): void {
  if (eventStreamRunId === runId && eventStreamAbort && !eventStreamAbort.signal.aborted) return;
  eventStreamGeneration += 1;
  eventStreamAbort?.abort();
  eventStreamRunId = runId;
  eventStreamCursor = undefined;
  eventStreamAbort = new AbortController();
  const generation = eventStreamGeneration;
  void consumeRunEventStream(runId, generation);
}
function stopRunEventStream(): void {
  eventStreamGeneration += 1;
  eventStreamAbort?.abort(); eventStreamAbort = undefined; eventStreamRunId = ''; eventStreamCursor = undefined;
  setLiveConnection('idle');
}
let signalsRendered = '';
function renderImprovementSignals(signals: ImprovementSignalSummary[]): void {
  const list = $('improvement-signals'); if (!list) return;
  const signature = JSON.stringify(signals); if (signalsRendered === signature) return; signalsRendered = signature;
  list.replaceChildren(); $('improvement-signals-empty').hidden = signals.length > 0;
  for (const signal of signals) {
    const item = element('div', '', 'fact-row');
    item.append(element('strong', `${signal.kind} · ${signal.candidateId ? '已形成候选' : signal.proposal ? '待评测' : '待补全提案'}`), element('small', `${signal.reason} · ${formatTime(signal.occurredAt)}`), element('small', `Run ${signal.runId} · 证据 ${signal.sourceRefs.join(', ')}`));
    if (signal.synthesis) {
      const attempt = signal.synthesis;
      const label = attempt.error ? attempt.error : attempt.state === 'completed' ? (attempt.hasProposal ? '已生成提案' : '证据不足，未提出改动') : attempt.state === 'unknown' ? '结果不明，等待核查' : attempt.state === 'started' ? '已预留调用；执行中或中断待核查' : '提案生成失败';
      item.append(element('small', `提案器：${label} · Tokens ${attempt.usage?.tokens ?? '未报告'}`));
      if (['started', 'unknown'].includes(attempt.state)) {
        const details = element('details'); details.append(element('summary', '核查提案调用'));
        details.append(element('p', '填写供应商确认的结果和用量。此操作保存核查结果，不会重新调用模型。'));
        const form = element('form');
        const payload = element('textarea'); payload.rows = 10; payload.required = true;
        payload.value = JSON.stringify({ outcome: 'completed', output: { proposal: null }, usage: { inputTokens: null, outputTokens: null }, reconciliation: { source: 'provider', reference: '', reason: '' } }, null, 2);
        const field = element('label', '供应商核查回执（JSON；请填写真实用量）'); field.append(payload);
        const submit = element('button', '保存核查结果'); submit.type = 'submit';
        const status = element('p'); status.setAttribute('role', 'status'); form.append(field, submit, status);
        form.onsubmit = event => {
          event.preventDefault(); submit.disabled = true;
          void Promise.resolve().then(() => api(`/runs/${signal.runId}/rsi-proposal-synthesis-reconcile`, { ...JSON.parse(payload.value), attemptId: attempt.id, inputHash: attempt.inputHash, idempotencyKey: attempt.idempotencyKey })).then(() => refresh()).catch(error => { status.textContent = errorMessage(error); submit.disabled = false; });
        };
        details.append(form); item.append(details);
      }
    }
    if (signal.candidateId) item.append(button('查看候选', async () => { selectedCandidateId = signal.candidateId!; localStorage.setItem('aeeis.candidate', selectedCandidateId); await renderCandidateDetail(); $('candidate-detail').scrollIntoView({ block: 'center' }); }));
    list.append(item);
  }
}
function renderAgents(agents: AgentSummary[]): void {
  const list = $('agents'); list.replaceChildren(); $('agents-empty').hidden = agents.length > 0;
  for (const agent of agents) {
    const item = element('div', '', `fact-row agent-${agent.status}`);
    const reputation = Object.entries(agent.reputation.dimensions).map(([key, value]) => `${key} ${value.toFixed(2)}`).join(' · ');
    item.append(element('strong', `${runStatusLabel(agent.status)} · ${agent.card.name}`), element('small', `${agent.agentId} · ${agent.card.owner} · v${agent.card.cardVersion}`), element('small', `${agent.card.capabilities.join(', ') || '无声明能力'}${agent.card.endpoint ? ` · ${agent.card.endpoint}` : ''}`), element('small', `信誉样本 ${agent.reputation.samples} 条 · ${reputation}`));
    const controls = element('div');
    if (agent.status === 'discovered') controls.append(button('批准', async () => { await api(`/agents/${encodeURIComponent(agent.agentId)}/admit`, {}); await refresh(); }));
    if (agent.status === 'admitted') controls.append(button('撤销', async () => { await api(`/agents/${encodeURIComponent(agent.agentId)}/revoke`, {}); await refresh(); }));
    controls.append(button('查看审计', async () => {
      const events = await api<AgentAuditEvent[]>(`/agents/${encodeURIComponent(agent.agentId)}/audit`);
      const details = element('details', '', 'inline-inspection');
      details.open = true;
      details.append(element('summary', '审计记录'));
      if (events.length) {
        const list = element('ul');
        for (const event of events) list.append(element('li', `${event.action} · ${event.actor} · ${formatTime(event.at)}`));
        details.append(list);
      } else details.append(element('p', '没有审计事件。', 'muted'));
      item.querySelector(':scope > .inline-inspection')?.remove();
      item.append(details);
    }));
    item.append(controls); list.append(item);
  }
}
function collaborationCostText(usage: CollaborationUsageView | undefined, budget?: CollaborationBudgetView): string {
  if (!usage) return '尚无调用用量汇总';
  const limits = budget ? Object.entries(budget).map(([key, value]) => `${key}=${value}`).join(' / ') : '';
  return `${usage.calls} 次模型调用 · ${usage.tokens} 已报告 tokens${usage.moneyUsd === undefined ? '' : ` · 估算 USD $${usage.moneyUsd.toFixed(6)}`}${usage.unreportedTokenCalls ? ` · ${usage.unreportedTokenCalls} 次 token 未确认` : ''}${usage.unreportedMoneyCalls ? ` · ${usage.unreportedMoneyCalls} 次 USD 未确认` : ''}${limits ? ` · 阈值 ${limits}` : ''}`;
}
function renderRuntimeStatus(status: RuntimeStatus): void {
  const modelHealthDetail = status.modelHealth
    ? [status.modelHealth.detail, status.modelHealth.catalog ? `目录：${status.modelHealth.catalog.detail ?? (status.modelHealth.catalog.ready ? '可用' : '不可用')}` : '', status.modelHealth.provider ? `供应商：${status.modelHealth.provider.detail ?? (status.modelHealth.provider.ready ? '可用' : '不可用')}` : ''].filter(Boolean).join(' · ')
    : '';
  const items: Array<[string, boolean, string]> = [
    ['模型', Boolean(status.modelConfigured && status.modelHealth?.ready), status.model ? `${status.model.model}${modelHealthDetail ? ` · ${modelHealthDetail}` : ''}` : (status.modelRouting === 'catalog' ? `目录路由${modelHealthDetail ? ` · ${modelHealthDetail}` : ''}` : '未配置')],
    ['执行器', Boolean(status.dispatcherHealth?.ready), `${runtimeLabel(status.runner)}${status.dispatcherHealth?.detail ? ` · ${status.dispatcherHealth.detail}` : ''}`],
    ['工具', Boolean(status.toolsConfigured && status.toolsHealth?.ready), status.toolsConfigured ? status.toolsHealth?.detail ?? '已配置，健康状态未验证' : '未配置'],
    ['Goal / Plan / Task', status.domainConfigured, status.domainConfigured ? '已启用' : '未启用'],
    ['DAG 调度', status.taskSchedulerConfigured, status.taskSchedulerConfigured ? '已启用' : '未启用'],
    ['Brain 语义检索', Boolean(status.brainSemanticSearchConfigured && status.brainSemanticIndexHealth?.ready), status.brainSemanticSearchConfigured ? (status.brainSemanticIndexHealth?.detail ?? 'pgvector / embedding，健康状态未验证') : '词法或未配置'],
    ['Knowledge', status.knowledgeConfigured, status.knowledgeConfigured ? '已启用' : '未启用'],
    ['项目源', status.projectSourcesConfigured, status.projectSourcesConfigured ? '已启用' : '未启用'],
    ['外部 Agent', status.agentGatewayConfigured, status.agentRegistryConfigured ? 'Gateway + Registry' : 'Gateway'],
    ['RSI 状态', status.evolutionConfigured, status.rsiAutomation?.enabled ? `内测自动进化${status.rsiAutomation.autoActivate ? ' · 自动激活' : ' · 等待激活'} · ${status.rsiAutomation.suiteVersion ?? 'suite'}` : status.rsiProposalSynthesisConfigured ? '信号 → 提案 → evaluator → Canary' : status.rsiEvaluatorConfigured ? '候选 + evaluator' : '候选存储'],
    ['RSI evaluator', Boolean(status.rsiEvaluatorConfigured && status.rsiEvaluatorHealth?.ready), status.rsiEvaluatorConfigured ? (status.rsiEvaluatorHealth?.detail ?? '已配置，健康状态未验证') : '未配置'],
    ['多 Agent 协作', status.collaborationConfigured, status.collaborationConfigured ? 'Competition / Debate' : '未启用'],
    ['Skill 治理', Boolean(status.skillGovernanceConfigured && status.skillGovernanceHealth?.ready), status.skillGovernanceConfigured ? `OwnHow${status.skillGovernanceHealth?.detail ? ` · ${status.skillGovernanceHealth.detail}` : ''}` : '未启用'],
    ['投影记录', status.projectionConfigured, status.projectionConfigured ? 'Outbox 已启用' : '未启用'],
    ['外部投递', Boolean(status.projectionSinkConfigured && status.projectionSinkHealth?.ready), status.projectionSinkConfigured ? (status.projectionSinkHealth?.detail ?? '已配置，健康状态未验证') : '未配置投递渠道'],
  ];
  const grid = $('system-status'); grid.replaceChildren();
  for (const [label, ready, detail] of items) {
    const card = element('div', '', `status-card ${ready ? 'ready' : 'off'}`);
    card.append(element('strong', `${ready ? '●' : '○'} ${label}`), element('small', detail)); grid.append(card);
  }
  $('system-status').setAttribute('data-mode', status.mode);
  $('system-status').setAttribute('data-profile', status.executionProfile ?? 'unverified');
}
function parsePromptJson(label: string, fallback: unknown = undefined): unknown {
  const value = window.prompt(label, fallback === undefined ? '' : JSON.stringify(fallback));
  if (value === null) return undefined;
  try { return JSON.parse(value); } catch { throw new Error(`${label}必须是有效 JSON`); }
}
function showCollaborationDetails(parent: HTMLElement, label: string, value: unknown): void {
  const details = element('details', '', 'inline-inspection');
  details.open = true;
  details.append(element('summary', label), element('pre', JSON.stringify(value, null, 2)));
  parent.querySelector(':scope > .inline-inspection')?.remove();
  parent.append(details);
}
async function reconcileCompetitionAttempt(competitionId: string, attempt: NonNullable<CompetitionSummary['attempts']>[number]): Promise<void> {
  const outcome = window.prompt(`核查 Competition 参与者 ${attempt.participantAgentId}：completed 或 failed`, 'completed');
  if (!outcome || !['completed', 'failed'].includes(outcome)) return;
  const reason = window.prompt('核查说明（必填）')?.trim(); if (!reason) return;
  const usage = parsePromptJson('provider usage（可选 JSON，例如 {"tokens":123,"moneyUsd":0.02}）');
  const result = outcome === 'completed' ? parsePromptJson('最终 Result Envelope（必填 JSON）') : undefined;
  await api(`/collaborations/competitions/${encodeURIComponent(competitionId)}/reconcile-attempt`, { attemptId: attempt.id, outcome, reason, ...(usage === undefined ? {} : { usage }), ...(result === undefined ? {} : { result }) });
  await refresh();
}
async function reconcileCompetitionEvaluator(competitionId: string, attempt: NonNullable<CompetitionSummary['evaluatorAttempt']>): Promise<void> {
  const outcome = window.prompt('核查 Competition evaluator：completed 或 failed', 'completed');
  if (!outcome || !['completed', 'failed'].includes(outcome)) return;
  const reason = window.prompt('核查说明（必填）')?.trim(); if (!reason) return;
  const usage = parsePromptJson('provider usage（可选 JSON，例如 {"tokens":123,"moneyUsd":0.02}）');
  const scores = outcome === 'completed' ? parsePromptJson('候选评分数组（必填 JSON）') : undefined;
  await api(`/collaborations/competitions/${encodeURIComponent(competitionId)}/reconcile-evaluator`, { attemptId: attempt.id, outcome, reason, ...(usage === undefined ? {} : { usage }), ...(scores === undefined ? {} : { scores }) });
  await refresh();
}
async function reconcileDebateAttempt(debateId: string, attempt: NonNullable<DebateSummary['attempts']>[number]): Promise<void> {
  const outcome = window.prompt(`核查 Debate 尝试 ${attempt.slot}：completed 或 failed`, 'completed');
  if (!outcome || !['completed', 'failed'].includes(outcome)) return;
  const reason = window.prompt('核查说明（必填）')?.trim(); if (!reason) return;
  const usage = parsePromptJson('provider usage（可选 JSON，例如 {"tokens":123,"moneyUsd":0.02}）');
  const output = outcome === 'completed' ? parsePromptJson('提供方输出（completed 时必填 JSON）') : undefined;
  await api(`/collaborations/debates/${encodeURIComponent(debateId)}/reconcile-attempt`, { attemptId: attempt.id, outcome, reason, ...(usage === undefined ? {} : { usage }), ...(output === undefined ? {} : { output }) });
  await refresh();
}
async function reconcileTriggerDecision(decision: TriggerDecisionSummary): Promise<void> {
  const hasResource = Boolean(decision.resourceId);
  const options = hasResource ? ['dispatch_completed', 'dispatch_failed'] : ['resource_created', 'failed'];
  const outcome = window.prompt(`核查 Trigger ${decision.id}：${options.join(' 或 ')}`, options[0]);
  if (!outcome || !options.includes(outcome)) return;
  const reason = window.prompt('核查说明（必填）')?.trim(); if (!reason) return;
  const resourceId = outcome === 'resource_created' ? window.prompt('已核实的 Competition/Debate ID（必填）')?.trim() : undefined;
  if (outcome === 'resource_created' && !resourceId) return;
  await api(`/collaborations/triggers/decisions/${encodeURIComponent(decision.id)}/reconcile`, { outcome, reason, ...(resourceId ? { resourceId } : {}) });
  await refresh();
}
function renderCollaborations(competitions: CompetitionSummary[], debates: DebateSummary[], projections: ProjectionSummary[], triggerPolicies: TriggerPolicySummary[], triggerDecisions: TriggerDecisionSummary[]): void {
  const competitionList = $('competitions'); competitionList.replaceChildren(); $('competitions-empty').hidden = competitions.length > 0;
  for (const competition of competitions.slice(0, 12)) {
    const item = element('div', '', `fact-row collaboration-${competition.status}`);
    item.append(element('strong', `${runStatusLabel(competition.status)} · ${competition.brief.goal.slice(0, 48)}`), element('small', `${competition.candidates.length}/${competition.brief.participantAgentIds.length} 个候选 · ${competition.scores.length} 个评分${competition.selectedAgentId ? ` · 已选 ${competition.selectedAgentId}` : ''}`), element('small', collaborationCostText(competition.usage, competition.brief.modelBudget)), element('small', competition.failureReason ?? ''), element('small', formatTime(competition.updatedAt)));
    item.append(button('查看详情', async () => { showCollaborationDetails(item, `Competition ${competition.id}`, await api(`/collaborations/competitions/${encodeURIComponent(competition.id)}`)); }));
    if (['collecting', 'running'].includes(competition.status)) item.append(button('运行 Competition', async () => { await api(`/collaborations/competitions/${encodeURIComponent(competition.id)}/run`, {}); await refresh(); }));
    for (const attempt of competition.attempts ?? []) if (['started', 'unknown'].includes(attempt.state)) item.append(button(`核查参与者 ${attempt.participantAgentId}`, () => reconcileCompetitionAttempt(competition.id, attempt)));
    if (competition.evaluatorAttempt && ['started', 'unknown'].includes(competition.evaluatorAttempt.state)) item.append(button('核查 evaluator', () => reconcileCompetitionEvaluator(competition.id, competition.evaluatorAttempt!)));
    competitionList.append(item);
  }
  const debateList = $('debates'); debateList.replaceChildren(); $('debates-empty').hidden = debates.length > 0;
  for (const debate of debates.slice(0, 12)) {
    const item = element('div', '', `fact-row debate-${debate.status}`);
    const flagged = debate.room.moderation?.filter(item => item.status === 'flagged').length ?? 0;
    const adjudication = debate.room.adjudication?.status ? ` · 裁决${runStatusLabel(debate.room.adjudication.status)}` : '';
    const unsettled = debate.attempts?.filter(item => ['started', 'unknown'].includes(item.state)).length ?? 0;
    item.append(element('strong', `${runStatusLabel(debate.status)} · ${(debate.room.goal ?? debate.room.taskId).slice(0, 48)}`), element('small', `${debate.room.messages.length} 条消息 · ${debate.room.participantAgentIds.length} 个 Agent${flagged ? ` · ${flagged} 条被标记` : ''}${unsettled ? ` · ${unsettled} 条待处理` : ''}${adjudication}`), element('small', collaborationCostText(debate.usage, debate.modelBudget)), element('small', debate.closeReason ?? ''), element('small', formatTime(debate.updatedAt)));
    item.append(button('查看消息与裁决', async () => { showCollaborationDetails(item, `Debate ${debate.id}`, await api(`/collaborations/debates/${encodeURIComponent(debate.id)}`)); }));
    if (debate.status === 'active') item.append(button('运行 Debate', async () => { await api(`/collaborations/debates/${encodeURIComponent(debate.id)}/run`, {}); await refresh(); }));
    for (const attempt of debate.attempts ?? []) if (['started', 'unknown'].includes(attempt.state)) item.append(button(`核查 ${attempt.slot}`, () => reconcileDebateAttempt(debate.id, attempt)));
    if (debate.status === 'active') item.append(button('关闭 Debate', async () => { const reason = window.prompt('关闭原因（必填）')?.trim(); if (reason) { await api(`/collaborations/debates/${encodeURIComponent(debate.id)}/close`, { reason }); await refresh(); } }));
    debateList.append(item);
  }
  const projectionList = $('projections'); projectionList.replaceChildren(); $('projections-empty').hidden = projections.length > 0;
  for (const projection of projections.slice(-12).reverse()) {
    const item = element('div', '', `fact-row projection-${projection.status}`);
    item.append(element('strong', `${runStatusLabel(projection.status)} · ${projection.aggregateType}:${projection.aggregateId}`), element('small', `${projection.channel} → ${projection.destination} · ${projection.attempts} 次尝试`), element('small', projection.lastError ?? formatTime(projection.updatedAt)));
    projectionList.append(item);
  }
  const policyList = $('trigger-policies'); policyList.replaceChildren(); $('trigger-policies-empty').hidden = triggerPolicies.length > 0;
  for (const policy of triggerPolicies.slice(0, 12)) {
    const item = element('div', '', `fact-row trigger-policy-${policy.enabled ? 'enabled' : 'disabled'}`);
    item.append(element('strong', `${policy.enabled ? '启用' : '停用'} · ${policy.name}`), element('small', `${policy.id} · ${policy.eventTypes.join(', ')} · ${policy.action.type}/${policy.action.dispatch}`), element('small', `participants: ${policy.action.participantAgentIds.join(', ')}`), element('small', formatTime(policy.updatedAt)));
    item.append(button(policy.enabled ? '停用' : '启用', async () => { await api(`/collaborations/triggers/policies/${encodeURIComponent(policy.id)}`, { enabled: !policy.enabled }, 'PATCH'); await refresh(); }));
    item.append(button('删除', async () => { if (window.confirm(`删除 Trigger Policy ${policy.name}？`)) { await api(`/collaborations/triggers/policies/${encodeURIComponent(policy.id)}`, undefined, 'DELETE'); await refresh(); } }));
    policyList.append(item);
  }
  const decisionList = $('trigger-decisions'); decisionList.replaceChildren(); $('trigger-decisions-empty').hidden = triggerDecisions.length > 0;
  for (const decision of triggerDecisions.slice(0, 20)) {
    const item = element('div', '', `fact-row trigger-decision-${decision.state}`);
    item.append(element('strong', `${runStatusLabel(decision.state)} · ${decision.actionType}`), element('small', `${decision.policyId} · ${decision.eventId}`), element('small', `${runStatusLabel(decision.dispatchState)}${decision.resourceId ? ` · ${decision.resourceId}` : ''}`), element('small', decision.error ?? decision.dispatchError ?? formatTime(decision.startedAt)));
    if (decision.state !== 'failed' && !['completed', 'failed'].includes(decision.dispatchState)) item.append(button('核查', () => reconcileTriggerDecision(decision)));
    decisionList.append(item);
  }
}
async function renderRooms(rooms: RoomSummary[]): Promise<void> {
  const list = $('rooms'); list.replaceChildren(); $('rooms-empty').hidden = rooms.length > 0;
  const roomData = await Promise.all(rooms.map(async room => {
    const [members, events] = await Promise.all([
      api<RoomMemberSummary[]>(`/rooms/${encodeURIComponent(room.id)}/members`).catch(() => undefined),
      api<SessionEventPage>(`/rooms/${encodeURIComponent(room.id)}/session-events?limit=20`).catch(() => undefined),
    ]);
    return { members, events };
  }));
  for (const [index, room] of rooms.entries()) {
    const item = element('div', '', 'fact-row room-' + room.status);
    item.append(element('strong', room.title + ' · ' + runStatusLabel(room.status)), element('small', room.id + ' · ' + formatTime(room.updatedAt)));
    if (room.description) item.append(element('small', room.description));
    if (room.canArchive !== false && room.status === 'active') item.append(button('归档 Room', async () => { await api(`/rooms/${encodeURIComponent(room.id)}`, { status: 'archived', expectedRevision: room.revision ?? 0 }, 'PATCH'); await refresh(); }));
    if (room.canArchive && room.status === 'archived') item.append(button('恢复频道', async () => { await api(`/rooms/${encodeURIComponent(room.id)}`, { status: 'active', expectedRevision: room.revision ?? 0 }, 'PATCH'); await refresh(); }));
    const { members, events } = roomData[index]!;
    if (members !== undefined) {
      const memberList = element('div', '', 'room-members');
      memberList.append(element('small', `成员 ${members.length} 人`));
      for (const member of members) {
        const row = element('div', '', 'room-member');
        row.append(element('span', `${member.principalId} · ${roleLabel(member.role)} · ${runStatusLabel(member.status)}`));
        if (member.status === 'active') row.append(button('撤销', async () => { await api(`/rooms/${encodeURIComponent(room.id)}/members/${encodeURIComponent(member.principalId)}`, undefined, 'DELETE'); await refresh(); }));
        memberList.append(row);
      }
      const invite = document.createElement('form'); invite.className = 'room-invite';
      const principal = element('input') as HTMLInputElement; principal.placeholder = '成员 principalId'; principal.required = true; principal.maxLength = 200;
      const role = document.createElement('select'); for (const value of ['editor', 'viewer', 'agent'] as const) { const option = element('option', roleLabel(value)); option.value = value; role.append(option); }
      const submit = element('button', '邀请成员') as HTMLButtonElement; submit.type = 'submit';
      invite.append(principal, role, submit);
      invite.onsubmit = event => { event.preventDefault(); submit.disabled = true; void api(`/rooms/${encodeURIComponent(room.id)}/members`, { principalId: principal.value.trim(), role: role.value }).then(async () => { principal.value = ''; await refresh(); }).catch(error => message(errorMessage(error))).finally(() => { submit.disabled = false; }); };
      memberList.append(invite); item.append(memberList);
    }
    const session = element('div', '', 'room-session');
    session.append(element('strong', '规范事件时间线'));
    if (events === undefined) {
      session.append(element('small', '当前身份无法读取，或 Shared Session 尚未配置。'));
    } else if (events.items.length === 0) {
      session.append(element('small', '还没有 canonical event。消息、决策和任务更新会以事实事件写入这里。'));
    } else {
      const timeline = element('ol', '', 'session-timeline');
      for (const event of events.items) appendSessionEventRow(timeline, room.id, event, events.items);
      session.append(timeline);
      if (events.nextCursor) {
        let nextCursor = events.nextCursor;
        const more = button('加载后续事件', async () => {
          const page = await api<SessionEventPage>(`/rooms/${encodeURIComponent(room.id)}/session-events?limit=20&cursor=${encodeURIComponent(nextCursor)}`);
          const loadedEvents = [...events.items, ...page.items];
          for (const event of page.items) appendSessionEventRow(timeline, room.id, event, loadedEvents);
          if (page.nextCursor) nextCursor = page.nextCursor;
          else more.remove();
        });
        session.append(more);
      }
    }
    item.append(session);
    list.append(item);
  }
}
function appendSessionEventRow(timeline: HTMLOListElement, roomId: string, event: SessionEventSummary, visibleEvents: SessionEventSummary[]): void {
  const row = element('li', '', `session-event session-event-${event.type}`);
  const heading = element('div', '', 'session-event-heading');
  const revision = event.revision && event.revision > 1 ? ` · v${event.revision}` : '';
  const operation = event.operation && event.operation !== 'publish' ? ` · ${event.operation}` : '';
  heading.append(element('strong', `#${event.sequence} · ${event.type}${operation}${revision}`), element('small', `${event.actorId} · ${formatTime(event.createdAt)}`));
  row.append(heading, element('p', event.content));
  row.append(element('small', `${event.goalId ? `Goal ${event.goalId}` : 'Room 共享上下文'} · manifest ${event.contextManifestId} · ${privacyLabel(event.classification)} · audience ${event.audienceSnapshot.digest.slice(0, 12)}…`));
  if (event.targetEventId) row.append(element('small', `目标事件：${event.targetEventId}`));
  if (event.retractionReason) row.append(element('small', `撤回原因：${event.retractionReason}`));
  if (event.evidenceRefs.length > 0) row.append(element('small', `Evidence: ${event.evidenceRefs.join(', ')}`));
  const latest = !visibleEvents.some(candidate => candidate.targetEventId === event.id);
  if (event.type === 'canonical_response' && event.operation !== 'retract' && latest) {
    const actions = element('div', '', 'session-event-actions');
    actions.append(button('修订答复', async () => {
      const content = window.prompt('新的规范答复', event.content)?.trim();
      if (!content) return;
      const refs = window.prompt('Evidence 引用（逗号分隔，可留空）', event.evidenceRefs.join(','));
      await api(`/rooms/${encodeURIComponent(roomId)}/session-events/${encodeURIComponent(event.id)}/revise`, {
        content,
        ...(refs === null ? {} : { evidenceRefs: refs.split(',').map(value => value.trim()).filter(Boolean) }),
        idempotencyKey: `ui-revise-${event.id}-${crypto.randomUUID()}`,
      });
      await refresh();
    }));
    actions.append(button('撤回答复', async () => {
      const reason = window.prompt('撤回原因')?.trim();
      if (!reason) return;
      await api(`/rooms/${encodeURIComponent(roomId)}/session-events/${encodeURIComponent(event.id)}/retract`, {
        reason,
        idempotencyKey: `ui-retract-${event.id}-${crypto.randomUUID()}`,
      });
      await refresh();
    }));
    row.append(actions);
  }
  timeline.append(row);
}
async function openRun(id: string): Promise<void> {
  currentId = id; current = undefined; localStorage.setItem('aeeis.run', id); await refresh();
}
async function renderGoals(goals: GoalSummary[], runs: RunSummary[], rooms: RoomSummary[]): Promise<void> {
  const plans = await Promise.all(goals.map(async goal => {
    const goalPlans = (await api<{ plans: DomainPlanSummary[] }>(`/goals/${goal.id}/plans/page?limit=50`)).plans;
    const dispatches = taskSchedulerConfigured
      ? await Promise.all(goalPlans.map(async plan => ({ planId: plan.id, dispatches: await api<TaskDispatchSummary[]>(`/plans/${plan.id}/scheduler`).catch(() => []) })))
      : [];
    const memories = await api<MemoryView[]>(`/goals/${encodeURIComponent(goal.id)}/memories?limit=50`).catch(() => []);
    return { goalId: goal.id, plans: goalPlans, dispatches, memories };
  }));
  const signature = JSON.stringify({ goals, plans, runs, rooms, modelConfigured });
  if (goalViewSignature === signature) return;
  const opened = new Set(Array.from($('goals').querySelectorAll<HTMLDetailsElement>('details[open]')).map(item => item.dataset.planId));
  const list = $('goals'); list.replaceChildren(); $('goals-empty').hidden = goals.length > 0;
  const selector = $<HTMLSelectElement>('goal-id');
  const selected = selector.value;
  selector.replaceChildren(element('option', '不绑定，创建独立运行'));
  selector.options[0]!.value = '';
 for (const goal of goals) {
   const option = element('option', `${goal.title} · ${runStatusLabel(goal.status)}`);
   option.value = goal.id; selector.append(option);
 }
 if (goals.some(goal => goal.id === selected)) selector.value = selected;
  const roomSelector = $<HTMLSelectElement>('goal-room-id');
  const selectedRoom = roomSelector.value;
  roomSelector.replaceChildren(element('option', '不绑定 Room'));
  roomSelector.options[0]!.value = '';
  for (const room of rooms) {
    const option = element('option', `${room.title} · ${runStatusLabel(room.status)}`);
    option.value = room.id; roomSelector.append(option);
  }
  if (rooms.some(room => room.id === selectedRoom)) roomSelector.value = selectedRoom;
  const roomById = new Map(rooms.map(room => [room.id, room]));
 for (const goal of goals) {
   const item = element('div', '', 'fact-row');
    item.append(element('strong', goal.title), element('small', `${runStatusLabel(goal.status)} · ${new Date(goal.createdAt).toLocaleDateString()}${goal.roomId && roomById.has(goal.roomId) ? ` · Room: ${roomById.get(goal.roomId)!.title}` : ''}`));
    const goalData = plans.find(entry => entry.goalId === goal.id);
    if (goalData?.memories.length) {
      const memoryDetails = element('details');
      memoryDetails.append(element('summary', `Goal 记忆 · ${goalData.memories.length} 条（含历史版本）`));
      for (const memory of goalData.memories) {
        const row = element('div', '', `memory-row memory-${memory.state ?? 'active'}`);
        row.append(element('strong', `${runStatusLabel(memory.state ?? 'active')} · ${memory.kind} · v${memory.version ?? 1}`), element('small', `${privacyLabel(memory.classification)} · ${memory.source} · 置信度 ${memory.confidence.toFixed(2)}`), element('span', memory.content));
        if (memory.evidenceRefs?.length) row.append(element('small', `证据：${memory.evidenceRefs.join(', ')}`));
        if (memory.evidenceRunId) row.append(element('small', `证据来源 Run：${memory.evidenceRunId}`));
        if (memory.supersedesId) row.append(element('small', `修正自：${memory.supersedesId}`));
        if (memory.retractionReason) row.append(element('small', `撤回原因：${memory.retractionReason}`));
        if ((memory.state ?? 'active') === 'active') {
          row.append(button('修正', async () => {
            const content = window.prompt('新的记忆内容', memory.content)?.trim(); if (!content) return;
            const refs = window.prompt('证据引用（逗号分隔，可留空）', (memory.evidenceRefs ?? []).join(','));
            await api(`/goals/${encodeURIComponent(goal.id)}/memories/${encodeURIComponent(memory.id)}/correct`, { kind: memory.kind, content, scope: memory.scope, classification: memory.classification, source: memory.source, confidence: memory.confidence, ...(refs === null ? {} : { evidenceRefs: refs.split(',').map(value => value.trim()).filter(Boolean) }) });
            goalViewSignature = ''; await refresh();
          }));
          row.append(button('撤回', async () => { const reason = window.prompt('撤回原因')?.trim(); if (reason) { await api(`/goals/${encodeURIComponent(goal.id)}/memories/${encodeURIComponent(memory.id)}/retract`, { reason }); goalViewSignature = ''; await refresh(); } }));
        }
        memoryDetails.append(row);
      }
      item.append(memoryDetails);
    }
    for (const [index, plan] of (goalData?.plans ?? []).entries()) {
      const details = element('details'); details.dataset.planId = plan.id; details.open = opened.has(plan.id);
      details.append(element('summary', `${index === 0 ? '最新' : '历史'}计划 v${plan.version} · ${plan.nodes.length} 个任务`));
      const planDispatches = goalData?.dispatches.find(entry => entry.planId === plan.id)?.dispatches ?? [];
      if (index === 0 && goal.status === 'active' && modelConfigured && taskSchedulerConfigured) {
        details.append(button(planDispatches.length ? '继续调度 DAG' : '调度整张 DAG', async () => {
          await api(`/plans/${plan.id}/schedule`, goalExecutionOptions()); await refresh();
        }));
      } else if (index === 0 && goal.status === 'active' && modelConfigured && !taskSchedulerConfigured) {
        details.append(element('small', 'DAG 调度器未启用；可直接执行单个任务。', 'muted'));
      }
      if (planDispatches.length) {
        details.append(button('核查调度状态', async () => {
          await api(`/plans/${plan.id}/scheduler/reconcile`, {}); goalViewSignature = ''; await refresh();
        }));
      }
      for (const node of plan.nodes) {
        const row = element('div', '', 'task-row');
        row.append(element('span', `${runStatusLabel(node.status)} · ${node.title}`));
        if (node.instruction && node.instruction !== node.title) row.append(element('small', node.instruction));
        if (node.dependsOn.length) row.append(element('small', `依赖：${node.dependsOn.join(', ')}`));
        const execution = runs.find(run => run.taskExecution?.domainPlanId === plan.id && run.taskExecution.taskId === node.id)
          ?? runs.find(run => run.domainPlanId === plan.id && !run.taskExecution);
        if (execution) row.append(button(`查看执行 · ${runStatusLabel(execution.status)}`, () => openRun(execution.id)));
        const dispatch = planDispatches.find(item => item.taskId === node.id);
        if (dispatch) {
          row.append(element('small', `调度：${runStatusLabel(dispatch.state)} · ${dispatch.lastRunStatus ? runStatusLabel(dispatch.lastRunStatus) : '尚未观察到运行'} · ${dispatch.runner}${dispatch.lastError ? ` · ${dispatch.lastError}` : ''}`));
          const control = async (action: string, body: unknown = {}): Promise<void> => {
            await api(`/plans/${plan.id}/tasks/${encodeURIComponent(node.id)}/control/${action}`, body);
            goalViewSignature = ''; await refresh();
          };
          const status = dispatch.lastRunStatus;
          if (['queued', 'planning', 'running', 'reviewing'].includes(status ?? '')) {
            row.append(button('暂停', () => control('pause')));
            row.append(button('取消', () => control('cancel')));
          } else if (status === 'paused') {
            row.append(button('继续', () => control('resume')));
            row.append(button('取消', () => control('cancel')));
          } else if (status === 'unknown' || status === 'waiting_external') {
            row.append(button('核查并继续', async () => {
              const reason = window.prompt('核查说明（必填）')?.trim();
              if (reason) await control('reconcile', { reason });
            }));
            row.append(button('取消', () => control('cancel')));
          } else if (status === 'needs_approval' || status === 'needs_input') {
            row.append(button('取消', () => control('cancel')));
          } else if (status === 'failed' && node.status === 'failed') {
            row.append(button('重试此任务', async () => {
              await api(`/plans/${plan.id}/tasks/${encodeURIComponent(node.id)}/transition`, { transition: 'retry', reason: '用户从调度器控制面发起重试' });
              await control('retry');
            }));
          }
        } else if (!execution && node.status === 'ready' && goal.status === 'active') {
          if (taskSchedulerConfigured) {
            const schedule = button('调度此任务', async () => {
              await api(`/plans/${plan.id}/tasks/${encodeURIComponent(node.id)}/schedule`, goalExecutionOptions()); goalViewSignature = ''; await refresh();
            });
            schedule.disabled = !modelConfigured; row.append(schedule);
          } else {
            row.append(element('small', '调度器未启用', 'muted'));
          }
          const start = button('直接执行此任务', async () => {
            const created = await api<{ id: string }>(`/plans/${plan.id}/tasks/${encodeURIComponent(node.id)}/run`, goalExecutionOptions());
            await openRun(created.id);
          });
          start.disabled = !modelConfigured; row.append(start);
        }
        if (node.evidenceRefs?.length) row.append(element('small', `证据：${node.evidenceRefs.join(', ')}`));
        if (node.evidenceRunId) row.append(button('查看来源运行', () => openRun(node.evidenceRunId!)));
        details.append(row);
      }
      details.append(button('查看任务回执', async () => {
        const snapshot = await api<{ receipts: Array<{ taskId: string; transition: string; occurredAt: string; reason?: string }> }>(`/plans/${plan.id}/snapshot`);
        const inspection = element('details', '', 'inline-inspection');
        inspection.open = true;
        inspection.append(element('summary', '任务回执'));
        if (snapshot.receipts.length) {
          const list = element('ul');
          for (const receipt of snapshot.receipts) list.append(element('li', `${receipt.taskId} · ${receipt.transition} · ${formatTime(receipt.occurredAt)}${receipt.reason ? ` · ${receipt.reason}` : ''}`));
          inspection.append(list);
        } else inspection.append(element('p', '尚无执行回执。', 'muted'));
        details.querySelector(':scope > .inline-inspection')?.remove();
        details.append(inspection);
      }));
      item.append(details);
    }
    list.append(item);
  }
  goalViewSignature = signature;
}
function formatMaterialFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
function renderMaterialFiles(status?: string): void {
  const list = $('material-file-list');
  const label = $('material-files-status');
  const clear = $('clear-material-files') as HTMLButtonElement | null;
  if (!list || !label) return;
  list.replaceChildren();
  for (const file of selectedMaterialFiles) {
    const item = element('li');
    item.append(element('span', file.name), element('small', formatMaterialFileSize(file.size)));
    list.append(item);
  }
  if (clear) clear.hidden = selectedMaterialFiles.length === 0 && !materialFilesLoading;
  if (status) label.textContent = status;
  else if (materialFilesLoading) label.textContent = '正在读取资料…';
  else if (selectedMaterialFiles.length) label.textContent = `${selectedMaterialFiles.length} 个文件已绑定到本次 Run`;
  else label.textContent = '支持 TXT、Markdown、CSV、JSON 和 AcroForm PDF（最多 512 KB）；文件只绑定当前 Run。';
}
async function readMaterialFiles(files: FileList | null): Promise<void> {
  const sequence = ++materialFileReadSequence;
  const incoming = [...(files ?? [])];
  if (!incoming.length) return;
  materialFilesLoading = true;
  renderMaterialFiles();
  const accepted = incoming.slice(0, MAX_MATERIAL_FILES);
  const skipped: string[] = incoming.length > MAX_MATERIAL_FILES ? incoming.slice(MAX_MATERIAL_FILES).map(file => file.name) : [];
  const loaded: Array<{ name: string; content: string; size: number }> = [];
  for (const file of accepted) {
    const extension = file.name.toLocaleLowerCase().split('.').pop() ?? '';
    const pdf = extension === 'pdf' || file.type === 'application/pdf';
    const supported = pdf || ['txt', 'md', 'markdown', 'csv', 'json'].includes(extension) || ['text/plain', 'text/markdown', 'text/csv', 'application/json'].includes(file.type);
    if (!supported) { skipped.push(`${file.name}（不支持的文件格式）`); continue; }
    if (pdf && file.size > 512 * 1024) { skipped.push(`${file.name}（PDF 超过 512 KB）`); continue; }
    if (file.size > MAX_MATERIAL_FILE_BYTES) { skipped.push(`${file.name}（超过 1 MB）`); continue; }
    try {
      let content: string;
      if (pdf) {
        const bytes = new Uint8Array(await file.arrayBuffer());
        let binary = ''; for (const byte of bytes) binary += String.fromCharCode(byte);
        content = `data:application/pdf;base64,${btoa(binary)}`;
      } else content = (await file.text()).slice(0, MAX_MATERIAL_CONTENT_LENGTH).trim();
      if (!content) { skipped.push(`${file.name}（内容为空）`); continue; }
      loaded.push({ name: file.name.slice(0, 200), content, size: file.size });
    } catch { skipped.push(`${file.name}（读取失败）`); }
  }
  if (sequence !== materialFileReadSequence) return;
  selectedMaterialFiles = loaded;
  materialFilesLoading = false;
  renderMaterialFiles(skipped.length ? `已载入 ${loaded.length} 个文件；跳过 ${skipped.join('、')}` : undefined);
}
($('material-files') as HTMLInputElement | null)?.addEventListener('change', event => {
  void readMaterialFiles((event.target as HTMLInputElement).files).catch(error => {
    materialFilesLoading = false;
    renderMaterialFiles('资料读取失败，请重新选择文本文件');
    message(errorMessage(error));
  });
});
($('clear-material-files') as HTMLButtonElement | null)?.addEventListener('click', () => {
  materialFileReadSequence += 1;
  materialFilesLoading = false;
  selectedMaterialFiles = [];
  const input = $<HTMLInputElement>('material-files');
  if (input) input.value = '';
  renderMaterialFiles();
});
renderMaterialFiles();
function listedIds(id: string): string[] {
  return [...new Set($<HTMLInputElement>(id).value.split(',').map(value => value.trim()).filter(Boolean))];
}
function externalBudgetPresent(): boolean {
  return ['external-budget-calls', 'external-budget-tokens', 'external-budget-usd'].some(id => $<HTMLInputElement>(id).value.trim());
}
function conversationExecutionGoal(): string {
  const text = $<HTMLTextAreaElement>('conversation-text').value.trim();
  const target = $<HTMLSelectElement>('conversation-target').value;
  const title = target === '__new' ? $<HTMLInputElement>('conversation-task-title').value.trim() : (conversationTargetTask()?.title ?? '当前任务');
  return `任务：${title || '当前任务'}\n当前请求：${text}`;
}
function currentPlanningDecision(goal = conversationExecutionGoal()) {
  const builtinSkill = $<HTMLSelectElement>('builtin-skill').value;
  return planningDecision({
    goal,
    ...(builtinSkill ? { builtinSkill } : {}),
    allowedTools: listedIds('allowed-tools'),
    allowedAgents: listedIds('allowed-agents'),
    ...(externalBudgetPresent() ? { externalBudget: { calls: 1 } } : {}),
  });
}
function executionReviewValue(): 'required' | 'auto' | 'yolo' {
  const value = $<HTMLSelectElement>('execution-review')?.value;
  return value === 'auto' || value === 'yolo' ? value : 'required';
}
function restoreExecutionReview(): void {
  const saved = localStorage.getItem('aeeis.execution-review');
  const select = $<HTMLSelectElement>('execution-review');
  if (!select) return;
  // Default is auto: a small task runs, and a real plan waits. YOLO runs the plan too. A saved grant is restored once grants load.
  if (saved?.startsWith('grant:') && [...select.options].some(option => option.value === saved)) { select.value = saved; return; }
  select.value = saved === 'required' || saved === 'yolo' ? saved : 'auto';
}
function executionReviewNote(): string {
  const grant = selectedWorkGrant();
  if (grant) return `授权「${grant.title}」：计划在授权范围内就直接做，重新规划也不再等你；只在工作区里的动作直接执行，对外的动作仍先问你。${workGrantSummary(grant)}。`;
  const mode = executionReviewValue();
  const decision = currentPlanningDecision();
  const gate = mode === 'yolo'
    ? 'YOLO：抽出计划也直接做，不再停下来等批准。外部工具或代理的内容进来之后，写入和发送不会自动执行。'
    : mode === 'auto'
      ? (decision.shape === 'direct'
        ? '自动：这是一件小任务，直接做。写入、发送等动作由审批模型判断，拿不准就问你。'
        : '自动：这次会抽出一份计划，计划出来后再请你批准。写入、发送等动作由审批模型判断，拿不准就问你。')
      : (decision.shape === 'direct'
        ? '需要审批：这是一件小任务，仍等你点头再做。写入、发送等动作不在允许清单里时会先问你。'
        : '需要审批：抽出计划后，等你批准再做。写入、发送等动作不在允许清单里时会先问你。');
  const shape = decision.shape === 'direct'
    ? '这次直接执行：跳过规划模型，写入一个步骤，仍按上面的权限放行。'
    : `这次先出任务图：${planningRefusal(decision.reason)}。`;
  return `${gate}${shape}`;
}
/** One line under the entry composer: what the next run will use, read from the Settings fields it is sent with. */
function entryDefaultsText(): string {
  const review = executionReviewValue();
  const grant = selectedWorkGrant();
  if (grant) return `默认：授权「${grant.title}」 · ${workGrantSummary(grant)}`;
  const parts = [review === 'yolo' ? '计划不停，直接执行' : review === 'auto' ? '自动审核' : '每份计划都要你批准'];
  const money = $<HTMLInputElement>('model-budget-usd')?.value.trim();
  const tokens = $<HTMLInputElement>('model-budget-tokens')?.value.trim();
  parts.push(money ? `金额上限 $${money}` : '不设金额上限');
  if (tokens) parts.push(`${Number(tokens).toLocaleString()} tokens 上限`);
  const tools = $<HTMLInputElement>('allowed-tools') ? listedIds('allowed-tools') : [];
  parts.push(!tools.length ? '不调用工具' : tools.length <= 2 ? `工具：${tools.join('、')}` : `工具：${tools.slice(0, 2).join('、')} 等 ${tools.length} 个`);
  const privacy = $<HTMLSelectElement>('privacy');
  if (privacy) parts.push(`隐私：${privacy.selectedOptions[0]?.textContent ?? privacy.value}`);
  return `默认：${parts.join(' · ')}`;
}
function syncEntryDefaults(): void {
  const line = $('entry-defaults');
  if (!line) return;
  line.hidden = !conversation || !localBotCanExecute(lifeAgent(conversation)) || !['entry', 'bot'].includes(rosterView());
  $('entry-defaults-text').textContent = entryDefaultsText();
}
function goalExecutionOptions(): Record<string, unknown> {
  // Goal tasks keep plan approval; a grant chosen in the composer does not carry over to them.
  const { workGrantId: _grant, allowedTools: _tools, ...options } = runOptions(false);
  return { ...options, allowedTools: listedIds('allowed-tools'), executionReview: 'required' };
}
function runOptions(includeProjectQuery = true, goal = ''): Record<string, unknown> {
  const content = $<HTMLTextAreaElement>('materials').value.trim();
  const knowledgeQuery = $<HTMLInputElement>('knowledge-query').value.trim();
  const allowedTools = listedIds('allowed-tools');
  const allowedAgents = listedIds('allowed-agents');
  const brainScope = $<HTMLInputElement>('brain-scope').value.trim();
  const brainQuery = $<HTMLInputElement>('brain-query').value.trim();
  const memoryQuery = $<HTMLInputElement>('memory-query').value.trim();
  // A scheduled follow-up executes its task, rather than generating another report.
  const builtinSkill = includeProjectQuery ? $<HTMLSelectElement>('builtin-skill').value : '';
  const projectSourceQuery = includeProjectQuery ? $<HTMLInputElement>('project-source-query').value.trim() : '';
  const tokenField = $<HTMLInputElement>('model-budget-tokens');
  const moneyField = $<HTMLInputElement>('model-budget-usd');
  if (!tokenField.checkValidity() || !moneyField.checkValidity()) throw new Error('请填写有效的 token 或 USD 预算阈值');
  const externalBudget: { calls?: number; tokens?: number; moneyUsd?: number } = {};
  for (const [key, fieldId] of [['calls', 'external-budget-calls'], ['tokens', 'external-budget-tokens'], ['moneyUsd', 'external-budget-usd']] as const) {
    const field = $<HTMLInputElement>(fieldId);
    if (!field.checkValidity()) throw new Error('请填写有效的外部执行预算');
    if (field.value) externalBudget[key] = Number(field.value);
  }
  const modelBudget = { ...(tokenField.value ? { tokens: Number(tokenField.value) } : {}), ...(moneyField.value ? { moneyUsd: Number(moneyField.value) } : {}) };
  if (materialFilesLoading) throw new Error('资料仍在读取，请稍候再启动 Run');
  const materials = [
    ...(content ? [{ title: '用户提供的项目资料', source: 'user-input', content }] : []),
    ...selectedMaterialFiles.map(file => ({ title: file.name, source: `browser-file:${file.name}`, content: file.content })),
  ];
  const planning = includeProjectQuery ? currentPlanningDecision(goal || conversationExecutionGoal()).shape : undefined;
  // Under a grant the grant supplies tools, agents and the model budget, and decides which plans wait.
  const grant = selectedWorkGrant();
  const scope = grant
    ? { workGrantId: grant.grantId, allowedTools: [] as string[] }
    : { executionReview: executionReviewValue(), allowedTools, ...(allowedAgents.length ? { allowedAgents } : {}), ...(modelBudget && Object.keys(modelBudget).length ? { modelBudget } : {}) };
  return { ...scope, ...(planning ? { planning } : {}), ...(builtinSkill ? { builtinSkill } : {}), materials, privacy: $<HTMLSelectElement>('privacy').value, ...(Object.keys(externalBudget).length ? { externalBudget } : {}), ...(knowledgeQuery ? { knowledgeQuery } : {}), ...(memoryQuery ? { memoryQuery } : {}), ...(brainScope ? { brainScope } : {}), ...(brainQuery ? { brainQuery } : {}), ...(projectSourceQuery ? { projectSourceQuery } : {}) };
}
($('new-goal') as HTMLFormElement).onsubmit = event => {
  event.preventDefault(); message('');
  const form = $('new-goal') as HTMLFormElement;
  const submit = form.querySelector('button') as HTMLButtonElement; submit.disabled = true;
  const roomId = $<HTMLSelectElement>('goal-room-id').value;
  void api('/goals', { title: $<HTMLInputElement>('goal-title').value, description: $<HTMLTextAreaElement>('goal-description').value || undefined, ...(roomId ? { roomId } : {}) })
    .then(async () => { $<HTMLInputElement>('goal-title').value = ''; $<HTMLTextAreaElement>('goal-description').value = ''; await refresh(); })
    .catch(error => message(errorMessage(error))).finally(() => { submit.disabled = false; });
};
($('discover-agent') as HTMLFormElement).onsubmit = event => {
  event.preventDefault(); message('');
  const form = $('discover-agent') as HTMLFormElement; const submit = form.querySelector('button') as HTMLButtonElement; submit.disabled = true;
  let card: unknown;
  try { card = JSON.parse($<HTMLTextAreaElement>('agent-card').value); }
  catch { message('Agent Card 必须是有效 JSON'); submit.disabled = false; return; }
  void api('/agents/discover', card).then(async () => { $<HTMLTextAreaElement>('agent-card').value = ''; await refresh(); }).catch(error => message(errorMessage(error))).finally(() => { submit.disabled = false; });
};
($('discover-agent-url') as HTMLFormElement).onsubmit = event => {
  event.preventDefault(); message('');
  const form = $('discover-agent-url') as HTMLFormElement; const submit = form.querySelector('button') as HTMLButtonElement; submit.disabled = true;
  void api('/agents/discover-url', { url: $<HTMLInputElement>('agent-card-url').value.trim() })
    .then(async () => { $<HTMLInputElement>('agent-card-url').value = ''; await refresh(); })
    .catch(error => message(errorMessage(error))).finally(() => { submit.disabled = false; });
};
($('new-room') as HTMLFormElement).onsubmit = event => {
  event.preventDefault(); message('');
  const form = event.currentTarget as HTMLFormElement;
  const submit = form.querySelector('button') as HTMLButtonElement; submit.disabled = true;
  void api('/rooms', { title: $<HTMLInputElement>('room-title').value, description: $<HTMLTextAreaElement>('room-description').value || undefined })
    .then(async () => { $<HTMLInputElement>('room-title').value = ''; $<HTMLTextAreaElement>('room-description').value = ''; await refresh(); })
    .catch(error => message(errorMessage(error))).finally(() => { submit.disabled = false; });
};
function bindJsonForm(formId: string, fieldId: string, path: string, label: string): void {
  ($(formId) as HTMLFormElement).onsubmit = event => {
    event.preventDefault(); message('');
    const form = $(formId) as HTMLFormElement; const submit = form.querySelector('button') as HTMLButtonElement; submit.disabled = true;
    let body: unknown;
    try { body = JSON.parse($<HTMLTextAreaElement>(fieldId).value); }
    catch { message(`${label} 必须是有效 JSON`); submit.disabled = false; return; }
    void api(path, body).then(async () => { $<HTMLTextAreaElement>(fieldId).value = ''; await refresh(); }).catch(error => message(errorMessage(error))).finally(() => { submit.disabled = false; });
  };
}
bindJsonForm('new-competition', 'competition-brief', '/collaborations/competitions', 'Competition Brief');
bindJsonForm('new-debate', 'debate-brief', '/collaborations/debates', 'Debate Brief');
bindJsonForm('new-trigger-policy', 'trigger-policy', '/collaborations/triggers/policies', 'Trigger Policy');
function renderCandidates(candidates: EvolutionSummary[]): void {
  const list = $('candidates'); list.replaceChildren(); $('candidates-empty').hidden = candidates.length > 0;
  for (const candidate of candidates) {
    const passed = candidate.evaluations.filter(item => item.passed).length;
    const item = button('', async () => { selectedCandidateId = candidate.id; localStorage.setItem('aeeis.candidate', candidate.id); await renderCandidateDetail(); });
    item.className = `fact-row candidate-${candidate.status}${candidate.id === selectedCandidateId ? ' selected' : ''}`;
    item.append(element('strong', `${candidate.target} · ${candidate.proposedVersion}`), element('small', `${runStatusLabel(candidate.status)} · 风险 ${candidate.risk} · ${passed}/${candidate.evaluations.length} 个评估门${candidate.proposalSignalId ? ' · 自动发现' : ''}`)); list.append(item);
  }
}
async function candidateCommand(id: string, action: string, body: unknown = {}): Promise<void> {
  await api(`/evolution/candidates/${id}/${action}`, body); await refresh();
}
async function renderCandidateDetail(): Promise<void> {
  if (!selectedCandidateId) { $('candidate-detail').hidden = true; return; }
  const [candidate, traffic] = await Promise.all([
    api<EvolutionView>(`/evolution/candidates/${selectedCandidateId}`),
    api<EvolutionTrafficView[]>('/evolution/traffic').catch(() => [] as EvolutionTrafficView[]),
  ]);
  $('candidate-detail').hidden = false;
  $('candidate-title').textContent = `${candidate.target} · ${candidate.proposedVersion}`;
  $('candidate-status').textContent = `${runStatusLabel(candidate.status)} · 风险 ${candidate.risk}`;
  $('candidate-change').textContent = `${candidate.change}\n\n原因：${candidate.reason}\n基线：${candidate.baseVersion}`;
  const gates = $('candidate-gates'); gates.replaceChildren();
  for (const gate of candidate.evaluations) gates.append(element('li', `${gate.kind} · ${gate.passed ? '通过' : '未通过'}`));
  if (!candidate.evaluations.length) gates.append(element('li', '尚未运行评估门', 'muted'));
  const rollout = $('candidate-rollout'); rollout.replaceChildren();
  for (const observation of [...(candidate.shadowObservations ?? []).map(item => ({ ...item, phase: 'shadow' })), ...(candidate.canaryObservations ?? []).map(item => ({ ...item, phase: 'canary' }))]) {
    rollout.append(element('li', `${runStatusLabel(observation.phase)} · ${observation.id} · ${observation.passed ? '通过' : '未通过'} · ${observation.score}`));
  }
  for (const attempt of candidate.rolloutAttempts ?? []) {
    const row = element('li', `${runStatusLabel(attempt.phase)} · ${attempt.caseId} · ${runStatusLabel(attempt.state)}${attempt.error ? ` · ${attempt.error}` : ''}`, attempt.state === 'failed' ? 'failure' : '');
    rollout.append(row);
    if (attempt.state === 'started') {
      const reconcile = button('Reconcile this attempt', async () => {
        const reason = window.prompt('核查原因（必填）')?.trim(); if (!reason) return;
        const passed = window.confirm('外部 evaluator 是否确认通过？');
        const scoreText = window.prompt('分数（0 到 1）', passed ? '1' : '0')?.trim();
        const score = Number(scoreText);
        const evidence = window.prompt('证据引用，逗号分隔', attempt.id)?.split(',').map(value => value.trim()).filter(Boolean);
        if (!Number.isFinite(score) || score < 0 || score > 1 || !evidence?.length) throw new Error('需要有效分数和至少一个证据引用');
        await candidateCommand(candidate.id, 'reconcile-rollout', { attemptId: attempt.id, outcome: 'completed', passed, score, evidenceRefs: evidence, reason });
      });
      rollout.append(reconcile);
    }
  }
  if (!rollout.children.length) rollout.append(element('li', '尚未有 rollout observation 或 attempt', 'muted'));
  const trafficList = $('candidate-traffic'); trafficList.replaceChildren();
  const routes = traffic.filter(route => route.candidateId === candidate.id);
  for (const route of routes) {
    trafficList.append(element('li', `${runStatusLabel(route.status)} · ${route.percentage / 100}% · ${route.version} · ${route.rolloutRef}${route.lastReason ? ` · ${route.lastReason}` : ''}`));
    for (const observation of route.observations ?? []) trafficList.append(element('li', `观察 ${observation.id} · ${observation.passed ? '通过' : '失败'} · ${observation.score} · ${observation.evidenceRefs.join(', ')}`));
  }
  if (!routes.length) trafficList.append(element('li', '当前没有生产流量 route', 'muted'));
  const controls = $('candidate-controls'); controls.replaceChildren();
  const allRequiredPassed = ['replay', 'holdout', 'safety'].every(kind => candidate.evaluations.some(item => item.kind === kind && item.passed));
  if (['evaluating', 'held'].includes(candidate.status) && allRequiredPassed) controls.append(button('批准候选', async () => { const approvalRef = window.prompt('审批引用（必填）')?.trim(); if (approvalRef) await candidateCommand(candidate.id, 'approve', { approvalRef }); }));
  if (candidate.status === 'approved' && candidate.risk === 'low') controls.append(button('晋升低风险候选', () => candidateCommand(candidate.id, 'promote')));
  if (candidate.status === 'approved' && candidate.risk !== 'low') controls.append(button('开始 Shadow', () => candidateCommand(candidate.id, 'start-shadow')));
  const shadowReady = (candidate.shadowObservations?.length ?? 0) >= (candidate.risk === 'high' ? 5 : candidate.risk === 'medium' ? 3 : 1) && (candidate.shadowObservations ?? []).every(item => item.passed);
  if (candidate.status === 'shadowing' && shadowReady) controls.append(button('开始 Canary', () => candidateCommand(candidate.id, 'start-canary')));
  if (candidate.status === 'canarying' && (candidate.canaryObservations?.length ?? 0) > 0) controls.append(button('晋升 Canary 候选', () => candidateCommand(candidate.id, 'promote')));
  if (candidate.status === 'promoted' && ['profile', 'prompt'].includes(candidate.target)) controls.append(button('激活到新 Run', async () => { const activationRef = window.prompt('激活引用（必填）')?.trim(); if (activationRef) await candidateCommand(candidate.id, 'activate', { activationRef }); }));
  const route = routes.find(item => item.status === 'active' || item.status === 'paused');
  if (candidate.status === 'promoted' && !route) controls.append(button('开始生产流量 Canary', async () => {
    const percentage = Number(window.prompt('流量百分比（1 到 99.99）', '5'));
    const rolloutRef = window.prompt('发布引用（必填）')?.trim();
    if (Number.isInteger(Math.round(percentage * 100)) && percentage > 0 && percentage < 100 && rolloutRef) await candidateCommand(candidate.id, 'start-traffic', { percentage: Math.round(percentage * 100), rolloutRef });
  }));
  if (route?.status === 'active') {
    controls.append(button('调整流量比例', async () => {
      const percentage = Number(window.prompt('流量百分比（1 到 99.99）', String(route.percentage / 100)));
      const rolloutRef = window.prompt('变更引用（必填）')?.trim();
      if (Number.isInteger(Math.round(percentage * 100)) && percentage > 0 && percentage < 100 && rolloutRef) await candidateCommand(candidate.id, 'update-traffic', { percentage: Math.round(percentage * 100), rolloutRef });
    }));
    controls.append(button('暂停生产流量', async () => { const reason = window.prompt('暂停原因（必填）')?.trim(); if (reason) await candidateCommand(candidate.id, 'pause-traffic', { reason }); }));
  }
  if (route?.status === 'paused') controls.append(button('恢复生产流量', async () => { const rolloutRef = window.prompt('恢复引用（必填）')?.trim(); if (rolloutRef) await candidateCommand(candidate.id, 'resume-traffic', { rolloutRef }); }));
  if (route && route.status !== 'stopped') controls.append(button('停止生产流量', async () => { const reason = window.prompt('停止原因（必填）')?.trim(); if (reason) await candidateCommand(candidate.id, 'stop-traffic', { reason }); }));
  if (route && route.status !== 'stopped') controls.append(button('记录线上观察', async () => {
    const id = window.prompt('观察 ID（必填）')?.trim();
    const score = Number(window.prompt('分数（0 到 1）', '1'));
    const passed = window.confirm('这次线上观察是否通过？');
    const evidence = window.prompt('证据引用，逗号分隔')?.split(',').map(value => value.trim()).filter(Boolean);
    if (id && Number.isFinite(score) && score >= 0 && score <= 1 && evidence?.length) await candidateCommand(candidate.id, 'record-traffic', { id, passed, score, evidenceRefs: evidence });
  }));
  if (['approved', 'shadowing', 'canarying', 'held', 'promoted'].includes(candidate.status)) controls.append(button('回滚候选', async () => { const reason = window.prompt('回滚原因（必填）')?.trim(); if (reason) await candidateCommand(candidate.id, 'rollback', { reason }); }));
}
function canTakeOver(run: RunView): boolean {
  return !run.takeover && run.steps.length > 0 && ['running', 'reviewing', 'paused'].includes(run.status);
}
async function takeOverRun(run: RunView): Promise<void> {
  if (!window.confirm(`接管「${runTitle(run)}」？Bot 会停下，由你来做。做完后写一句说明交还，Bot 从你做到的地方接着做。接管不绕过审批。`)) return;
  await command('takeover');
}
interface TakeoverActionView { at: string; toolId: string; summary: string; status: string; receiptId: string }
interface TakeoverToolResponse { status: string; output?: unknown; actions: TakeoverActionView[] }
const takeoverToolLabels: Record<string, string> = { shell: '命令', python: 'Python', read: '打开', write: '保存', diff: '对比', glob: '列文件', grep: '搜索', process: '后台进程' };
/** Built once per taken-over Run so a refresh never wipes what the person is typing; only the log is redrawn. */
let takeoverWorkspace: { runId: string; log: HTMLOListElement } | undefined;
function renderTakeoverActions(log: HTMLOListElement, actions: TakeoverActionView[]): void {
  log.replaceChildren(...actions.map(action => {
    const row = element('li', '', 'takeover-action');
    row.dataset.status = action.status;
    row.append(element('time', formatTime(action.at)), element('strong', takeoverToolLabels[action.toolId] ?? action.toolId), element('span', action.summary || '—'), element('small', runStatusLabel(action.status)));
    return row;
  }));
  if (!actions.length) log.append(element('li', '还没有在工作区里做事。', 'muted'));
}
function takeoverOutputText(output: unknown): string {
  if (output && typeof output === 'object') {
    const value = output as { stdout?: string; stderr?: string; exitCode?: number; error?: string; paths?: string[]; matches?: Array<{ path: string; line: number; text?: string; excerpt?: string }> };
    if (typeof value.error === 'string') return value.error;
    if (value.paths) return value.paths.join('\n') || '（没有文件）';
    if (value.matches) return value.matches.map(match => `${match.path}:${match.line} ${match.excerpt ?? match.text ?? ''}`).join('\n') || '（没有找到）';
    if ('stdout' in value || 'stderr' in value) return [value.stdout ?? '', value.stderr ? `[stderr]\n${value.stderr}` : '', value.exitCode === undefined ? '' : `[退出码 ${value.exitCode}]`].filter(Boolean).join('\n');
  }
  return typeof output === 'string' ? output : JSON.stringify(output, null, 2);
}
function renderTakeoverWorkspace(run: RunView): void {
  const root = $<HTMLElement>('takeover-workspace');
  if (!root) return;
  const active = Boolean(run.takeover) && run.status === 'paused' && run.canEdit !== false && !readOnlyShare;
  if (!active) { root.hidden = true; root.replaceChildren(); takeoverWorkspace = undefined; return; }
  root.hidden = false;
  if (takeoverWorkspace?.runId === run.id) { renderTakeoverActions(takeoverWorkspace.log, run.takeover?.actions ?? []); return; }
  root.replaceChildren();
  const tools = new Set((run.approvedTools ?? []).map(tool => tool.id).filter(toolId => toolId in takeoverToolLabels));
  root.append(element('h3', 'Bot 的工作区'));
  if (!tools.size) {
    root.append(element('p', '这件 Run 没有用到 Bot 的工作区。在 AEEIS 外面做完，回来写一句说明交还。', 'muted'));
    takeoverWorkspace = { runId: run.id, log: document.createElement('ol') };
    return;
  }
  root.append(element('p', '这是 Bot 做这件事用的那台机器，文件、装好的东西和后台进程都还在。你在这里做的每一步都会记下来，交还时连同说明一起交给 Bot。', 'muted'));
  const output = element('pre', '', 'takeover-output');
  output.setAttribute('role', 'status'); output.setAttribute('aria-live', 'polite'); output.hidden = true;
  const log = element('ol', '', 'takeover-log');
  const runTool = async (toolId: string, input: Record<string, unknown>): Promise<TakeoverToolResponse | undefined> => {
    const runId = run.id;
    try {
      const result = await api<TakeoverToolResponse>(`/runs/${runId}/takeover-tool`, { toolId, input });
      if (takeoverWorkspace?.runId === runId) renderTakeoverActions(takeoverWorkspace.log, result.actions);
      return result;
    } catch (error) { message(error instanceof Error ? error.message : '工作区操作失败'); return undefined; }
  };
  const show = (text: string) => { output.hidden = false; output.textContent = text; };
  if (tools.has('read') || tools.has('glob')) {
    const files = element('div', '', 'takeover-files');
    const path = document.createElement('input');
    path.id = 'takeover-path'; path.placeholder = '文件路径，例如 artifacts/report.md'; path.setAttribute('aria-label', '文件路径'); path.maxLength = 1000;
    const editor = document.createElement('textarea');
    editor.id = 'takeover-editor'; editor.rows = 10; editor.hidden = true; editor.setAttribute('aria-label', '文件内容');
    let openHash = '';
    const openFile = async (name: string) => {
      const result = await runTool('read', { path: name, maxLines: 500 });
      if (!result) return;
      const value = result.output as { content?: string; sha256?: string; truncated?: boolean; error?: string } | undefined;
      if (result.status !== 'completed' || typeof value?.content !== 'string') { show(takeoverOutputText(result.output)); return; }
      path.value = name; openHash = value.sha256 ?? '';
      editor.value = value.content.split('\n').map(line => line.replace(/^\d+: /, '')).join('\n');
      editor.hidden = false; editor.readOnly = Boolean(value.truncated) || !tools.has('write');
      show(value.truncated ? '文件超过 500 行，这里只读。要改请用命令。' : tools.has('write') ? `已打开 ${name}。改完点「保存」。` : `已打开 ${name}（这件 Run 不能写文件，只读）。`);
    };
    const row = element('div', '', 'takeover-row');
    row.append(path);
    if (tools.has('read')) row.append(button('打开', async () => { if (path.value.trim()) await openFile(path.value.trim()); else path.focus(); }));
    if (tools.has('write')) row.append(button('保存', async () => {
      if (editor.hidden || editor.readOnly) { show('先打开一个能改的文件。'); return; }
      const result = await runTool('write', { path: path.value.trim(), content: editor.value, ...(openHash ? { expectedHash: openHash } : {}) });
      if (!result) return;
      const value = result.output as { sha256?: string } | undefined;
      if (result.status === 'completed' && value?.sha256) { openHash = value.sha256; show(`已保存 ${path.value.trim()}。`); }
      else show(takeoverOutputText(result.output));
    }));
    if (tools.has('glob')) {
      const list = element('ul', '', 'takeover-file-list');
      row.append(button('列文件', async () => {
        const result = await runTool('glob', { pattern: '**/*', limit: 200 });
        if (!result) return;
        const paths = (result.output as { paths?: string[] } | undefined)?.paths;
        if (result.status !== 'completed' || !paths) { show(takeoverOutputText(result.output)); return; }
        list.replaceChildren(...paths.map(name => {
          const item = element('li');
          if (tools.has('read')) item.append(button(name, () => openFile(name))); else item.textContent = name;
          return item;
        }));
        if (!paths.length) list.append(element('li', '工作区里还没有文件。', 'muted'));
      }));
      files.append(row, list, editor);
    } else files.append(row, editor);
    root.append(files);
  }
  const commandTool = tools.has('shell') ? 'shell' : tools.has('python') ? 'python' : '';
  if (commandTool) {
    const row = element('form', '', 'takeover-row takeover-command');
    const input = document.createElement('input');
    input.id = 'takeover-command'; input.maxLength = 100_000;
    input.placeholder = commandTool === 'shell' ? '在 /workspace 里运行一条命令' : '运行一段 Python';
    input.setAttribute('aria-label', commandTool === 'shell' ? '命令' : 'Python 代码');
    const submit = element('button', '运行'); submit.type = 'submit';
    row.onsubmit = async event => {
      event.preventDefault();
      const text = input.value.trim(); if (!text) { input.focus(); return; }
      submit.disabled = true; show('运行中…');
      const result = await runTool(commandTool, commandTool === 'shell' ? { command: text } : { code: text });
      submit.disabled = false;
      if (result) show(takeoverOutputText(result.output));
    };
    row.append(input, submit);
    root.append(row);
  }
  if (tools.has('process')) {
    const row = element('div', '', 'takeover-row');
    row.append(button('看后台进程', async () => { const result = await runTool('process', { action: 'list' }); if (result) show(takeoverOutputText(result.output)); }));
    root.append(row);
  }
  root.append(output, element('h4', '你在工作区做过的'), log);
  takeoverWorkspace = { runId: run.id, log };
  renderTakeoverActions(log, run.takeover?.actions ?? []);
}
function handbackControls(): HTMLElement {
  const box = element('div', '', 'handback');
  const note = document.createElement('textarea');
  note.id = 'handback-note'; note.maxLength = 2000; note.rows = 2;
  note.placeholder = '写下你做了什么、做到哪一步。交还后 Bot 读这句接着做。';
  note.setAttribute('aria-label', '交还说明');
  const submit = button('交还', async () => {
    const text = note.value.trim();
    if (!text) { message('交还前写一句说明：你做了什么、做到哪一步。'); note.focus(); return; }
    await command('handback', { note: text });
  });
  box.append(element('small', '你已接管，Bot 停在这里。'), note, submit);
  return box;
}
async function command(action: string, body: unknown = {}): Promise<void> {
  await api(`/runs/${currentId}/${action}`, body);
  await refresh();
  window.requestAnimationFrame(() => $<HTMLElement>('#decision-title')?.focus({ preventScroll: true }));
}
function updateRunActivity(run: RunView): void {
  const stage = $('activity-stage');
  const meta = $('activity-meta');
  const activity = $('run-activity');
  if (!stage || !meta || !activity) return;
  const copy: Record<string, [string, string]> = {
    queued: taskSchedulerConfigured ? ['已排队，准备启动', '调度器正在为这次运行分配入口'] : ['等待运行服务配置', '调度器尚未启用，配置后这次运行才能继续'],
    planning: ['正在拆解目标', 'Agent 正在把目标整理成可审批的任务图'],
    needs_approval: ['计划已准备好', '请查看执行图，批准后 Agent 才会继续'],
    running: ['Agent 正在推进', '任务、工具和证据会随着事件流逐步出现'],
    reviewing: ['正在做独立复核', '审核器正在检查结果和证据之间的关系'],
    needs_input: ['轮到你了', '补充信息后，Agent 会从当前节点继续'],
    waiting_external: ['等待外部回执', '调用已经留有凭证，核查后即可恢复'],
    unknown: ['结果需要核查', '这一步没有自动重试，保留原调用以避免重复副作用'],
    paused: ['运行已暂停', '状态和证据已保存，随时可以继续'],
    succeeded: ['交付已完成', '结果、产物和证据已经写入本次运行'],
    failed: ['运行遇到问题', '查看错误后可以重试失败步骤或重新规划'],
    cancelled: ['运行已取消', '已保存取消前的状态和外部调用边界'],
  };
  const latest = run.events.at(-1);
  const compacting = ['running', 'reviewing'].includes(run.status) ? compactionProgress(latest) : undefined;
  const taken: [string, string] | undefined = run.status === 'paused' && run.takeover ? ['你已接管', 'Bot 停在这里。做完后写一句说明交还，Bot 接着做'] : undefined;
  const [title, detail] = compacting ?? taken ?? copy[run.status] ?? ['运行状态已更新', `当前状态：${run.status}`];
  if (stage.textContent !== title) stage.textContent = title;
  const anchor = run.events.find(event => ['run.created', 'run.started', 'run.planned'].includes(event.type))?.at ?? run.updatedAt;
  const elapsedMs = anchor ? Date.now() - Date.parse(anchor) : 0;
  const elapsed = Number.isFinite(elapsedMs) && elapsedMs > 0 ? formatElapsed(elapsedMs) : '';
  const activityMeta = `${detail}${elapsed ? ` · 已${['queued', 'planning'].includes(run.status) ? '等待' : '运行'} ${elapsed}` : ''}${latest ? ` · 最新事件 ${describeEvent(latest.type, latest.data, true)}` : ''}`;
  if (meta.textContent !== activityMeta) meta.textContent = activityMeta;
  const trail = $('activity-trail');
  if (trail) {
    const trailEvents = run.events.slice(-3);
    const trailSignature = trailEvents.map(event => `${event.seq}:${event.type}:${event.at}`).join('|');
    if (trail.dataset.signature !== trailSignature) {
      trail.replaceChildren();
      for (const event of trailEvents) {
        const item = element('li', describeEvent(event.type, event.data));
        item.title = `${describeEvent(event.type, event.data, true)} · ${event.type} · ${formatTime(event.at)}`;
        trail.append(item);
      }
      trail.dataset.signature = trailSignature;
    }
  }
  activity.dataset.status = run.status;
  const phaseIndex = ['queued', 'planning'].includes(run.status) ? 0
    : run.status === 'needs_approval' ? 1
    : ['running', 'paused', 'needs_input', 'unknown', 'waiting_external'].includes(run.status) ? 2
    : ['reviewing'].includes(run.status) ? 3
    : run.status === 'succeeded' ? 4 : 2;
  document.querySelectorAll<HTMLElement>('#run-phases [data-phase]').forEach((item, index) => {
    const active = index === Math.min(phaseIndex, 3);
    item.classList.toggle('is-active', active);
    if (active) item.setAttribute('aria-current', 'step'); else item.removeAttribute('aria-current');
    item.classList.toggle('is-done', index < phaseIndex || run.status === 'succeeded');
  });
}
function formatElapsed(milliseconds: number): string {
  const totalSeconds = Math.floor(milliseconds / 1000);
  if (totalSeconds < 60) return `${totalSeconds} 秒`;
  const minutes = Math.floor(totalSeconds / 60);
  if (minutes < 60) return `${minutes} 分钟`;
  return `${Math.floor(minutes / 60)} 小时 ${minutes % 60} 分钟`;
}
function renderRunDecision(run: RunView): void {
  const panel = $('run-decision');
  if (!panel) return;
  const labels: Record<string, [string, string]> = {
    queued: ['等待调度', '目标已接收，调度器会为它分配执行入口。'],
    planning: ['正在规划', 'Agent 正在把目标拆成可审批的任务。'],
    needs_approval: ['等待批准', '计划已经准备好，批准后才会产生执行副作用。'],
    running: ['执行中', 'Agent 正在推进当前任务，事件流会持续更新。'],
    reviewing: ['复核中', '审核器正在检查结果与证据之间的关系。'],
    needs_input: ['需要你补充', '回答一个问题后，Agent 会从当前节点继续。'],
    waiting_external: ['等待外部回执', '调用已有凭证，核查后可以恢复。'],
    unknown: ['需要核查', '外部结果不明确，先核查再决定是否继续。'],
    paused: ['已暂停', '状态和证据已保存，可以从当前节点继续。'],
    succeeded: ['已完成', '结果、产物和证据已经写入本次运行。'],
    failed: ['运行失败', '可以重试失败步骤，或让 Agent 重新规划。'],
    cancelled: ['已取消', '取消前的状态、证据和外部调用仍然可追溯。'],
  };
  const [badge, badgeDetail] = run.status === 'paused' && run.takeover ? ['人已接管', 'Bot 停在这里，由你来做。做完后写一句说明交还，Bot 从你做到的地方接着做。'] : labels[run.status] ?? ['状态更新', `当前状态：${run.status}`];
  const plan = run.plans.at(-1);
  const total = plan?.nodes.length ?? run.steps.length;
  const doneStatuses = new Set(['succeeded', 'completed', 'done']);
  const activeStatuses = new Set(['running', 'active', 'in_progress']);
  const completed = run.steps.filter(step => doneStatuses.has(step.status)).length;
  const active = run.steps.find(step => activeStatuses.has(step.status));
  const pending = run.steps.find(step => !doneStatuses.has(step.status) && !activeStatuses.has(step.status));
  const node = plan?.nodes.find(item => item.id === (active?.taskId ?? pending?.taskId));
  const nodeLabel = node?.title ?? active?.taskId ?? pending?.taskId ?? (plan ? '等待任务状态' : '计划尚未生成');
  const percent = total > 0 ? Math.min(100, Math.round((completed / total) * 100)) : run.status === 'succeeded' ? 100 : 0;
  const metrics = $('decision-metrics');
  const progressBar = $('decision-progress-bar');
  const title = $('decision-title');
  const decisionBadge = $('decision-badge');
  const nextAction = $('decision-next-action');
  const nextDetail = $('decision-next-detail');
  const nextButton = $('decision-next-button') as HTMLButtonElement | null;
  if (!metrics || !progressBar || !title || !decisionBadge || !nextAction || !nextDetail) return;
  panel.dataset.status = run.status;
  title.textContent = badgeDetail;
  decisionBadge.textContent = badge;
  decisionBadge.className = `decision-badge ${run.status}`;
  progressBar.style.width = `${percent}%`;
  const progress = $('decision-progress');
  progress.setAttribute('aria-valuenow', String(percent));
  progress.setAttribute('aria-valuetext', `${percent}% · ${completed}/${total || 0} 个任务`);
  metrics.replaceChildren();
  const metricValues: Array<[string, string]> = [
    ['进度', `${completed}/${total || '—'} 个任务`],
    ['当前节点', nodeLabel],
    ['证据', `${run.artifacts.length} 个产物 · ${(run.context?.sources ?? []).length} 个来源`],
    ['事件', `${run.events.length} 条`],
  ];
  for (const [label, value] of metricValues) {
    const metric = element('div', '', 'decision-metric');
    metric.append(element('small', label), element('strong', value));
    metrics.append(metric);
  }
  const review = $('decision-review');
  const reviewGrid = $('decision-review-grid');
  const reviewTasks = $('decision-review-tasks');
  const reviewActions = $('decision-review-actions');
  if (review && reviewGrid && reviewTasks && reviewActions) {
    const isReview = run.status === 'needs_approval';
    const pendingAction = run.actionApproval?.status === 'pending' ? run.actionApproval : undefined;
    review.hidden = !isReview;
    reviewGrid.replaceChildren();
    reviewTasks.replaceChildren();
    reviewActions.replaceChildren();
    if (isReview && pendingAction) {
      const reviewValues: Array<[string, string]> = [
        ['动作', `${pendingAction.kind === 'agent' ? '交给外部代理' : '调用工具'} ${pendingAction.ref}`],
        ['任务', pendingAction.taskId],
        ['为什么要问', pendingAction.reason],
      ];
      for (const [label, value] of reviewValues) {
        const item = element('div', '', 'review-fact');
        item.append(element('small', label), element('strong', value));
        reviewGrid.append(item);
      }
      reviewTasks.append(element('p', '计划已经批准。这一步里的这个动作需要你单独决定。拒绝或阻止时不会执行它，Run 会继续，执行器会知道原因。', 'muted'));
      if (!readOnlyShare && run.canEdit !== false) {
        const decide = (decision: 'once' | 'always' | 'deny' | 'block') => () => command('approve-action', { idempotencyKey: pendingAction.idempotencyKey, decision });
        const once = button('仅这一次', decide('once'));
        once.className = 'decision-primary';
        once.dataset.actionDecision = 'once';
        const always = button('以后都允许', decide('always'));
        always.dataset.actionDecision = 'always';
        const deny = button('拒绝这一次', decide('deny'));
        deny.dataset.actionDecision = 'deny';
        const block = button('以后都阻止', decide('block'));
        block.dataset.actionDecision = 'block';
        reviewActions.append(once, always, deny, block);
      }
    } else if (isReview && plan) {
      const modelBudget = [run.modelBudget?.tokens === undefined ? '' : `${run.modelBudget.tokens.toLocaleString()} tokens`, run.modelBudget?.moneyUsd === undefined ? '' : `$${run.modelBudget.moneyUsd.toFixed(2)}`].filter(Boolean).join(' / ') || '未设置';
      const externalBudget = [run.externalBudget?.calls === undefined ? '' : `${run.externalBudget.calls} 次调用`, run.externalBudget?.tokens === undefined ? '' : `${run.externalBudget.tokens.toLocaleString()} tokens`, run.externalBudget?.moneyUsd === undefined ? '' : `$${run.externalBudget.moneyUsd.toFixed(2)}`].filter(Boolean).join(' / ') || '未设置';
      const reviewValues: Array<[string, string]> = [
        ['计划', `v${plan.version} · ${plan.nodes.length} 个任务`],
        ['资料边界', `${(run.context?.sources ?? []).length} 个来源 · ${privacyLabel(run.privacy)}`],
        ['Tool / Agent', `${run.approvedTools?.length ?? 0} 个 Tool · ${run.pendingDelegation ? 1 : 0} 个 Agent`],
        ['预算上限', `模型 ${modelBudget} · 外部 ${externalBudget}`],
      ];
      for (const [label, value] of reviewValues) {
        const item = element('div', '', 'review-fact');
        item.append(element('small', label), element('strong', value));
        reviewGrid.append(item);
      }
      reviewTasks.append(element('small', '任务预览 · 点击查看依赖和证据要求', 'review-task-label'));
      for (const node of plan.nodes) {
        const task = element('details', '', 'review-task');
        task.append(element('summary', node.title));
        task.append(element('small', `任务 ID：${node.id}`));
        task.append(element('small', `依赖：${node.dependsOn.length ? node.dependsOn.join('、') : '无'}`));
        if (node.evidenceRefs?.length) task.append(element('small', `已有证据：${node.evidenceRefs.join('、')}`));
        else task.append(element('small', '已有证据：待执行后生成'));
        reviewTasks.append(task);
      }
      const viewPlan = button('展开任务图', async () => {
        setRunDetailsMode(true);
        $('graph')?.closest('section')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
      viewPlan.className = 'quiet-button';
      reviewActions.append(viewPlan);
      const writable = !readOnlyShare && run.canEdit !== false;
      const editor = planReview(run, command, writable);
      reviewTasks.append(editor.root);
      if (writable) {
        const approve = button('批准并执行', editor.approve);
        approve.className = 'decision-primary';
        reviewActions.append(approve);
      }
    }
  }
  const actions: Record<string, [string, string]> = {
    needs_approval: ['批准计划并执行', '先检查任务图、预算和外部调用边界。'],
    needs_input: ['补充信息', '回答上方问题即可从当前节点继续。'],
    waiting_external: ['核查外部结果', '确认供应方回执后再恢复，避免重复副作用。'],
    unknown: ['核查不明结果', '先确认原调用是否完成，再决定是否重试。'],
    failed: ['重试或重新规划', '查看错误和证据后选择恢复路径。'],
    paused: ['继续运行', '所有已产生的事实和证据都会被保留。'],
    succeeded: ['查看证据与产物', '交付已经完成，可以继续沉淀为长期目标。'],
  };
  if (run.status === 'paused' && run.takeover) actions.paused = ['写说明并交还', '写下你做了什么、做到哪一步，Bot 读这句接着做。'];
  let [action, detail] = actions[run.status] ?? (active ? [`等待「${nodeLabel}」完成`, 'Agent 正在执行，新的事件会自动出现。'] : ['等待下一步', '运行状态变化后，这里会给出可执行动作。']);
  if (run.status === 'queued' && !taskSchedulerConfigured) {
    action = '等待运行服务配置';
    detail = '调度器尚未启用；打开详细设置查看当前运行能力。';
  }
  nextAction.textContent = action;
  nextDetail.textContent = detail;
  if (nextButton) {
    nextButton.hidden = true;
    nextButton.disabled = false;
    nextButton.classList.remove('is-busy');
    nextButton.onclick = null;
    const installAction = (label: string, task: () => Promise<void>): void => {
      nextButton.hidden = false;
      nextButton.textContent = label;
      nextButton.onclick = () => {
        nextButton.disabled = true;
        nextButton.classList.add('is-busy');
        void task().catch(error => message(errorMessage(error))).finally(() => {
          nextButton.disabled = false;
          nextButton.classList.remove('is-busy');
        });
      };
    };
    if (run.status === 'queued' && taskSchedulerConfigured) installAction('恢复调度', () => command('dispatch'));
    else if (run.status === 'needs_approval' && run.actionApproval?.status === 'pending') { /* The action card above carries the decision. */ }
    else if (run.status === 'needs_approval' && plan && !readOnlyShare && run.canEdit !== false) installAction('批准并执行', planReview(run, command, true).approve);
    else if (run.status === 'needs_input' || run.status === 'unknown') installAction(run.status === 'unknown' ? '填写核查说明' : '补充信息', async () => {
      openInputPanel(run.status === 'unknown' ? 'reconcile' : 'answer');
    });
    else if (run.status === 'waiting_external') installAction('核查外部结果', async () => {
      openInputPanel('reconcile');
    });
    else if (run.status === 'failed') installAction('重试失败步骤', () => command('retry'));
    else if (run.status === 'paused' && run.takeover) installAction('写说明并交还', async () => { $<HTMLTextAreaElement>('handback-note')?.focus(); });
    else if (run.status === 'paused') installAction('继续运行', () => command('resume'));
    else if (run.status === 'succeeded') installAction('查看证据与产物', async () => {
      setRunDetailsMode(true);
      $('artifacts')?.closest('section')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
    else if (run.status === 'cancelled') installAction('查看外部回执', async () => {
      setRunDetailsMode(true);
      $('external-effects')?.closest('section')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  }
  if (nextButton && (readOnlyShare || run.canEdit === false)) { nextButton.hidden = true; nextButton.onclick = null; }
}
interface MemoryOriginalSummary { id?: string; originalId?: string; locator?: string; phase?: string; totalChars?: number; excerpt?: string }
function renderWorkingMemory(run: RunView): void {
  const panel = $('working-memory-panel'), content = $('working-memory-content');
  panel.hidden = readOnlyShare || run.canEdit !== true || !run.workingMemoryEnabled;
  if (panel.hidden) { content.replaceChildren(); delete content.dataset.signature; if (openMemoryForRunId === run.id) openMemoryForRunId = ''; return; }
  const signature = `${run.id}:${run.plans.at(-1)?.hash}`;
  const revealMemory = openMemoryForRunId === run.id;
  if (revealMemory) delete content.dataset.signature;
  if (!revealMemory && content.dataset.signature === signature) return;
  content.dataset.signature = signature; content.replaceChildren();
  const epoch = conversationEpoch, token = getToken();
  let sequence = 0;
  const task = element('select'); task.id = 'working-memory-task';
  const label = element('label', 'Run 计划节点'); label.htmlFor = task.id;
  for (const node of run.plans.at(-1)?.nodes ?? []) { const option = element('option', `${node.title} (${node.id})`); option.value = node.id; task.append(option); }
  const query = element('input'); query.id = 'working-memory-query'; query.maxLength = 200; query.placeholder = '搜索原文，输入 * 列出全部';
  const queryLabel = element('label', '搜索工作记忆'); queryLabel.htmlFor = query.id;
  const output = element('div'), original = element('div'), status = element('p'); status.setAttribute('role', 'status');
  const valid = (request: number) => request === sequence && currentId === run.id && content.dataset.signature === signature && epoch === conversationEpoch && token === getToken();
  const path = (suffix: string, params: Record<string, string>) => `/runs/${encodeURIComponent(run.id)}/working-memory${suffix}?${new URLSearchParams({ taskId: task.value, ...params })}`;
  const showOriginal = async (entryId: string, offset = 0) => {
    const request = ++sequence; status.textContent = '正在读取原文…'; original.replaceChildren();
    try {
      const page = await api<{ originalId: string; text: string; page: { characterOffset: number; totalChars: number; nextCharacterOffset: number | null } }>(path('/original', { entryId, offset: String(offset) }));
      if (!valid(request)) return;
      original.append(element('h4', '原文（不可信资料）'), element('small', `${page.originalId} · 字符 ${page.page.characterOffset}–${page.page.characterOffset + page.text.length} / ${page.page.totalChars}`), element('pre', page.text));
      if (offset > 0) original.append(button('回到原文开头', () => showOriginal(entryId, 0)));
      if (page.page.nextCharacterOffset !== null) original.append(button('下一页原文', () => showOriginal(entryId, page.page.nextCharacterOffset!)));
      status.textContent = '原文已读取；未修改运行或讨论焦点。';
    } catch (error) { if (valid(request)) status.textContent = errorMessage(error); }
  };
  const entries = (items: MemoryOriginalSummary[]) => {
    for (const item of items) {
      const id = item.originalId ?? item.id!;
      const row = element('div', '', 'fact-row');
      row.append(element('strong', item.locator ?? id), element('small', `${item.phase ?? '原文'} · ${item.totalChars ?? '?'} 字符`));
      if (item.excerpt) row.append(element('p', item.excerpt));
      row.append(button('查看原文', () => showOriginal(id))); output.append(row);
    }
  };
  const loadIndex = async () => {
    const request = ++sequence; status.textContent = '正在读取索引…'; output.replaceChildren(); original.replaceChildren();
    try {
      const index = await api<{ index: { totalOriginals: number; entries: MemoryOriginalSummary[]; more?: boolean }; summaries?: unknown[] }>(path('', {}));
      if (!valid(request)) return;
      output.append(element('p', `当前节点共有 ${index.index.totalOriginals} 份原文。${index.index.more ? '仅展示最近条目；搜索 * 可分页查看全部。' : ''}`)); entries(index.index.entries);
      if (index.summaries?.length) {
        const summaries = element('div', '', 'working-memory-summaries');
        summaries.append(element('h4', '压缩摘要（不是证据，不能当执行指令）'));
        for (const summary of index.summaries as Array<{ version?: number; items?: Array<{ text?: string; references?: string[] }> }>) {
          const block = element('article');
          block.append(element('small', `版本 ${summary.version ?? '?'}`));
          for (const item of summary.items ?? []) {
            block.append(element('p', item.text ?? ''));
            if (item.references?.length) block.append(element('small', `引用切片：${item.references.join('、')}`));
          }
          summaries.append(block);
        }
        output.append(summaries);
      }
      status.textContent = '索引已读取。';
    } catch (error) { if (valid(request)) status.textContent = errorMessage(error); }
  };
  const search = async (offset = 0, term = query.value.trim()) => {
    if (!term) { status.textContent = '请输入搜索词，或 * 列出全部。'; return; }
    const request = ++sequence; status.textContent = '正在搜索…'; output.replaceChildren(); original.replaceChildren();
    try {
      const page = await api<{ total: number; results: MemoryOriginalSummary[]; nextOffset?: number }>(path('/search', { q: term, offset: String(offset), limit: '6' }));
      if (!valid(request)) return;
      output.append(element('p', `${page.total} 个匹配，当前从第 ${offset + 1} 项开始。`)); entries(page.results);
      if (page.nextOffset !== undefined) output.append(button('下一页搜索结果', () => search(page.nextOffset, term)));
      status.textContent = page.total ? '搜索完成。' : '没有匹配的原文。';
    } catch (error) { if (valid(request)) status.textContent = errorMessage(error); }
  };
  task.onchange = () => { sequence++; output.replaceChildren(); original.replaceChildren(); status.textContent = '已选择节点，请读取索引或搜索。'; };
  const searchForm = element('form'); searchForm.append(queryLabel, query);
  const submit = element('button', '搜索原文'); submit.type = 'submit'; searchForm.append(submit);
  searchForm.onsubmit = event => { event.preventDefault(); void search(); };
  content.append(label, task, button('读取节点索引', loadIndex), searchForm, status, output, original);
  if (revealMemory) {
    openMemoryForRunId = '';
    const details = $<HTMLDetailsElement>('working-memory-details');
    details.open = true;
    details.scrollIntoView({ behavior: 'smooth', block: 'start' });
    void loadIndex();
  }
}
interface ComputerObservation {
  foreground: { command: string; startedAt?: string | null; finishedAt?: string | null; output: string } | null;
  processes: { processId: string; command: string; running: boolean; output: string }[];
  repository: { status: string; diff: string; truncated: boolean } | null;
  files: { path: string; modifiedAt: string }[];
}
interface ComputerView {
  status: string;
  machine: { state: string; detail?: string; live?: ComputerObservation; previews: { port: number; url: string }[] };
  screenshots: { name: string; bytes: number; capturedAt: string }[];
  hostWait?: { since: string; message: string; availableAt?: string };
}
const COMPUTER_POLL_MS = 5000;
/** Each look reaches the sandbox host, and on some hosts that counts as activity. Only work in progress is followed. */
const COMPUTER_FOLLOWED = ['queued', 'planning', 'running', 'reviewing'];
const COMPUTER_STATES: Record<string, string> = {
  absent: '还没有开机', released: '已经收掉', running: '运行中', frozen: '已冻结，进程停在原地，内容都在',
  stopped: '已停止', unreachable: '连不上', unknown: '',
};
const computer = { runId: '', status: '', looked: '', available: true, timer: 0, busy: false, shotName: '', live: undefined as ComputerObservation | undefined };
function resetComputer(runId: string): void {
  window.clearTimeout(computer.timer);
  Object.assign(computer, { runId, status: '', looked: '', available: true, shotName: '', live: undefined });
  $('computer-shot').hidden = true;
  $('computer-notice').hidden = true;
  $('computer-previews').hidden = true;
  $('computer-terminal-block').hidden = true;
  $('computer-changes-block').hidden = true;
  $('computer-state').textContent = '';
}
/** Everything here comes from inside the machine, so it is only ever written as text. */
function setComputerOutput(id: string, text: string): void {
  const output = $(id), block = $(`${id}-block`);
  // Stay on the newest lines unless the person has scrolled up. A block that was hidden has nothing to keep.
  const following = block.hidden || output.scrollHeight - output.scrollTop - output.clientHeight < 24;
  block.hidden = !text;
  if (output.textContent !== text) output.textContent = text;
  if (following) output.scrollTop = output.scrollHeight;
}
function computerTerminal(live: ComputerObservation): string {
  const parts: string[] = [];
  if (live.foreground) parts.push(`$ ${live.foreground.command}${live.foreground.finishedAt ? '' : '  （运行中）'}\n${live.foreground.output}`.trimEnd());
  for (const item of live.processes) parts.push(`后台 · ${item.running ? '运行中' : '已退出'} · ${item.command}\n${item.output}`.trimEnd());
  return parts.join('\n\n');
}
function computerChanges(live: ComputerObservation): string {
  if (live.repository) return `${live.repository.status}\n${live.repository.diff}${live.repository.truncated ? '\n…（改动太长，这里只显示开头）' : ''}`.trim();
  return live.files.map(file => `${formatTime(file.modifiedAt)}  ${file.path}`).join('\n');
}
async function showComputerScreenshot(runId: string, shot: ComputerView['screenshots'][number]): Promise<void> {
  if (shot.name === computer.shotName) return;
  const token = getToken();
  const response = await fetch(`/api/runs/${encodeURIComponent(runId)}/computer/screenshots/${encodeURIComponent(shot.name)}`, { headers: token ? { authorization: `Bearer ${token}` } : {} });
  if (!response.ok || computer.runId !== runId) return;
  // The screenshot route needs the auth header, and the page's image policy allows data: but not blob: URLs.
  const image = await response.blob();
  const url = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('Screenshot could not be read'));
    reader.readAsDataURL(image);
  });
  if (computer.runId !== runId) return;
  computer.shotName = shot.name;
  $<HTMLImageElement>('computer-shot-image').src = url;
  $('computer-shot-caption').textContent = `最新截图 · ${formatTime(shot.capturedAt)}`;
  $('computer-shot').hidden = false;
}
interface AcceptanceView { round: number; passed: boolean; projectChanged: boolean; error?: string; items: { requirement: string; status: string; notes: string; screenshot?: string }[]; previewUrl?: string; sourceArchive?: string }
const ACCEPTANCE_STATES: Record<string, string> = { passed: '通过', failed: '没通过', unverified: '没能确认' };
function renderAcceptance(run: RunView): void {
  const check = ((run as RunView & { acceptanceChecks?: AcceptanceView[] }).acceptanceChecks ?? []).at(-1);
  $('computer-acceptance').hidden = !check;
  if (!check) return;
  const passed = check.items.filter(item => item.status === 'passed').length;
  $('computer-acceptance-summary').textContent = `${check.passed ? '独立检查通过' : '独立检查没通过'}：${passed} / ${check.items.length} 条需求${check.round ? `（第 ${check.round + 1} 轮）` : ''}。这是另一个会话亲自打开页面得出的结论，没有参考执行者的说法。${check.error ? ` ${check.error}` : ''}`;
  $('computer-acceptance-items').replaceChildren(...check.items.map(item => {
    const row = element('li', '', `acceptance-${item.status}`);
    row.append(element('strong', `${ACCEPTANCE_STATES[item.status] ?? item.status}：${item.requirement}`), element('p', item.notes, 'muted'));
    return row;
  }));
  const delivery = $('computer-delivery');
  delivery.replaceChildren();
  if (check.previewUrl?.startsWith('https://')) {
    const link = element('a', '打开交付的预览');
    link.href = check.previewUrl; link.target = '_blank'; link.rel = 'noopener noreferrer';
    delivery.append(link);
  }
  if (check.sourceArchive) delivery.append(button('下载源码', async () => {
    const token = getToken();
    const response = await fetch(`/api/runs/${encodeURIComponent(run.id)}/computer/source`, { headers: token ? { authorization: `Bearer ${token}` } : {} });
    if (!response.ok) throw new Error('源码包读不出来');
    const url = URL.createObjectURL(await response.blob());
    const link = element('a'); link.href = url; link.download = `${run.id}-source.tar.gz`; link.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 10_000);
  }));
  delivery.hidden = !delivery.children.length;
}
function renderComputerView(run: RunView, view: ComputerView): void {
  renderAcceptance(run);
  $('computer-state').textContent = COMPUTER_STATES[view.machine.state] ?? '';
  const interrupted = [...(run.events ?? [])].reverse().find(item => item.type.startsWith('machine.'));
  const notice = view.hostWait
    ? `这次工具调用在等沙箱主机恢复（从 ${formatTime(view.hostWait.since)} 起${view.hostWait.availableAt ? `，主机说 ${formatTime(view.hostWait.availableAt)} 后可用` : ''}）。工具还没有执行，主机恢复后会继续。`
    : interrupted?.type === 'machine.interrupt_unconfirmed' ? '没能确认机器上的工作已经停下：连不上沙箱主机。主机恢复后再看一眼。'
    : view.machine.detail ?? '';
  $('computer-notice').textContent = notice;
  $('computer-notice').hidden = !notice;
  const previews = $('computer-previews');
  previews.replaceChildren();
  for (const preview of view.machine.previews) {
    let url: URL;
    try { url = new URL(preview.url); } catch { continue; }
    if (url.protocol !== 'https:') continue;
    const link = element('a', `打开预览（端口 ${preview.port}）`);
    link.href = url.href; link.target = '_blank'; link.rel = 'noopener noreferrer';
    previews.append(link);
  }
  previews.hidden = !previews.children.length;
  computer.live = view.machine.live ?? computer.live;
  if (computer.live) {
    setComputerOutput('computer-terminal', computerTerminal(computer.live));
    setComputerOutput('computer-changes', computerChanges(computer.live));
  }
}
async function pollComputer(run: RunView): Promise<void> {
  if (computer.busy || computer.runId !== run.id || !computer.available) return;
  computer.busy = true;
  const lookedAt = computer.status;
  computer.looked = lookedAt;
  try {
    const view = await api<ComputerView>(`/runs/${encodeURIComponent(run.id)}/computer`);
    if (computer.runId !== run.id) return;
    renderComputerView(run, view);
    const latest = view.screenshots[0];
    if (latest) await showComputerScreenshot(run.id, latest);
  } catch (error) {
    if (error instanceof ApiError && error.status === 404) { computer.available = false; $('run-computer').hidden = true; }
  } finally {
    computer.busy = false;
    window.clearTimeout(computer.timer);
    const panel = $<HTMLDetailsElement>('run-computer');
    // A pause pressed during this look changed the machine after it was read, so the view above is already old.
    if (computer.runId === run.id && computer.available && computer.status !== lookedAt && panel.open) void pollComputer(current ?? run);
    else if (computer.runId === run.id && computer.available && COMPUTER_FOLLOWED.includes(computer.status) && panel.open && !document.hidden) {
      computer.timer = window.setTimeout(() => { void pollComputer(current ?? run); }, COMPUTER_POLL_MS);
    }
  }
}
function renderComputer(run: RunView): void {
  const panel = $<HTMLDetailsElement>('run-computer');
  if (readOnlyShare || run.canEdit === false) { window.clearTimeout(computer.timer); panel.hidden = true; return; }
  if (computer.runId !== run.id) resetComputer(run.id);
  if (!computer.available) return;
  panel.hidden = false;
  if (computer.status === run.status) return;
  computer.status = run.status;
  if (panel.open && !document.hidden) void pollComputer(run);
}
/** Coming back to the panel: a followed Run picks up again, and anything else is read only if it has not been yet. */
function reopenComputer(): void {
  if (!current || !$<HTMLDetailsElement>('run-computer').open || document.hidden) return;
  if (COMPUTER_FOLLOWED.includes(computer.status) || computer.looked !== computer.status) void pollComputer(current);
}
$<HTMLDetailsElement>('run-computer').addEventListener('toggle', reopenComputer);
document.addEventListener('visibilitychange', reopenComputer);
function render(run: RunView): void {
  renderWorkingMemory(run);
  document.body.classList.toggle('run-open', currentRunOpen);
  const shareResult = $('run-share-result');
  if (shareResult.dataset.runId !== run.id) { shareResult.replaceChildren(); shareResult.dataset.runId = run.id; }
  if (!readOnlyShare && !linkedThreadId && !conversationEnabled && window.location.pathname !== `/runs/${run.id}`) window.history.replaceState(null, '', `/runs/${run.id}`);
  $('create-run-share').hidden = readOnlyShare || run.canEdit === false;
  const threadLink = $<HTMLAnchorElement>('run-thread-link');
  threadLink.hidden = readOnlyShare || !run.threadId;
  if (run.threadId && !readOnlyShare) threadLink.href = `/threads/${run.threadId}`;
  $('run-title').textContent = runTitle(run);
  $('run-status').textContent = runStatusLabel(run.status);
  $('run-status').className = `status ${run.status}`;
  updateRunActivity(run);
  renderRunDecision(run);
  syncTranscriptEmpty();
  $('detail').hidden = !currentRunOpen;
  syncCurrentRunToggle(run);
  syncPresence(run);
  if (intentPresetsOpen) setIntentPresetsOpen(false);
  renderDeliverySummary(run);
  const validationEvent = [...run.events].reverse().find(event => event.type === 'run.failed' && event.data?.validation?.issues?.length);
  const validationText = validationEvent?.data?.validation?.issues?.slice(0, 3).map(issue => `${issue.path ?? '$'}：${issue.message ?? '格式不符合要求'}`).join('；');
  $('run-error').textContent = run.error ? `${run.error}${validationText ? ` · ${validationText}` : ''}` : '';
  const traffic = run.evolutionTraffic ?? [];
  $('evolution-traffic').textContent = traffic.length
    ? `RSI traffic：${traffic.map(item => `${item.target}=${item.selected ? item.candidateId : 'base'} (${item.percentage / 100}% · bucket ${item.bucket})`).join('；')}`
    : '';
  const effects = $('external-effects'); effects.replaceChildren();
  const creditTotal = (run.toolReceipts ?? []).reduce((sum, receipt) => sum + (receipt.cost?.credits ?? 0), 0);
  const unsettled = (run.toolReceipts ?? []).filter(receipt => receipt.costStatus === 'interrupted' || receipt.costStatus === 'unreported').length;
  if (run.toolReceipts?.length) effects.append(element('li', `工具费用合计 ${creditTotal} credits${unsettled ? ` · ${unsettled} 次未结算` : ''}`));
  for (const receipt of run.toolReceipts ?? []) effects.append(element('li', `Tool ${receipt.operation} · ${runStatusLabel(receipt.status)} · ${receipt.cost?.credits !== undefined ? `${receipt.cost.credits} credits · ` : receipt.costStatus === 'interrupted' ? '费用未结算(中断) · ' : ''}${receipt.authorization ? `接纳=${receipt.authorization.decision}(${receipt.authorization.reason}) · ` : ''}${receipt.receiptId}${receipt.errorCode ? ` · ${receipt.errorCode}` : ''}`));
  for (const outcome of run.delegationOutcomes ?? []) effects.append(element('li', `Agent ${outcome.agentId ?? 'external'} · ${runStatusLabel(outcome.status)} · ${outcome.receiptRef}`));
  if (run.pendingTool) effects.append(element('li', `等待 Tool reconcile：${run.pendingTool.toolId} · ${run.pendingTool.receiptId ?? '尚未生成 receipt'}`, 'failure'));
  if (run.pendingDelegation) effects.append(element('li', `等待 Agent reconcile：${run.pendingDelegation.agentId} · ${run.pendingDelegation.receiptRef ?? '尚未生成 receipt'}`, 'failure'));
  if (!effects.children.length) effects.append(element('li', '本次运行没有外部 Tool 或 Agent 调用记录', 'muted'));
  const progressList = $('agent-progress'); progressList.replaceChildren();
  const progress = [...(run.agentProgress ?? [])].sort((a, b) => a.progress.at.localeCompare(b.progress.at) || a.progress.sequence - b.progress.sequence);
  for (const item of progress) {
    const value = item.progress;
    const row = element('li', '', 'agent-progress-item');
    row.append(element('time', formatTime(value.at)), element('strong', `${runStatusLabel(value.status)} · ${value.agentId} · #${value.sequence}`), element('span', value.percent === undefined ? value.message : `${value.message} · ${value.percent}%`));
    if (value.evidenceRefs.length || value.artifactRefs.length) row.append(element('small', `引用：${[...value.evidenceRefs, ...value.artifactRefs].join(', ')}`));
    progressList.append(row);
  }
  if (!progressList.children.length) progressList.append(element('li', '当前没有外部 Agent 流式进度', 'muted'));
  const controls = $('controls'); controls.replaceChildren();
  controls.hidden = readOnlyShare || run.canEdit === false;
  if (['queued', 'planning', 'running', 'reviewing'].includes(run.status)) controls.append(button('暂停', () => command('pause')));
  if (run.status === 'paused' && !run.takeover) controls.append(button('继续', () => command('resume')));
  if (canTakeOver(run)) controls.append(button('接管', () => takeOverRun(run)));
  if (run.takeover && run.status === 'paused') controls.append(handbackControls());
  renderTakeoverWorkspace(run);
  renderComputer(run);
  if (run.status === 'waiting_external') controls.append(button('核查外部 Agent 结果', async () => { openInputPanel('reconcile'); }));
  if (run.status === 'needs_input' || run.status === 'unknown') controls.append(button(run.status === 'unknown' ? '填写核查说明' : '填写补充信息', async () => {
    openInputPanel(run.status === 'unknown' ? 'reconcile' : 'answer');
  }));
  if (run.status === 'cancelled' && (run.pendingTool?.receiptId || run.pendingDelegation?.receiptRef)) controls.append(button('核查已取消运行的外部调用', async () => {
    openInputPanel('reconcile-cancelled');
  }));
  if (run.status === 'failed') controls.append(button('重试失败步骤', () => command('retry')));
  if (run.status === 'failed' && !run.taskExecution) controls.append(button('重新规划', () => command('replan', { reason: '根据审核或失败信息生成新的计划版本' })));
  if (!['succeeded', 'cancelled'].includes(run.status)) {
    const cancel = button(cancelArmedRunId === run.id ? '再次点击确认取消' : '取消运行', async () => {
      if (cancelArmedRunId !== run.id) {
        cancelArmedRunId = run.id;
        cancel.textContent = '再次点击确认取消';
        cancel.dataset.state = 'attention';
        window.setTimeout(() => {
          if (cancelArmedRunId !== run.id) return;
          cancelArmedRunId = '';
          if (cancel.isConnected) { cancel.textContent = '取消运行'; delete cancel.dataset.state; }
        }, 5000);
        return;
      }
      cancel.disabled = true;
      cancel.textContent = '正在取消…';
      cancelArmedRunId = '';
      await command('cancel');
    });
    cancel.className = 'quiet-button';
    if (cancelArmedRunId === run.id) cancel.dataset.state = 'attention';
    controls.append(cancel);
  }
  if (run.status === 'queued' && taskSchedulerConfigured) controls.append(button('恢复调度', () => command('dispatch')));
  const reconcileMode: InputPanelMode | undefined = run.status === 'waiting_external'
    ? 'reconcile'
    : run.status === 'cancelled' && (run.pendingTool?.receiptId || run.pendingDelegation?.receiptRef)
      ? 'reconcile-cancelled'
      : run.status === 'unknown' ? 'reconcile' : run.status === 'needs_input' ? 'answer' : undefined;
  if (reconcileMode) inputPanelMode = reconcileMode;
  $('input-panel').hidden = reconcileMode === undefined;
  const inputHeading = $('input-panel').querySelector('h2');
  const inputSubmit = $('input-panel').querySelector('button');
  if (inputHeading) inputHeading.textContent = inputPanelMode === 'answer' ? '需要你的信息' : '核查外部结果';
  if (inputSubmit) inputSubmit.textContent = inputPanelMode === 'answer' ? '提交并继续' : '提交核查并继续';
  $('question').textContent = inputPanelMode === 'answer'
    ? (run.question?.text ?? 'Agent 需要一条补充信息才能继续。')
    : inputPanelMode === 'reconcile-cancelled'
      ? '运行已经取消，但外部调用仍需核查。请说明已确认的回执或后续处理。'
      : '请说明你确认的外部结果；核查后 AEEIS 才会决定是否恢复，避免重复副作用。';
  const plan = run.plans.at(-1);
  $('plan-summary').textContent = plan
    ? `计划 v${plan.version} · ${plan.summary}${run.plans.length > 1 ? ` · 历史版本：${run.plans.slice(0, -1).map(item => `v${item.version}`).join('、')}` : ''}`
    : '正在等待模型生成任务计划';
  const sources = $('sources'); sources.replaceChildren();
  const contextSummary: string[] = [];
  if (run.context?.manifestHash) contextSummary.push(`Context Manifest hash ${run.context.manifestHash}`);
  if (run.context?.memoryManifestId) contextSummary.push(`Goal Memory Manifest：${run.context.memoryManifestId} · hash ${run.context.memoryManifestHash ?? 'legacy'} · 冻结 ${run.context.memoryRefs?.length ?? 0} 条记忆引用`);
  $('memory-context').textContent = contextSummary.length ? contextSummary.join(' · ') : '本次 Run 没有绑定 Context Manifest。';
  for (const source of run.context?.sources ?? []) {
    const box = element('details');
    box.append(element('summary', `${source.title} · ${privacyLabel(source.classification ?? run.privacy)}`), element('small', `${source.kind ?? 'source'}${source.untrusted ? ' · 外部资料' : ''} · ${source.source} · ${source.id} · sha256 ${source.hash}${source.contentHash ? ` · content ${source.contentHash}` : ''}${source.origin ? ` · 来源 Run ${source.origin.runId}` : ''}`), element('pre', source.content));
    sources.append(box);
  }
  if (!sources.children.length) sources.append(element('p', '本次运行没有读取外部项目源或知识记录。', 'muted'));
  renderGovernance(run);
  const graph = $('graph'); graph.replaceChildren();
  if (plan) {
    const levels = new Map<string, number>();
    function level(id: string): number {
      if (levels.has(id)) return levels.get(id)!;
      const node = plan!.nodes.find(n => n.id === id)!;
      const value = node.dependsOn.length ? 1 + Math.max(...node.dependsOn.map(level)) : 0; levels.set(id, value); return value;
    }
    plan.nodes.forEach(n => level(n.id));
    const positions = new Map<string, { x: number; y: number }>();
    const rows = new Map<number, number>();
    for (const node of plan.nodes) {
      const l = levels.get(node.id)!, row = rows.get(l) ?? 0; rows.set(l, row + 1);
      positions.set(node.id, { x: l * 268 + 8, y: row * 128 + 8 });
    }
    const canvas = element('div', '', 'canvas');
    const width = (Math.max(...levels.values()) + 1) * 268, height = Math.max(...rows.values()) * 128;
    canvas.style.width = `${width}px`; canvas.style.height = `${height}px`;
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); svg.setAttribute('width', String(width)); svg.setAttribute('height', String(height));
    for (const node of plan.nodes) for (const dependency of node.dependsOn) {
      const a = positions.get(dependency)!, b = positions.get(node.id)!;
      const path = document.createElementNS(svg.namespaceURI, 'path');
      path.setAttribute('d', `M${a.x+236} ${a.y+48} C${a.x+253} ${a.y+48} ${b.x-17} ${b.y+48} ${b.x} ${b.y+48}`);
      path.setAttribute('fill', 'none'); path.setAttribute('stroke', '#d4d4d4'); path.setAttribute('stroke-width', '1.5'); svg.append(path);
    }
    canvas.append(svg);
    for (const node of plan.nodes) {
      const p = positions.get(node.id)!; const step = run.steps.find(s => s.taskId === node.id); const status = step?.error ? 'failed' : step?.status ?? 'pending';
      const card = element('article', '', `node ${status}`); card.style.left = `${p.x}px`; card.style.top = `${p.y}px`;
      card.append(element('small', runStatusLabel(status)), element('strong', node.title), element('small', node.id));
      if (node.evidenceRefs?.length) card.append(element('small', `证据：${node.evidenceRefs.join(', ')}${node.evidenceRunId ? ` · Run ${node.evidenceRunId}` : ''}`));
      if (step?.error) card.title = `${step.error} · ${step.failureReason ?? step.error}`;
      canvas.append(card);
    }
    graph.append(canvas);
    const failures = element('div', '', 'task-failures');
    for (const step of run.steps.filter(step => step.error)) failures.append(element('p', `${step.taskId} · 失败 · ${step.error} · 原因：${step.failureReason ?? step.error}`, 'failure'));
    graph.append(failures);
  }
  renderGraphList($('execution-graph'), run.graphs?.execution, '执行图尚无节点');
  renderGraphList($('evidence-graph'), run.graphs?.evidence, '证据图尚无节点');
  renderPlanHistory(run);
  const artifacts = $('artifacts'); artifacts.replaceChildren();
  for (const artifact of run.artifacts) {
    const box = element('details'); box.open = true;
    const actions = element('div', '', 'artifact-actions');
    if (!readOnlyShare) actions.append(artifactDownloadLink(run.id, artifact, { getToken, onError: message }));
    box.append(element('summary', `${artifact.title}${artifact.artifactType ? ` · ${artifact.artifactType}` : ''}`), actions, renderArtifactMarkdown(artifact.content));
    if (isProjectPulseArtifact(artifact.structured)) appendProjectPulse(box, artifact.structured, run);
    else if (isFillablePdfArtifact(artifact.structured)) box.append(renderFillablePdf(artifact.structured, ref => evidenceDetail(run, ref)));
    else if (artifact.structured) box.append(element('small', '结构化产物'), element('pre', JSON.stringify(artifact.structured, null, 2)));
    box.append(element('small', `证据：${artifact.evidenceRefs.join(', ') || '无外部来源引用'}`)); artifacts.append(box);
    if (!readOnlyShare && run.goalId && artifact.evidenceRefs.length) box.append(memoryWritebackForm(run, artifact));
    if (evolutionConfigured) box.append(correctionForm(run, artifact));
    for (const correction of run.corrections ?? []) {
      if (!correction.sourceRefs.includes(artifact.id)) continue;
      const history = element('div', '', 'correction-history');
      history.append(element('p', correction.text), button('查看改进候选', async () => {
        selectedCandidateId = correction.candidateId;
        localStorage.setItem('aeeis.candidate', selectedCandidateId);
        await renderCandidateDetail(); $('candidate-detail').scrollIntoView({ block: 'center' });
      }));
      box.append(history);
    }
  }
  if (!run.artifacts.length) artifacts.append(element('p', '实际执行后，报告和其他产物会出现在这里。', 'muted'));
  $('review').textContent = run.review
    ? `审核${reviewVerdictLabel(run.review.verdict)}：${run.review.summary}${run.review.issues.length ? `\n${run.review.verdict === 'accepted' ? '提示（不影响通过）' : '问题'}：\n${run.review.issues.map(issue => `· ${issue}`).join('\n')}` : ''}`
    : '';
  $('review').dataset.state = run.review?.verdict === 'accepted' ? (run.review.issues.length ? 'warning' : 'ok') : run.review ? 'attention' : '';
  const timeline = $('timeline'); timeline.replaceChildren();
  renderTimelineFilterState();
  const timelineEvents = run.events.filter(event => timelineMatchesFilter(event.type)).sort((a, b) => a.seq - b.seq);
  if (!timelineEvents.length) timeline.append(element('li', '尚无执行事件', 'muted'));
  for (const e of timelineEvents) {
    const item = element('li', '', `timeline-item timeline-${timelineTone(e.type)}`);
    item.title = e.type;
    item.append(element('time', formatTime(e.at)), element('strong', describeEvent(e.type, e.data, true)), element('small', `#${e.seq}`));
    const details = element('details'); details.append(element('summary', '事件详情'), element('pre', JSON.stringify(e.data ?? {}, null, 2))); item.append(details);
    timeline.append(item);
  }
  const events = $('events'); events.replaceChildren();
  for (const e of run.events.slice(-60).reverse()) {
    const item = element('li', `${new Date(e.at).toLocaleTimeString()} · ${describeEvent(e.type, e.data, true)}`);
    item.title = e.type;
    const details = element('details'); details.append(element('summary', '事件详情'), element('pre', JSON.stringify(e.data ?? {}, null, 2))); item.append(details);
    events.append(item);
  }
  const reportedTokens = run.modelUsage?.tokens ?? run.calls.reduce((sum,c) => sum+(c.usage?.inputTokens ?? 0)+(c.usage?.outputTokens ?? 0),0);
  const budget = run.modelBudget ? ` · 预算 ${run.modelBudget.tokens === undefined ? '' : `${run.modelBudget.tokens} tokens`}${run.modelBudget.tokens !== undefined && run.modelBudget.moneyUsd !== undefined ? ' / ' : ''}${run.modelBudget.moneyUsd === undefined ? '' : `$${run.modelBudget.moneyUsd.toFixed(4)}`}` : '';
  const spent = run.modelUsage?.moneyUsd !== undefined ? ` · 目录价估算 $${run.modelUsage.moneyUsd.toFixed(4)}` : '';
  const external = run.externalUsage;
  const externalLimits = Object.entries(run.externalBudget ?? {}).map(([key, value]) => `${key}=${value}`).join(' / ');
  $('external-usage').textContent = external ? `外部执行：${external.calls} 次调用 · ${external.tokens} 已报告 tokens${external.moneyUsd === undefined ? '' : ` · 已报告 USD $${external.moneyUsd.toFixed(4)}`}${externalLimits ? ` · 阈值 ${externalLimits}` : ''}${external.unreportedTokenCalls ? ` · ${external.unreportedTokenCalls} 次 token 未报告` : ''}${external.unreportedMoneyCalls ? ` · ${external.unreportedMoneyCalls} 次 USD 未确认` : ''}` : '历史运行未汇总外部用量';
  $('usage').textContent = `${run.calls.length} 次模型请求 · ${reportedTokens} 已报告 tokens${spent}${budget}${run.modelUsage?.unreportedCalls ? ` · ${run.modelUsage.unreportedCalls} 次用量未确认` : ''}`;
}

function renderExplanation(explanation: RunExplanation): void {
  const panel = $('run-explanation');
  if (!panel) return;
  panel.replaceChildren();
  const attention = element('div', '', `explanation-attention ${explanation.attention.kind === 'none' ? 'clear' : 'needs-attention'}`);
  attention.append(element('strong', explanation.attention.kind === 'none' ? '当前没有待处理阻塞' : `需要关注：${explanation.attention.kind}`), element('span', explanation.attention.nextAction));
  for (const blocker of explanation.attention.blockers) attention.append(element('small', `${blocker.detail}${blocker.refs.length ? ` · ${blocker.refs.join(', ')}` : ''}`));
  panel.append(attention);
  const plan = element('div', '', 'explanation-grid');
  const task = explanation.plan.tasks;
  const planFact = element('div', '', 'fact-row');
  planFact.append(element('strong', '计划'), element('span', explanation.plan.version === undefined ? '尚未生成' : `v${explanation.plan.version} · ${task.total} 个任务`), element('small', `${task.succeeded} 已完成 · ${task.running} 执行中 · ${task.pending} 待处理`));
  plan.append(planFact);
  const execution = element('div', '', 'fact-row');
  const calls = explanation.execution.modelCalls;
  execution.append(element('strong', '执行'), element('span', `${calls.total} 次模型调用 · ${explanation.execution.eventCount} 条事件`), element('small', `Tool ${explanation.execution.tools.total} · Agent ${explanation.execution.delegations.total}`));
  plan.append(execution);
  const evidence = element('div', '', 'fact-row');
  evidence.append(element('strong', '证据'), element('span', `${explanation.evidence.sourceCount} 个来源 · ${explanation.evidence.artifactCount} 个产物 · ${explanation.evidence.receiptCount} 个回执`), element('small', `Evidence Graph ${explanation.evidence.evidenceNodeCount} 个节点`));
  if (explanation.evidence.contextManifestId) evidence.append(element('small', `Context Manifest：${explanation.evidence.contextManifestId}`));
  plan.append(evidence);
  const governance = element('div', '', 'fact-row');
  governance.append(element('strong', '治理冻结'));
  governance.append(element('span', explanation.governance.model ? `模型：${explanation.governance.model.provider ? `${explanation.governance.model.provider}/` : ''}${explanation.governance.model.model}` : '模型：未记录'));
  if (explanation.governance.skill) governance.append(element('small', `Skill：${explanation.governance.skill.methodId ?? '未命名'} ${explanation.governance.skill.version ?? ''}`));
  governance.append(element('small', `Tool ${explanation.governance.tools.length} 个 · Agent ${explanation.governance.agents.length} 个`));
  plan.append(governance);
  panel.append(plan);
  if (explanation.review) panel.append(element('p', `审核：${reviewVerdictLabel(explanation.review.verdict)} · ${explanation.review.summary}${explanation.review.confidence === undefined ? '' : ` · 置信度 ${(explanation.review.confidence * 100).toFixed(0)}%`}`, 'muted'));
}

function renderGovernance(run: RunView): void {
  const container = $('governance');
  container.replaceChildren();
  const skill = element('div', '', 'fact-row');
  skill.append(element('strong', 'Skill 治理'));
  if (run.skillSelection) {
    skill.append(element('span', `${run.skillSelection.methodId ?? '未命名方法'} · ${run.skillSelection.version ?? '未版本化'}`));
    if (run.skillRuntime) skill.append(element('small', `runtime：${run.skillRuntime}`));
    if (run.skillSelection.receiptRef) skill.append(element('small', `resolve receipt：${run.skillSelection.receiptRef}`));
    const skillDetails = element('details');
    skillDetails.append(element('summary', '查看冻结的 Skill plan'), element('pre', JSON.stringify(run.skillSelection.plan, null, 2)));
    skill.append(skillDetails);
    if (run.skillOutcome) skill.append(element('small', `结果：${run.skillOutcome.outcome}${run.skillOutcome.receiptRef ? ` · ${run.skillOutcome.receiptRef}` : ''}${run.skillOutcome.error ? ` · ${run.skillOutcome.error}` : ''}`));
  } else skill.append(element('span', '本次运行没有绑定外部 Skill 治理。', 'muted'));
  container.append(skill);

  const model = element('div', '', 'fact-row');
  model.append(element('strong', 'Model 决策'));
  if (run.modelDecision?.selected) {
    model.append(element('span', `${run.modelDecision.selected.provider ?? 'provider'} / ${run.modelDecision.selected.model ?? 'model'}`));
    if (run.modelDecision.catalogHash) model.append(element('small', `catalog hash：${run.modelDecision.catalogHash}`));
    if (run.modelDecision.catalogRetrievedAt) model.append(element('small', `目录读取：${formatTime(run.modelDecision.catalogRetrievedAt)}`));
    if (run.modelDecision.reason) model.append(element('small', run.modelDecision.reason));
  } else model.append(element('span', '固定模型或旧 Run 未保存目录决策。', 'muted'));
  container.append(model);

  const tools = element('div', '', 'fact-row');
  tools.append(element('strong', 'Tool 版本冻结'));
  if (run.approvedTools?.length) {
    tools.append(element('small', `manifest digest：${run.toolManifestDigest ?? '未记录'}`));
    for (const tool of run.approvedTools) tools.append(element('span', `${tool.id}@${tool.version} · ${tool.capabilities.join(', ')}`));
  } else tools.append(element('span', '本次运行没有获准的外部 Tool。', 'muted'));
  container.append(tools);

  if (run.resourceSnapshot) {
    const resources = element('div', '', 'fact-row');
    resources.append(element('strong', '资源快照'));
    const refs = [run.resourceSnapshot.plugin, run.resourceSnapshot.skill, run.resourceSnapshot.workflow].filter(Boolean) as Array<{ id: string; version: string; interface: string; channel?: string }>;
    for (const ref of refs) resources.append(element('span', `${ref.id}@${ref.version} · ${ref.interface}${ref.channel ? ` · ${ref.channel}` : ''}`));
    resources.append(element('small', `lockfile：${run.resourceSnapshot.lockfileDigest} · policy：${run.resourceSnapshot.policyDigest}`));
    const resourceDetails = element('details'); resourceDetails.append(element('summary', '查看资源 digest'), element('pre', JSON.stringify(run.resourceSnapshot, null, 2))); resources.append(resourceDetails);
    container.append(resources);
  }
}

function memoryWritebackForm(run: RunView, artifact: RunView['artifacts'][number]): HTMLElement {
  const details = element('details', '', 'artifact-memory');
  details.append(element('summary', '保存为 Goal 记忆'));
  const form = element('form');
  const label = (text: string, control: HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement): void => {
    const wrapper = element('label', text); wrapper.append(control); form.append(wrapper);
  };
  const kind = element('select');
  for (const [value, text] of [['note', '笔记'], ['fact', '事实'], ['decision', '决策'], ['preference', '偏好']] as const) {
    const option = element('option', text); option.value = value; kind.append(option);
  }
  label('记忆类型', kind);
  const scope = element('select');
  for (const [value, text] of [['project', '项目'], ['session', '本次会话'], ['private', '私人']] as const) {
    const option = element('option', text); option.value = value; scope.append(option);
  }
  label('记忆范围', scope);
  const classification = element('select');
  for (const value of ['public', 'internal', 'confidential', 'private'] as const) {
    const option = element('option', value === run.privacy ? `${privacyLabel(value)}（本次运行）` : privacyLabel(value)); option.value = value; classification.append(option);
  }
  classification.value = run.privacy ?? 'internal';
  label('隐私分类', classification);
  const content = element('textarea'); content.rows = 4; content.required = true; content.maxLength = 30000; content.value = artifact.content;
  label('写入内容', content);
  form.append(element('small', `证据将绑定到 ${artifact.evidenceRefs.join(', ')}，来源 Run 为 ${run.id}。写入后会进入该 Goal 的下一次上下文检索。`));
  const submit = element('button', '保存记忆'); submit.type = 'submit';
  const status = element('p'); status.setAttribute('role', 'status'); form.append(submit, status);
  form.onsubmit = event => {
    event.preventDefault(); if (!form.reportValidity()) return;
    submit.disabled = true; status.textContent = '正在保存…';
    void api(`/goals/${encodeURIComponent(run.goalId!)}/memories/from-run`, {
      runId: run.id, kind: kind.value, scope: scope.value, classification: classification.value,
      content: content.value.trim(), source: `artifact:${artifact.id}`, evidenceRefs: artifact.evidenceRefs,
    }).then(async () => { status.textContent = '已保存到 Goal 记忆。'; await refresh(); }).catch(error => { status.textContent = errorMessage(error); submit.disabled = false; });
  };
  details.append(form); return details;
}

function renderDeliverySummary(run: RunView): void {
  const messages: Record<string, string> = {
    queued: '已接收目标，等待开始规划。',
    planning: '正在把目标拆解为可审批的任务计划。',
    needs_approval: '计划已生成，等待你确认后执行。',
    running: 'Agent 正在推进任务；新的事件会自动出现在时间线。',
    reviewing: '任务已执行，正在进行独立审核。',
    needs_input: 'Agent 需要你的补充信息才能继续。',
    paused: '运行已暂停，可以在确认边界后继续。',
    waiting_external: '外部 Agent 已接收任务，等待带证据的回执。',
    unknown: '有一次外部调用结果不明确，需要先核查再继续。',
    succeeded: '本次目标已完成，下面是交付结果和证据。',
    failed: '运行未完成，可以查看原因并重试或重新规划。',
    cancelled: '运行已取消；已有产物和证据仍可查看。',
  };
  if (run.status === 'paused' && run.takeover) messages.paused = '人已接管，Bot 停在这里。交还后它从你做到的地方接着做。';
  $('delivery-message').textContent = messages[run.status] ?? `当前状态：${runStatusLabel(run.status)}`;
  const metrics = $('delivery-metrics'); metrics.replaceChildren();
  const plan = run.plans.at(-1);
  const values = [
    ['状态', runStatusLabel(run.status)],
    ['计划', plan ? `v${plan.version}` : '尚未生成'],
    ['任务', `${run.steps.length} 个`],
    ['产物', `${run.artifacts.length} 个`],
    ['事件', `${run.events.length} 条`],
    ['审核', run.review?.verdict ?? '尚未审核'],
  ];
  for (const [label, value] of values) {
    const card = element('div', '', 'delivery-metric');
    card.append(element('small', label), element('strong', value)); metrics.append(card);
  }
  renderDeliveryArtifact(run);
  renderFollowUpPlan(run);
}

function renderDeliveryArtifact(run: RunView): void {
  const box = $('delivery-artifact');
  if (!box) return;
  box.replaceChildren();
  box.hidden = true;
  const artifact = run.artifacts.at(-1);
  if (!artifact) {
    const completedCalls = run.calls.filter(call => call.state === 'completed').length;
    const model = run.model?.model ?? run.modelDecision?.selected?.model ?? '固定模型';
    const isFixture = /fixture|local/i.test(`${model} ${run.model?.endpoint ?? ''}`);
    if (run.calls.length || run.status === 'succeeded') {
      box.hidden = false;
      box.append(element('strong', run.status === 'succeeded' ? '运行已完成，但没有生成可展示的产物。' : '运行没有生成产物。'));
      if (run.calls.length) box.append(element('small', `已发起 ${run.calls.length} 次模型请求，${completedCalls} 次完成 · ${model}`, 'delivery-runtime-ok'));
      box.append(element('p', isFixture
        ? '当前连接的是本地固定协议桩：它会返回预置 JSON 来验证 AEEIS 流程，不代表真实 LLM 推理。要验证真实模型，需要配置实际 provider endpoint 和 key。'
        : '请打开它的工作台查看模型调用和事件记录。', 'delivery-artifact-warning'));
    }
    return;
  }
  box.hidden = false;
  const completedCalls = run.calls.filter(call => call.state === 'completed').length;
  const failedCalls = run.calls.filter(call => call.state === 'failed' || call.state === 'unknown').length;
  const model = run.model?.model ?? run.modelDecision?.selected?.model ?? '固定模型';
  const isFixture = /fixture|local/i.test(`${model} ${run.model?.endpoint ?? ''}`);
  const runtimeText = run.calls.length
    ? `Agent runtime 已执行：${run.calls.length} 次模型请求，${completedCalls} 次完成${failedCalls ? `，${failedCalls} 次异常` : ''} · ${model}`
    : '未记录模型调用；当前产物可能来自恢复或历史导入。';
  const runtime = element('small', runtimeText, completedCalls === run.calls.length && run.calls.length ? 'delivery-runtime-ok' : 'delivery-runtime-warning');
  const content = renderArtifactMarkdown(artifact.content);
  content.classList.add('delivery-artifact-content');
  const evidence = element('small', `证据引用：${artifact.evidenceRefs.length ? artifact.evidenceRefs.join('、') : '无外部来源引用'}`, 'delivery-artifact-evidence');
  box.append(element('div', '最终产物', 'delivery-artifact-kicker'), element('h3', artifact.title), runtime, content, evidence);
  if (isFixture) box.append(element('p', run.toolReceipts?.length
    ? '编排使用的是本地固定协议桩；上面的外部资料来自已授权 Tool，模型本身没有进行真实推理。'
    : '当前使用本地固定协议桩，仅验证 AEEIS 的规划、执行和交付协议；这份内容不能替代真实资料报告。', 'delivery-artifact-warning'));
  const open = button('打开完整产物与证据', async () => {
    setRunDetailsMode(true);
    $('artifacts')?.closest('section')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
  open.className = 'quiet-button delivery-artifact-open';
  const actions = element('div', '', 'artifact-actions');
  if (!readOnlyShare) actions.append(artifactDownloadLink(run.id, artifact, { getToken, onError: message }));
  actions.append(open);
  box.insertBefore(actions, content);
}

function renderFollowUpPlan(run: RunView): void {
  const box = $('follow-up-plan');
  box.replaceChildren();
  box.hidden = !run.followUpPlanId;
  if (readOnlyShare || !run.followUpPlanId) { box.hidden = true; return; }
  box.append(
    element('strong', '已生成后续计划'),
    element('small', `Plan ${run.followUpPlanId} · 下一步行动已从本次交付的证据中冻结`),
  );
  const status = element('p', '后续计划尚未展开。');
  const details = element('div', '', 'follow-up-plan-details');
  const open = button('查看后续任务', async () => {
    const plan = await api<DomainPlanSummary>(`/plans/${encodeURIComponent(run.followUpPlanId!)}/snapshot`);
    details.replaceChildren(
      element('p', `计划 v${plan.version} · ${plan.nodes.length} 个任务`),
      ...plan.nodes.map(node => {
        const row = element('div', '', 'follow-up-task');
        row.append(element('span', `${runStatusLabel(node.status)} · ${node.title}`));
        if (node.dependsOn.length) row.append(element('small', `依赖：${node.dependsOn.join(', ')}`));
        if (node.evidenceRefs?.length) row.append(element('small', `证据：${node.evidenceRefs.join(', ')}`));
        return row;
      }),
    );
    status.textContent = '后续任务已经从领域计划读取。可以在“长期目标”区域继续调度。';
    open.hidden = true;
  });
  box.append(status, open, details);
}

function isProjectPulseArtifact(value: unknown): value is ProjectPulseArtifact {
  if (!value || typeof value !== 'object') return false;
  const item = value as Record<string, unknown>;
  const sections = ['progress', 'completedChanges', 'blockers', 'risks', 'decisions', 'owners', 'deadlines', 'nextActions', 'unknowns'];
  return item.schemaVersion === 'project-pulse/1' && sections.every(section => Array.isArray(item[section]) && item[section].every(row => row && typeof row === 'object' && Array.isArray(row.evidenceRefs) && row.evidenceRefs.every((ref: unknown) => typeof ref === 'string')));
}

function appendProjectPulse(container: HTMLElement, pulse: ProjectPulseArtifact, run: RunView): void {
  const sectionLabels: Array<[keyof Omit<ProjectPulseArtifact, 'schemaVersion'>, string]> = [
    ['progress', '当前进展'], ['completedChanges', '已完成变更'], ['blockers', '阻塞'], ['risks', '风险'],
    ['decisions', '决策'], ['owners', '负责人'], ['deadlines', '截止日期'], ['nextActions', '下一步'], ['unknowns', '未知信息'],
  ];
  const panel = element('div', '', 'project-pulse');
  panel.append(element('strong', 'Project Pulse'));
  for (const [key, label] of sectionLabels) {
    const items = pulse[key];
    const group = element('section', '', 'pulse-group');
    group.append(element('h4', `${label} · ${items.length}`));
    if (!items.length) group.append(element('p', '暂无记录', 'muted'));
    for (const item of items) {
      const row = element('article', '', 'pulse-item');
      const copy = key === 'owners' ? `${item.name} · ${item.responsibility}` : key === 'deadlines' ? `${item.date} · ${item.text}` : String(item.text ?? '');
      row.append(element('span', copy || '结构化条目'));
      if (Array.isArray(item.evidenceRefs)) for (const ref of item.evidenceRefs) row.append(evidenceDetail(run, String(ref)));
      group.append(row);
    }
    panel.append(group);
  }
  container.append(element('small', '结构化产物 · project-pulse/1'), panel);
}

function renderPlanHistory(run: RunView): void {
  const container = $('plan-history'); container.replaceChildren();
  const comparisons = run.graphs?.planComparisons ?? [];
  if (comparisons.length === 0) return;
  const heading = element('h3', '计划版本差异');
  const note = element('p', '对比相邻版本的说明、任务、目标、证据要求、依赖和顺序。展开后可查看修改前后的内容。', 'muted');
  container.append(heading, note);
  for (const comparison of comparisons) {
    const details = element('details');
    const count = comparison.changes.length + (comparison.summary ? 1 : 0) + (comparison.order ? 1 : 0);
    details.append(element('summary', `v${comparison.fromVersion} → v${comparison.toVersion} · ${count} 项变化`));
    const pair = (parent: HTMLElement, label: string, before: string, after: string): void => {
      parent.append(element('strong', label), element('small', '修改前'), element('pre', before), element('small', '修改后'), element('pre', after));
    };
    if (comparison.summary) pair(details, '计划说明', comparison.summary.before, comparison.summary.after);
    if (comparison.order) pair(details, '任务顺序', comparison.order.before.join(' → '), comparison.order.after.join(' → '));
    for (const change of comparison.changes) {
      const item = element('div', '', 'fact-row');
      item.append(element('strong', `${change.kind === 'added' ? '新增' : change.kind === 'removed' ? '移除' : '修改'}任务 · ${change.taskId}`));
      if (change.kind === 'modified' && change.before && change.after) {
        for (const field of change.fields) {
          const label = { title: '标题', instruction: '执行要求', dependsOn: '依赖', evidenceRequirements: '证据要求' }[field];
          const display = (value: string | string[] | undefined) => Array.isArray(value) ? value.join('、') || '无' : value ?? '未设置';
          pair(item, label, display(change.before[field]), display(change.after[field]));
        }
      } else {
        const node = change.after ?? change.before;
        if (node) item.append(element('p', node.title), element('pre', node.instruction), element('small', `依赖：${node.dependsOn.join('、') || '无'}`));
      }
      details.append(item);
    }
    if (!count) details.append(element('p', '计划说明、任务定义和依赖没有变化。', 'muted'));
    container.append(details);
  }
}

function timelineTone(type: string): 'success' | 'failure' | 'waiting' | 'neutral' {
  if (type.startsWith('context.summary_')) return type.endsWith('_active') ? 'neutral' : 'failure';
  if (/succeed|complete|accepted|finished|artifact|review.accepted|goal.completed/i.test(type)) return 'success';
  if (/fail|error|reject|cancel|unknown|blocked/i.test(type)) return 'failure';
  if (/wait|pause|approval|question|input|reconcile/i.test(type)) return 'waiting';
  return 'neutral';
}

function renderGraphList(container: HTMLElement, graph: { nodes: GraphNodeView[]; edges: GraphEdgeView[] } | undefined, emptyText: string): void {
  container.replaceChildren();
  if (!graph || graph.nodes.length === 0) { container.append(element('p', emptyText, 'muted')); return; }
  const nodes = element('div', '', 'graph-list');
  for (const node of graph.nodes) {
    const row = element('div', '', `graph-item ${node.status ?? ''}`);
    row.append(element('strong', node.label), element('small', `${node.type} · ${node.id}${node.status ? ` · ${runStatusLabel(node.status)}` : ''}`));
    if (node.metadata && Object.keys(node.metadata).length) row.append(element('small', JSON.stringify(node.metadata)));
    nodes.append(row);
  }
  container.append(nodes);
  if (graph.edges.length) {
    const edges = element('details'); edges.append(element('summary', `${graph.edges.length} 条关系`));
    const list = element('ul');
    for (const edge of graph.edges) list.append(element('li', `${edge.from} → ${edge.to} · ${edge.type}`));
    edges.append(list); container.append(edges);
  }
}
($('reminder-status-filter') as HTMLSelectElement | null)?.addEventListener('change', event => {
  reminderStatusFilter = (event.target as HTMLSelectElement).value;
  void refresh().catch(error => message(errorMessage(error)));
});
($('reminders-more') as HTMLButtonElement | null)?.addEventListener('click', event => {
  const button = event.currentTarget as HTMLButtonElement; button.disabled = true;
  void loadMoreReminders().catch(error => message(errorMessage(error))).finally(() => { button.disabled = false; });
});
function updateReminderFields(): void {
  const repeat = $<HTMLSelectElement>('reminder-repeat').value;
  $('reminder-interval-fields').hidden = repeat !== 'interval';
  $('reminder-calendar-fields').hidden = !['daily', 'weekly', 'monthly'].includes(repeat);
  $('reminder-weekly-fields').hidden = repeat !== 'weekly';
  $('reminder-monthly-fields').hidden = repeat !== 'monthly';
}
$('reminder-repeat')?.addEventListener('change', updateReminderFields);
($('new-reminder') as HTMLFormElement | null)?.addEventListener('submit', event => {
  event.preventDefault();
  const form = event.currentTarget as HTMLFormElement;
  const submit = form.querySelector('button') as HTMLButtonElement;
  submit.disabled = true; message('');
  void Promise.resolve().then(() => {
    const repeat = $<HTMLSelectElement>('reminder-repeat').value;
    const max = $<HTMLInputElement>('reminder-max-occurrences').value;
    const limit = max ? { maxOccurrences: Number(max) } : {};
    const recurrence = repeat === 'once' ? undefined : repeat === 'interval'
      ? { intervalMs: Number($<HTMLInputElement>('reminder-interval').value) * 60_000, ...limit }
      : { calendar: { frequency: repeat, timeZone: $<HTMLInputElement>('reminder-time-zone').value.trim(), time: $<HTMLInputElement>('reminder-local-time').value,
          ...(repeat === 'weekly' ? { daysOfWeek: $<HTMLInputElement>('reminder-weekdays').value.split(',').map(value => Number(value.trim())) } : {}),
          ...(repeat === 'monthly' ? { dayOfMonth: Number($<HTMLInputElement>('reminder-month-day').value) } : {}),
        }, ...limit };
    return api('/reminders', { title: $<HTMLInputElement>('reminder-title').value, message: $<HTMLTextAreaElement>('reminder-message').value, dueAt: new Date($<HTMLInputElement>('reminder-due-at').value).toISOString(), channel: $<HTMLInputElement>('reminder-channel').value, destination: $<HTMLInputElement>('reminder-destination').value, privacy: $<HTMLSelectElement>('reminder-privacy').value, ...(recurrence ? { recurrence } : {}) });
  }).then(async () => { form.reset(); updateReminderFields(); await refresh(); })
    .catch(error => message(errorMessage(error))).finally(() => { submit.disabled = false; });
});
$('new-run').onsubmit = event => {
  event.preventDefault(); const submit = $('submit') as HTMLButtonElement; submit.disabled = true; submit.classList.add('is-busy'); submit.setAttribute('aria-busy', 'true'); message('');
  const goalId = $<HTMLSelectElement>('goal-id').value;
  const goal = $<HTMLTextAreaElement>('goal').value;
  let quickRunOutcome = '';
  void Promise.resolve().then(() => {
    const options = runOptions(true, goal);
    quickRunOutcome = options.planning === 'direct' ? '已启动，正在准备直接执行…' : '已启动，正在生成计划…';
    return api<{ id: string }>('/runs', { goal, ...(goalId ? { goalId } : {}), ...options });
  })
    .then(async result => {
      setCurrentRunOpen(true);
      currentId = result.id;
      current = undefined;
      localStorage.setItem('aeeis.run', currentId);
      await refresh();
      window.requestAnimationFrame(() => $('run-workspace')?.scrollIntoView({ behavior: 'smooth', block: 'start' }));
    })
    .catch(error => { quickRunOutcome = '启动失败，请检查输入'; message(errorMessage(error)); })
    .finally(() => { submit.disabled = false; submit.classList.remove('is-busy'); submit.removeAttribute('aria-busy'); setQuickRunBusy(false, quickRunOutcome); });
};
$('conversation-earlier').onclick = () => {
  if (!conversation?.messages[0] || conversationBusy) return;
  const id = conversation.id, first = conversation.messages[0].id, epoch = conversationEpoch;
  conversationBusy = true; updateConversationControls();
  void api<ConversationView>(`/conversations/${encodeURIComponent(id)}?before=${encodeURIComponent(first)}`).then(page => {
    if (conversationEpoch !== epoch || conversation?.id !== id) return;
    if (page.revision !== conversation.revision) throw new Error('对话已更新，请刷新后再读取更早消息');
    conversation = { ...conversation, messages: [...page.messages, ...conversation.messages], hasEarlierMessages: page.hasEarlierMessages ?? false };
    renderConversation();
  }).catch(error => { $('conversation-error').textContent = errorMessage(error); }).finally(() => { if (conversationEpoch === epoch) { conversationBusy = false; updateConversationControls(); } });
};
$('answer-form').onsubmit = event => {
  event.preventDefault();
  const form = event.currentTarget as HTMLFormElement;
  const submit = form.querySelector('button') as HTMLButtonElement;
  const answer = $<HTMLTextAreaElement>('answer').value.trim();
  if (!answer) return;
  submit.disabled = true;
  submit.classList.add('is-busy');
  submit.setAttribute('aria-busy', 'true');
  message('');
  const action = inputPanelMode === 'answer' ? 'answer' : inputPanelMode === 'reconcile-cancelled' ? 'reconcile-cancelled' : 'reconcile';
  void command(action, inputPanelMode === 'answer' ? { answer } : { reason: answer })
    .then(() => { $<HTMLTextAreaElement>('answer').value = ''; })
    .catch(error => message(errorMessage(error)))
    .finally(() => { submit.disabled = false; submit.classList.remove('is-busy'); submit.removeAttribute('aria-busy'); });
};
// The composer starts as one box and Send; who is speaking and which task a message goes to open from 更多.
$('conversation-more').addEventListener('click', () => {
  const form = $('conversation-composer');
  const open = form.dataset.more !== 'true';
  form.dataset.more = String(open);
  $('conversation-more').setAttribute('aria-expanded', String(open));
});
$('connect').onclick = () => {
  const token = cleanToken($<HTMLInputElement>('token').value);
  if (token === undefined) { badTokenNotice = false; message(BAD_TOKEN); $<HTMLInputElement>('token').focus(); return; }
  badTokenNotice = false;
  $<HTMLInputElement>('token').value = token;
  if (token !== (getToken() ?? '')) {
    resetConversation(); conversationScope = '';
    stopRunEventStream(); current = undefined; currentId = ''; pendingFollowup = undefined;
    localStorage.removeItem('aeeis.run'); $('detail').hidden = true; $('thread-panel').hidden = true;
    $('run-share-result').replaceChildren(); $('thread-share-result').replaceChildren();
  }
  setToken(token);
  const connect = $('connect') as HTMLButtonElement;
  connect.disabled = true;
  connect.classList.add('is-busy');
  setSystemSignal('loading');
  void initialize().finally(() => { connect.disabled = false; connect.classList.remove('is-busy'); });
};
$('forget-token').onclick = () => {
  clearToken();
  $<HTMLInputElement>('token').value = '';
  $('connect').click();
};
async function initialize(): Promise<void> {
  if (linkedThreadId) { await refresh().catch(error => message(errorMessage(error))); return; }
  if (readOnlyShare) {
    $('instance-mode').textContent = '只读分享 · Read-only';
    await refresh().catch(error => message(errorMessage(error)));
    return;
  }
  try {
    const status = await api<RuntimeStatus>('/status');
    const toolHelp = $('tool-config-summary');
    try {
      const toolCatalog = await api<{ tools: { id: string }[]; defaultAllowedTools: string[] }>('/tools');
      const allowedTools = $<HTMLInputElement>('allowed-tools');
      if (!allowedTools.dataset.initialized) {
        if (!allowedTools.value.trim()) allowedTools.value = toolCatalog.defaultAllowedTools.join(', ');
        syncEntryDefaults();
        allowedTools.dataset.initialized = 'true';
      }
      if (toolHelp) toolHelp.textContent = toolCatalog.tools.length
        ? `已连接：${toolCatalog.tools.map(tool => tool.id).join('、')}。默认选择来自服务端配置；清空可禁用本次运行的外部工具。`
        : '尚未配置工具；本次运行只能使用提供的资料。';
    } catch (error) {
      if (toolHelp) toolHelp.textContent = `工具暂不可用：${status.toolsHealth?.detail ?? errorMessage(error)}。恢复后重新连接以加载工具。`;
    }

    const mode = $('instance-mode');
    const modeLabels: Record<string, string> = { 'single-owner-local': '开发版 · 单用户本地模式', 'static-principal-scoped': '开发版 · Principal / Tenant 隔离', 'oidc-principal-scoped': '开发版 · OIDC Principal / Tenant 隔离', 'principal-scoped': '开发版 · Principal / Tenant 隔离' };
    mode.textContent = modeLabels[status.mode] ?? `开发版 · ${status.mode}`;
    mode.dataset.state = status.modelConfigured && status.modelHealth?.ready !== false ? 'ready' : 'attention';
    mode.title = status.principal ? `当前身份：${status.principal} · 租户：${status.tenantId ?? 'default'} · 角色：${(status.roles ?? []).join(', ') || '未声明'}` : '';
    renderRuntimeStatus(status);
    const profile = status.executionProfile === 'fixture' ? '当前为 Fixture 演示环境：流程可验证，但结果不代表真实模型能力。' : '当前依赖被标记为未验证；请确认已接入真实模型和生产治理服务。';
    const fullConfiguration = status.modelConfigured
      ? `${profile} ${status.model ? `${status.model.model} · ${status.runner}` : `模型目录路由 · ${status.runner}`}。${status.modelHealth?.ready === false ? `模型探测失败：${status.modelHealth.detail ?? '未知原因'}。` : ''}${status.skillGovernanceConfigured && status.skillGovernanceHealth?.ready === false ? ` OwnHow 探测失败：${status.skillGovernanceHealth.detail ?? '未知原因'}。` : ''}${status.knowledgeConfigured ? 'Knowledge 已启用；' : ''}${status.evolutionConfigured ? 'RSI 候选存储已启用；' : ''}${status.collaborationConfigured ? '协作平面已启用。' : ''}`
      : '尚未配置模型。请在服务端设置 AEEIS_MODEL_BASE_URL、AEEIS_MODEL，或配置 AEEIS_PLANPRICE_URL 后重启；Knowledge、RSI 和协作状态仍可查看，但不会生成模拟结果。';
    const minimalConfiguration = status.modelConfigured
      ? `已连接 · ${status.model ? `${status.model.model} · ${status.runner}` : '模型目录路由'}${status.toolsConfigured && status.toolsHealth?.ready === false ? ' · 工具暂不可用，请查看设置' : ''}`
      : '模型尚未连接；点击“连接模型”打开运行配置。';
    const configuration = $('configuration');
    configuration.dataset.fullText = fullConfiguration;
    configuration.dataset.minimalText = minimalConfiguration;
    syncConfigurationNotice();
    const configAction = $('config-action') as HTMLButtonElement | null;
    if (configAction) {
      configAction.hidden = status.modelConfigured && status.modelHealth?.ready !== false;
      configAction.textContent = status.modelConfigured ? '检查运行配置' : '打开运行配置';
    }
    evolutionConfigured = status.evolutionConfigured;
    sessionPrincipal = status.principal ?? '';
    modelConfigured = status.modelConfigured;
    routinesConfigured = Boolean(status.routinesConfigured);
    runtimeModel = status.model?.model ?? '';
    taskSchedulerConfigured = status.taskSchedulerConfigured;
    botsActive = Boolean(status.botTeamConfigured);
    authRequired = false;
    quickRunReady = status.modelConfigured && status.modelHealth?.ready !== false;
    syncConfigurationNotice();
    syncDetailsToggleLabel();
    setSystemSignal(quickRunReady ? 'connected' : 'attention');
    ($('submit') as HTMLButtonElement).disabled = !quickRunReady;
    const quickSubmit = document.querySelector<HTMLButtonElement>('#quick-run button[type="submit"]');
    if (quickSubmit) {
      quickSubmit.disabled = !quickRunReady;
      quickSubmit.title = quickRunReady ? '发送' : '请先连接模型';
      const label = quickSubmit.querySelector('span');
      if (!quickRunReady) quickSubmit.childNodes[0]!.textContent = '等待连接 ';
      else if (label) quickSubmit.childNodes[0]!.textContent = '发送 ';
    }
    await initializeConversations(status);
    await refresh(); message('');
    await openLinkedRoom();
    if (minimalMode && !currentId) window.requestAnimationFrame(() => {
      if (conversationEnabled) $<HTMLTextAreaElement>('conversation-text').focus();
      else if (quickRunReady) $<HTMLInputElement>('quick-goal').focus();
      else ($('details-toggle') as HTMLButtonElement | null)?.focus();
    });
  } catch (e) {
    if (e instanceof ApiError && [401, 403].includes(e.status)) resetConversation();
    modelConfigured = false;
    quickRunReady = false;
    syncDetailsToggleLabel();
    ($('submit') as HTMLButtonElement | null)?.setAttribute('disabled', 'true');
    const quickSubmit = document.querySelector<HTMLButtonElement>('#quick-run button[type="submit"]');
    if (quickSubmit) {
      quickSubmit.disabled = true;
      quickSubmit.title = '运行服务暂时不可用';
      quickSubmit.childNodes[0]!.textContent = '等待连接 ';
    }
    const configAction = $('config-action') as HTMLButtonElement | null;
    if (configAction) { configAction.hidden = false; configAction.textContent = '检查运行配置'; }
    setSystemSignal('offline');
    const mode = $('instance-mode');
    if (mode) { mode.dataset.state = 'offline'; mode.textContent = '运行服务不可达'; }
    message(errorMessage(e));
  }
}
if (linkedRunId || linkedThreadId || readOnlyShare) { setCurrentRunOpen(true); setRunDetailsMode(true); }
($('thread-more') as HTMLButtonElement).addEventListener('click', event => {
  if (threadNextAfter === undefined) return;
  const control = event.currentTarget as HTMLButtonElement; control.disabled = true;
  threadPagesAfter.push(threadNextAfter);
  void refresh().catch(error => { threadPagesAfter.pop(); message(errorMessage(error)); }).finally(() => { control.disabled = false; });
});
$('thread-parent').addEventListener('change', () => {
  $<HTMLSelectElement>('thread-privacy').value = threadRuns.find(run => run.id === $<HTMLSelectElement>('thread-parent').value)?.privacy ?? 'internal';
});
($('thread-followup') as HTMLFormElement).addEventListener('input', () => { if (!followupSubmitting) pendingFollowup = undefined; });
($('thread-followup') as HTMLFormElement).addEventListener('submit', event => {
  event.preventDefault();
  if (!linkedThreadId || readOnlyShare || followupSubmitting) return;
  const goal = $<HTMLTextAreaElement>('thread-message').value.trim();
  if (!goal) return;
  const parentRunId = $<HTMLSelectElement>('thread-parent').value;
  const body = { request: { goal, privacy: $<HTMLSelectElement>('thread-privacy').value }, ...(parentRunId ? { parentRunId } : {}) };
  const signature = JSON.stringify(body);
  if (pendingFollowup?.signature !== signature) pendingFollowup = { key: crypto.randomUUID(), body, signature };
  const attempt = pendingFollowup;
  const submit = $<HTMLButtonElement>('thread-submit'); submit.disabled = true; followupSubmitting = true;
  void api<RunView>(`/threads/${linkedThreadId}/runs`, attempt.body, 'POST', attempt.key).then(async run => {
    pendingFollowup = undefined; currentId = run.id; $<HTMLTextAreaElement>('thread-message').value = ''; await refresh();
  }).catch(error => message(errorMessage(error))).finally(() => { followupSubmitting = false; submit.disabled = !pendingFollowup && Boolean(threadRuns.length && !threadRuns.some(run => ['succeeded', 'failed', 'cancelled'].includes(run.status))); });
});
($('create-thread-share') as HTMLButtonElement).addEventListener('click', async event => {
  if (!linkedThreadId || readOnlyShare) return;
  const control = event.currentTarget as HTMLButtonElement; control.disabled = true;
  try {
    const share = await api<{ url: string; id: string; expiresAt: string; throughSequence: number }>(`/threads/${linkedThreadId}/share`, {});
    const url = new URL(share.url, window.location.origin).href, link = element('a', url); link.href = url;
    const revoke = button('撤销分享', async () => { await api(`/threads/${linkedThreadId}/share/${share.id}`, undefined, 'DELETE'); $('thread-share-result').replaceChildren(element('span', '分享已撤销')); });
    $('thread-share-result').replaceChildren(link, element('small', `截至 #${share.throughSequence} · 到期：${new Date(share.expiresAt).toLocaleString()}`), revoke);
    await copyRunLink(url).catch(() => undefined);
  } catch (error) { message(errorMessage(error)); }
  finally { control.disabled = false; }
});
($('copy-run-link') as HTMLButtonElement | null)?.addEventListener('click', () => {
  const url = readOnlyShare ? window.location.href : new URL(`/runs/${currentId}`, window.location.origin).href;
  void copyRunLink(url).then(() => message('链接已复制')).catch(() => {
    const link = element('a', url); link.href = url;
    $('run-share-result').replaceChildren(link);
    message('请选择并复制链接');
  });
});
async function copyRunLink(url: string): Promise<void> { await navigator.clipboard.writeText(url); }
($('create-run-share') as HTMLButtonElement | null)?.addEventListener('click', async event => {
  const button = event.currentTarget as HTMLButtonElement;
  const runId = currentId;
  button.disabled = true;
  try {
    const share = await api<{ url: string; expiresAt: string }>(`/runs/${runId}/share`, {});
    const url = new URL(share.url, window.location.origin).href;
    if (currentId !== runId) return;
    const result = $('run-share-result');
    result.replaceChildren();
    const link = element('a', url); link.href = url;
    result.append(link, element('small', ` · 到期：${formatTime(share.expiresAt)}`));
    await copyRunLink(url).catch(() => undefined);
  } catch (error) { message(errorMessage(error)); }
  finally { button.disabled = false; }
});
if (!readOnlyShare) {
  // A token saved before cleanToken existed may still carry characters fetch refuses; clean it or drop it.
  // A token only an older build kept in sessionStorage moves to localStorage here.
  const saved = getToken();
  const token = saved === null ? '' : cleanToken(saved);
  setToken(token ?? '');
  if (saved && token === undefined) { badTokenNotice = true; message(BAD_TOKEN); }
  $<HTMLInputElement>('token').value = token ?? '';
}
void initialize();
setInterval(() => { if (polling || document.hidden) return; polling = true; void refresh(true).catch(error => message(errorMessage(error))).finally(() => { polling = false; }); }, 2000);
window.setInterval(() => {
  if (!document.hidden && current && !DONE_STATUSES.has(current.status)) updateRunActivity(current);
}, 1000);
document.addEventListener('visibilitychange', () => {
  if (document.hidden || !currentId || polling) return;
  polling = true;
  void refresh().catch(error => message(errorMessage(error))).finally(() => { polling = false; });
});
window.addEventListener('offline', () => { setLiveConnection('offline'); setSystemSignal('offline'); });
window.addEventListener('online', () => {
  setSystemSignal('loading');
  void initialize();
});

function evidenceDetail(run: RunView, ref: string): HTMLElement {
  const source = run.context?.sources.find(item => item.id === ref);
  const artifact = run.artifacts.find(item => item.id === ref);
  const box = element('details', '', 'pulse-evidence');
  box.append(element('summary', source?.title ?? artifact?.title ?? `证据 ${ref}`));
  box.append(element('small', ref), element('pre', source?.content ?? artifact?.content ?? '调用回执可在本次运行的证据图和外部调用记录中核查。'));
  return box;
}

function correctionForm(run: RunView, artifact: RunView['artifacts'][number]): HTMLElement {
  const details = element('details', '', 'artifact-correction');
  details.append(element('summary', '提出改进建议'));
  const form = element('form');
  const label = (text: string, control: HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement) => {
    const wrapper = element('label', text); wrapper.append(control); form.append(wrapper);
  };
  const target = element('select');
  for (const [value, text] of [['profile', '个人偏好'], ['prompt', '工作方法']] as const) {
    const option = element('option', text); option.value = value; target.append(option);
  }
  label('希望改进什么', target);
  const base = element('input'); base.readOnly = true;
  const updateBase = () => { base.value = run.evolution?.find(item => item.target === target.value)?.version ?? `${target.value}/1`; };
  target.onchange = updateBase; updateBase(); label('本次运行使用的版本', base);
  const reason = element('textarea'); reason.required = true; reason.maxLength = 4000; reason.rows = 3;
  reason.placeholder = '这份结果哪里需要改进？'; label('问题与原因', reason);
  const change = element('textarea'); change.required = true; change.maxLength = 8000; change.rows = 3;
  change.placeholder = '例如：先列出阻塞和下一步，再提供详细背景。'; label('以后应该怎样做', change);
  const risk = element('select');
  for (const [value, text] of [['medium', '中：影响工作方式'], ['low', '低：仅格式和措辞偏好'], ['high', '高：需要更严格评估']] as const) {
    const option = element('option', text); option.value = value; risk.append(option);
  }
  label('影响范围', risk);
  form.append(element('small', '绑定当前产物作为证据。提交后生成候选，须经过评测、审批和激活才会影响后续运行。'));
  const status = element('p'); status.setAttribute('role', 'status');
  const submit = element('button', '提交改进候选'); submit.type = 'submit'; form.append(submit, status);
  form.onsubmit = event => {
    event.preventDefault(); if (!form.reportValidity()) return;
    const proposedVersion = `${target.value}/${crypto.randomUUID()}`;
    submit.disabled = true; status.textContent = '正在保存…';
    void api<{ candidate: EvolutionView }>(`/runs/${encodeURIComponent(run.id)}/corrections`, {
      target: target.value, baseVersion: base.value, proposedVersion, change: change.value.trim(), reason: reason.value.trim(), risk: risk.value,
      sourceReceiptRefs: [artifact.id],
    }).then(async result => {
      selectedCandidateId = result.candidate.id; localStorage.setItem('aeeis.candidate', result.candidate.id);
      form.replaceChildren(element('p', '改进候选已保存，等待评测。')); await refresh();
    }).catch(error => { status.textContent = errorMessage(error); submit.disabled = false; });
  };
  details.append(form); return details;
}


$('channel-noise-open')?.addEventListener('click', () => {
  const roomId = openGroupId;
  if (!roomId) return;
  void api<ChannelNoiseSettings>(`/rooms/${encodeURIComponent(roomId)}/noise-settings`).then(settings => {
    if (openGroupId !== roomId) return;
    $<HTMLSelectElement>('channel-noise-mode')!.value = settings.mode;
    $<HTMLInputElement>('channel-noise-minutes')!.value = String(settings.digestMinutes);
    $<HTMLInputElement>('channel-noise-hours')!.checked = Boolean(settings.quietHours);
    $<HTMLInputElement>('channel-noise-start')!.value = settings.quietHours?.start ?? '22:00';
    $<HTMLInputElement>('channel-noise-end')!.value = settings.quietHours?.end ?? '08:00';
    $<HTMLInputElement>('channel-noise-zone')!.value = settings.quietHours?.timeZone ?? Intl.DateTimeFormat().resolvedOptions().timeZone;
    document.querySelectorAll<HTMLInputElement | HTMLSelectElement | HTMLButtonElement>('#channel-noise-form input, #channel-noise-form select, #channel-noise-form button').forEach(input => { input.disabled = !settings.canEdit; });
    $('channel-noise-note')!.textContent = settings.canEdit ? '' : '只有群主可以修改。';
    $('channel-noise')!.hidden = false;
  }).catch(error => message(errorMessage(error)));
});
$('channel-noise-close')?.addEventListener('click', () => { $('channel-noise')!.hidden = true; });
$('channel-noise-form')?.addEventListener('submit', event => {
  event.preventDefault();
  const roomId = openGroupId;
  if (!roomId) return;
  const value = (id: string) => $<HTMLInputElement>(id)!.value;
  const save = $<HTMLButtonElement>('channel-noise-save')!;
  save.disabled = true;
  void api(`/rooms/${encodeURIComponent(roomId)}/noise-settings`, {
    mode: value('channel-noise-mode'), digestMinutes: Number(value('channel-noise-minutes')),
    quietHours: $<HTMLInputElement>('channel-noise-hours')!.checked ? { start: value('channel-noise-start'), end: value('channel-noise-end'), timeZone: value('channel-noise-zone') } : null,
  }, 'PUT').then(() => { if (roomId === openGroupId) $('channel-noise-note')!.textContent = '已保存'; })
    .catch(error => message(errorMessage(error))).finally(() => { save.disabled = false; });
});
