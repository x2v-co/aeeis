import { acquireFileWriter, releaseFileWriter } from './adapters/file-writer-lock.js';
import { persistBoardAction, boardControlVersion } from './task-board-controls.js';
import { ChannelDigestDelivery } from './channel-digest.js';
import { InMemoryChannelNoiseStore, type ChannelNoiseStore, type ChannelScope } from './channel-noise.js';
import { mkdir, open, readFile, rename, unlink, type FileHandle } from 'node:fs/promises';
import { dirname } from 'node:path';
import pg from 'pg';
import { z } from 'zod';
import { contextManifestBindingHash } from './context-manifest-binding.js';
import { digestProtocol } from './protocol.js';
import { contextAudienceSnapshotSchema, type ContextAudienceSnapshot } from './context-audience.js';
import type { ContextManifest, Id } from './contracts.js';
import type { AeeisService } from './application/aeeis-service.js';
import { AeeisConflict, AeeisNotFound } from './application/aeeis-service.js';
import { principalAudience } from './security/principal.js';
import { channelTaskActionSchema, type ChannelTaskAction } from './channel-task-action.js';
import { withPostgresMigrationLock } from './adapters/postgres-migration.js';
import { createPostgresPool } from './adapters/postgres-pool.js';
import { openAggregate, pick, sealAggregate } from './content-encryption.js';

const id = z.string().regex(/^[a-z][a-z0-9_.-]{1,127}$/);
const isoDate = z.string().datetime({ offset: true });
const hash = z.string().regex(/^[a-f0-9]{64}$/);

export const sessionEventTypeSchema = z.enum(['message', 'canonical_response', 'decision', 'task_update', 'system', 'digest']);
export type SessionEventType = z.infer<typeof sessionEventTypeSchema>;
export const sessionEventActorTypeSchema = z.enum(['principal', 'agent', 'system']);
export type SessionEventActorType = z.infer<typeof sessionEventActorTypeSchema>;
export const sessionEventClassificationSchema = z.enum(['public', 'internal', 'confidential', 'private']);
export type SessionEventClassification = z.infer<typeof sessionEventClassificationSchema>;
export const sessionEventOperationSchema = z.enum(['publish', 'revise', 'retract']);
export type SessionEventOperation = z.infer<typeof sessionEventOperationSchema>;

export const sessionEventSchema = z.object({
  schemaVersion: z.literal('session-event/1'),
  id,
  roomId: id,
  goalId: id.optional(),
  owner: z.string().min(1).max(200),
  tenantId: z.string().min(1).max(200),
  sequence: z.number().int().positive(),
  type: sessionEventTypeSchema,
  actorId: z.string().min(1).max(200),
  actorType: sessionEventActorTypeSchema,
  operation: sessionEventOperationSchema.default('publish'),
  targetEventId: id.optional(),
  revision: z.number().int().positive().default(1),
  retractionReason: z.string().trim().min(1).max(4000).optional(),
  classification: sessionEventClassificationSchema.default('internal'),
  contextManifestId: id,
  contextManifestHash: hash,
  audienceSnapshot: contextAudienceSnapshotSchema,
  content: z.string().trim().min(1).max(20_000),
  contentHash: hash,
  evidenceRefs: z.array(id).max(200),
  idempotencyKey: z.string().trim().min(1).max(500),
  recordedBy: z.object({ id: z.string().min(1).max(200), type: sessionEventActorTypeSchema }).strict().optional(),
  /** Structured channel task action. The board reads this, never `content`. */
  taskAction: channelTaskActionSchema.optional(),
  notificationKind: z.enum(['approval', 'question', 'blocked', 'failure', 'escalation', 'channel-upgrade', 'progress', 'message']).optional(),
  botDelivery: z.object({ mode: z.enum(['immediate', 'digest']), at: isoDate }).strict().optional(),
  digest: z.object({ eventIds: z.array(id).min(1), minutes: z.number().int().min(15).max(30) }).strict().optional(),
  createdAt: isoDate,
}).strict().superRefine((event, ctx) => {
  if (event.taskAction && event.operation !== 'publish') ctx.addIssue({ code: 'custom', message: 'A task action cannot be revised or retracted' });
  if (event.taskAction && !(event.type === 'task_update' || (event.type === 'system' && event.taskAction.kind === 'hand_up'))) ctx.addIssue({ code: 'custom', message: 'A task action belongs on a task update' });
  if (event.operation === 'publish' && (event.targetEventId !== undefined || event.revision !== 1 || event.retractionReason !== undefined)) ctx.addIssue({ code: 'custom', message: 'Published event cannot carry revision metadata' });
  if (event.operation === 'revise' && (!event.targetEventId || event.revision < 2 || event.retractionReason !== undefined)) ctx.addIssue({ code: 'custom', message: 'Revision requires a target and revision number' });
  if (event.operation === 'retract' && (!event.targetEventId || !event.retractionReason)) ctx.addIssue({ code: 'custom', message: 'Retraction requires a target and reason' });
});
export type SessionEvent = z.infer<typeof sessionEventSchema>;

export interface SessionEventDraft {
  roomId: Id;
  goalId?: Id;
  owner: string;
  tenantId: string;
  type: SessionEventType;
  actorId: string;
  actorType: SessionEventActorType;
  operation?: SessionEventOperation;
  targetEventId?: Id;
  revision?: number;
  retractionReason?: string;
  classification?: SessionEventClassification;
  contextManifestId: Id;
  contextManifestHash: string;
  audienceSnapshot: ContextAudienceSnapshot;
  content: string;
  contentHash: string;
  evidenceRefs: Id[];
  idempotencyKey: string;
  recordedBy?: { id: string; type: SessionEventActorType };
  taskAction?: ChannelTaskAction;
  notificationKind?: 'approval' | 'question' | 'blocked' | 'failure' | 'escalation' | 'channel-upgrade' | 'progress' | 'message';
  botDelivery?: { mode: 'immediate' | 'digest'; at: string };
  digest?: { eventIds: string[]; minutes: number };
  createdAt: string;
}

export interface SessionEventPage { items: SessionEvent[]; nextCursor?: string; previousCursor?: string }
export interface SessionEventScope { tenantId: string; owner?: string }
/** Checks the events already written about one task before a new action is
 * appended. It runs inside the same serialization boundary as sequence
 * allocation, so two writers cannot both pass it. Throw to refuse. */
export type TaskActionGuard = (events: SessionEvent[]) => void | Promise<void>;
export interface SessionEventRepository {
  boardRoomsPage?(after?: string, limit?: number): Promise<{ items: ChannelScope[]; next?: string }>;
  pendingDigestRooms?(): Promise<ChannelScope[]>;
  init?(): Promise<void>;
  append(draft: SessionEventDraft): Promise<SessionEvent>;
  /** Append a task action after `guard` accepts the events that already
   * cite `taskId` in this room. A replayed idempotency key returns the
   * original event without running the guard. */
  appendGuarded(draft: SessionEventDraft, taskId: Id, guard: TaskActionGuard): Promise<SessionEvent>;
  /** Append a revision/retraction while atomically asserting that the target
   * still has no child event. Durable repositories must perform this check in
   * the same serialization boundary as sequence allocation. */
  appendLinear?(draft: SessionEventDraft, targetEventId: Id, expectedTargetRevision: number): Promise<SessionEvent>;
  get(id: Id, scope?: SessionEventScope): Promise<SessionEvent | undefined>;
  page(roomId: Id, scope: SessionEventScope | undefined, limit: number, afterSequence?: number): Promise<SessionEventPage>;
  /** The newest `limit` events before `beforeSequence` (or the newest of
   * all), in ascending order. `previousCursor` is set when older events
   * remain and is the sequence to pass as the next `beforeSequence`. */
  pageBefore(roomId: Id, scope: SessionEventScope | undefined, limit: number, beforeSequence?: number): Promise<SessionEventPage>;
  findByTarget?(roomId: Id, targetEventId: Id, scope?: SessionEventScope): Promise<SessionEvent[]>;
  close(): Promise<void>;
}

export class SessionEventConflict extends Error {}

/** In-memory repository used by protocol tests and embedded deployments. */
export class InMemorySessionEventRepository implements SessionEventRepository {
  private readonly events: SessionEvent[] = [];

  async append(input: SessionEventDraft): Promise<SessionEvent> {
    const existing = this.events.find(event => event.roomId === input.roomId && event.owner === input.owner && event.tenantId === input.tenantId && event.idempotencyKey === input.idempotencyKey);
    if (existing) return sameDraft(existing, input);
    const event = sessionEventSchema.parse({ schemaVersion: 'session-event/1', id: `session_event_${this.events.length + 1}_${Date.now()}`, sequence: this.events.filter(item => item.roomId === input.roomId && item.owner === input.owner && item.tenantId === input.tenantId).length + 1, ...input });
    this.events.push(structuredClone(event));
    return structuredClone(event);
  }
  async appendLinear(input: SessionEventDraft, targetEventId: Id, expectedTargetRevision: number): Promise<SessionEvent> {
    const existing = this.events.find(event => event.roomId === input.roomId && event.owner === input.owner && event.tenantId === input.tenantId && event.idempotencyKey === input.idempotencyKey);
    if (existing) return sameDraft(existing, input);
    const target = this.events.find(event => event.id === targetEventId && event.roomId === input.roomId && event.owner === input.owner && event.tenantId === input.tenantId);
    if (!target) throw new SessionEventConflict('Unknown session event revision target');
    if (target.revision !== expectedTargetRevision) throw new SessionEventConflict('Session event target revision is stale');
    if (this.events.some(event => event.roomId === input.roomId && event.owner === input.owner && event.tenantId === input.tenantId && event.targetEventId === targetEventId)) throw new SessionEventConflict('Only the latest canonical response revision can be changed');
    const count = this.events.filter(event => event.roomId === input.roomId && event.owner === input.owner && event.tenantId === input.tenantId).length;
    const event = sessionEventSchema.parse({ schemaVersion: 'session-event/1', id: `session_event_${this.events.length + 1}_${Date.now()}`, sequence: count + 1, ...input });
    this.events.push(structuredClone(event));
    return structuredClone(event);
  }
  private guardQueue: Promise<unknown> = Promise.resolve();
  appendGuarded(input: SessionEventDraft, taskId: Id, guard: TaskActionGuard): Promise<SessionEvent> {
    const next = this.guardQueue.then(async () => {
      const existing = this.events.find(event => event.roomId === input.roomId && event.owner === input.owner && event.tenantId === input.tenantId && event.idempotencyKey === input.idempotencyKey);
      if (existing) return sameDraft(existing, input);
      await guard(structuredClone(this.events.filter(event => event.roomId === input.roomId && event.owner === input.owner && event.tenantId === input.tenantId)));
      return this.append(input);
    });
    this.guardQueue = next.catch(() => undefined); return next;
  }
  async get(eventId: Id, scope?: SessionEventScope): Promise<SessionEvent | undefined> {
    const event = this.events.find(item => item.id === eventId && matchesScope(item, scope));
    return event ? structuredClone(event) : undefined;
  }
  async page(roomId: Id, scope: SessionEventScope | undefined, limit: number, afterSequence = 0): Promise<SessionEventPage> {
    if (!Number.isInteger(limit) || limit < 1 || limit > 200) throw new RangeError('Session event page limit must be between 1 and 200');
    const items = this.events.filter(event => event.roomId === roomId && matchesScope(event, scope) && event.sequence > afterSequence).sort((a, b) => a.sequence - b.sequence);
    const visible = items.slice(0, limit);
    return { items: structuredClone(visible), ...(items.length > limit && visible.length ? { nextCursor: String(visible.at(-1)!.sequence) } : {}) };
  }
  async pageBefore(roomId: Id, scope: SessionEventScope | undefined, limit: number, beforeSequence?: number): Promise<SessionEventPage> {
    return newestPage(this.events.filter(event => event.roomId === roomId && matchesScope(event, scope)), limit, beforeSequence);
  }
  async findByTarget(roomId: Id, targetEventId: Id, scope?: SessionEventScope): Promise<SessionEvent[]> { return structuredClone(this.events.filter(event => event.roomId === roomId && event.targetEventId === targetEventId && matchesScope(event, scope))); }
  async boardRoomsPage(after?: string, limit = 25) { return boardRoomsPage(this.events,after,limit); }
  async pendingDigestRooms(): Promise<ChannelScope[]> { return pendingRooms(this.events); }
  async close(): Promise<void> {}
}

/** Durable single-writer JSON repository. Events are append-only facts. */
export class JsonSessionEventRepository implements SessionEventRepository {
  private events: SessionEvent[] = [];
  private loaded = false;
  private lock: { handle: FileHandle; token: string } | undefined = undefined;
  private queue: Promise<void> = Promise.resolve();

  constructor(private readonly filePath: string) {}

  async init(): Promise<void> {
    if (this.loaded) return;
    await mkdir(dirname(this.filePath), { recursive: true, mode: 0o700 });
    this.lock = await acquireFileWriter(`${this.filePath}.lock`);
    try {
      const raw = await readFile(this.filePath, 'utf8');
      const parsed: unknown = JSON.parse(raw);
      const values = Array.isArray(parsed) ? parsed : parsed && typeof parsed === 'object' && Array.isArray((parsed as { events?: unknown }).events) ? (parsed as { events: unknown[] }).events : undefined;
      if (!values) throw new Error('session event file must be an array or an object with events');
      this.events = await Promise.all(values.map(value => openEvent(value as SessionEvent)));
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'ENOENT') { await this.close(); throw error; }
    }
    this.loaded = true;
  }

  async append(input: SessionEventDraft): Promise<SessionEvent> {
    return this.serial(async () => {
      this.assertOpen();
      const existing = this.events.find(event => event.roomId === input.roomId && event.owner === input.owner && event.tenantId === input.tenantId && event.idempotencyKey === input.idempotencyKey);
      if (existing) return sameDraft(existing, input);
      const count = this.events.filter(event => event.roomId === input.roomId && event.owner === input.owner && event.tenantId === input.tenantId).length;
      const event = sessionEventSchema.parse({ schemaVersion: 'session-event/1', id: `session_event_${cryptoRandomId()}`, sequence: count + 1, ...input });
      await this.persist([...this.events, event]);
      return structuredClone(event);
    });
  }
  async appendLinear(input: SessionEventDraft, targetEventId: Id, expectedTargetRevision: number): Promise<SessionEvent> {
    return this.serial(async () => {
      this.assertOpen();
      const existing = this.events.find(event => event.roomId === input.roomId && event.owner === input.owner && event.tenantId === input.tenantId && event.idempotencyKey === input.idempotencyKey);
      if (existing) return sameDraft(existing, input);
      const target = this.events.find(event => event.id === targetEventId && event.roomId === input.roomId && event.owner === input.owner && event.tenantId === input.tenantId);
      if (!target) throw new SessionEventConflict('Unknown session event revision target');
      if (target.revision !== expectedTargetRevision) throw new SessionEventConflict('Session event target revision is stale');
      if (this.events.some(event => event.roomId === input.roomId && event.owner === input.owner && event.tenantId === input.tenantId && event.targetEventId === targetEventId)) throw new SessionEventConflict('Only the latest canonical response revision can be changed');
      const count = this.events.filter(event => event.roomId === input.roomId && event.owner === input.owner && event.tenantId === input.tenantId).length;
      const event = sessionEventSchema.parse({ schemaVersion: 'session-event/1', id: `session_event_${cryptoRandomId()}`, sequence: count + 1, ...input });
      await this.persist([...this.events, event]);
      return structuredClone(event);
    });
  }
  async appendGuarded(input: SessionEventDraft, taskId: Id, guard: TaskActionGuard): Promise<SessionEvent> {
    return this.serial(async () => {
      this.assertOpen();
      const existing = this.events.find(event => event.roomId === input.roomId && event.owner === input.owner && event.tenantId === input.tenantId && event.idempotencyKey === input.idempotencyKey);
      if (existing) return sameDraft(existing, input);
      await guard(structuredClone(this.events.filter(event => event.roomId === input.roomId && event.owner === input.owner && event.tenantId === input.tenantId)));
      const count = this.events.filter(event => event.roomId === input.roomId && event.owner === input.owner && event.tenantId === input.tenantId).length;
      const event = sessionEventSchema.parse({ schemaVersion: 'session-event/1', id: `session_event_${cryptoRandomId()}`, sequence: count + 1, ...input });
      await this.persist([...this.events, event]);
      return structuredClone(event);
    });
  }
  async get(eventId: Id, scope?: SessionEventScope): Promise<SessionEvent | undefined> { this.assertOpen(); const event = this.events.find(item => item.id === eventId && matchesScope(item, scope)); return event ? structuredClone(event) : undefined; }
  async pageBefore(roomId: Id, scope: SessionEventScope | undefined, limit: number, beforeSequence?: number): Promise<SessionEventPage> {
    this.assertOpen();
    return newestPage(this.events.filter(event => event.roomId === roomId && matchesScope(event, scope)), limit, beforeSequence);
  }
  async page(roomId: Id, scope: SessionEventScope | undefined, limit: number, afterSequence = 0): Promise<SessionEventPage> {
    this.assertOpen();
    if (!Number.isInteger(limit) || limit < 1 || limit > 200) throw new RangeError('Session event page limit must be between 1 and 200');
    const items = this.events.filter(event => event.roomId === roomId && matchesScope(event, scope) && event.sequence > afterSequence).sort((a, b) => a.sequence - b.sequence);
    const visible = items.slice(0, limit);
    return { items: structuredClone(visible), ...(items.length > limit && visible.length ? { nextCursor: String(visible.at(-1)!.sequence) } : {}) };
  }
  async findByTarget(roomId: Id, targetEventId: Id, scope?: SessionEventScope): Promise<SessionEvent[]> { this.assertOpen(); return structuredClone(this.events.filter(event => event.roomId === roomId && event.targetEventId === targetEventId && matchesScope(event, scope))); }
  async boardRoomsPage(after?: string, limit = 25) { this.assertOpen(); return boardRoomsPage(this.events,after,limit); }
  async pendingDigestRooms(): Promise<ChannelScope[]> { this.assertOpen(); return pendingRooms(this.events); }
  async close(): Promise<void> { await this.queue; this.loaded = false; if (this.lock) { await releaseFileWriter(`${this.filePath}.lock`,this.lock); this.lock = undefined; } }

  private assertOpen(): void { if (!this.loaded || !this.lock) throw new Error('Session event store is not open'); }
  private async serial<T>(operation: () => Promise<T>): Promise<T> { const previous = this.queue; let release!: () => void; this.queue = new Promise(resolve => { release = resolve; }); await previous; try { return await operation(); } finally { release(); } }
  private async persist(events: SessionEvent[]): Promise<void> {
    const tempPath = `${this.filePath}.${cryptoRandomId()}.tmp`;
    const file = await open(tempPath, 'wx', 0o600);
    try { await file.writeFile(`${JSON.stringify({ events: await Promise.all(events.map(event => sealEvent(event))) }, null, 2)}\n`); await file.sync(); } finally { await file.close(); }
    await rename(tempPath, this.filePath);
    const directory = await open(dirname(this.filePath), 'r'); try { await directory.sync(); } finally { await directory.close(); }
    this.events = events;
  }
}

/** SQL reads the room, sequence, citations and the cited task; content and reasons are sealed. */
function eventPlain(event: SessionEvent): Record<string, unknown> {
  return {
    ...pick(event, ['schemaVersion', 'id', 'roomId', 'goalId', 'owner', 'sequence', 'type', 'operation', 'targetEventId', 'revision', 'evidenceRefs', 'createdAt', 'botDelivery', 'digest']),
    ...(event.taskAction ? { taskAction: pick(event.taskAction, ['kind', 'taskId']) } : {}),
  };
}
export const sealEvent = (event: SessionEvent) => sealAggregate('session-event', event.tenantId, event.id, event, eventPlain);
const openEvent = (stored: unknown) => openAggregate<SessionEvent>('session-event', String((stored as { id?: unknown }).id), stored);

/** PostgreSQL repository. A transaction-local advisory lock serializes the
 * sequence allocation for one room/owner/tenant without a hot global lock. */
export class PostgresSessionEventRepository implements SessionEventRepository {
  private readonly pool: pg.Pool;
  constructor(connectionString: string) { this.pool = createPostgresPool(connectionString); }
  async init(): Promise<void> {
    await withPostgresMigrationLock(this.pool, 'session-events', async client => { await client.query(`CREATE TABLE IF NOT EXISTS aeeis_session_events (id text PRIMARY KEY, room_id text NOT NULL, goal_id text, owner text NOT NULL, tenant_id text NOT NULL, sequence integer NOT NULL, idempotency_key text NOT NULL, state jsonb NOT NULL, created_at timestamptz NOT NULL, UNIQUE(room_id, owner, tenant_id, idempotency_key), UNIQUE(room_id, owner, tenant_id, sequence)); ALTER TABLE aeeis_session_events ALTER COLUMN goal_id DROP NOT NULL; CREATE INDEX IF NOT EXISTS aeeis_session_events_room_idx ON aeeis_session_events(room_id, owner, tenant_id, sequence)`); });
  }
  async boardRoomsPage(after?: string, limit = 25): Promise<{ items: ChannelScope[]; next?: string }> {
    if (!Number.isInteger(limit) || limit < 1 || limit > 200) throw new RangeError('Invalid board room scan limit');
    const parts = after ? z.array(z.string()).length(3).parse(JSON.parse(after)) : ['', '', ''];
    const result = await this.pool.query(`SELECT DISTINCT tenant_id,owner,room_id FROM aeeis_session_events
      WHERE (tenant_id,owner,room_id)>($1,$2,$3) ORDER BY tenant_id,owner,room_id LIMIT $4`, [...parts,limit+1]);
    const items = result.rows.slice(0,limit).map(row => ({ tenantId: row.tenant_id as string, owner: row.owner as string, roomId: row.room_id as string }));
    const last = items.at(-1); return { items, ...(result.rows.length > limit && last ? { next: JSON.stringify([last.tenantId,last.owner,last.roomId]) } : {}) };
  }
  async pendingDigestRooms(): Promise<ChannelScope[]> {
    const result = await this.pool.query<{ room_id: string; owner: string; tenant_id: string }>(`SELECT DISTINCT p.room_id,p.owner,p.tenant_id FROM aeeis_session_events p
      WHERE p.state->'botDelivery'->>'mode'='digest' AND NOT EXISTS (
        SELECT 1 FROM aeeis_session_events d WHERE d.room_id=p.room_id AND d.owner=p.owner AND d.tenant_id=p.tenant_id AND d.state->'digest'->'eventIds' ? p.id)`);
    return result.rows.map(row => ({ roomId: row.room_id, owner: row.owner, tenantId: row.tenant_id }));
  }
  async append(input: SessionEventDraft): Promise<SessionEvent> {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      await client.query('SELECT pg_advisory_xact_lock(hashtextextended($1, 0))', [`${input.tenantId}:${input.owner}:${input.roomId}`]);
      const existing = await client.query<{ state: SessionEvent }>('SELECT state FROM aeeis_session_events WHERE room_id=$1 AND owner=$2 AND tenant_id=$3 AND idempotency_key=$4', [input.roomId, input.owner, input.tenantId, input.idempotencyKey]);
      if (existing.rows[0]) { await client.query('COMMIT'); return sameDraft(await openEvent(existing.rows[0].state), input); }
      const count = await client.query<{ max: number | null }>('SELECT max(sequence)::int AS max FROM aeeis_session_events WHERE room_id=$1 AND owner=$2 AND tenant_id=$3', [input.roomId, input.owner, input.tenantId]);
      const event = sessionEventSchema.parse({ schemaVersion: 'session-event/1', id: `session_event_${cryptoRandomId()}`, sequence: (count.rows[0]?.max ?? 0) + 1, ...input });
      await client.query('INSERT INTO aeeis_session_events(id,room_id,goal_id,owner,tenant_id,sequence,idempotency_key,state,created_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)', [event.id, event.roomId, event.goalId ?? null, event.owner, event.tenantId, event.sequence, event.idempotencyKey, await sealEvent(event), event.createdAt]);
      await client.query('COMMIT');
      return event;
    } catch (error) { await client.query('ROLLBACK').catch(() => undefined); throw error; } finally { client.release(); }
  }
  async appendLinear(input: SessionEventDraft, targetEventId: Id, expectedTargetRevision: number): Promise<SessionEvent> {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      await client.query('SELECT pg_advisory_xact_lock(hashtextextended($1, 0))', [`${input.tenantId}:${input.owner}:${input.roomId}`]);
      const existing = await client.query<{ state: SessionEvent }>('SELECT state FROM aeeis_session_events WHERE room_id=$1 AND owner=$2 AND tenant_id=$3 AND idempotency_key=$4', [input.roomId, input.owner, input.tenantId, input.idempotencyKey]);
      if (existing.rows[0]) { await client.query('COMMIT'); return sameDraft(await openEvent(existing.rows[0].state), input); }
      const target = await client.query<{ state: SessionEvent }>('SELECT state FROM aeeis_session_events WHERE id=$1 AND room_id=$2 AND owner=$3 AND tenant_id=$4 FOR UPDATE', [targetEventId, input.roomId, input.owner, input.tenantId]);
      if (!target.rows[0]) throw new SessionEventConflict('Unknown session event revision target');
      if ((await openEvent(target.rows[0].state)).revision !== expectedTargetRevision) throw new SessionEventConflict('Session event target revision is stale');
      const child = await client.query('SELECT 1 FROM aeeis_session_events WHERE room_id=$1 AND owner=$2 AND tenant_id=$3 AND state->>\'targetEventId\'=$4 LIMIT 1', [input.roomId, input.owner, input.tenantId, targetEventId]);
      if (child.rows[0]) throw new SessionEventConflict('Only the latest canonical response revision can be changed');
      const count = await client.query<{ max: number | null }>('SELECT max(sequence)::int AS max FROM aeeis_session_events WHERE room_id=$1 AND owner=$2 AND tenant_id=$3', [input.roomId, input.owner, input.tenantId]);
      const event = sessionEventSchema.parse({ schemaVersion: 'session-event/1', id: `session_event_${cryptoRandomId()}`, sequence: (count.rows[0]?.max ?? 0) + 1, ...input });
      await client.query('INSERT INTO aeeis_session_events(id,room_id,goal_id,owner,tenant_id,sequence,idempotency_key,state,created_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)', [event.id, event.roomId, event.goalId ?? null, event.owner, event.tenantId, event.sequence, event.idempotencyKey, await sealEvent(event), event.createdAt]);
      await client.query('COMMIT');
      return event;
    } catch (error) { await client.query('ROLLBACK').catch(() => undefined); throw error; } finally { client.release(); }
  }
  async appendGuarded(input: SessionEventDraft, taskId: Id, guard: TaskActionGuard): Promise<SessionEvent> {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      await client.query('SELECT pg_advisory_xact_lock(hashtextextended($1, 0))', [`${input.tenantId}:${input.owner}:${input.roomId}`]);
      // Share the Room row lock with archive/update commits. Run locks are
      // never held here. Embedded tests may use a separate domain store.
      if (input.taskAction && !(input.taskAction.schemaVersion === 'channel-task-action/2' && input.taskAction.source === 'system')) {
        const table = await client.query("SELECT to_regclass('aeeis_rooms') AS name");
        if (table.rows[0]?.name) {
          const room = await client.query("SELECT state FROM aeeis_rooms WHERE id=$1 AND owner=$2 AND tenant_id=$3 FOR UPDATE",[input.roomId,input.owner,input.tenantId]);
          if (!room.rows[0] || room.rows[0].state.status !== 'active') throw new AeeisConflict('频道已归档或不可写，请刷新');
        }
      }
      const existing = await client.query<{ state: SessionEvent }>('SELECT state FROM aeeis_session_events WHERE room_id=$1 AND owner=$2 AND tenant_id=$3 AND idempotency_key=$4', [input.roomId, input.owner, input.tenantId, input.idempotencyKey]);
      if (existing.rows[0]) { await client.query('COMMIT'); return sameDraft(await openEvent(existing.rows[0].state), input); }
      const cited = await client.query<{ state: SessionEvent }>(`SELECT state FROM aeeis_session_events WHERE room_id=$1 AND owner=$2 AND tenant_id=$3 ORDER BY sequence ASC`, [input.roomId, input.owner, input.tenantId]);
      await guard(await Promise.all(cited.rows.map(row => openEvent(row.state))));
      const count = await client.query<{ max: number | null }>('SELECT max(sequence)::int AS max FROM aeeis_session_events WHERE room_id=$1 AND owner=$2 AND tenant_id=$3', [input.roomId, input.owner, input.tenantId]);
      const event = sessionEventSchema.parse({ schemaVersion: 'session-event/1', id: `session_event_${cryptoRandomId()}`, sequence: (count.rows[0]?.max ?? 0) + 1, ...input });
      await client.query('INSERT INTO aeeis_session_events(id,room_id,goal_id,owner,tenant_id,sequence,idempotency_key,state,created_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)', [event.id, event.roomId, event.goalId ?? null, event.owner, event.tenantId, event.sequence, event.idempotencyKey, await sealEvent(event), event.createdAt]);
      await persistBoardAction(client, event);
      await client.query('COMMIT');
      return event;
    } catch (error) { await client.query('ROLLBACK').catch(() => undefined); throw error; } finally { client.release(); }
  }
  async get(eventId: Id, scope?: SessionEventScope): Promise<SessionEvent | undefined> {
    const result = await this.pool.query<{ state: SessionEvent }>('SELECT state FROM aeeis_session_events WHERE id=$1', [eventId]);
    const event = result.rows[0] ? await openEvent(result.rows[0].state) : undefined;
    return event && matchesScope(event, scope) ? event : undefined;
  }
  async page(roomId: Id, scope: SessionEventScope | undefined, limit: number, afterSequence = 0): Promise<SessionEventPage> {
    if (!Number.isInteger(limit) || limit < 1 || limit > 200) throw new RangeError('Session event page limit must be between 1 and 200');
    const params: unknown[] = [roomId, afterSequence, limit + 1];
    let query = 'SELECT state FROM aeeis_session_events WHERE room_id=$1 AND sequence>$2';
    if (scope) { params.push(scope.tenantId); query += ` AND tenant_id=$${params.length}`; if (scope.owner) { params.push(scope.owner); query += ` AND owner=$${params.length}`; } }
    query += ` ORDER BY sequence ASC LIMIT $3`;
    const result = await this.pool.query<{ state: SessionEvent }>(query, params);
    const rows = await Promise.all(result.rows.map(row => openEvent(row.state)));
    const visible = rows.slice(0, limit);
    return { items: visible, ...(rows.length > limit && visible.length ? { nextCursor: String(visible.at(-1)!.sequence) } : {}) };
  }
  async pageBefore(roomId: Id, scope: SessionEventScope | undefined, limit: number, beforeSequence?: number): Promise<SessionEventPage> {
    if (!Number.isInteger(limit) || limit < 1 || limit > 200) throw new RangeError('Session event page limit must be between 1 and 200');
    const params: unknown[] = [roomId, beforeSequence ?? 2_147_483_647, limit + 1];
    let query = 'SELECT state FROM aeeis_session_events WHERE room_id=$1 AND sequence<$2';
    if (scope) { params.push(scope.tenantId); query += ` AND tenant_id=$${params.length}`; if (scope.owner) { params.push(scope.owner); query += ` AND owner=$${params.length}`; } }
    query += ' ORDER BY sequence DESC LIMIT $3';
    const result = await this.pool.query<{ state: SessionEvent }>(query, params);
    const rows = await Promise.all(result.rows.map(row => openEvent(row.state)));
    const visible = rows.slice(0, limit).reverse();
    return { items: visible, ...(rows.length > limit && visible.length ? { previousCursor: String(visible[0]!.sequence) } : {}) };
  }
  async findByTarget(roomId: Id, targetEventId: Id, scope?: SessionEventScope): Promise<SessionEvent[]> {
    const params: unknown[] = [roomId, targetEventId]; let query = `SELECT state FROM aeeis_session_events WHERE room_id=$1 AND state->>'targetEventId'=$2`;
    if (scope) { params.push(scope.tenantId); query += ` AND tenant_id=$${params.length}`; if (scope.owner) { params.push(scope.owner); query += ` AND owner=$${params.length}`; } }
    query += ' ORDER BY sequence ASC'; const result = await this.pool.query<{ state: SessionEvent }>(query, params); return Promise.all(result.rows.map(row => openEvent(row.state)));
  }
  async close(): Promise<void> { await this.pool.end(); }
}

export interface CreateSessionEventInput {
  /** Server-only notification intent; HTTP clients cannot elevate their message. */
  notificationKind?: SessionEventDraft['notificationKind'];
  goalId?: Id;
  type: SessionEventType;
  content: string;
  contextManifestId: Id;
  evidenceRefs?: Id[];
  idempotencyKey: string;
  /** Who spoke. Missing keeps the caller. An agent speaker must be an active bot member of this room and in the manifest audience. A private room can also name the other active member. It does not grant tools or approval. */
  actor?: { type: 'principal' | 'agent'; id: string };
}

export interface ReviseSessionEventInput {
  content: string;
  evidenceRefs?: Id[];
  idempotencyKey: string;
}

/** Domain service for canonical Shared Session events. A Room is the current
 * product representation of a Shared Session; the event repository remains a
 * separate append-only fact source so Debate/Projection transports cannot
 * become the canonical response. */
export class SessionEventService {
  /** Installed by the dialogue gateway; includes background Bot writes. */
  writeGate?: <T>(roomId: string, actorId: string, tenantId: string, work: () => Promise<T>) => Promise<T>;
  readonly delivery: ChannelDigestDelivery;
  constructor(private readonly repository: SessionEventRepository, private readonly domain: AeeisService, readonly noise: ChannelNoiseStore = new InMemoryChannelNoiseStore(), now: () => number = Date.now) {
    this.delivery = new ChannelDigestDelivery(repository, noise, now);
  }

  async boardRoomsPage(after?: string): Promise<{ items: ChannelScope[]; next?: string }> { return this.repository.boardRoomsPage?.(after,25) ?? { items: [] }; }
  async create(roomId: Id, input: CreateSessionEventInput, actorId: string, tenantId: string, actorType: SessionEventActorType = 'principal'): Promise<SessionEvent> {
    const write = async () => this.delivery.write(await this.draft(roomId, input, actorId, tenantId, actorType), draft => this.repository.append(draft));
    return this.writeGate ? this.writeGate(roomId, actorId, tenantId, write) : write();
  }

  /** Writes a channel task action. The repository runs `guard` on the events
   * that already cite the task, inside the same lock as the append, so a
   * rule such as "the first claim holds" cannot be raced past. */
  async createTaskAction(roomId: Id, input: Omit<CreateSessionEventInput, 'type' | 'actor'> & { taskAction: ChannelTaskAction; type?: 'task_update' | 'system' }, actorId: string, tenantId: string, guard: TaskActionGuard): Promise<SessionEvent> {
    const action = channelTaskActionSchema.parse(input.taskAction);
    const draft = await this.draft(roomId, { ...input, type: input.type ?? 'task_update' }, actorId, tenantId, 'principal', action);
    return this.delivery.write(draft, item => this.repository.appendGuarded(item, action.taskId, guard));
  }

  /** System-only invalidation reuses the original audience/manifest. It may
   * repair archived boards, never authorizes a new user write or approval. */
  async invalidateBoardControl(previous: SessionEvent, action: ChannelTaskAction): Promise<void> {
    if (action.schemaVersion !== 'channel-task-action/2' || action.source !== 'system' || action.kind !== 'clear_override') throw new AeeisConflict('Invalid system board action');
    const content = taskActionLineForClear(action.reason);
    const draft = { ...previous, actorId: 'system', actorType: 'system', recordedBy: { id: 'system', type: 'system' },
      content, contentHash: digestProtocol({ content, action }), taskAction: action, idempotencyKey: `board-auto:${previous.id}:${action.expectedRunId}:${action.expectedRunRevision}`, createdAt: new Date().toISOString() };
    // Do not spread event identity/sequence into the new draft.
    const { id: _id, sequence: _seq, schemaVersion: _schema, ...clean } = draft as SessionEvent;
    await this.repository.appendGuarded(clean as SessionEventDraft, action.taskId, written => {
      if (boardControlVersion(written,action.conversationId,action.taskId) !== action.expectedVersion) throw new AeeisConflict('任务已变化');
    });
  }

  private async draft(roomId: Id, input: CreateSessionEventInput, actorId: string, tenantId: string, actorType: SessionEventActorType, taskAction?: ChannelTaskAction): Promise<SessionEventDraft> {
    const room = await this.domain.assertRoomEventWriter(roomId, actorId, tenantId);
    const manifest = await this.resolveManifest(room.id, input.goalId, input.contextManifestId, actorId, tenantId);
    if (!manifest.audienceSnapshot || !manifest.audience.includes(audienceFor(actorId, tenantId))) throw new AeeisNotFound('Context manifest is not shared with this actor');
    const snapshot = contextAudienceSnapshotSchema.parse(manifest.audienceSnapshot);
    const content = input.content.trim();
    if (!content) throw new AeeisConflict('Session event content is required');
    let eventActorId = actorId;
    let eventActorType = actorType;
    if (input.actor) {
      if (input.type !== 'message') throw new AeeisConflict('只有会话消息可以指定说话人');
      if (actorType !== 'principal') throw new AeeisConflict('只能由房间里的人代为记下对方的发言');
      const members = await this.domain.listRoomMembers(roomId, actorId, tenantId);
      if (input.actor.type === 'principal' && input.actor.id === actorId) {
        eventActorId = actorId;
        eventActorType = 'principal';
      } else if (input.actor.type === 'agent') {
        if ((room.owner ?? 'owner') !== actorId) throw new AeeisConflict('只能由房间主人以 bot 的身份记下这句话');
        const member = members.find(item => item.principalId === input.actor!.id && item.status === 'active' && item.role === 'agent');
        if (!member) throw new AeeisConflict('只能以这个会话里的 bot 身份说话');
        if (!manifest.audience.includes(audienceFor(member.principalId, tenantId))) throw new AeeisConflict('这个 bot 不在这条会话的受众里');
        eventActorId = member.principalId;
        eventActorType = 'agent';
      } else if (room.chat === 'direct' && (room.owner ?? 'owner') === actorId) {
        const member = members.find(item => item.principalId === input.actor!.id && item.status === 'active' && (item.role === 'editor' || item.role === 'agent'));
        if (!member || member.principalId === actorId) throw new AeeisConflict('只能以这间私聊里的对方身份说话');
        if (!manifest.audience.includes(audienceFor(member.principalId, tenantId))) throw new AeeisConflict('对方不在这条会话的受众里');
        eventActorId = member.principalId;
        eventActorType = member.role === 'agent' ? 'agent' : 'principal';
      } else throw new AeeisConflict('只能以本人的身份说话');
    }
    const evidenceRefs = [...new Set(input.evidenceRefs ?? [])];
    const contextManifestHash = contextManifestBindingHash(manifest);
    const contentHash = digestProtocol({ type: input.type, content, evidenceRefs, contextManifestId: manifest.id, contextManifestHash, audienceDigest: snapshot.digest, ...(taskAction ? { taskAction } : {}), ...(input.notificationKind ? { notificationKind: input.notificationKind } : {}) });
    return { ...(input.notificationKind ? { notificationKind: input.notificationKind } : {}), roomId, ...(input.goalId === undefined ? {} : { goalId: input.goalId }), owner: room.owner ?? 'owner', tenantId, type: input.type, actorId: eventActorId, actorType: eventActorType, recordedBy: { id: actorId, type: actorType }, operation: 'publish', revision: 1, classification: manifestClassification(manifest), contextManifestId: manifest.id, contextManifestHash, audienceSnapshot: snapshot, content, contentHash, evidenceRefs, idempotencyKey: input.idempotencyKey, ...(taskAction ? { taskAction } : {}), createdAt: new Date().toISOString() };
  }

  async revise(roomId: Id, eventId: Id, input: ReviseSessionEventInput, actorId: string, tenantId: string, actorType: SessionEventActorType = 'principal'): Promise<SessionEvent> {
    const write = () => this.reviseUnchecked(roomId, eventId, input, actorId, tenantId, actorType);
    return this.writeGate ? this.writeGate(roomId, actorId, tenantId, write) : write();
  }
  private async reviseUnchecked(roomId: Id, eventId: Id, input: ReviseSessionEventInput, actorId: string, tenantId: string, actorType: SessionEventActorType = 'principal'): Promise<SessionEvent> {
    const room = await this.domain.assertRoomEventWriter(roomId, actorId, tenantId);
    const target = await this.get(eventId, actorId, tenantId);
    if (target.roomId !== room.id) throw new AeeisNotFound(`Unknown session event: ${eventId}`);
    if (target.type !== 'canonical_response' || target.operation === 'retract') throw new AeeisConflict('Only an active canonical response can be revised');
    if (!this.repository.appendLinear && this.repository.findByTarget) {
      const children = await this.repository.findByTarget(room.id, target.id, { tenantId });
      if (children.length > 0) throw new AeeisConflict('Only the latest canonical response revision can be revised');
    }
    const manifest = await this.resolveManifest(room.id, target.goalId, target.contextManifestId, actorId, tenantId);
    const snapshot = contextAudienceSnapshotSchema.parse(manifest.audienceSnapshot);
    const content = input.content.trim();
    if (!content) throw new AeeisConflict('Session event content is required');
    const evidenceRefs = [...new Set(input.evidenceRefs ?? target.evidenceRefs)];
    const contextManifestHash = contextManifestBindingHash(manifest);
    const revision = target.revision + 1;
    const contentHash = digestProtocol({ type: target.type, operation: 'revise', targetEventId: target.id, revision, content, evidenceRefs, contextManifestId: manifest.id, contextManifestHash, audienceDigest: snapshot.digest });
    const draft = { roomId, ...(target.goalId === undefined ? {} : { goalId: target.goalId }), owner: room.owner ?? 'owner', tenantId, type: target.type, actorId, actorType, recordedBy: { id: actorId, type: actorType }, operation: 'revise' as const, targetEventId: target.id, revision, classification: manifestClassification(manifest), contextManifestId: manifest.id, contextManifestHash, audienceSnapshot: snapshot, content, contentHash, evidenceRefs, idempotencyKey: input.idempotencyKey, createdAt: new Date().toISOString() };
    return this.delivery.write(draft, item => this.repository.appendLinear ? this.repository.appendLinear(item, target.id, target.revision) : this.repository.append(item));
  }

  async retract(roomId: Id, eventId: Id, reason: string, idempotencyKey: string, actorId: string, tenantId: string, actorType: SessionEventActorType = 'principal'): Promise<SessionEvent> {
    const write = () => this.retractUnchecked(roomId, eventId, reason, idempotencyKey, actorId, tenantId, actorType);
    return this.writeGate ? this.writeGate(roomId, actorId, tenantId, write) : write();
  }
  private async retractUnchecked(roomId: Id, eventId: Id, reason: string, idempotencyKey: string, actorId: string, tenantId: string, actorType: SessionEventActorType = 'principal'): Promise<SessionEvent> {
    const room = await this.domain.assertRoomEventWriter(roomId, actorId, tenantId);
    const target = await this.get(eventId, actorId, tenantId);
    if (target.roomId !== room.id) throw new AeeisNotFound(`Unknown session event: ${eventId}`);
    if (target.operation === 'retract') throw new AeeisConflict('A retraction cannot be retracted');
    if (target.type !== 'canonical_response') throw new AeeisConflict('Only an active canonical response can be retracted');
    if (!this.repository.appendLinear && this.repository.findByTarget) {
      const children = await this.repository.findByTarget(room.id, target.id, { tenantId });
      if (children.length > 0) throw new AeeisConflict('Only the latest canonical response revision can be retracted');
    }
    if (!reason.trim()) throw new AeeisConflict('Session event retraction reason is required');
    const manifest = await this.resolveManifest(room.id, target.goalId, target.contextManifestId, actorId, tenantId);
    const snapshot = contextAudienceSnapshotSchema.parse(manifest.audienceSnapshot);
    const contextManifestHash = contextManifestBindingHash(manifest);
    const content = `Retracted: ${reason.trim()}`;
    const contentHash = digestProtocol({ type: target.type, operation: 'retract', targetEventId: target.id, content, contextManifestId: manifest.id, contextManifestHash, audienceDigest: snapshot.digest });
    const draft = { roomId, ...(target.goalId === undefined ? {} : { goalId: target.goalId }), owner: room.owner ?? 'owner', tenantId, type: target.type, actorId, actorType, recordedBy: { id: actorId, type: actorType }, operation: 'retract' as const, targetEventId: target.id, revision: target.revision, retractionReason: reason.trim(), classification: manifestClassification(manifest), contextManifestId: manifest.id, contextManifestHash, audienceSnapshot: snapshot, content, contentHash, evidenceRefs: target.evidenceRefs, idempotencyKey, createdAt: new Date().toISOString() };
    return this.delivery.write(draft, item => this.repository.appendLinear ? this.repository.appendLinear(item, target.id, target.revision) : this.repository.append(item));
  }

  async page(roomId: Id, actorId: string, tenantId: string, limit = 50, afterSequence = 0): Promise<SessionEventPage> {
    await this.domain.getRoomForPrincipal(roomId, actorId, tenantId);
    const page = await this.repository.page(roomId, { tenantId }, limit, afterSequence);
    return { items: await this.visible(page.items, actorId, tenantId), ...(page.nextCursor ? { nextCursor: page.nextCursor } : {}) };
  }

  /** The newest page, or the page before `beforeSequence`. A channel opens on
   * this so a long backlog never hides the latest messages. */
  async pageBefore(roomId: Id, actorId: string, tenantId: string, limit = 50, beforeSequence?: number): Promise<SessionEventPage> {
    await this.domain.getRoomForPrincipal(roomId, actorId, tenantId);
    const page = await this.repository.pageBefore(roomId, { tenantId }, limit, beforeSequence);
    return { items: await this.visible(page.items, actorId, tenantId), ...(page.previousCursor ? { previousCursor: page.previousCursor } : {}) };
  }

  /** Owner-only migration scan, including events hidden by later membership changes. */
  async migrationHistory(roomId: string, owner: string, tenantId: string): Promise<SessionEvent[]> {
    await this.domain.getRoom(roomId, owner, tenantId);
    const events: SessionEvent[] = []; let after = 0;
    for (;;) {
      const page = await this.repository.page(roomId, { owner, tenantId }, 200, after);
      events.push(...page.items);
      if (!page.nextCursor) return events;
      const next = Number(page.nextCursor);
      if (!Number.isInteger(next) || next <= after) throw new AeeisConflict('Invalid migration cursor');
      after = next;
    }
  }

  /** Every event this reader may see, oldest first. */
  async history(roomId: Id, actorId: string, tenantId: string): Promise<SessionEvent[]> {
    const events: SessionEvent[] = [];
    let after = 0;
    for (;;) {
      const page = await this.page(roomId, actorId, tenantId, 200, after);
      events.push(...page.items);
      const next = Number(page.nextCursor);
      if (!page.nextCursor || !Number.isInteger(next) || next <= after) return events;
      after = next;
    }
  }

  private async visible(items: SessionEvent[], actorId: string, tenantId: string): Promise<SessionEvent[]> {
    const visible: SessionEvent[] = [];
    for (const event of items) {
      try {
        const manifest = await this.resolveManifest(event.roomId, event.goalId, event.contextManifestId, actorId, tenantId);
        if (contextManifestBindingHash(manifest) !== event.contextManifestHash || manifest.audienceSnapshot?.digest !== event.audienceSnapshot.digest) continue;
        await this.assertRelation(event, actorId, tenantId);
        visible.push(event);
      } catch (error) {
        if (!(error instanceof AeeisNotFound || error instanceof AeeisConflict)) throw error;
      }
    }
    return visible;
  }

  async get(eventId: Id, actorId: string, tenantId: string): Promise<SessionEvent> {
    const event = await this.repository.get(eventId);
    if (!event || event.tenantId !== tenantId) throw new AeeisNotFound(`Unknown session event: ${eventId}`);
    await this.domain.getRoomForPrincipal(event.roomId, actorId, tenantId);
    const manifest = await this.resolveManifest(event.roomId, event.goalId, event.contextManifestId, actorId, tenantId);
    if (contextManifestBindingHash(manifest) !== event.contextManifestHash || manifest.audienceSnapshot?.digest !== event.audienceSnapshot.digest) throw new AeeisNotFound(`Unknown session event: ${eventId}`);
    await this.assertRelation(event, actorId, tenantId);
    return event;
  }
  private async assertRelation(event: SessionEvent, actorId: string, tenantId: string): Promise<void> {
    if (!event.targetEventId) return;
    const target = await this.repository.get(event.targetEventId);
    if (!target || target.roomId !== event.roomId || target.owner !== event.owner || target.tenantId !== event.tenantId || target.type !== event.type || target.operation === 'retract') throw new AeeisNotFound(`Unknown target session event: ${event.targetEventId}`);
    if (target.goalId !== event.goalId || target.contextManifestId !== event.contextManifestId) throw new AeeisNotFound(`Unknown target session event: ${event.targetEventId}`);
    const targetManifest = await this.resolveManifest(target.roomId, target.goalId, target.contextManifestId, actorId, tenantId);
    if (contextManifestBindingHash(targetManifest) !== target.contextManifestHash) throw new AeeisNotFound(`Unknown target session event: ${event.targetEventId}`);
  }
  private async resolveManifest(roomId: Id, goalId: Id | undefined, manifestId: Id, actorId: string, tenantId: string): Promise<ContextManifest> {
    if (goalId !== undefined) {
      const goal = await this.domain.getGoal(goalId, actorId, tenantId);
      if (goal.roomId !== roomId) throw new AeeisNotFound(`Unknown goal for Room: ${goalId}`);
      return this.domain.getContextManifest(goalId, manifestId, actorId, tenantId);
    }
    return this.domain.getSessionContextManifest(roomId, manifestId, actorId, tenantId);
  }

}

function newestPage(events: SessionEvent[], limit: number, beforeSequence?: number): SessionEventPage {
  if (!Number.isInteger(limit) || limit < 1 || limit > 200) throw new RangeError('Session event page limit must be between 1 and 200');
  const items = events.filter(event => beforeSequence === undefined || event.sequence < beforeSequence).sort((a, b) => a.sequence - b.sequence);
  const visible = items.slice(-limit);
  return { items: structuredClone(visible), ...(items.length > limit && visible.length ? { previousCursor: String(visible[0]!.sequence) } : {}) };
}
function matchesScope(event: { owner: string; tenantId: string }, scope?: SessionEventScope): boolean { return !scope || (event.tenantId === scope.tenantId && (scope.owner === undefined || event.owner === scope.owner)); }
function sameDraft(existing: SessionEvent, input: SessionEventDraft): SessionEvent {
  if (existing.taskAction?.schemaVersion === 'channel-task-action/2' && input.taskAction?.schemaVersion === 'channel-task-action/2') {
    const intent = (action: Extract<ChannelTaskAction,{ schemaVersion: 'channel-task-action/2' }>) => [action.kind,action.conversationId,action.taskId,action.toColumn,action.expectedVersion,action.expectedRunId,action.expectedRunRevision,action.reason,action.source];
    if (existing.roomId !== input.roomId || existing.owner !== input.owner || existing.tenantId !== input.tenantId || existing.actorId !== input.actorId || existing.actorType !== input.actorType || existing.content !== input.content || JSON.stringify(intent(existing.taskAction)) !== JSON.stringify(intent(input.taskAction))) throw new SessionEventConflict('Session event idempotency key is bound to different content');
    // Goal/context manifests are server-generated audit bindings. Independent
    // API processes may prepare different manifests for the same command.
    return structuredClone(existing);
  }
  if (existing.roomId !== input.roomId || existing.goalId !== input.goalId || existing.owner !== input.owner || existing.tenantId !== input.tenantId || existing.type !== input.type || existing.actorId !== input.actorId || existing.actorType !== input.actorType || existing.operation !== (input.operation ?? 'publish') || existing.targetEventId !== input.targetEventId || existing.revision !== (input.revision ?? 1) || existing.retractionReason !== input.retractionReason || existing.contextManifestId !== input.contextManifestId || existing.contextManifestHash !== input.contextManifestHash || existing.contentHash !== input.contentHash || existing.idempotencyKey !== input.idempotencyKey || JSON.stringify(existing.taskAction ?? null) !== JSON.stringify(input.taskAction ?? null)) throw new SessionEventConflict('Session event idempotency key is bound to different content');
  return structuredClone(existing);
}
function audienceFor(principalId: string, tenantId: string): string { return principalAudience({ id: principalId, tenantId }); }
function manifestClassification(manifest: ContextManifest): SessionEventClassification {
  const values = [
    ...manifest.included.map(item => item.classification),
    ...(manifest.includedKnowledge ?? []).map(item => item.classification),
  ];
  if (values.length === 0) return 'internal';
  if (values.includes('private')) return 'private';
  if (values.includes('confidential')) return 'confidential';
  if (values.includes('internal')) return 'internal';
  return 'public';
}
function cryptoRandomId(): string { return `${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 14)}`; }

function pendingRooms(events: SessionEvent[]): ChannelScope[] {
  const done = new Set(events.flatMap(event => event.digest?.eventIds ?? []));
  const rooms = new Map<string, ChannelScope>();
  for (const event of events) if (event.botDelivery?.mode === 'digest' && !done.has(event.id)) {
    const scope = { roomId: event.roomId, owner: event.owner, tenantId: event.tenantId };
    rooms.set(JSON.stringify(scope), scope);
  }
  return [...rooms.values()];
}

function taskActionLineForClear(reason: string): string { return `恢复自动列：${reason}`; }

function boardRoomsPage(events: SessionEvent[], after?: string, limit = 25): { items: ChannelScope[]; next?: string } {
  const key = (e: ChannelScope) => JSON.stringify([e.tenantId,e.owner,e.roomId]);
  const rooms = [...new Map(events.map(event => [key(event), { tenantId: event.tenantId, owner: event.owner, roomId: event.roomId }])).values()]
    .filter(room => !after || key(room) > after).sort((a,b) => key(a) < key(b) ? -1 : 1);
  const items = rooms.slice(0,limit); return { items, ...(rooms.length > limit ? { next: key(items.at(-1)!) } : {}) };
}
