import type { AgentRun } from './contracts.js';
import { event } from './engine.js';
import type { RunRepository } from './repository.js';
import { populateRunLimitations } from './run-limitations.js';
import { preserveRunOutput } from './run-output.js';

/** Close execution while preserving unknown provider receipts for later billing reconciliation.
 * Completed artifacts and verified PDF writes count. Source dumps are not salvage: a run with zero produced
 * output must end failed (or another clear error status), never succeeded/partial. */
export async function terminalizeRun(repository: RunRepository, runId: string, reason: string): Promise<AgentRun> {
  return repository.mutate(runId, async run => {
    populateRunLimitations(run);
    if (['succeeded', 'failed', 'cancelled'].includes(run.status)) return;
    // A late timeout must not close a business wait that won the race.
    if (!['queued', 'planning', 'running', 'reviewing', 'unknown'].includes(run.status)) return;
    // Prefer the durable call diagnostic over a workflow's generic unknown status.
    const callReason = [...run.calls].reverse().find(call => call.state === 'unknown' || call.state === 'started')?.validationErrors?.map(issue => issue.message).join('; ');
    const diagnostic = callReason || run.error;
    const specificReason = /outcome is unknown/i.test(reason) ? diagnostic || reason : [...new Set([reason, diagnostic].filter(Boolean))].join(': ');
    const limitation = `Execution stopped: ${specificReason}. Independent review was not completed.`;
    for (const call of run.calls) if (call.state === 'started') { call.state = 'unknown'; call.endedAt = new Date().toISOString(); }
    // Retain completed deliverables, including a PDF whose finish call was interrupted.
    if (await preserveRunOutput(run, limitation)) {
      event(run, 'run.partial', { reason, terminalized: true, producedArtifacts: run.artifacts.length });
    } else {
      run.status = 'failed';
      run.error = limitation;
      // Drop empty placeholder artifacts so operators never see a green partial with no output.
      run.artifacts = run.artifacts.filter(artifact => artifact.content.trim() || artifact.evidenceRefs.length);
      event(run, 'run.failed', { reason, terminalized: true, producedArtifacts: 0 });
    }
    delete run.resumeStatus;
    delete run.takeover;
    populateRunLimitations(run);
  });
}
