import { describe, expect, it, vi } from 'vitest';
import { InMemoryRunRepository } from '../src/adapters/in-memory-run-repository.js';
import { AgentEngine, digest } from '../src/runtime/engine.js';
import { decisionSchema } from '../src/runtime/contracts.js';
import { materialContentHash } from '../src/runtime/materials.js';
import { sourceReadUsage, runSourceReadUsage, type ExecutionLimits } from '../src/runtime/execution-limits.js';
import type { ModelRequest } from '../src/runtime/model.js';
import { HttpModelAdapter } from '../src/runtime/model.js';
import type { ThreadHistory } from '../src/runtime/thread-history.js';

type Input = {
  sourceCatalog: Array<{ id: string }>;
  observations: Array<{ tool: string; argument: string; result: any }>;
  executionBudget: { finalOnly: boolean; nodeReads: { pages: number; chars: number }; runReads: { pages: number; chars: number } };
};
const content = ['team,amount', ...Array.from({ length: 200 }, (_, i) => `${i % 2 ? 'A' : 'B'},"1,000"`)].join('\n');
const finish = (input: Input) => ({ type: 'finish', title: 'Totals', content: 'Calculated totals from the received query evidence.', evidenceRefs: input.sourceCatalog.map(source => source.id) });
const query = (input: Input) => ({ type: 'tool', tool: 'sources.csvQuery', argument: input.sourceCatalog[0]!.id, groupBy: ['team'], aggregates: [{ op: 'sum', column: 'amount', as: 'total' }], orderBy: [{ column: 'total', direction: 'desc' }] });

async function setup(decide: (input: Input) => unknown = input => input.observations.length || input.executionBudget.finalOnly ? finish(input) : query(input), options: {
  legacy?: boolean; limits?: Partial<ExecutionLimits>; materials?: Array<{ title: string; source: string; content: string }>; history?: ThreadHistory;
} = {}) {
  const repository = new InMemoryRunRepository();
  const complete = vi.fn(async (request: ModelRequest) => {
    if (request.system.includes('Plan a real deliverable')) return { value: { summary: 'Totals', nodes: [{ id: 'totals', title: 'Totals', instruction: 'Calculate team totals', dependsOn: [] }] } };
    if (request.system.includes('Independently review')) return { value: { verdict: 'accepted', summary: 'Totals match evidence' } };
    expect(request.system).toContain('sources.csvQuery');
    expect(request.system).toContain('countDistinct');
    return { value: decide(request.input as Input) };
  });
  const model = { pin: { model: 'fixture', endpoint: 'http://localhost', promptVersion: 'test' }, complete };
  let engine = new AgentEngine(repository, { model, executionLimits: options.limits });
  const run = await engine.create({ goal: 'Calculate team totals', materials: options.materials ?? [{ title: 'totals.csv', source: 'upload', content }] }, 'owner', 'local', options.history ? async current => {
    current.context.threadHistory = options.history;
    await repository.create(current); return current;
  } : undefined);
  if (options.legacy) await repository.mutate(run.id, current => { delete current.capabilityCatalogVersion; });
  await engine.advance(run.id);
  await engine.command(run.id, 'approve', { planHash: (await repository.get(run.id)).plans[0]!.hash, planVersion: (await repository.get(run.id)).plans[0]!.version });
  return { repository, run, complete, get engine() { return engine; }, restart() { engine = new AgentEngine(repository, { model }); },
    async drain() {
      for (let i = 0; i < 16; i++) {
        const status = await engine.advance(run.id);
        if (['succeeded', 'failed'].includes(status)) return repository.get(run.id);
      }
      throw new Error('Run did not terminate');
    },
  };
}

describe('executor CSV query tool', () => {
  it('reads all 60 detail rows across five pages and delivers three due-date counts instead of citations alone', async () => {
    const dates = ['2026-10-13', '2026-10-14', '2026-10-15'];
    const detail = ['id,status,due,notes', ...Array.from({ length: 60 }, (_, i) => `${i + 1},${i < 28 ? 'open' : 'done'},${dates[i % 3]},${'detail '.repeat(8)}`)].join('\n');
    const fixture = await setup(input => {
      const reads = input.observations.filter(item => item.tool === 'sources.read');
      const last = reads.at(-1)?.result;
      const presented = (input as any).presentedSources[0];
      expect(presented.truncated).toBe(false);
      expect(presented.content).toContain('60,done');
      expect(presented.representation).toBeUndefined();
      if (!reads.length || last.page.nextRead) return { type: 'tool', tool: 'sources.read', argument: input.sourceCatalog[0]!.id, offset: 0, limit: 12, ...last?.page.nextRead };
      if (!input.observations.some(item => item.tool === 'sources.csvQuery')) return {
        type: 'tool', tool: 'sources.csvQuery', argument: input.sourceCatalog[0]!.id, filters: [{ column: 'status', op: 'eq', value: 'open' }],
        groupBy: ['due'], aggregates: [{ op: 'count', as: 'count' }], orderBy: [{ column: 'due', direction: 'asc' }],
      };
      return { type: 'finish', title: 'Due-date counts', content: `Results: [${input.sourceCatalog[0]!.id}]`, evidenceRefs: [input.sourceCatalog[0]!.id] };
    }, { materials: [{ title: 'detail.csv', source: 'upload', content: detail }] });
    await fixture.engine.advance(fixture.run.id);
    fixture.restart();
    const run = await fixture.drain();
    expect(run.status, run.error).toBe('succeeded');
    expect(run.partial).not.toBe(true);
    const reads = run.steps[0]!.observations.filter(item => item.tool === 'sources.read');
    expect(reads).toHaveLength(5);
    expect(reads.reduce((sum, item) => sum + (item.result as any).page.returnedRows, 0)).toBe(60);
    expect(sourceReadUsage(run.steps).pages).toBe(0);
    expect(runSourceReadUsage(run)).toEqual(sourceReadUsage(run.steps));
    expect(run.events.some(event => event.type === 'execution.limited')).toBe(false);
    expect(run.artifacts[0]!.content).toContain('| 2026-10-13 | 10 |');
    expect(run.artifacts[0]!.content).toContain('| 2026-10-14 | 9 |');
    expect(run.artifacts[0]!.content).toContain('| 2026-10-15 | 9 |');
    expect(run.artifacts[0]!.content).toContain('28 matched rows');
  });

  it('revises a rejected CSV synthesis with tools after connection retries and exhausted node allowance', async () => {
    const repository = new InMemoryRunRepository();
    let reviews = 0, connectFailures = 0;
    const fetch = vi.fn(async (_url: unknown, options: any) => {
      const body = JSON.parse(options.body), system = body.messages[0].content, input = JSON.parse(body.messages[1].content);
      let value: unknown;
      if (system.includes('Plan a real deliverable')) value = { summary: 'Totals', nodes: [{ id: 'synthesize', title: 'Totals', instruction: 'Calculate team totals', dependsOn: [] }] };
      else if (system.includes('Independently review')) value = ++reviews === 1 ? { verdict: 'needs_revision', summary: 'Missing total', issues: ['Include the numeric total'] } : { verdict: 'accepted', summary: 'Total verified', issues: [] };
      else if (!input.observations.length) value = query(input);
      else if (input.outputRecovery && input.observations.filter((item: any) => item.tool === 'sources.csvQuery').length === 1) {
        expect(input.executionBudget.finalOnly).toBe(false);
        expect(input.executionBudget.remainingModelCalls).toBeGreaterThan(1);
        expect(system).toContain('Tools are allowed');
        expect(input.outputRecovery.reason).toContain('Include the numeric total');
        value = { ...query(input), limit: 51 }; // A distinct query; identical completed queries reuse the prior result.
      } else {
        if (!input.outputRecovery && connectFailures++ < 2) throw new TypeError('fetch failed', { cause: Object.assign(new Error('Connection timed out'), { code: 'UND_ERR_CONNECT_TIMEOUT' }) });
        value = { ...finish(input), content: input.outputRecovery ? 'Total: 200,000.' : 'Calculated totals.' };
      }
      return new Response(JSON.stringify({ choices: [{ message: { content: JSON.stringify(value) }, finish_reason: 'stop' }] }), { status: 200, headers: { 'content-type': 'application/json' } });
    });
    vi.stubGlobal('fetch', fetch);
    const logs = vi.spyOn(console, 'error').mockImplementation(() => {}), warnings = vi.spyOn(console, 'warn').mockImplementation(() => {});
    try {
      const model = new HttpModelAdapter('http://localhost/v1', 'fixture', '', undefined, 5000, undefined, false, undefined, { maxAttempts: 2, retryBaseMs: 0, retryMaxMs: 0 });
      let engine = new AgentEngine(repository, { model, executionLimits: { maxNodeIterations: 2, maxNodeSourcePages: 1 } });
      const run = await engine.create({ goal: 'Calculate team totals', materials: [{ title: 'totals.csv', source: 'upload', content }] });
      await engine.advance(run.id);
      await engine.command(run.id, 'approve', { planHash: (await repository.get(run.id)).plans[0]!.hash, planVersion: (await repository.get(run.id)).plans[0]!.version });
      for (let i = 0; i < 12; i++) {
        const status = await engine.advance(run.id);
        if ((await repository.get(run.id)).events.some(event => event.type === 'review.revision_requested')) engine = new AgentEngine(repository, { model });
        if (['succeeded', 'failed'].includes(status)) break;
      }
      const completed = await repository.get(run.id);
      expect(completed.status, completed.error).toBe('succeeded');
      expect(completed.artifacts[0]!.content).toContain('200,000');
      expect(completed.events.filter(event => event.type === 'review.revision_requested')).toHaveLength(1);
      expect(completed.steps[0]!.observations.filter(observation => observation.tool === 'sources.csvQuery')).toHaveLength(2);
      expect(completed.calls).toHaveLength(7);
      expect(fetch).toHaveBeenCalledTimes(9);
      expect(logs.mock.calls.map(([line]) => JSON.parse(String(line)))).toEqual(expect.arrayContaining([expect.objectContaining({ errorCode: 'UND_ERR_CONNECT_TIMEOUT', willRetry: true }), expect.objectContaining({ retryDecision: 'connect-retry' })]));
    } finally { vi.unstubAllGlobals(); logs.mockRestore(); warnings.mockRestore(); }
  });

  it.each(['<', 'less_than', 'BEFORE', ' LT ', '<=', 'LTE', 'less-than-or-equal'])('run_313c8bce: normalizes %s and retains date comparisons', async op => {
    const fixture = await setup(input => input.observations.length ? finish(input) : {
      type: 'tool', tool: 'sources.csvQuery', argument: input.sourceCatalog[0]!.id,
      filters: [{ column: 'status', op: 'NE', value: 'done' }, { column: 'due', op, value: '2026-10-14' }], select: ['id'],
    }, { materials: [{ title: 'tasks.csv', source: 'upload', content: 'id,status,due\n1,open,2026-10-04\n2,done,2026-10-09\n3,open,2026-10-21\n4,open,2026-10-13\n5,open,2026-10-14' }] });
    const run = await fixture.drain();
    expect(run.status, run.error).toBe('succeeded');
    expect(run.events.some(event => event.type === 'model.schema_retry')).toBe(false);
    const inclusive = ['<=', 'LTE', 'less-than-or-equal'].includes(op);
    expect((run.steps[0]!.observations[0]!.result as any).rows).toEqual(inclusive ? [['1'], ['4'], ['5']] : [['1'], ['4']]);
  });
  it('run_313c8bce: retry explains filters.1.op and lists valid operators', async () => {
    const fixture = await setup(input => {
      if (input.observations.some(item => item.tool === 'sources.csvQuery')) return finish(input);
      const retry = input.observations.find(item => item.tool === 'output.schema');
      if (retry) {
        expect(retry.result.error.message).toContain('eq, ne, gt, gte, lt, lte, contains, in, nin, isEmpty');
        expect(retry.result.error.issues).toEqual(expect.arrayContaining([expect.objectContaining({ path: 'filters.1.op', message: expect.stringContaining('Valid ops:') })]));
      }
      return { ...query(input), filters: [{ column: 'team', op: 'eq', value: 'A' }, { column: 'amount', op: retry ? 'less_than' : 'unsupported', value: 2000 }] };
    });
    const run = await fixture.drain();
    expect(run.status, run.error).toBe('succeeded');
    expect(run.events.filter(event => event.type === 'model.schema_retry')).toHaveLength(1);
  });

  it('offers a new schema hint after an earlier retry, including unsupported operators across restart', async () => {
    const fixture = await setup(input => {
      const errors = input.observations.filter(item => item.tool === 'output.schema');
      if (input.observations.some(item => item.tool === 'sources.csvQuery')) return finish(input);
      if (errors.length) expect(errors.at(-1)!.result.error).toMatchObject({ recoverable: true, message: expect.stringContaining('nin') });
      if (!errors.length) return { ...query(input), filters: 'bad-shape' };
      if (errors.length === 1) return { ...query(input), filters: { column: 'team', op: 'regex', value: 'A' } };
      if (errors.length === 2) {
        expect(errors.at(-1)!.result.error.issues).toEqual(expect.arrayContaining([expect.objectContaining({ path: 'filters.0.op', message: expect.stringContaining('Valid ops:') })]));
        return { ...query(input), filters: { column: 'team', op: 'another_unsupported_op', value: 'A' } };
      }
      return { ...query(input), filters: { column: 'team', op: 'notIn', value: ['B'] } };
    });
    await fixture.engine.advance(fixture.run.id);
    fixture.restart();
    const run = await fixture.drain();
    expect(run.status, run.error).toBe('succeeded');
    expect(run.events.filter(event => event.type === 'model.schema_retry')).toHaveLength(3);
    expect(run.events.some(event => event.type === 'run.failed')).toBe(false);
    expect((run.steps[0]!.observations.find(item => item.tool === 'sources.csvQuery')!.result as any).rows).toEqual([['A', 100000]]);
  });

  it('returns a different non-CSV schema error after the first corrective retry', async () => {
    const fixture = await setup(input => {
      const errors = input.observations.filter(item => item.tool === 'output.schema');
      if (!errors.length) return { ...query(input), limit: 201 };
      if (errors.length === 1) return { ...query(input), select: 'team' };
      expect(errors.at(-1)!.result.error.issues).toEqual(expect.arrayContaining([expect.objectContaining({ path: 'select' })]));
      return finish(input);
    });
    const run = await fixture.drain();
    expect(run.status, run.error).toBe('succeeded');
    expect(run.events.filter(event => event.type === 'model.schema_retry')).toHaveLength(2);
  });

  it.each([false, true])('executes a built-in query without an external tool allowlist (legacy=%s)', async legacy => {
    const fixture = await setup(undefined, { legacy });
    const completed = await fixture.drain();
    expect(completed.status, completed.error).toBe('succeeded');
    expect(completed.allowedTools).toEqual([]);
    expect(completed.toolReceipts).toEqual([]);
    const observation = completed.steps[0]!.observations[0]!;
    expect(observation.tool).toBe('sources.csvQuery');
    expect(observation.result).toMatchObject({ id: completed.context.sources[0]!.id, rows: [['B', 100000], ['A', 100000]], matchedRowCount: 200, sourceContentHash: materialContentHash(content), truncated: false });
    expect(sourceReadUsage(completed.steps)).toEqual({ pages: 1, chars: JSON.stringify(observation.result).length });
    const executor = fixture.complete.mock.calls.map(([request]) => request).filter(request => !request.system.includes('Plan a real deliverable') && !request.system.includes('Independently review'));
    expect((executor[1]!.input as Input).observations[0]).toEqual(observation);
    expect(completed.events.find(event => event.type === 'tool.completed')!.data.inputHash).toBe(digest(decisionSchema.parse(query(executor[0]!.input as Input))));
    const review = fixture.complete.mock.calls.at(-1)![0].input as { sourceObservations: unknown[] };
    expect(review.sourceObservations).toEqual([observation]);
    expect(completed.artifacts[0]!.evidenceRefs).toEqual([completed.context.sources[0]!.id]);
    expect(completed.context.sources[0]!.content).toBe(content);
  });

  it('normalizes the missing type field like sources.read', async () => {
    const fixture = await setup(input => {
      if (input.observations.length) return finish(input);
      const { type: _type, ...decision } = query(input); return decision;
    });
    expect((await fixture.drain()).status).toBe('succeeded');
  });

  it.each(['missing-source', '../sources/other.csv'])('denies an unknown source id: %s', async argument => {
    const fixture = await setup(input => ({ ...query(input), argument }));
    const completed = await fixture.drain();
    expect(completed.status).toBe('failed');
    expect(completed.error).toContain('Source tool denied an unknown resource');
    expect(completed.steps[0]!.observations).toEqual([]);
    expect(completed.pendingTool).toBeUndefined();
  });

  it('rejects a non-CSV stored source as a recoverable executor error', async () => {
    const fixture = await setup(undefined, { materials: [{ title: 'notes.txt', source: 'upload', content: 'Plain notes' }] });
    const completed = await fixture.drain();
    expect(completed.status).toBe('succeeded');
    expect(JSON.stringify(completed.steps[0]!.observations)).toContain('requires a CSV source');
    // Invalid query arguments are first returned to the executor as recoverable errors.
    expect(completed.events.filter(item => item.type === 'tool.failed_recoverable').length).toBeGreaterThan(0);
  });

  it('returns invalid comparison operands to the executor and lets it correct the query', async () => {
    const fixture = await setup(input => {
      const errors = input.observations.filter((item: { result?: { error?: unknown } }) => item.result?.error);
      if (input.observations.length > errors.length) return finish(input);
      if (errors.length) return { ...query(input), filters: [{ column: 'amount', op: 'lt', value: 1000 }] };
      return { ...query(input), filters: [{ column: 'team', op: 'lt', value: 'not-a-number' }] };
    });
    const completed = await fixture.drain();
    expect(completed.status).toBe('succeeded');
    expect(completed.events.filter(item => item.type === 'tool.failed_recoverable')).toHaveLength(1);
  });

  it.each([{ limit: 201 }, { unexpected: 'field' }, { type: 'invalid' }])('rejects malformed query decisions without external capability fallback: %j', async fields => {
    const fixture = await setup(input => ({ ...query(input), ...fields }));
    const completed = await fixture.drain();
    expect(completed.status).toBe('failed');
    expect(completed.error).toContain('schema validation');
    expect(completed.calls.at(-1)!.validationErrors).toBeDefined();
    // One corrective schema retry is offered before the Run fails.
    expect(completed.steps[0]!.observations.map(item => item.tool)).toEqual(['output.schema']);
    expect(completed.events.filter(item => item.type === 'model.schema_retry')).toHaveLength(1);
    expect(completed.pendingTool).toBeUndefined();
    expect(completed.toolReceipts).toEqual([]);
  });

  it('counts reads and queries against shared durable source allowances across restart', async () => {
    const fixture = await setup(input => input.executionBudget.finalOnly ? finish(input) : input.observations.length ? query(input) : { type: 'tool', tool: 'sources.read', argument: input.sourceCatalog[0]!.id, offset: 0, limit: 1 }, { limits: { maxNodeSourcePages: 2 } });
    await fixture.engine.advance(fixture.run.id);
    fixture.restart();
    const completed = await fixture.drain();
    expect(completed.status).toBe('succeeded');
    expect(completed.steps[0]!.observations.map(observation => observation.tool)).toEqual(['sources.read', 'sources.csvQuery']);
    expect(sourceReadUsage(completed.steps).pages).toBe(2);
    expect(runSourceReadUsage(completed)).toEqual(sourceReadUsage(completed.steps));
    expect(completed.artifacts[0]).toMatchObject({ partial: true, limitations: ['Node source page limit reached'] });
    expect(completed.calls.filter(call => call.phase === 'executor')).toHaveLength(3);
  });

  it.each(['maxNodeSourceChars', 'maxRunSourceChars'] as const)('withholds queries exceeding remaining %s', async field => {
    const fixture = await setup(undefined, { limits: { [field]: 100 } });
    const completed = await fixture.drain();
    expect(completed.status).toBe('succeeded');
    expect(completed.steps[0]!.observations[0]!.tool).toBe('sources.csvQuery.limit');
    expect(sourceReadUsage(completed.steps)).toEqual({ pages: 0, chars: 0 });
    expect(completed.artifacts[0]!.partial).toBe(true);
    expect(completed.calls.filter(call => call.phase === 'executor')).toHaveLength(2);
  });

  it('rejects query decisions during a final finish call', async () => {
    const fixture = await setup(query, { limits: { maxNodeSourcePages: 1 } });
    const completed = await fixture.drain();
    expect(completed.status).toBe('failed');
    expect(completed.error).toContain('tools are disallowed');
    expect(sourceReadUsage(completed.steps).pages).toBe(1);
  });

  it('queries only the frozen CSV history excerpt and preserves CSV quoting', async () => {
    const text = 'team,amount\n"A, Inc.","1,200"\n"A, Inc.",30';
    const history: ThreadHistory = {
      policyVersion: 'aeeis-thread-history/1', threadId: 'thread_fixture', budgetBytes: 4096, actualBytes: 1000,
      hash: 'frozen-history-hash', exclusions: [], visitedAncestors: 1, omitted: { excerpts: 0, artifacts: 0, ancestorContinuations: 0 }, truncated: 0, accessProvenance: [],
      entries: [{ runId: 'run_parent', revision: 1, threadSequence: 1, classification: 'internal', excerpts: [{ kind: 'artifact', ref: 'report.csv', hash: materialContentHash(text), text, truncated: false }] }],
    };
    const fixture = await setup(undefined, { materials: [], history });
    const completed = await fixture.drain();
    expect(completed.status, completed.error).toBe('succeeded');
    expect(completed.steps[0]!.observations[0]!.result).toMatchObject({ id: 'history:run_parent:report.csv', rows: [['A, Inc.', 1230]], sourceContentHash: materialContentHash(text), origin: { runId: 'run_parent', ref: 'report.csv' } });
  });
});
