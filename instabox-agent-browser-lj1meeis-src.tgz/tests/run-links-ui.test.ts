import { afterEach, beforeAll, describe, expect, it, vi } from 'vitest';
import { JSDOM } from 'jsdom';
import { build } from 'esbuild';
import { readFile } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { sharedRunView } from '../src/runtime/run-debug.js';
import type { AgentRun } from '../src/runtime/contracts.js';
import { fillPdf } from '../src/runtime/fillable-pdf.js';
import { formSource, profile, pdfArtifact } from './fillable-pdf-fixture.js';
let source: string, html: string, css: string;
let dom: JSDOM;
beforeAll(async () => {
  const result = await build({ entryPoints: ['src/ui/app.ts'], bundle: true, format: 'iife', target: 'es2022', write: false });
  source = result.outputFiles![0]!.text;
  [html, css] = await Promise.all([readFile('public/index.html', 'utf8'), readFile('public/style.css', 'utf8')]);
});
afterEach(() => dom?.window.close());
function fixture(): AgentRun {
  const now = new Date().toISOString();
  return { schemaVersion: 1, id: `run_${randomUUID()}`, owner: 'owner', tenantId: 'local', revision: 1,
    goal: 'Linked failure', status: 'failed', createdAt: now, updatedAt: now,
    model: { model: 'fixture', endpoint: 'http://localhost', promptVersion: 'test' }, maxModelCalls: 20,
    plans: [{ summary: 'Investigate', nodes: [{ id: 'task', title: 'Task', instruction: 'Do task', dependsOn: [] }], version: 1, hash: 'hash', createdAt: now }],
    steps: [{ taskId: 'task', status: 'running', attempts: 1, observations: [], error: 'Model failed', failureReason: 'Missing structured output' }],
    events: [{ id: 'event', seq: 1, type: 'run.failed', at: now, data: { reason: 'Missing structured output' } }],
    artifacts: [{ id: 'artifact', taskId: 'task', title: 'Result', content: 'Visible result', evidenceRefs: ['source'], hash: 'hash', createdAt: now }],
    context: { id: 'context', audience: ['owner'], sources: [{ id: 'source', title: 'Evidence', content: 'Evidence body', source: 'local', hash: 'hash' }] },
    calls: [], answers: [], toolReceipts: [], allowedTools: [], allowedAgents: [], privacy: 'internal', brainMaxItems: 1, knowledgeMaxItems: 1, memoryMaxItems: 1,
    review: { verdict: 'needs_revision', summary: 'Missing data', issues: ['Missing structured output'] }, error: 'Model failed' };
}
function start(path: string, fetch: any, intervals?: Array<() => void>, setup?: (window: any) => void) {
  dom = new JSDOM(html, { url: `http://localhost${path}`, runScripts: 'outside-only', pretendToBeVisual: true });
  const style = dom.window.document.createElement('style'); style.textContent = css; dom.window.document.head.append(style);
  dom.window.localStorage.setItem('aeeis.run', `run_${randomUUID()}`);
  dom.window.localStorage.setItem('aeeis.demo-roster', '1');
  dom.window.sessionStorage.setItem('aeeis.token', 'saved-auth-secret');
  dom.window.fetch = fetch;
  dom.window.setInterval = ((callback: () => void) => { intervals?.push(callback); return 1; }) as any;
  dom.window.HTMLElement.prototype.scrollIntoView = () => {};
  dom.window.matchMedia = (() => ({ matches: false, addEventListener() {}, removeEventListener() {} })) as any;
  setup?.(dom.window);
  dom.window.eval(source);
}
const response = (data: unknown) => ({ ok: true, status: 200, text: async () => JSON.stringify(data) });
describe('access token', () => {
  // Browsers refuse a header value outside Latin-1 before sending anything; mimic that.
  const strictFetch = (run: AgentRun) => vi.fn(async (url: string, init?: { headers?: Record<string, string> }) => {
    for (const value of Object.values(init?.headers ?? {})) if (/[^\x00-\xFF]/.test(value)) throw new TypeError("Failed to execute 'fetch' on 'Window': String contains non ISO-8859-1 code point.");
    if (url === `/api/runs/${run.id}`) return response(run);
    if (String(url).endsWith('/graphs')) return response(sharedRunView(run).graphs);
    if (String(url).endsWith('/explanation')) return response(sharedRunView(run).explanation);
    if (String(url).includes('/page?')) return response({ items: [], goals: [] });
    return response([]);
  });
  it('cleans what copying adds to a token and refuses characters a header cannot carry', async () => {
    const run = fixture(), fetch = strictFetch(run);
    start(`/runs/${run.id}`, fetch);
    const doc = dom.window.document, input = doc.getElementById('token') as HTMLInputElement;
    await vi.waitFor(() => expect(doc.getElementById('run-title')?.textContent).toBe(run.goal));
    input.value = ' Bearer “abc-123”\u200B ';
    doc.getElementById('connect')!.click();
    await vi.waitFor(() => expect(dom.window.localStorage.getItem('aeeis.token')).toBe('abc-123'));
    expect(dom.window.sessionStorage.getItem('aeeis.token')).toBeNull();
    expect(input.value).toBe('abc-123');
    await vi.waitFor(() => expect(fetch.mock.calls.some(([, init]) => init?.headers?.authorization === 'Bearer abc-123')).toBe(true));
    await vi.waitFor(() => expect((doc.getElementById('connect') as HTMLButtonElement).disabled).toBe(false));
    input.value = '令牌abc';
    doc.getElementById('connect')!.click();
    expect(doc.getElementById('error')?.textContent).toContain('不能放进请求头');
    expect(dom.window.localStorage.getItem('aeeis.token')).toBe('abc-123');
    expect(doc.getElementById('error')?.textContent).not.toContain('ISO-8859-1');
  });
  it('drops a saved token that a header cannot carry', async () => {
    const run = fixture(), fetch = strictFetch(run);
    start(`/runs/${run.id}`, fetch, undefined, window => window.sessionStorage.setItem('aeeis.token', '中文令牌'));
    const doc = dom.window.document;
    await vi.waitFor(() => expect(doc.getElementById('run-title')?.textContent).toBe(run.goal));
    expect(dom.window.sessionStorage.getItem('aeeis.token')).toBeNull();
    expect(dom.window.localStorage.getItem('aeeis.token')).toBeNull();
    expect((doc.getElementById('token') as HTMLInputElement).value).toBe('');
    expect(doc.getElementById('error')?.textContent).not.toContain('ISO-8859-1');
  });
  // The server answers the tokenless request that follows with 401; that must not hide why the token was dropped.
  it('keeps the bad-token explanation when the next request is refused for a missing token', async () => {
    const fetch = vi.fn(async (_url: string, init?: { headers?: Record<string, string> }) => {
      if (init?.headers?.authorization) return response([]);
      return { ok: false, status: 401, text: async () => JSON.stringify({ error: 'Local access token required' }) };
    });
    start('/', fetch, undefined, window => { window.sessionStorage.removeItem('aeeis.token'); window.localStorage.setItem('aeeis.token', '中文令牌'); });
    const doc = dom.window.document;
    await vi.waitFor(() => expect(fetch).toHaveBeenCalled());
    await new Promise(resolve => setTimeout(resolve, 50));
    expect(doc.getElementById('error')?.textContent).toContain('不能放进请求头');
    expect(doc.getElementById('error')?.textContent).not.toContain('需要访问令牌');
  });
  it('shows a distinct message for a wrong token', async () => {
    const fetch = vi.fn(async () => ({ ok: false, status: 401, text: async () => JSON.stringify({ error: 'Invalid local access token' }) }));
    start('/', fetch);
    const doc = dom.window.document;
    await vi.waitFor(() => expect(doc.getElementById('error')?.textContent).toContain('访问令牌无效'));
  });
  it('remembers the token across tabs, carries an older tab-only token over, and forgets both on request', async () => {
    const run = fixture(), fetch = strictFetch(run);
    // start() seeds sessionStorage the way an older build stored the token.
    start(`/runs/${run.id}`, fetch);
    const doc = dom.window.document;
    await vi.waitFor(() => expect(doc.getElementById('run-title')?.textContent).toBe(run.goal));
    expect(dom.window.localStorage.getItem('aeeis.token')).toBe('saved-auth-secret');
    expect(dom.window.sessionStorage.getItem('aeeis.token')).toBeNull();
    expect(fetch.mock.calls.some(([, init]) => init?.headers?.authorization === 'Bearer saved-auth-secret')).toBe(true);
    const local = dom.window.localStorage.getItem('aeeis.token');
    dom.window.close();
    // A new tab or the home-screen app starts with empty sessionStorage but the same localStorage.
    const fresh = strictFetch(run);
    start(`/runs/${run.id}`, fresh, undefined, window => { window.sessionStorage.clear(); window.localStorage.setItem('aeeis.token', local!); });
    const next = dom.window.document;
    await vi.waitFor(() => expect(next.getElementById('run-title')?.textContent).toBe(run.goal));
    expect((next.getElementById('token') as HTMLInputElement).value).toBe('saved-auth-secret');
    expect(fresh.mock.calls.some(([, init]) => init?.headers?.authorization === 'Bearer saved-auth-secret')).toBe(true);
    next.getElementById('forget-token')!.click();
    expect(dom.window.localStorage.getItem('aeeis.token')).toBeNull();
    expect(dom.window.sessionStorage.getItem('aeeis.token')).toBeNull();
    expect((next.getElementById('token') as HTMLInputElement).value).toBe('');
  });
});
describe('group chat', () => {
  it('opens a draft from the roster and refuses a group that is only AEEIS', async () => {
    const run = fixture();
    const fetch = vi.fn(async (url: string, init?: { method?: string }) => {
      if (url === '/api/status') return response({ modelConfigured: false, runner: 'unconfigured', mode: 'single-owner-local' });
      if (url === `/api/runs/${run.id}`) return response(run);
      if (String(url).endsWith('/graphs')) return response(sharedRunView(run).graphs);
      if (String(url).endsWith('/explanation')) return response(sharedRunView(run).explanation);
      if (String(url).includes('/page?')) return response({ items: [], goals: [] });
      if (String(url).startsWith('/api/rooms') && init?.method === 'POST') return response({ id: 'room_created', title: '发布协作', status: 'active', createdAt: run.createdAt, updatedAt: run.updatedAt });
      return response([]);
    });
    start(`/runs/${run.id}`, fetch);
    await vi.waitFor(() => expect(dom.window.document.getElementById('run-title')?.textContent).toBe(run.goal));
    dom.window.document.getElementById('gb-new-group')!.click();
    await vi.waitFor(() => expect(dom.window.document.body.classList.contains('group-draft')).toBe(true));
    const doc = dom.window.document;
    expect(doc.getElementById('group-draft')?.hidden).toBe(false);
    expect(doc.getElementById('detail')?.hidden).toBe(true);
    expect(doc.getElementById('group-count-live')?.textContent).toContain('1 / 10');
    (doc.getElementById('group-title') as HTMLInputElement).value = '发布协作';
    (doc.getElementById('group-create') as HTMLFormElement).requestSubmit();
    await vi.waitFor(() => expect(doc.getElementById('error')?.textContent).toContain('至少'));
    expect(fetch.mock.calls.some(call => String(call[0]) === '/api/rooms' && (call[1] as { method?: string } | undefined)?.method === 'POST')).toBe(false);
  });
});
describe('bot groups', () => {
  it('shows built-in bots in groups and lets them take work directly', async () => {
    const run = fixture();
    const fetch = vi.fn(async (url: string, init?: { method?: string }) => {
      if (url === '/api/status') return response({ modelConfigured: false, runner: 'unconfigured', mode: 'single-owner-local' });
      if (url === `/api/runs/${run.id}`) return response(run);
      if (String(url).endsWith('/graphs')) return response(sharedRunView(run).graphs);
      if (String(url).endsWith('/explanation')) return response(sharedRunView(run).explanation);
      if (String(url).includes('/runs/page')) return response({ items: [run] });
      if (String(url).includes('/page?')) return response({ items: [], goals: [] });
      if (String(url).startsWith('/api/runs') && init?.method === 'POST') return response(run);
      return response([]);
    });
    start(`/runs/${run.id}`, fetch);
    await vi.waitFor(() => expect(dom.window.document.getElementById('bots')?.textContent).toContain('发布'));
    const doc = dom.window.document;
    expect(doc.getElementById('bots')?.textContent).toContain('工作');
    expect(doc.getElementById('bots')?.textContent).toContain('研究');
    expect(doc.getElementById('bots')?.textContent).toContain('纪要');
    const release = [...doc.querySelectorAll<HTMLButtonElement>('#bots [data-bot-id]')].find(row => row.dataset.botId === 'demo.release');
    release?.click();
    expect(doc.getElementById('gb-title')?.textContent).toBe('发布');
    expect(doc.getElementById('empty')?.textContent).toContain('直接发给它就能开工');
    expect(doc.querySelector<HTMLButtonElement>('#quick-run button[type="submit"]')?.disabled).toBe(true);
    expect(fetch.mock.calls.some(call => String(call[0]).startsWith('/api/runs') && (call[1] as { method?: string } | undefined)?.method === 'POST')).toBe(false);
    (doc.getElementById('bot-group-name') as HTMLInputElement).value = '值班';
    (doc.getElementById('bot-group-draft') as HTMLFormElement).requestSubmit();
    const duty = [...doc.querySelectorAll<HTMLButtonElement>('#bot-placement button')].find(button => button.textContent === '值班');
    duty?.click();
    const heading = [...doc.querySelectorAll('.bot-group-label')].find(item => item.textContent?.startsWith('值班'));
    expect(heading?.nextElementSibling?.textContent).toContain('发布');
    doc.getElementById('gb-bot')!.click();
    expect(doc.getElementById('gb-title')?.textContent).toBe('AEEIS');
    expect(doc.getElementById('runs')?.textContent).toContain(run.goal);
  });

  it('replaces the demo roster when an agent is admitted', async () => {
    const run = fixture();
    const fetch = vi.fn(async (url: string) => {
      if (url === '/api/status') return response({ modelConfigured: false, runner: 'unconfigured', mode: 'single-owner-local' });
      if (url === `/api/runs/${run.id}`) return response(run);
      if (String(url).endsWith('/graphs')) return response(sharedRunView(run).graphs);
      if (String(url).endsWith('/explanation')) return response(sharedRunView(run).explanation);
      if (String(url).includes('/page?')) return response({ items: [], goals: [] });
      if (String(url).startsWith('/api/agents')) return response([{
        agentId: 'agent.release', status: 'admitted', discoveredAt: run.createdAt,
        card: { name: '发布核对', owner: 'demo', capabilities: [], cardVersion: '1' },
        reputation: { samples: 0, dimensions: {} },
      }]);
      return response([]);
    });
    start(`/runs/${run.id}`, fetch);
    await vi.waitFor(() => expect(dom.window.document.getElementById('bots')?.textContent).toContain('发布核对'));
    const text = dom.window.document.getElementById('bots')?.textContent ?? '';
    expect(text).not.toContain('纪要');
    expect(text).toContain('AEEIS');
  });
});
describe('entry', () => {
  it('returns to the entry when the Bot is selected and keeps the task in the roster', async () => {
    const run = fixture();
    const fetch = vi.fn(async (url: string) => {
      if (url === '/api/status') return response({ modelConfigured: false, runner: 'unconfigured', mode: 'single-owner-local' });
      if (url === `/api/runs/${run.id}`) return response(run);
      if (String(url).endsWith('/graphs')) return response(sharedRunView(run).graphs);
      if (String(url).endsWith('/explanation')) return response(sharedRunView(run).explanation);
      if (String(url).includes('/runs/page')) return response({ items: [run] });
      if (String(url).includes('/page?')) return response({ items: [], goals: [] });
      return response([]);
    });
    start(`/runs/${run.id}`, fetch);
    await vi.waitFor(() => expect(dom.window.document.getElementById('run-title')?.textContent).toBe(run.goal));
    const draft = dom.window.document.getElementById('quick-goal') as HTMLInputElement;
    draft.value = '先别发出去';
    expect(dom.window.document.getElementById('gb-new-chat')).toBeNull();
    dom.window.document.getElementById('gb-bot')!.click();
    const doc = dom.window.document;
    expect(doc.getElementById('detail')?.hidden).toBe(true);
    expect(doc.getElementById('empty')?.hidden).toBe(false);
    expect(doc.body.classList.contains('run-open')).toBe(false);
    expect(doc.getElementById('gb-title')?.textContent).toBe('AEEIS');
    expect(doc.getElementById('gb-presence')?.textContent).toContain('任务都还在跑');
    expect(doc.getElementById('runs')?.textContent).toContain(run.goal);
    expect(draft.value).toBe('先别发出去');
    expect(doc.defaultView!.localStorage.getItem('aeeis.run')).toBeNull();
  });
});
describe('run link workbench', () => {
  it('renders filled PDF fields, unknowns, evidence and a PDF download in the actual workbench', async () => {
    const run = fixture(), output = await fillPdf(formSource, profile);
    run.builtinSkill = 'fillable-pdf/1';
    run.artifacts[0]!.artifactType = 'fillable-pdf/1';
    run.artifacts[0]!.structured = pdfArtifact(output);
    const fetch = vi.fn(async (url: string) => {
      if (url === '/api/status') return response({ modelConfigured: false, runner: 'unconfigured', mode: 'single-owner-local' });
      if (url === `/api/runs/${run.id}`) return response(run);
      if (url.endsWith('/graphs')) return response(sharedRunView(run).graphs);
      if (url.endsWith('/explanation')) return response(sharedRunView(run).explanation);
      if (url.includes('/page?')) return response({ items: [], goals: [] });
      return response([]);
    });
    start(`/runs/${run.id}`, fetch);
    await vi.waitFor(() => expect(dom.window.document.querySelector('.fillable-pdf')?.textContent).toContain('Maya Chen'));
    const doc = dom.window.document;
    expect(doc.querySelector('.fillable-pdf')?.textContent).toContain('phone · No source value; left empty.');
    expect(doc.querySelector('.fillable-pdf')?.textContent).toContain('caseId · Read-only; explicitly untouched.');
    expect(doc.querySelector('.fillable-pdf')?.textContent).toContain(output.sha256);
    expect(doc.querySelector('#artifacts a[download]')?.textContent).toBe('下载 PDF');
    expect(doc.querySelector('#artifacts a[download]')?.getAttribute('download')).toBe('filled-form.pdf');
    expect(doc.querySelector('#builtin-skill option[value="fillable-pdf/1"]')).not.toBeNull();
    expect(doc.querySelector('#material-files')?.getAttribute('accept')).toContain('.pdf');
  });
  it('loads only the shared run without auth and shows all requested read-only details', async () => {
    const run = fixture(), token = 'a'.repeat(43);
    for (let seq = 2; seq <= 100; seq++) run.events.push({ id: `event_${seq}`, seq, type: 'model.completed', at: run.createdAt, data: {} });
    const fetch = vi.fn(async () => response(sharedRunView(run)));
    start(`/share/${token}`, fetch);
    await vi.waitFor(() => expect(dom.window.document.getElementById('run-title')?.textContent).toBe(run.goal));
    const doc = dom.window.document;
    expect(doc.getElementById('copy-run-link')?.textContent).toBe('复制链接');
    expect(fetch).toHaveBeenCalledTimes(1);
    expect(fetch.mock.calls[0]![0]).toBe(`/api/share/${token}`);
    expect(fetch.mock.calls[0]![1].headers).not.toHaveProperty('authorization');
    expect(doc.getElementById('detail')?.hidden).toBe(false);
    expect(doc.body.classList.contains('run-details-mode')).toBe(true);
    expect(doc.getElementById('graph')?.textContent).toContain('Missing structured output');
    expect(doc.getElementById('timeline')?.textContent).toContain('#1');
    expect(doc.querySelectorAll('#timeline > li')).toHaveLength(100);
    expect(doc.querySelector('#timeline > li:first-child pre')?.textContent).toContain('Missing structured output');
    expect(doc.getElementById('artifacts')?.textContent).toContain('Visible result');
    expect(doc.getElementById('run-explanation')?.textContent).toContain('needs_revision');
    expect(doc.getElementById('evidence-graph')?.textContent).toContain('Evidence');
    expect(doc.getElementById('controls')?.childElementCount).toBe(0);
    expect(doc.getElementById('decision-review-actions')?.childElementCount).toBe(0);
    expect(doc.getElementById('decision-next-button')?.hidden).toBe(true);
    expect(dom.window.getComputedStyle(doc.getElementById('create-run-share')!).display).toBe('none');
  });
  it('selects the run in the URL over saved state and expands the workbench', async () => {
    const run = fixture();
    const fetch = vi.fn(async (url: string) => {
      if (url === '/api/status') return response({ modelConfigured: false, runner: 'unconfigured', mode: 'single-owner-local' });
      if (url === '/api/tools') return response({ tools: [], defaultAllowedTools: [] });
      if (url === `/api/runs/${run.id}`) return response(run);
      if (url === `/api/runs/${run.id}/graphs`) return response(sharedRunView(run).graphs);
      if (url === `/api/runs/${run.id}/explanation`) return response(sharedRunView(run).explanation);
      if (url.includes('/page?')) return response({ items: [], goals: [] });
      return response([]);
    });
    start(`/runs/${run.id}`, fetch);
    await vi.waitFor(() => expect(dom.window.document.getElementById('run-title')?.textContent).toBe(run.goal));
    expect(dom.window.document.getElementById('detail')?.hidden).toBe(false);
    expect(dom.window.document.body.classList.contains('run-details-mode')).toBe(true);
    expect(fetch.mock.calls.some(([url]) => url === `/api/runs/${run.id}`)).toBe(true);
    expect(dom.window.location.pathname).toBe(`/runs/${run.id}`);
    const writeText = vi.fn().mockResolvedValue(undefined);
    Object.defineProperty(dom.window.navigator, 'clipboard', { value: { writeText }, configurable: true });
    dom.window.document.getElementById('copy-run-link')!.click();
    await vi.waitFor(() => expect(writeText).toHaveBeenCalledWith(`http://localhost/runs/${run.id}`));
  });
  it('keeps a copyable URL visible when clipboard access is unavailable', async () => {
    const run = fixture(), token = 'a'.repeat(43);
    start(`/share/${token}`, vi.fn(async () => response(sharedRunView(run))));
    await vi.waitFor(() => expect(dom.window.document.getElementById('run-title')?.textContent).toBe(run.goal));
    dom.window.document.getElementById('copy-run-link')!.click();
    await vi.waitFor(() => expect(dom.window.document.querySelector('#run-share-result a')?.textContent).toBe(`http://localhost/share/${token}`));
  });
  it('renders a thread timeline, paginates, links parents, and retains the key after a lost follow-up response', async () => {
    const root = fixture(), child = fixture(), threadId = `thread_${randomUUID()}`;
    root.threadId = child.threadId = threadId; root.threadSequence = 1; child.threadSequence = 2; child.parentRunId = root.id;
    root.goal = '<img src=x onerror=alert(1)> root';
    const summaries = [root, child].map(run => ({ id: run.id, threadId, threadSequence: run.threadSequence, parentRunId: run.parentRunId, status: run.status, goal: run.goal, privacy: run.privacy, outputExcerpt: 'Timeline output <script>unsafe</script>' }));
    let attempts = 0;
    const fetch = vi.fn(async (url: string, options: any) => {
      if (url === `/api/threads/${threadId}/runs`) { if (++attempts === 1) throw new Error('Lost response'); return response(child); }
      if (url.startsWith(`/api/threads/${threadId}?`)) return response({ id: threadId, title: 'Reports', runs: url.endsWith('afterSequence=0') ? [summaries[0]] : [summaries[1]], ...(url.endsWith('afterSequence=0') ? { nextAfterSequence: 1 } : {}) });
      const run = url.includes(child.id) ? child : root;
      if (url.endsWith('/graphs')) return response(sharedRunView(run).graphs);
      if (url.endsWith('/explanation')) return response(sharedRunView(run).explanation);
      return response(run);
    });
    start(`/threads/${threadId}`, fetch);
    const doc = dom.window.document;
    await vi.waitFor(() => expect(doc.getElementById('thread-timeline')?.textContent).toContain(root.goal));
    expect(doc.querySelector('#thread-timeline img')).toBeNull(); expect(doc.querySelector('#thread-timeline script')).toBeNull();
    expect(doc.getElementById('thread-timeline')?.textContent).toContain('Timeline output');
    expect((doc.getElementById('run-thread-link') as HTMLAnchorElement).pathname).toBe(`/threads/${threadId}`);
    expect(dom.window.location.pathname).toBe(`/threads/${threadId}`);
    doc.getElementById('thread-more')!.click();
    await vi.waitFor(() => expect(doc.querySelectorAll('#thread-timeline > li')).toHaveLength(2));
    expect(doc.querySelector(`#thread-timeline a[href="/runs/${root.id}"]`)).not.toBeNull();
    expect(doc.querySelectorAll('#thread-parent option')).toHaveLength(2);
    (doc.getElementById('thread-message') as HTMLTextAreaElement).value = 'Continue the report';
    const submit = () => doc.getElementById('thread-followup')!.dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
    submit(); await vi.waitFor(() => expect(doc.getElementById('error')?.textContent).toContain('Lost response'));
    submit(); await vi.waitFor(() => expect(doc.getElementById('run-title')?.textContent).toBe(child.goal));
    const posts = fetch.mock.calls.filter(([url]) => url === `/api/threads/${threadId}/runs`);
    expect(posts).toHaveLength(2);
    expect(posts[0]![1].headers['Idempotency-Key']).toMatch(/^[a-f0-9-]{36}$/);
    expect(posts[1]![1].headers['Idempotency-Key']).toBe(posts[0]![1].headers['Idempotency-Key']);
    expect(JSON.parse(posts[0]![1].body)).toEqual({ request: { goal: 'Continue the report', privacy: 'internal' }, parentRunId: root.id });
    expect(fetch.mock.calls.every(([, options]) => options.headers.authorization === 'Bearer saved-auth-secret')).toBe(true);
    expect(dom.window.location.pathname).toBe(`/threads/${threadId}`);
  });
  it('shows needs_input with the existing answer control and only terminal follow-up parents', async () => {
    const root = fixture(), child = fixture(), threadId = `thread_${randomUUID()}`;
    root.threadId = child.threadId = threadId; root.threadSequence = 1; child.threadSequence = 2; child.parentRunId = root.id;
    child.status = 'needs_input'; child.question = { text: 'Which report?' };
    const fetch = vi.fn(async (url: string) => {
      if (url.startsWith(`/api/threads/${threadId}?`)) return response({ id: threadId, runs: [root, child] });
      if (url.includes('/events/stream')) return new Promise(() => {});
      const run = url.includes(root.id) ? root : child;
      if (url.endsWith('/graphs')) return response(sharedRunView(run).graphs);
      if (url.endsWith('/explanation')) return response(sharedRunView(run).explanation);
      if (url.endsWith('/answer')) { child.status = 'running'; return response({}); }
      return response(run);
    });
    start(`/threads/${threadId}`, fetch);
    const doc = dom.window.document;
    await vi.waitFor(() => expect(doc.getElementById('run-title')?.textContent).toBe(child.goal));
    expect(doc.querySelectorAll('#thread-parent option')).toHaveLength(1);
    expect((doc.getElementById('thread-parent') as HTMLSelectElement).value).toBe(root.id);
    const answerButton = [...doc.querySelectorAll<HTMLButtonElement>('#thread-timeline button')].find(button => button.textContent === '回答当前问题')!;
    answerButton.click(); await vi.waitFor(() => expect(doc.getElementById('input-panel')?.hidden).toBe(false));
    expect(doc.getElementById('question')?.textContent).toBe('Which report?');
    (doc.getElementById('answer') as HTMLTextAreaElement).value = 'October report';
    doc.getElementById('answer-form')!.dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
    await vi.waitFor(() => expect(fetch.mock.calls.some(([url]) => url === `/api/runs/${child.id}/answer`)).toBe(true));
  });
  it('renders thread shares without auth or owner links, and lets readers select each redacted run', async () => {
    const root = fixture(), child = fixture(), token = 't'.repeat(43), threadId = `thread_${randomUUID()}`;
    root.threadId = child.threadId = threadId; root.threadSequence = 1; child.threadSequence = 2; child.parentRunId = root.id; child.goal = 'Second report';
    const fetch = vi.fn(async () => response({ kind: 'thread', thread: { id: threadId, title: 'Shared reports' }, throughSequence: 2, runs: [sharedRunView(root), sharedRunView(child)] }));
    start(`/share/${token}`, fetch);
    const doc = dom.window.document;
    await vi.waitFor(() => expect(doc.getElementById('run-title')?.textContent).toBe(child.goal));
    expect(doc.querySelectorAll('#thread-timeline > li')).toHaveLength(2);
    expect(doc.getElementById('thread-meta')?.textContent).toContain('#2');
    expect(doc.getElementById('thread-followup')?.hidden).toBe(true); expect(doc.getElementById('thread-share-controls')?.hidden).toBe(true);
    expect(doc.getElementById('run-thread-link')?.hidden).toBe(true);
    expect(doc.querySelector('#thread-timeline a')).toBeNull(); expect(doc.querySelector('#artifacts a[download]')).toBeNull();
    (doc.querySelector('#thread-timeline button') as HTMLButtonElement).click();
    await vi.waitFor(() => expect(doc.getElementById('run-title')?.textContent).toBe(root.goal));
    expect(fetch.mock.calls.every(([url, options]: any) => url === `/api/share/${token}` && !options.headers.authorization)).toBe(true);
    expect(doc.getElementById('controls')?.childElementCount).toBe(0);
  });
  it('keeps the root request and key when a lost response is followed by a refreshed nonempty thread', async () => {
    const root = fixture(), threadId = `thread_${randomUUID()}`;
    root.threadId = threadId; root.threadSequence = 1;
    let posted = false, attempts = 0;
    const fetch = vi.fn(async (url: string, options: any) => {
      if (url === `/api/threads/${threadId}/runs`) { posted = true; if (++attempts === 1) throw new Error('Lost root response'); return response(root); }
      if (url.startsWith(`/api/threads/${threadId}?`)) return response({ id: threadId, runs: posted ? [root] : [] });
      if (url.endsWith('/graphs')) return response(sharedRunView(root).graphs);
      if (url.endsWith('/explanation')) return response(sharedRunView(root).explanation);
      return response(root);
    });
    start(`/threads/${threadId}`, fetch);
    const doc = dom.window.document;
    await vi.waitFor(() => expect(doc.getElementById('thread-panel')?.hidden).toBe(false));
    (doc.getElementById('thread-message') as HTMLTextAreaElement).value = 'First report';
    const submit = () => doc.getElementById('thread-followup')!.dispatchEvent(new dom.window.Event('submit', { bubbles: true, cancelable: true }));
    submit(); await vi.waitFor(() => expect(doc.getElementById('error')?.textContent).toContain('Lost root response'));
    doc.getElementById('connect')!.click();
    await vi.waitFor(() => expect(doc.getElementById('run-title')?.textContent).toBe(root.goal));
    expect((doc.getElementById('thread-parent') as HTMLSelectElement).value).toBe('');
    submit(); await vi.waitFor(() => expect((doc.getElementById('thread-message') as HTMLTextAreaElement).value).toBe(''));
    const posts = fetch.mock.calls.filter(([url]) => url.endsWith('/runs'));
    expect(posts).toHaveLength(2); expect(posts[0]![1].body).toBe(posts[1]![1].body);
    expect(JSON.parse(posts[0]![1].body)).not.toHaveProperty('parentRunId');
    expect(posts[0]![1].headers['Idempotency-Key']).toBe(posts[1]![1].headers['Idempotency-Key']);
  });
  it('creates and revokes a thread share with a copyable URL', async () => {
    const root = fixture(), threadId = `thread_${randomUUID()}`, token = 's'.repeat(43);
    root.threadId = threadId; root.threadSequence = 1;
    const fetch = vi.fn(async (url: string, options: any) => {
      if (url === `/api/threads/${threadId}/share`) return response({ url: `/share/${token}`, id: 'share_one', expiresAt: root.updatedAt, throughSequence: 1 });
      if (options.method === 'DELETE') return response({});
      if (url.startsWith(`/api/threads/${threadId}?`)) return response({ id: threadId, runs: [root] });
      if (url.endsWith('/graphs')) return response(sharedRunView(root).graphs);
      if (url.endsWith('/explanation')) return response(sharedRunView(root).explanation);
      return response(root);
    });
    start(`/threads/${threadId}`, fetch);
    const doc = dom.window.document;
    await vi.waitFor(() => expect(doc.getElementById('thread-panel')?.hidden).toBe(false));
    doc.getElementById('create-thread-share')!.click();
    await vi.waitFor(() => expect(doc.querySelector('#thread-share-result a')?.textContent).toBe(`http://localhost/share/${token}`));
    expect(doc.getElementById('thread-share-result')?.textContent).toContain('#1');
    (doc.querySelector('#thread-share-result button') as HTMLButtonElement).click();
    await vi.waitFor(() => expect(doc.getElementById('thread-share-result')?.textContent).toBe('分享已撤销'));
    expect(fetch.mock.calls.some(([url, options]) => url === `/api/threads/${threadId}/share/share_one` && options.method === 'DELETE')).toBe(true);
  });
});

describe('plan review workbench', () => {
  async function workbench(options: { readOnly?: boolean; shared?: boolean; stale?: boolean } = {}) {
    const run = fixture();
    run.status = 'needs_approval'; run.steps = []; run.artifacts = []; delete run.error; delete run.review;
    run.plans[0]!.summary = '初始计划';
    run.plans[0]!.nodes = [
      { id: 'read', title: '读取资料', instruction: '整理资料', dependsOn: [] },
      { id: 'write', title: '生成报告', instruction: '撰写报告', dependsOn: ['read'] },
    ];
    const posts: Array<{ action: string; body: any }> = [];
    const fetch = vi.fn(async (url: string, options: any) => {
      if (options.method === 'POST') {
        const action = url.split('/').at(-1)!, body = JSON.parse(options.body); posts.push({ action, body });
        if (action === 'approve' && optionsForFetch.stale) return { ok: false, status: 409, text: async () => JSON.stringify({ error: '计划已更新，请刷新后批准最新版本' }) };
        run.revision++;
        if (action === 'edit-plan') run.plans.push({ ...body.plan, version: body.planVersion + 1, hash: `hash${body.planVersion + 1}`, createdAt: run.createdAt, author: { type: 'user', actor: 'owner' } });
        if (action === 'budgets') { run.modelBudget = body.modelBudget; run.externalBudget = body.externalBudget; }
        if (action === 'revise-plan') run.status = 'planning';
        if (action === 'approve') run.status = 'running';
        return response(run);
      }
      if (url === '/api/status') return response({ modelConfigured: false, runner: 'unconfigured', mode: 'single-owner-local' });
      if (url.startsWith('/api/share/')) return response(sharedRunView(run));
      if (url.endsWith('/graphs')) return response(sharedRunView(run).graphs);
      if (url.endsWith('/explanation')) return response(sharedRunView(run).explanation);
      if (url === `/api/runs/${run.id}`) return response({ ...run, canEdit: !optionsForFetch.readOnly });
      if (url.includes('/page?')) return response({ items: [], goals: [] });
      return response([]);
    });
    const optionsForFetch = options;
    start(options.shared ? `/share/${'s'.repeat(43)}` : `/runs/${run.id}`, fetch);
    await vi.waitFor(() => expect(dom.window.document.querySelector('.plan-review-editor')).not.toBeNull());
    const doc = dom.window.document;
    const click = (label: string, parent: ParentNode = doc) => {
      const button = [...parent.querySelectorAll('button')].find(button => button.textContent === label);
      expect(button, label).toBeDefined(); button!.click();
    };
    const fill = (label: string, value: string) => {
      const input = doc.querySelector<HTMLInputElement | HTMLTextAreaElement>(`[aria-label="${label}"]`)!;
      expect(input, label).not.toBeNull(); input.value = value; input.dispatchEvent(new dom.window.Event('input', { bubbles: true }));
    };
    return { run, posts, doc, click, fill };
  }

  it('edits tasks inline, deletes, adds, reorders and displays version changes before approval', async () => {
    const f = await workbench();
    f.fill('任务 1 标题', '核查资料'); f.fill('任务 1 目标', '核对原始资料'); f.fill('任务 1 证据要求', '引用原始文件');
    f.doc.getElementById('decision-next-button')!.click();
    await vi.waitFor(() => expect(f.doc.body.textContent).toContain('请先将任务修改保存为新版本'));
    expect(f.posts).toHaveLength(0);
    const tasks = f.doc.querySelectorAll('.plan-review-editor fieldset');
    f.click('删除任务', tasks[2]!);
    await vi.waitFor(() => expect(f.doc.querySelector('[aria-label="任务 2 标题"]')).toBeNull());
    f.click('添加任务');
    await vi.waitFor(() => expect(f.doc.querySelector('[aria-label="任务 2 标题"]')).not.toBeNull());
    f.fill('任务 2 标题', '生成简报'); f.fill('任务 2 目标', '整理简报');
    f.click('上移', f.doc.querySelectorAll('.plan-review-editor fieldset')[2]!);
    await vi.waitFor(() => expect((f.doc.querySelector('[aria-label="任务 1 标题"]') as HTMLInputElement).value).toBe('生成简报'));
    f.click('保存为新版本');
    await vi.waitFor(() => expect(f.doc.querySelector('.plan-review-editor')?.textContent).toContain('计划版本历史 · 2 个版本'));
    expect(f.posts[0]).toMatchObject({ action: 'edit-plan', body: { planVersion: 1, plan: { nodes: [
      { id: 'task_1', title: '生成简报', instruction: '整理简报' },
      { id: 'read', title: '核查资料', instruction: '核对原始资料', evidenceRequirements: '引用原始文件' },
    ] } } });
    expect(f.doc.querySelector('.plan-review-editor')?.textContent).toContain('删除任务：生成报告');
    expect(f.doc.querySelector('.plan-review-editor')?.textContent).toContain('新增任务：生成简报');
    expect(f.doc.querySelector('.plan-review-editor')?.textContent).toContain('证据要求：未设置 → 引用原始文件');
    expect(f.doc.querySelector('.plan-review-editor')?.textContent).toContain('任务顺序：');
    f.doc.getElementById('decision-next-button')!.click();
    await vi.waitFor(() => expect(f.posts.at(-1)).toMatchObject({ action: 'approve', body: { planVersion: 2, planHash: 'hash2' } }));
  });

  it('submits free-text feedback and rejects empty feedback without a request', async () => {
    const f = await workbench(); f.click('提交要求并重新规划');
    await vi.waitFor(() => expect(f.doc.querySelector('.plan-review-editor [role="alert"]')?.textContent).toContain('请填写补充要求'));
    expect(f.posts).toHaveLength(0);
    f.fill('补充要求', '  增加风险和证据核查  '); f.click('提交要求并重新规划');
    await vi.waitFor(() => expect(f.posts).toEqual([{ action: 'revise-plan', body: { planVersion: 1, feedback: '增加风险和证据核查' } }]));
    await vi.waitFor(() => expect(f.doc.getElementById('decision-review')?.hidden).toBe(true));
  });

  it('preserves draft inputs through refresh and sends all budget limits with approval', async () => {
    const f = await workbench();
    f.fill('补充要求', '保留未提交的反馈'); f.fill('任务 1 标题', '待保存的标题');
    f.fill('模型 Token 上限', '1000'); f.fill('模型金额上限（美元）', '0.5');
    f.fill('外部调用次数上限', '3'); f.fill('外部 Token 上限', '100'); f.fill('外部金额上限（美元）', '1.2');
    f.click('保存预算');
    await vi.waitFor(() => expect(f.posts).toHaveLength(1));
    await vi.waitFor(() => expect([...f.doc.querySelectorAll('.plan-review-editor button')].find(button => button.textContent === '保存预算')?.disabled).toBe(false));
    expect((f.doc.querySelector('[aria-label="补充要求"]') as HTMLTextAreaElement).value).toBe('保留未提交的反馈');
    expect((f.doc.querySelector('[aria-label="任务 1 标题"]') as HTMLInputElement).value).toBe('待保存的标题');
    f.click('保存为新版本');
    await vi.waitFor(() => expect(f.doc.querySelector('.plan-review-editor')?.textContent).toContain('2 个版本'));
    f.click('批准并执行', f.doc.getElementById('decision-review-actions')!);
    await vi.waitFor(() => expect(f.posts.at(-1)).toEqual({ action: 'approve', body: { planVersion: 2, planHash: 'hash2', modelBudget: { tokens: 1000, moneyUsd: 0.5 }, externalBudget: { calls: 3, tokens: 100, moneyUsd: 1.2 } } }));
  });

  it('shows stale approval conflicts and keeps the review form available', async () => {
    const f = await workbench({ stale: true }); f.fill('外部调用次数上限', '2');
    f.click('批准并执行', f.doc.getElementById('decision-review-actions')!);
    await vi.waitFor(() => expect(f.doc.body.textContent).toContain('计划已更新，请刷新后批准最新版本'));
    expect(f.posts[0]).toMatchObject({ action: 'approve', body: { planVersion: 1, externalBudget: { calls: 2 } } });
    expect(f.doc.getElementById('decision-review')?.hidden).toBe(false);
  });

  it.each([{ readOnly: true }, { shared: true }])('omits editing and approval controls in read-only views (%j)', async options => {
    const f = await workbench(options);
    expect(f.doc.querySelector('.plan-review-editor input, .plan-review-editor textarea, .plan-review-editor button')).toBeNull();
    expect(f.doc.getElementById('decision-review-actions')?.textContent).not.toContain('批准并执行');
    expect(f.doc.getElementById('decision-next-button')?.hidden).toBe(true);
    expect(f.doc.getElementById('controls')?.hidden).toBe(true);
    expect(f.posts).toHaveLength(0);
  });
});
describe('the computer panel', () => {
  const view = (overrides: Record<string, unknown> = {}) => ({
    status: 'running',
    machine: { state: 'running', previews: [{ port: 3000, url: 'https://3000-abc.instabox.tech/?_token=ibp_secret' }, { port: 3001, url: 'javascript:alert(1)' }], live: {
      foreground: { command: 'npm test', startedAt: '2026-11-06T00:00:00Z', output: '<img src=x onerror=alert(1)>passing' },
      processes: [{ processId: 'proc_1', command: 'npm run dev', running: true, output: 'listening on 3000' }],
      repository: { status: ' M a.txt', diff: '+new line', truncated: false }, files: [],
    } },
    screenshots: [],
    ...overrides,
  });
  const open = async (status: string, computer: (url: string) => unknown, canEdit = true) => {
    const run = fixture();
    Object.assign(run, { status, review: undefined, error: undefined, events: [] });
    const calls: string[] = [];
    const fetch = vi.fn(async (url: string) => {
      if (String(url).endsWith('/computer')) { calls.push(String(url)); return computer(String(url)); }
      if (String(url) === `/api/runs/${run.id}`) return response({ ...run, canEdit });
      if (String(url).endsWith('/graphs')) return response(sharedRunView(run).graphs);
      if (String(url).endsWith('/explanation')) return response(sharedRunView(run).explanation);
      if (String(url).includes('/page?')) return response({ items: [], goals: [] });
      return response([]);
    });
    start(`/runs/${run.id}`, fetch);
    await vi.waitFor(() => expect(dom.window.document.getElementById('run-title')?.textContent).toBeTruthy());
    return { doc: dom.window.document, calls, run };
  };
  it('shows what the machine is doing, as text only, with safe links', async () => {
    const { doc } = await open('running', () => response(view()));
    await vi.waitFor(() => expect(doc.getElementById('computer-state')?.textContent).toBe('运行中'));
    const terminal = doc.getElementById('computer-terminal')!;
    expect(terminal.textContent).toContain('$ npm test  （运行中）');
    expect(terminal.textContent).toContain('<img src=x onerror=alert(1)>passing');
    expect(terminal.textContent).toContain('后台 · 运行中 · npm run dev');
    expect(terminal.querySelector('img')).toBeNull();
    expect(doc.getElementById('computer-changes')?.textContent).toContain('+new line');
    const links = [...doc.querySelectorAll<HTMLAnchorElement>('#computer-previews a')];
    expect(links.map(link => link.textContent)).toEqual(['打开预览（端口 3000）']);
    expect(links[0]!.rel).toBe('noopener noreferrer');
  });
  it('says when a tool call is waiting for the host, and when a stop was not confirmed', async () => {
    const waiting = await open('running', () => response(view({ machine: { state: 'unreachable', previews: [] }, hostWait: { since: '2026-11-06T00:00:00Z', message: 'paused' } })));
    await vi.waitFor(() => expect(waiting.doc.getElementById('computer-notice')?.textContent).toContain('在等沙箱主机恢复'));
    expect(waiting.doc.getElementById('computer-state')?.textContent).toBe('连不上');
    expect(waiting.doc.getElementById('computer-notice')?.textContent).toContain('工具还没有执行');
  });
  it('shows the independent check, requirement by requirement, with the delivery', async () => {
    const run = fixture();
    Object.assign(run, { status: 'succeeded', review: undefined, error: undefined, events: [], acceptanceChecks: [{ round: 1, passed: true, projectChanged: false, previewUrl: 'https://3000-x.instabox.tech/?_token=t', sourceArchive: 'source.tar.gz', items: [{ requirement: 'The page loads', status: 'passed', notes: '<b>HTTP 200</b>' }] }] });
    const fetch = vi.fn(async (url: string) => {
      if (String(url).endsWith('/computer')) return response(view({ status: 'succeeded', machine: { state: 'unknown', previews: [] } }));
      if (String(url) === `/api/runs/${run.id}`) return response({ ...run, canEdit: true });
      if (String(url).endsWith('/graphs')) return response(sharedRunView(run).graphs);
      if (String(url).endsWith('/explanation')) return response(sharedRunView(run).explanation);
      if (String(url).includes('/page?')) return response({ items: [], goals: [] });
      return response([]);
    });
    start(`/runs/${run.id}`, fetch);
    const doc = dom.window.document;
    await vi.waitFor(() => expect(doc.getElementById('computer-acceptance')?.hidden).toBe(false));
    expect(doc.getElementById('computer-acceptance-summary')?.textContent).toContain('1 / 1 条需求（第 2 轮）');
    const row = doc.querySelector('#computer-acceptance-items li')!;
    expect(row.textContent).toContain('通过：The page loads');
    expect(row.querySelector('b')).toBeNull();
    expect(doc.querySelector<HTMLAnchorElement>('#computer-delivery a')?.rel).toBe('noopener noreferrer');
    expect([...doc.querySelectorAll('#computer-delivery button')].map(item => item.textContent)).toEqual(['下载源码']);
  });
  it('is not offered to people who can only read the Run', async () => {
    const { doc, calls } = await open('running', () => response(view()), false);
    await new Promise(resolve => setTimeout(resolve, 50));
    expect(doc.querySelector<HTMLElement>('#run-computer')!.hidden).toBe(true);
    expect(calls).toEqual([]);
  });
  it('disappears on an AEEIS without Run machines', async () => {
    const { doc, calls } = await open('running', () => ({ ok: false, status: 404, text: async () => JSON.stringify({ error: 'no machines' }) }));
    await vi.waitFor(() => expect(calls).toHaveLength(1));
    await vi.waitFor(() => expect(doc.querySelector<HTMLElement>('#run-computer')!.hidden).toBe(true));
  });
  it('looks once at a finished Run instead of following it', async () => {
    const { calls } = await open('succeeded', () => response(view({ status: 'succeeded', machine: { state: 'released', previews: [] } })));
    await vi.waitFor(() => expect(calls).toHaveLength(1));
    await new Promise(resolve => setTimeout(resolve, 100));
    expect(calls).toHaveLength(1);
  });
});

describe('workbench takeover', () => {
  it('takes over a running Run after confirming, and hands it back only with a note', async () => {
    const run = fixture();
    Object.assign(run, { status: 'running', review: undefined, error: undefined, events: [] });
    run.plans[0]!.nodes.push({ id: 'second', title: 'Second', instruction: 'Do second', dependsOn: ['task'] });
    run.steps = [{ taskId: 'task', status: 'succeeded', attempts: 1, observations: [] }, { taskId: 'second', status: 'pending', attempts: 0, observations: [] }];
    const posts: Array<{ url: string; body: unknown }> = [];
    const fetch = vi.fn(async (url: string, init?: { method?: string; body?: string }) => {
      if (init?.method === 'POST' && url === `/api/runs/${run.id}/takeover`) {
        posts.push({ url, body: JSON.parse(init.body ?? '{}') });
        Object.assign(run, { status: 'paused', resumeStatus: 'running', takeover: { by: 'owner', at: new Date().toISOString() }, revision: run.revision + 1 });
        return response(run);
      }
      if (init?.method === 'POST' && url === `/api/runs/${run.id}/handback`) {
        posts.push({ url, body: JSON.parse(init.body ?? '{}') });
        Object.assign(run, { status: 'running', revision: run.revision + 1 }); delete (run as Partial<AgentRun>).takeover; delete run.resumeStatus;
        return response(run);
      }
      if (url === '/api/status') return response({ modelConfigured: true, runner: 'fixture', mode: 'single-owner-local' });
      if (url === `/api/runs/${run.id}`) return response(run);
      if (String(url).endsWith('/graphs')) return response(sharedRunView(run).graphs);
      if (String(url).endsWith('/explanation')) return response(sharedRunView(run).explanation);
      if (String(url).includes('/runs/page')) return response({ items: [run] });
      if (String(url).includes('/page?')) return response({ items: [], goals: [] });
      return response([]);
    });
    start(`/runs/${run.id}`, fetch);
    const doc = dom.window.document;
    const control = (text: string) => [...doc.querySelectorAll<HTMLButtonElement>('#controls button')].find(button => button.textContent === text);
    await vi.waitFor(() => expect(control('接管')).toBeTruthy());
    dom.window.confirm = () => false;
    control('接管')!.click();
    await new Promise(resolve => setTimeout(resolve, 50));
    expect(posts).toHaveLength(0);
    dom.window.confirm = () => true;
    control('接管')!.click();
    await vi.waitFor(() => expect(doc.getElementById('handback-note')).not.toBeNull());
    expect(posts[0]).toEqual({ url: `/api/runs/${run.id}/takeover`, body: {} });
    expect(control('继续')).toBeUndefined();
    expect(control('接管')).toBeUndefined();
    await vi.waitFor(() => expect(doc.getElementById('decision-badge')?.textContent).toBe('人已接管'));
    control('交还')!.click();
    await new Promise(resolve => setTimeout(resolve, 50));
    expect(posts).toHaveLength(1);
    (doc.getElementById('handback-note') as HTMLTextAreaElement).value = '第一段我写好了';
    control('交还')!.click();
    await vi.waitFor(() => expect(posts).toHaveLength(2));
    expect(posts[1]).toEqual({ url: `/api/runs/${run.id}/handback`, body: { note: '第一段我写好了' } });
    await vi.waitFor(() => expect(doc.getElementById('handback-note')).toBeNull());
    expect(control('暂停')).toBeTruthy();
  });

  it('gives the person the Bot workspace while taken over: list, open, save, run, and a log that survives refresh', async () => {
    const run = fixture();
    Object.assign(run, { status: 'paused', resumeStatus: 'running', review: undefined, error: undefined, events: [], takeover: { by: 'owner', at: new Date().toISOString(), actions: [] } });
    run.approvedTools = ['read', 'write', 'glob', 'shell'].map(id => ({ id, version: '3', capabilities: ['read'] }));
    run.steps = [{ taskId: 'task', status: 'pending', attempts: 0, observations: [] }];
    const posts: Array<{ toolId: string; input: Record<string, unknown> }> = [];
    const outputs: Record<string, unknown> = {
      glob: { paths: ['notes.md', 'artifacts/report.md'], truncated: false },
      read: { path: 'notes.md', sha256: 'b'.repeat(64), totalLines: 2, startLine: 1, content: '1: 第一行\n2: 第二行', truncated: false },
      write: { path: 'notes.md', bytes: 10, sha256: 'c'.repeat(64), created: false },
      shell: { stdout: 'all good\n', stderr: '', exitCode: 0 },
    };
    const fetch = vi.fn(async (url: string, init?: { method?: string; body?: string }) => {
      if (init?.method === 'POST' && url === `/api/runs/${run.id}/takeover-tool`) {
        const body = JSON.parse(init.body ?? '{}') as { toolId: string; input: Record<string, unknown> };
        posts.push(body);
        const actions = (run.takeover!.actions ??= []);
        actions.push({ at: new Date().toISOString(), toolId: body.toolId, summary: String(body.input.command ?? body.input.path ?? body.input.pattern ?? ''), status: 'completed', receiptId: `receipt_${actions.length}` });
        return response({ status: 'completed', output: outputs[body.toolId], actions });
      }
      if (url === '/api/status') return response({ modelConfigured: true, runner: 'fixture', mode: 'single-owner-local' });
      if (url === `/api/runs/${run.id}`) return response(run);
      if (String(url).endsWith('/graphs')) return response(sharedRunView(run).graphs);
      if (String(url).endsWith('/explanation')) return response(sharedRunView(run).explanation);
      if (String(url).includes('/runs/page')) return response({ items: [run] });
      if (String(url).includes('/page?')) return response({ items: [], goals: [] });
      return response([]);
    });
    const intervals: Array<() => void> = [];
    start(`/runs/${run.id}`, fetch, intervals);
    const doc = dom.window.document;
    const workspace = () => doc.getElementById('takeover-workspace')!;
    const press = (text: string) => [...workspace().querySelectorAll<HTMLButtonElement>('button')].find(button => button.textContent === text)!.click();
    await vi.waitFor(() => expect(workspace().hidden).toBe(false));
    expect(workspace().textContent).toContain('Bot 的工作区');
    press('列文件');
    await vi.waitFor(() => expect(workspace().querySelector('.takeover-file-list')?.textContent).toContain('artifacts/report.md'));
    press('notes.md');
    const editor = doc.getElementById('takeover-editor') as HTMLTextAreaElement;
    await vi.waitFor(() => expect(editor.hidden).toBe(false));
    expect(editor.value).toBe('第一行\n第二行');
    editor.value = '第一行\n改好的第二行';
    press('保存');
    await vi.waitFor(() => expect(posts.at(-1)?.toolId).toBe('write'));
    expect(posts.at(-1)?.input).toEqual({ path: 'notes.md', content: '第一行\n改好的第二行', expectedHash: 'b'.repeat(64) });
    (doc.getElementById('takeover-command') as HTMLInputElement).value = 'npm test';
    workspace().querySelector<HTMLFormElement>('.takeover-command')!.requestSubmit();
    await vi.waitFor(() => expect(workspace().querySelector('.takeover-output')?.textContent).toContain('all good'));
    expect(posts.map(post => post.toolId)).toEqual(['glob', 'read', 'write', 'shell']);
    expect(workspace().querySelectorAll('.takeover-log li')).toHaveLength(4);
    // A refresh redraws the log but keeps what the person typed.
    editor.value = '还没保存的改动';
    run.revision += 1; run.takeover!.actions!.push({ at: new Date().toISOString(), toolId: 'shell', summary: 'ls', status: 'failed', receiptId: 'receipt_x' });
    const fetched = fetch.mock.calls.length;
    for (const tick of intervals) tick();
    await vi.waitFor(() => expect(workspace().querySelectorAll('.takeover-log li')).toHaveLength(5));
    expect(fetch.mock.calls.length).toBeGreaterThan(fetched);
    expect((doc.getElementById('takeover-editor') as HTMLTextAreaElement).value).toBe('还没保存的改动');
  });
});

describe('push to this device', () => {
  it('subscribes through the service worker with the server key, and unsubscribes on the server and in the browser', async () => {
    const run = fixture();
    const calls: Array<{ url: string; method: string; body?: unknown }> = [];
    let subscription: { endpoint: string; unsubscribe: () => Promise<boolean>; toJSON: () => unknown } | null = null;
    let subscribedKey: Uint8Array | undefined;
    const fetch = vi.fn(async (url: string, init?: { method?: string; body?: string }) => {
      calls.push({ url, method: init?.method ?? 'GET', ...(init?.body ? { body: JSON.parse(init.body) } : {}) });
      if (url === '/api/push/config') return response({ web: { publicKey: 'BA' + 'A'.repeat(85) }, apns: false, fcm: false });
      if (url === '/api/push/subscriptions' && init?.method === 'POST') return response({ id: 'push_00000000-0000-4000-8000-000000000001' });
      if (url.startsWith('/api/push/subscriptions/')) return { ok: true, status: 204, text: async () => '' };
      if (url === '/api/status') return response({ modelConfigured: true, runner: 'fixture', mode: 'single-owner-local' });
      if (url === `/api/runs/${run.id}`) return response(run);
      if (String(url).endsWith('/graphs')) return response(sharedRunView(run).graphs);
      if (String(url).endsWith('/explanation')) return response(sharedRunView(run).explanation);
      if (String(url).includes('/runs/page')) return response({ items: [run] });
      if (String(url).includes('/page?')) return response({ items: [], goals: [] });
      return response([]);
    });
    start(`/runs/${run.id}`, fetch, undefined, window => {
      const pushManager = {
        getSubscription: async () => subscription,
        subscribe: async (options: { applicationServerKey: Uint8Array }) => {
          subscribedKey = options.applicationServerKey;
          subscription = { endpoint: 'https://push.example.test/abc', unsubscribe: async () => { subscription = null; return true; }, toJSON: () => ({ endpoint: 'https://push.example.test/abc', keys: { p256dh: 'p256', auth: 'auth' } }) };
          return subscription;
        },
      };
      const registration = { pushManager };
      window.PushManager = function PushManager() {};
      window.Notification = Object.assign(function Notification() {}, { permission: 'granted', requestPermission: async () => 'granted' });
      Object.defineProperty(window.navigator, 'serviceWorker', { configurable: true, value: { register: async () => registration, getRegistration: async () => registration, ready: Promise.resolve(registration), addEventListener: () => {} } });
    });
    const doc = dom.window.document;
    const toggle = doc.getElementById('push-notify') as HTMLInputElement;
    await vi.waitFor(() => expect(doc.getElementById('push-notify-note')?.textContent).toContain('默认关闭。打开后'));
    expect(toggle.disabled).toBe(false);
    toggle.checked = true;
    toggle.dispatchEvent(new dom.window.Event('change'));
    await vi.waitFor(() => expect(doc.getElementById('push-notify-note')?.textContent).toContain('已打开'));
    expect(subscribedKey?.[0]).toBe(4);
    expect(subscribedKey).toHaveLength(65);
    expect(calls.find(call => call.url === '/api/push/subscriptions' && call.method === 'POST')?.body).toEqual({ channel: 'web', label: '这台电脑的浏览器', endpoint: 'https://push.example.test/abc', keys: { p256dh: 'p256', auth: 'auth' } });
    expect(dom.window.localStorage.getItem('aeeis.push-subscription')).toBe('push_00000000-0000-4000-8000-000000000001');
    toggle.checked = false;
    toggle.dispatchEvent(new dom.window.Event('change'));
    await vi.waitFor(() => expect(calls.some(call => call.method === 'DELETE' && call.url === '/api/push/subscriptions/push_00000000-0000-4000-8000-000000000001')).toBe(true));
    await vi.waitFor(() => expect(subscription).toBeNull());
    expect(dom.window.localStorage.getItem('aeeis.push-subscription')).toBeNull();
  });

  it('says why push is off when the browser cannot do it', async () => {
    const run = fixture();
    start(`/runs/${run.id}`, vi.fn(async (url: string) => url === `/api/runs/${run.id}` ? response(run) : url === '/api/status' ? response({ modelConfigured: true, runner: 'fixture', mode: 'single-owner-local' }) : response([])));
    const doc = dom.window.document;
    await vi.waitFor(() => expect(doc.getElementById('push-notify-note')?.textContent).toBe('这个浏览器不支持推送。'));
    expect((doc.getElementById('push-notify') as HTMLInputElement).disabled).toBe(true);
  });
});
