import { afterEach, describe, expect, it, vi } from 'vitest';
import { buildApp } from '../src/runtime/http.js';
import { InMemoryRoutineStore } from '../src/routines.js';
import { InMemoryUiEventCountStore } from '../src/ui-event-counts.js';
import { InMemoryRunRepository } from '../src/adapters/in-memory-run-repository.js';
import { InMemoryConversationStore } from '../src/adapters/conversation-store.js';
import { InMemoryStore } from '../src/adapters/in-memory-store.js';
import { AeeisService } from '../src/application/aeeis-service.js';
import { InMemoryRoomMembershipRepository } from '../src/room-membership.js';
import { InMemorySessionEventRepository, SessionEventService } from '../src/session-events.js';
import { InMemoryOwnedBotStore } from '../src/owned-bots.js';
import { AgentEngine } from '../src/runtime/engine.js';
import type { ModelRequest } from '../src/runtime/model.js';

const headers = { authorization: 'Bearer alice' };
const scope = { owner: 'alice', tenantId: 'team-a' };
const cleanup: Array<() => Promise<void>> = [];
afterEach(async () => { while (cleanup.length) await cleanup.pop()!(); delete process.env.AEEIS_BOT_HANDOFF_MAX_TURNS; vi.restoreAllMocks(); });

type Script = {
  reply?: (input: any) => unknown;
  turn?: (input: any) => unknown;
  plan?: () => unknown;
};

async function team(script: Script, options: { quiet?: boolean; writerAutonomy?: string; researcherAutonomy?: string } = {}) {
  const bots = new InMemoryOwnedBotStore();
  const domain = new AeeisService(new InMemoryStore(), [], new InMemoryRoomMembershipRepository(), undefined, bots);
  const conversations = new InMemoryConversationStore();
  const sessionEvents = new SessionEventService(new InMemorySessionEventRepository(), domain);
  const repository = new InMemoryRunRepository();
  const calls: ModelRequest[] = [];
  const model = { pin: { model: 'team-fixture', endpoint: 'http://localhost', promptVersion: 'team/1' }, complete: vi.fn(async (request: ModelRequest) => {
    calls.push(request);
    if (request.system.includes('在团队群聊（或私聊）里回复一条消息')) return { value: script.reply?.(request.input) ?? { reply: '收到。' }, usage: { inputTokens: 10, outputTokens: 5 } };
    if (request.system.includes('在你们的侧线程里谈一件任务的交接')) return { value: script.turn?.(request.input) ?? { decision: 'accept', message: '我来。' }, usage: { inputTokens: 10, outputTokens: 5 } };
    if (request.system.includes('Plan a real deliverable')) {
      const plan = script.plan?.();
      if (plan instanceof Error) throw plan;
      return { value: plan ?? { summary: 'Work', nodes: [{ id: 'work', title: 'Work', instruction: 'Do it', dependsOn: [] }] } };
    }
    throw new Error(`unexpected model call: ${request.system.slice(0, 40)}`);
  }) };
  const engine = new AgentEngine(repository, model);
  const notify = vi.fn(async () => undefined);
  const app = buildApp({ repository, engine, dispatcher: { notify, close: async () => undefined }, domain, ownedBots: bots, conversationStore: conversations, sessionEvents, routines: new InMemoryRoutineStore(), uiEvents: new InMemoryUiEventCountStore(), principalTokens: { alice: { id: 'alice', tenantId: 'team-a', roles: ['owner'] } } });
  cleanup.push(() => app.close());
  const bot = async (name: string, role: string, autonomy?: string) => (await app.inject({ method: 'POST', url: '/api/bots', headers, payload: { name, role, mark: 'letter', color: '#176b45', background: `${name}负责${role}。`, ...(autonomy ? { autonomy } : {}) } })).json() as { id: string; name: string };
  const researcher = await bot('阿研', '研究', options.quiet ? 'quiet' : options.researcherAutonomy);
  const writer = await bot('阿写', '写作', options.writerAutonomy);
  const roomId = (await app.inject({ method: 'POST', url: '/api/rooms', headers, payload: { title: '发布协作', description: '群聊' } })).json().id as string;
  for (const member of [researcher, writer]) expect((await app.inject({ method: 'POST', url: `/api/rooms/${roomId}/members`, headers, payload: { principalId: member.id, role: 'agent' } })).statusCode).toBe(200);
  const goalId = (await app.inject({ method: 'POST', url: '/api/goals', headers, payload: { title: '发布协作', roomId } })).json().id as string;
  const manifestId = async () => (await app.inject({ method: 'POST', url: `/api/goals/${goalId}/context-manifests`, headers, payload: { purpose: '群聊消息', audienceMode: 'room' } })).json().id as string;
  let n = 0;
  const say = async (content: string, actor?: { type: 'agent'; id: string }) => {
    const response = await app.inject({ method: 'POST', url: `/api/rooms/${roomId}/session-events`, headers, payload: { goalId, type: 'message', content, contextManifestId: await manifestId(), idempotencyKey: `say-${++n}`, ...(actor ? { actor } : {}) } });
    expect(response.statusCode, response.body).toBe(200);
    await app.aeeisBots!.drain();
    return response.json() as { id: string };
  };
  const events = async () => (await app.inject({ method: 'GET', url: `/api/rooms/${roomId}/session-events?limit=200&includeQueued=1`, headers })).json().items as Array<{ id: string; type: string; actorId: string; actorType: string; content: string; evidenceRefs: string[]; idempotencyKey: string; botDelivery?: { mode: string }; taskAction?: { kind: string } }>;
  const board = async () => (await app.inject({ method: 'GET', url: `/api/rooms/${roomId}/board`, headers })).json() as { cards: Array<{ conversationId: string; taskId: string; title?: string; status: string; ownerId: string; decision: { assigneeId?: string; proposedBy?: string; offer?: { to: string }; blockedNote?: string } }> };
  const room = () => domain.getRoomForPrincipal(roomId, 'alice', 'team-a');
  return { app, domain, conversations, repository, engine, notify, calls, researcher, writer, roomId, goalId, manifestId, say, events, board, room };
}

describe('Bots that act on their own', () => {
  it('answers with one voice: AEEIS for an undirected line, the named member otherwise, never a Bot', async () => {
    const f = await team({ reply: input => ({ reply: `${input.you.name}收到：${input.message.text}` }) });
    const first = await f.say('今天先把发布说明理一下');
    let items = await f.events();
    const replies = items.filter(item => item.type === 'message' && item.actorType === 'agent');
    expect(replies).toEqual([expect.objectContaining({ actorId: 'aeeis', content: 'AEEIS收到：今天先把发布说明理一下', evidenceRefs: [first.id], idempotencyKey: `bot-reply:${first.id}:aeeis` })]);
    const named = await f.say(`@阿研 风险点有哪些？`);
    items = await f.events();
    const forNamed = items.filter(item => item.actorType === 'agent' && item.evidenceRefs.includes(named.id));
    expect(forNamed.map(item => item.actorId)).toEqual([f.researcher.id]);
    // A Bot's line (written by the owner for the Bot) starts no reply chain.
    const before = (await f.events()).length;
    await f.say('我补一句：数据在表里', { type: 'agent', id: f.writer.id });
    expect((await f.events()).length).toBe(before + 1);
    // Replays and the restart sweep do not answer twice or call the model again.
    const callsBefore = f.calls.length;
    await f.app.aeeisBots!.sweep(await f.room(), scope);
    await f.app.aeeisBots!.drain();
    expect((await f.events()).length).toBe(before + 1);
    expect(f.calls.length).toBe(callsBefore);
    // The transcript reaches the model as untrusted data, with the speakers' names.
    const last = f.calls.filter(call => call.system.includes('回复一条消息')).at(-1)!.input as any;
    expect(last.transcript_untrusted.at(-1)).toEqual({ speaker: '主人', text: '@阿研 风险点有哪些？' });
    expect(last.you).toMatchObject({ name: '阿研', role: '研究', frontDoor: false });
  });

  it('频道热闹允许 Bot 接话，安静恢复一个声音；热闹也只有六条主动消息', async () => {
    const f = await team({ reply: input => ({ reply: `${input.you.name}补充意见` }) });
    const url = `/api/rooms/${f.roomId}/noise-settings`;
    expect((await f.app.inject({ method: 'GET', url, headers })).json()).toMatchObject({ mode: 'quiet', digestMinutes: 15, canEdit: true });
    expect((await f.app.inject({ method: 'PUT', url, headers, payload: { mode: 'lively' } })).statusCode).toBe(200);
    await f.say('请一起看看');
    const first = (await f.events()).filter(item => item.actorType === 'agent');
    expect(first.map(item => item.actorId)).toEqual(['aeeis', f.researcher.id]);
    for (let i = 0; i < 4; i++) await f.say(`接着聊 ${i}`);
    const messages = (await f.events()).filter(item => item.actorType === 'agent');
    expect(messages.filter(item => item.botDelivery?.mode === 'immediate')).toHaveLength(6);
    expect(messages.filter(item => item.botDelivery?.mode === 'digest').length).toBeGreaterThan(0);
    await f.app.inject({ method: 'PUT', url, headers, payload: { mode: 'quiet' } });
    const before = (await f.events()).length;
    await f.say('Bot 的一句话', { type: 'agent', id: f.writer.id });
    expect((await f.events()).length).toBe(before + 1);
  });

  it('keeps a quiet Bot silent and writes a failure note instead of retrying a bad reply', async () => {
    const f = await team({ reply: input => input.you.name === 'AEEIS' ? { nope: true } : { reply: 'x' } }, { quiet: true });
    const named = await f.say('@阿研 在吗');
    expect((await f.events()).filter(item => item.evidenceRefs.includes(named.id) && item.actorType === 'agent')).toEqual([]);
    const plain = await f.say('大家好');
    const notes = (await f.events()).filter(item => item.evidenceRefs.includes(plain.id));
    expect(notes).toEqual([expect.objectContaining({ type: 'system', content: 'AEEIS这次没有回复：回复格式不对', idempotencyKey: `bot-fail:${plain.id}:aeeis` })]);
    await f.app.aeeisBots!.sweep(await f.room(), scope);
    await f.app.aeeisBots!.drain();
    expect((await f.events()).filter(item => item.evidenceRefs.includes(plain.id))).toHaveLength(1);
  });

  it('puts a proposal on the board, and an automatic Bot starts it as an agent-origin Run', async () => {
    const f = await team({ reply: input => input.you.name === 'AEEIS' ? { reply: '我请阿写起草。', proposeTask: { title: '起草发布说明', reason: '下周发布', for: '阿写' } } : { reply: '好' } }, { writerAutonomy: 'auto' });
    await f.say('下周发布，需要一份发布说明');
    const card = (await f.board()).cards.find(item => item.title === '起草发布说明');
    expect(card).toMatchObject({ ownerId: f.writer.id, decision: { proposedBy: 'aeeis' } });
    const life = (await f.conversations.list(scope)).find(item => item.agentId === f.writer.id)!;
    expect(life.tasks.map(task => task.title)).toEqual(['起草发布说明']);
    const runs = await f.repository.list();
    expect(runs).toHaveLength(1);
    expect(runs[0]).toMatchObject({ origin: 'agent', executionReview: 'auto' });
    // The Run reads who asked and why, not a bare "I'll do it".
    expect(runs[0]!.goal).toContain('任务：起草发布说明');
    expect(runs[0]!.goal).toContain('在群里说：「下周发布，需要一份发布说明」');
    expect(runs[0]!.goal).toContain('理由：下周发布');
    expect(f.notify).toHaveBeenCalledWith(runs[0]!.id);
    expect((await f.events()).some(item => item.taskAction?.kind === 'propose')).toBe(true);
  });

  it('splits one message into several tasks, and two automatic Bots start theirs side by side', async () => {
    const f = await team({ reply: input => input.you.name === 'AEEIS' ? { reply: '拆成三件：阿研查两件，阿写起草。', tasks: [
      { title: '查竞品的发布节奏', reason: '定发布日', for: '阿研' },
      { title: '整理已知风险', for: '阿研' },
      { title: '起草发布说明', reason: '下周发布', for: '阿写' },
    ] } : { reply: '好' } }, { writerAutonomy: 'auto', researcherAutonomy: 'auto' });
    await f.say('下周发布：查竞品节奏、整理风险、写发布说明');
    const cards = (await f.board()).cards;
    expect(cards.map(card => [card.title, card.ownerId])).toEqual(expect.arrayContaining([
      ['查竞品的发布节奏', f.researcher.id], ['整理已知风险', f.researcher.id], ['起草发布说明', f.writer.id],
    ]));
    const items = await f.events();
    expect(items.filter(item => item.taskAction?.kind === 'propose')).toHaveLength(3);
    expect(items.filter(item => item.content.startsWith('AEEIS提议由'))).toHaveLength(3);
    // Each task gets its own Run, even two for the same Bot; each Run knows what its siblings cover.
    const runs = await f.repository.list();
    expect(runs).toHaveLength(3);
    expect(runs.every(run => run.origin === 'agent')).toBe(true);
    const competitor = runs.find(run => run.goal.includes('任务：查竞品的发布节奏'))!;
    expect(competitor.goal).toContain('同一句话还拆出了：「整理已知风险」、「起草发布说明」');
    expect(new Set(runs.map(run => run.goal.match(/任务：(.+)/)?.[1]))).toEqual(new Set(['查竞品的发布节奏', '整理已知风险', '起草发布说明']));
    expect(f.notify).toHaveBeenCalledTimes(3);
    // Saying the same thing again does not add cards: the reply is keyed by the message.
    await f.app.aeeisBots!.respond((items.find(item => item.content === '下周发布：查竞品节奏、整理风险、写发布说明') as any));
    expect((await f.board()).cards).toHaveLength(3);
  });

  it('lets a member keep one task and hand the other over when it splits its own reply', async () => {
    const f = await team({
      reply: input => input.you.name === '阿研' ? { reply: '我查数据，说明给阿写。', tasks: [{ title: '查上线数据' }, { title: '写上线说明', for: '阿写', note: '你写得快' }] } : { reply: '好' },
      turn: () => ({ decision: 'accept', message: '好，我来。' }),
    });
    await f.say('@阿研 上线前查数据并写说明');
    const cards = (await f.board()).cards;
    expect(cards.find(card => card.title === '查上线数据')).toMatchObject({ ownerId: f.researcher.id });
    expect(cards.find(card => card.title === '写上线说明')).toMatchObject({ ownerId: f.writer.id, movedFrom: f.researcher.id });
    expect((await f.events()).map(item => item.taskAction?.kind).filter(Boolean)).toEqual(['propose', 'propose', 'offer', 'transfer']);
  });

  it('records a demonstration in the group, drafts a routine for one Bot, runs it when asked, and revokes it', async () => {
    const f = await team({ reply: input => input.you.name === '阿研' ? { reply: '我来查。', tasks: [{ title: '查上线数据' }] } : { reply: '好' } }, { researcherAutonomy: 'auto' });
    const teachings = async () => (await f.app.inject({ method: 'GET', url: `/api/rooms/${f.roomId}/teachings`, headers })).json().items as Array<Record<string, any>>;
    const start = await f.app.inject({ method: 'POST', url: `/api/rooms/${f.roomId}/teachings`, headers, payload: { agentId: f.researcher.id } });
    expect(start.statusCode, start.body).toBe(200);
    const id = start.json().id as string;
    expect(start.json()).toMatchObject({ agentId: f.researcher.id, agentName: '阿研', state: 'recording' });
    expect((await f.app.inject({ method: 'POST', url: `/api/rooms/${f.roomId}/teachings`, headers, payload: { agentId: f.writer.id } })).statusCode).toBe(409);
    expect((await f.app.inject({ method: 'POST', url: `/api/rooms/${f.roomId}/teachings/${id}/adopt`, headers, payload: { name: '上线检查' } })).statusCode).toBe(409);
    await f.say('@阿研 上线前先查数据');
    const card = (await f.board()).cards.find(item => item.title === '查上线数据')!;
    const block = await f.app.inject({ method: 'POST', url: `/api/rooms/${f.roomId}/task-actions`, headers, payload: { kind: 'block', conversationId: card.conversationId, taskId: card.taskId, reason: '等运维给数据', goalId: f.goalId, contextManifestId: await f.manifestId(), idempotencyKey: 'block-1' } });
    expect(block.statusCode, block.body).toBe(200);
    // The dispatcher is a stub here: plan the Bot's Run so the draft can read its steps.
    for (const run of await f.repository.list()) await f.engine.advance(run.id);
    const stop = await f.app.inject({ method: 'POST', url: `/api/rooms/${f.roomId}/teachings/${id}/stop`, headers, payload: {} });
    expect(stop.statusCode, stop.body).toBe(200);
    const recorded = stop.json();
    expect(recorded.state).toBe('recorded');
    const texts = (recorded.draft.steps as Array<{ text: string; source: string; decision: boolean }>);
    expect(texts).toEqual(expect.arrayContaining([
      expect.objectContaining({ text: '@阿研 上线前先查数据', source: 'message', decision: false }),
      expect.objectContaining({ text: '阻塞：等运维给数据', source: 'action', decision: true }),
      expect.objectContaining({ text: '查上线数据：Work', source: 'run' }),
    ]));
    // The Bot's own reply and the teaching markers are not steps.
    expect(texts.some(step => step.text.includes('我来查') || step.text.includes('开始示范'))).toBe(false);
    expect(recorded.draft).toMatchObject({ executionReview: 'required', decisions: ['阻塞：等运维给数据'] });
    expect(recorded.draft.prompt).toContain('到这些地方先停下，等人确认：\n- 阻塞：等运维给数据');
    expect((await f.events()).filter(item => item.content.startsWith('开始示范：教给阿研') || item.content.startsWith('示范结束'))).toHaveLength(2);

    const adopted = await f.app.inject({ method: 'POST', url: `/api/rooms/${f.roomId}/teachings/${id}/adopt`, headers, payload: { name: '上线检查' } });
    expect(adopted.statusCode, adopted.body).toBe(200);
    expect(adopted.json()).toMatchObject({ state: 'adopted', routineId: expect.stringMatching(/^routine_/) });
    const routineId = adopted.json().routineId as string;
    const routines = (await f.app.inject({ method: 'GET', url: `/api/routines?agentId=${f.researcher.id}`, headers })).json().routines as Array<Record<string, any>>;
    expect(routines).toEqual([expect.objectContaining({ id: routineId, name: '上线检查', trigger: { kind: 'manual' }, executionReview: 'required', status: 'active' })]);
    expect(routines[0]!.prompt).toContain('按「发布协作」里的一次示范来做');
    expect((await f.app.inject({ method: 'POST', url: `/api/rooms/${f.roomId}/teachings/${id}/adopt`, headers, payload: { name: '再来一次' } })).statusCode).toBe(409);
    const run = await f.app.inject({ method: 'POST', url: `/api/routines/${routineId}/run`, headers, payload: {} });
    expect(run.statusCode, run.body).toBe(200);
    expect(run.json()).toMatchObject({ status: 'started', runId: expect.any(String) });
    const started = await f.repository.get(run.json().runId, { owner: 'alice', tenantId: 'team-a' });
    expect(started.goal).toContain('主人让它现在做一次');

    expect((await f.app.inject({ method: 'POST', url: `/api/rooms/${f.roomId}/teachings/${id}/revoke`, headers, payload: { reason: '' } })).statusCode).toBe(400);
    const revoked = await f.app.inject({ method: 'POST', url: `/api/rooms/${f.roomId}/teachings/${id}/revoke`, headers, payload: { reason: '流程改了' } });
    expect(revoked.statusCode, revoked.body).toBe(200);
    expect(revoked.json().state).toBe('revoked');
    expect((await f.app.inject({ method: 'GET', url: `/api/routines/${routineId}`, headers })).statusCode).toBe(404);
    expect((await teachings()).map(item => item.state)).toEqual(['revoked']);

    // Approving a plan is written on the Run, not in the room: a decision made while recording still counts,
    // even on a task the room cited before, and nothing decided outside the recording leaks in.
    const pending = (await f.repository.list()).find(item => item.status === 'needs_approval' && item.goal.includes('查上线数据'))!;
    expect(pending).toBeTruthy();
    const second = (await f.app.inject({ method: 'POST', url: `/api/rooms/${f.roomId}/teachings`, headers, payload: { agentId: f.researcher.id } })).json().id as string;
    const plan = pending.plans.at(-1)!;
    const approved = await f.app.inject({ method: 'POST', url: `/api/runs/${pending.id}/approve`, headers, payload: { planHash: plan.hash, planVersion: plan.version } });
    expect(approved.statusCode, approved.body).toBe(200);
    const recordedAgain = (await f.app.inject({ method: 'POST', url: `/api/rooms/${f.roomId}/teachings/${second}/stop`, headers, payload: {} })).json();
    expect(recordedAgain.draft.steps).toEqual([
      expect.objectContaining({ text: '批准「查上线数据」的计划', source: 'run', decision: true }),
      expect.objectContaining({ text: '查上线数据：Work', source: 'run', decision: false }),
    ]);
    expect(recordedAgain.draft.steps.some((step: { text: string }) => step.text.includes('阻塞'))).toBe(false);
  });

  it('measures the channel from what it recorded: tasks, first reply, handoffs and evidence opened', async () => {
    const f = await team({
      reply: input => input.you.name === '阿研' ? { reply: '我查数据，说明给阿写。', tasks: [{ title: '查上线数据' }, { title: '写上线说明', for: '阿写', note: '你写得快' }] } : { reply: '好' },
      turn: () => ({ decision: 'accept', message: '好，我来。' }),
    });
    await f.say('@阿研 上线前查数据并写说明');
    for (const name of ['ui.artifact.view', 'ui.artifact.view', 'ui.evidence.open']) {
      expect((await f.app.inject({ method: 'POST', url: '/api/ui-events', headers, payload: { name, roomId: f.roomId } })).statusCode).toBe(204);
    }
    expect((await f.app.inject({ method: 'POST', url: '/api/ui-events', headers, payload: { name: 'ui.artifact.view', roomId: f.roomId, content: '正文不收' } })).statusCode).toBe(400);
    expect((await f.app.inject({ method: 'POST', url: '/api/ui-events', headers, payload: { name: 'ui.message.read', roomId: f.roomId } })).statusCode).toBe(400);
    expect((await f.app.inject({ method: 'POST', url: '/api/ui-events', headers, payload: { name: 'ui.studio.open', roomId: 'room_nobody' } })).statusCode).toBeGreaterThanOrEqual(400);
    expect((await f.app.inject({ method: 'GET', url: `/api/rooms/${f.roomId}/metrics?days=0`, headers })).statusCode).toBe(400);
    const response = await f.app.inject({ method: 'GET', url: `/api/rooms/${f.roomId}/metrics?days=7`, headers });
    expect(response.statusCode, response.body).toBe(200);
    const metrics = response.json() as { tasks: { created: number; done: number }; indicators: Array<{ key: string; value?: number; samples: number; ok?: boolean; detail?: Record<string, number> }> };
    const of = (key: string) => metrics.indicators.find(item => item.key === key)!;
    expect(metrics.tasks).toEqual({ created: 2, done: 0 });
    expect(of('completion_rate')).toMatchObject({ value: 0, samples: 2 });
    expect(of('first_reply')).toMatchObject({ samples: 1, ok: true });
    expect(of('handoff_depth')).toMatchObject({ value: 0, samples: 2, ok: true, detail: { max: 1 } });
    expect(of('handoff_failure_rate')).toMatchObject({ value: 0, samples: 1, ok: true });
    expect(of('evidence_open_rate')).toMatchObject({ value: 0.5, samples: 2, ok: true });
    expect(of('noise').detail?.botMessages).toBeGreaterThanOrEqual(1);
    expect(of('cycle_time').value).toBeUndefined();
    expect(of('blocked_time')).toMatchObject({ samples: 0 });
    expect(of('duplicate_effects')).toMatchObject({ value: 0, ok: true });
    expect(JSON.stringify(metrics)).not.toContain('上线前查数据');
  });

  it('replays one task from the request to the handoff, and sums the digest window from the Runs', async () => {
    const f = await team({
      reply: input => input.you.name === '阿研' ? { reply: '我查数据，说明给阿写。', tasks: [{ title: '查上线数据' }, { title: '写上线说明', for: '阿写', note: '你写得快' }] } : { reply: '好' },
      turn: () => ({ decision: 'accept', message: '好，我来。' }),
    }, { writerAutonomy: 'auto' });
    await f.say('@阿研 上线前查数据并写说明');
    const card = (await f.board()).cards.find(item => item.title === '写上线说明')!;
    const timeline = await f.app.inject({ method: 'GET', url: `/api/rooms/${f.roomId}/tasks/${card.conversationId}/${card.taskId}/timeline`, headers });
    expect(timeline.statusCode, timeline.body).toBe(200);
    const lines = (timeline.json().items as Array<{ who: string; text: string }>).map(item => `${item.who}：${item.text}`);
    expect(lines).toEqual([
      '自动记录：阿研提议：写上线说明',
      '自动记录：阿研提议这件事',
      '自动记录：交接中：交给 阿写',
      '自动记录：转交给 阿写',
      '自动记录：阿写接下了「写上线说明」（来自阿研）。',
      '阿写：开了一件 Run',
    ]);
    expect((await f.app.inject({ method: 'GET', url: `/api/rooms/${f.roomId}/tasks/${card.conversationId}/task_missing/timeline`, headers })).statusCode).toBe(404);
    const from = new Date(Date.now() - 3_600_000).toISOString(), to = new Date(Date.now() + 60_000).toISOString();
    const digest = await f.app.inject({ method: 'GET', url: `/api/rooms/${f.roomId}/digest?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`, headers });
    expect(digest.statusCode, digest.body).toBe(200);
    expect(digest.json()).toMatchObject({ from, to, accepted: 0, credits: 0 });
    expect(digest.json().tokens).toBeGreaterThanOrEqual(0);
    expect((await f.app.inject({ method: 'GET', url: `/api/rooms/${f.roomId}/digest?from=${encodeURIComponent(to)}&to=${encodeURIComponent(from)}`, headers })).statusCode).toBe(400);
    expect((await f.app.inject({ method: 'GET', url: `/api/rooms/${f.roomId}/digest?from=${encodeURIComponent('2026-01-01T00:00:00.000Z')}&to=${encodeURIComponent(to)}`, headers })).statusCode).toBe(400);
  });

  it('hands work over in the side thread: the card moves only when the other Bot accepts', async () => {
    const turns = [{ decision: 'discuss', message: '需要多久交？' }, { decision: 'discuss', message: '今天下班前。' }, { decision: 'accept', message: '好，我来。' }];
    let turn = 0;
    const f = await team({
      reply: input => input.you.name === '阿研' ? { reply: '这件阿写更合适。', proposeTask: { title: '写风险摘要', reason: '发布前要' }, handoff: { to: '阿写', note: '你写得快' } } : { reply: '好' },
      turn: () => turns[turn++],
    });
    await f.say('@阿研 发布前要一份风险摘要');
    const card = (await f.board()).cards.find(item => item.title === '写风险摘要')!;
    expect(card.decision).toMatchObject({ assigneeId: f.writer.id });
    expect(card.decision.offer).toBeUndefined();
    // The holder is the one who accepted; the task still lives on the proposer's thread.
    expect(card).toMatchObject({ ownerId: f.writer.id, movedFrom: f.researcher.id });
    const holdings = await f.app.inject({ method: 'GET', url: '/api/board-holdings', headers });
    expect(holdings.json().items).toEqual([expect.objectContaining({ taskId: card.taskId, holderId: f.writer.id, fromId: f.researcher.id, title: '写风险摘要' })]);
    const sides = (await f.domain.listRooms('alice', 'team-a')).filter(room => room.description === '侧线程');
    expect(sides).toHaveLength(1);
    const side = await f.app.inject({ method: 'GET', url: `/api/rooms/${sides[0]!.id}/session-events?limit=50`, headers });
    expect((side.json().items as Array<{ actorId: string; content: string }>).map(item => [item.actorId, item.content])).toEqual([
      [f.writer.id, '需要多久交？'], [f.researcher.id, '今天下班前。'], [f.writer.id, '好，我来。'],
    ]);
    const items = await f.events();
    expect(items.map(item => item.taskAction?.kind).filter(Boolean)).toEqual(['propose', 'offer', 'transfer']);
    expect(items.some(item => item.content === '阿写接下了「写风险摘要」（来自阿研）。')).toBe(true);
    // The side thread is not a chat on the group: it never triggers replies of its own.
    expect(f.calls.filter(call => call.system.includes('回复一条消息'))).toHaveLength(1);
  });

  it('leaves the card in place when the other Bot declines, and asks a person when they cannot agree', async () => {
    process.env.AEEIS_BOT_HANDOFF_MAX_TURNS = '4';
    let mode: 'decline' | 'stall' = 'decline';
    const f = await team({
      reply: () => ({ reply: '交给阿写。', proposeTask: { title: `整理数据 ${mode}` }, handoff: { to: '阿写' } }),
      turn: input => mode === 'decline' && input.you.side === 'receiver' ? { decision: 'decline', message: '我手上满了。' } : { decision: 'discuss', message: '再想想。' },
    });
    await f.say('@阿研 整理一下数据');
    let card = (await f.board()).cards.find(item => item.title === '整理数据 decline')!;
    expect(card.decision.assigneeId).toBeUndefined();
    expect(card.ownerId).toBe(f.researcher.id);
    expect(card.decision.offer).toBeUndefined();
    expect((await f.events()).some(item => item.content.includes('没有交给阿写。阿写没有接：我手上满了。'))).toBe(true);
    mode = 'stall';
    await f.say('@阿研 再整理一次');
    card = (await f.board()).cards.find(item => item.title === '整理数据 stall')!;
    expect(card.decision.offer).toBeUndefined();
    expect(card.decision.blockedNote).toContain('交接谈不拢：谈了 4 轮还没有结论');
    expect(card.decision.blockedNote).toContain('需要你决定');
    // The block waits for a person outside the channel too: the roster and inbox read it here.
    const holdings = (await f.app.inject({ method: 'GET', url: '/api/board-holdings', headers })).json().items as Array<Record<string, string>>;
    expect(holdings).toEqual([expect.objectContaining({ taskId: card.taskId, holderId: f.researcher.id, fromId: f.researcher.id, roomId: f.roomId, blocked: card.decision.blockedNote })]);
    expect(holdings[0]!.blockedAt).toEqual(expect.any(String));
  });

  it('starts the talk when a person hands a card over, and refuses a second offer meanwhile', async () => {
    const f = await team({ reply: () => ({ reply: '我先做。', proposeTask: { title: '查竞品' } }), turn: () => ({ decision: 'accept', message: '可以。' }) });
    await f.say('@阿研 查一下竞品');
    const card = (await f.board()).cards.find(item => item.title === '查竞品')!;
    const offer = await f.app.inject({ method: 'POST', url: `/api/rooms/${f.roomId}/task-actions`, headers, payload: { kind: 'offer', conversationId: card.conversationId, taskId: card.taskId, agentId: f.writer.id, goalId: f.goalId, contextManifestId: await f.manifestId(), idempotencyKey: 'offer-1' } });
    expect(offer.statusCode, offer.body).toBe(200);
    const again = await f.app.inject({ method: 'POST', url: `/api/rooms/${f.roomId}/task-actions`, headers, payload: { kind: 'offer', conversationId: card.conversationId, taskId: card.taskId, agentId: f.writer.id, goalId: f.goalId, contextManifestId: await f.manifestId(), idempotencyKey: 'offer-2' } });
    expect(again.statusCode).toBe(409);
    await f.app.aeeisBots!.drain();
    expect((await f.board()).cards.find(item => item.title === '查竞品')!.decision.assigneeId).toBe(f.writer.id);
  });

  it('hands a task that failed twice to the least busy member, once', async () => {
    const f = await team({
      reply: () => ({ reply: '我来。', proposeTask: { title: '跑数据' } }),
      turn: () => ({ decision: 'accept', message: '交给我。' }),
      plan: () => new Error('planner down'),
    }, { writerAutonomy: 'auto' });
    await f.say('@阿研 跑一下数据');
    const card = (await f.board()).cards.find(item => item.title === '跑数据')!;
    // Two Runs on the task, both failing.
    for (const key of ['fail-1', 'fail-2']) {
      const started = await f.app.inject({ method: 'POST', url: `/api/conversations/${card.conversationId}/messages`, headers: { ...headers, 'idempotency-key': key }, payload: { text: '跑', taskIds: [card.taskId], intent: 'execute', expectedRevision: 0 } });
      expect(started.statusCode, started.body).toBe(202);
      const runId = started.json().runId as string;
      for (let i = 0; i < 6; i++) { const status = await f.engine.advance(runId).catch(() => 'failed'); if (status === 'failed') break; }
      expect((await f.repository.get(runId)).status).toBe('failed');
    }
    expect((await f.board()).cards.find(item => item.title === '跑数据')!.status).toBe('failed');
    expect(await f.app.aeeisBots!.reassignFailures(await f.room(), scope)).toBe(1);
    await f.app.aeeisBots!.drain();
    const items = await f.events();
    expect(items.some(item => item.actorId === 'aeeis' && item.content.startsWith('「跑数据」连续失败两次') && item.content.endsWith('我请阿写接手。'))).toBe(true);
    expect((await f.board()).cards.find(item => item.title === '跑数据')!.decision.assigneeId).toBe(f.writer.id);
    expect(await f.app.aeeisBots!.reassignFailures(await f.room(), scope)).toBe(0);
  });
});
